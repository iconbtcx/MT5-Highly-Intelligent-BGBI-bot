// BGBI-Intelligent-OCO-V1 — 11 instrument profiles; compile and DEMO-test before use.
// Genesis intelligence + Super Hybrid; range/compression uses a matched, terminal-managed OCO stop pair.
// Legacy campaign/straddle routing is gated; OCO cancellation is not atomic broker-native OCO.
//+------------------------------------------------------------------+
//|                         BTC-BGBI-V1-PROFILE-V2.mq5      |
//|                                                                  |
//|  BGBI SUPER INTELLIGENCE V1 — GENESIS + COORDINATED ENGINES          |
//|                                                                  |
//|  Factor A (bridge-fed): REVERSAL, CUSUM, KILLSHOT, MONSTER,     |
//|                         SWING, RANGE, VWAP-CHOP                 |
//|  Factor B (fallback):   V106A — CHOP, TREND, MONSTER_FB, REV_FB |
//|                                                                  |
//|  Auto-switch by BridgeReady(). 30 fixes integrated.             |
//|                                                                  |
//|  Two Brothers Trading — 2026                                     |
//+------------------------------------------------------------------+
#property copyright "Two Brothers Trading"
#property version   "2.12"
#property description "BGBI-PERFECT-OCO-DEMO-V2.12: early M15/M5 pre-arm, flow-confirm semantics, native-flow health, range sibling cleanup"
#property strict

#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include <Trade\OrderInfo.mqh>

CTrade         trade;
CPositionInfo  posInfo;
COrderInfo     ordInfo;

//===================================================================
// SECTION 1 — ENUMS
//===================================================================
enum ENUM_ACCOUNT_MODE
// ------------------------------------------------------------------
// BTC GENESIS LEGACY CAMPAIGN v0.10
// Preserve V2 opportunity engines; add fair-gap continuation + M1 path.
// Exact RCM / Auto-SR / Perfect-Zones source adapters are intentionally
// NOT hard-coded yet; this build is the clean test baseline.
// ------------------------------------------------------------------
  {
   ACC_AUTO   = 0,
   ACC_CENT   = 1,
   ACC_DOLLAR = 2
  };

enum ENUM_V1_ASSET_CLASS
  {
   V1_ASSET_AUTO   = 0,
   V1_ASSET_CRYPTO = 1,
   V1_ASSET_FOREX  = 2,
   V1_ASSET_METAL  = 3,
   V1_ASSET_INDEX  = 4,
   V1_ASSET_OTHER  = 5
  };

enum ENUM_HEALTH
  {
   HEALTH_GREEN  = 0,
   HEALTH_YELLOW = 1,
   HEALTH_RED    = 2,
   HEALTH_BLACK  = 3
  };

enum ENUM_FLOW_MODE
  {
   FLOW_OFF      = 0,
   FLOW_VETO     = 1,
   FLOW_CONFIRM  = 2,
   FLOW_REQUIRED = 3
  };

enum ENUM_REGIME7
  {
   R7_STRONG_UP   = 0,
   R7_STRONG_DOWN = 1,
   R7_WEAK_UP     = 2,
   R7_WEAK_DOWN   = 3,
   R7_CHOP        = 4,
   R7_COMPRESSION = 5,
   R7_EXPANSION   = 6
  };

enum ENUM_MONSTER_PHASE
  {
   MP_IDLE         = 0,
   MP_IGNITION     = 1,
   MP_ACCELERATION = 2,
   MP_HARVEST      = 3
  };

enum ENUM_REV_STATE
  {
   REV_IDLE    = 0,
   REV_WATCH   = 1,
   REV_ALERT   = 2,
   REV_CONFIRM = 3
  };

enum ENUM_ENGINE
  {
   ENG_NONE     = 0,
   ENG_REVERSAL = 1,
   ENG_CUSUM    = 2,
   ENG_KILLSHOT = 3,
   ENG_MONSTER  = 4,
   ENG_TREND    = 5,
   ENG_RANGE    = 6,
   ENG_STRADDLE = 7
  };

enum ENUM_ORDER_MODE
  {
   OMODE_STOP    = 0,
   OMODE_LIMIT   = 1,
   OMODE_DYNAMIC = 2
  };

enum ENUM_BASKET_MODE
  {
   BASKET_R_BASED      = 0,
   BASKET_DOLLAR_BASED = 1
  };

enum ENUM_ACTIVE_FACTOR
  {
   FACTOR_A_BRIDGE   = 0,
   FACTOR_B_FALLBACK = 1
  };

enum ENUM_GENESIS_PHASE
  {
   GI_PHASE_CHOP         = 0,
   GI_PHASE_COMPRESSION  = 1,
   GI_PHASE_TRANSITION   = 2,
   GI_PHASE_IGNITION     = 3,
   GI_PHASE_ACCELERATION = 4,
   GI_PHASE_EXPANSION    = 5,
   GI_PHASE_CLIMAX       = 6,
   GI_PHASE_EXHAUSTION   = 7,
   GI_PHASE_TREND        = 8
  };

enum ENUM_GENESIS_ACTION
  {
   GI_WAIT         = 0,
   GI_ATTACK       = 1,
   GI_REVERSAL     = 2,
   GI_CONTINUATION = 3,
   GI_RANGE        = 4
  };

enum ENUM_V4_M15_PHASE
  {
   V4_M15_PHASE_UNKNOWN    = 0,
   V4_M15_PHASE_BEGINNING  = 1,
   V4_M15_PHASE_EXPANSION  = 2,
   V4_M15_PHASE_EXHAUSTION = 3,
   V4_M15_PHASE_COMPRESSION= 4,
   V4_M15_PHASE_NEUTRAL    = 5
  };
enum ENUM_GI_LUX_STATE
  {
   GI_LUX_NONE=0,
   GI_LUX_BULL_PRESSURE=1,
   GI_LUX_BEAR_PRESSURE=2,
   GI_LUX_BULL_EXHAUSTION=3,
   GI_LUX_BEAR_EXHAUSTION=4,
   GI_LUX_BULL_FLIP=5,
   GI_LUX_BEAR_FLIP=6
  };

enum ENUM_GI_SPECTRAL_STATE
  {
   GI_SPEC_UNKNOWN=0,
   GI_SPEC_DIRECTIONAL=1,
   GI_SPEC_CYCLIC=2,
   GI_SPEC_NOISY=3,
   GI_SPEC_TRANSITION=4
  };


//===================================================================
// SECTION 2 — STRUCTS
// Buyer/seller profile concept in this adaptation is based on the
// Zeiierman source identified above (CC BY-NC-SA 4.0). Preserve attribution;
// commercial redistribution/use requires separate licence review/permission.
//===================================================================
struct S_OrderBlock
  {
   double   high, low, avg;
   int      dir;
   datetime t;
   bool     mitigated;
  };

struct S_FVG
  {
   double   high, low, mid;
   int      dir;
   datetime t;
   bool     mitigated;
  };

struct S_Flow
  {
   bool     valid;
   bool     healthy;
   datetime local_update;
   double   price, flow_score;
   double   buy_pct, sell_pct;
   double   d5, d15;
   double   absorption_score, price_return_5, price_return_15;
   double   cvd, book, depth;
   double   trade_rate, buy_rate, sell_rate;
   double   spread_bps, persistence;
   double   velocity, acceleration;
   double   ofi;
   int      persistence_count;
   string   action;
  };

struct S_USDHybrid
  {
   bool     valid;
   datetime local_update;
   double   pair_score;
   double   usd_strength_score;
   double   usd_price_score;
   double   news_usd_score;
   double   news_confidence;
   double   risk_level;
   double   risk_multiplier;
   bool     price_feed_ok;
   bool     news_feed_ok;
   string   symbol;
  };

struct S_VP
  {
   bool     valid;
   datetime local_update;
   double   poc, vah, val;
   double   width_pct;
   double   min_p, max_p;
  };

struct S_Aux
  {
   bool     valid;
   datetime local_update;
   double   vroc, range_exp, atr_m1;
   double   vwap, vwap_slope;
   double   funding, oi, oi_delta_1m;
   double   bid_wall_price, bid_wall_size;
   double   ask_wall_price, ask_wall_size;
   double   vpin, vpin_pct, vpin_pressure;
   int      vpin_regime, oi_regime;
   double   naked_above, naked_below;
   int      naked_count;
   double   rolling_vwap, vwap_stdev, vwap_z;
   bool     vwap_exhausted, vroc_sustained;
   double   long_short_ratio;
   double   liquidation_buy, liquidation_sell, liquidation_imbalance;
  };

struct S_NativeVP
  {
   bool     valid;
   double   minP, maxP, binSize;
   double   poc, vah, val;
   double   totalVol, vaWidthPct;
   double   bins[40];
  };

struct S_Health
  {
   string   name;
   datetime lastUpdate;
   int      maxAgeSec;
   bool     healthy;
  };

struct S_SMC
  {
   int      m15_bias, m5_bias, m1_bias;
   int      m15_event, m5_event, m1_event;
   datetime m15_event_time, m5_event_time, m1_event_time;
   double   m15_high, m15_low;
   double   m5_high, m5_low;
   double   m1_high, m1_low;
   double   pd_location;
   bool     bull_zone_near, bear_zone_near;
   bool     bull_liq_sweep, bear_liq_sweep;
   bool     eq_high_active, eq_low_active;
   double   eq_high_level, eq_low_level;
  };

struct S_OU
  {
   bool     valid;
   double   mu, theta, sigma, z;
   double   half_life, reversion_prob;
  };

struct S_SignalPack
  {
   int      dir;
   double   score;
   bool     sweep, mss, displacement, fvg;
   bool     m5_agree, m15_agree;
   bool     flow_agree, flow_strong;
   double   flow_score;
  };

struct S_GenesisIntelligence
  {
   bool     valid; datetime updated; int direction;
   double   bullControl; double bearControl; double directionConfidence;
   double   volatilityScore; double ignitionScore; double exhaustionScore;
   double   reversalProbability; double flowPressure; double locationScore;
   double   mtfCoherence; double transitionProbability; double priceEfficiency;
   double   chaseRisk; double signalFreshness; double finalConfidence;
   int      luxBullMomentum; int luxBearMomentum;
   int      luxBullExhaustion; int luxBearExhaustion;
   bool     luxBullComplete; bool luxBearComplete;
   int      luxBullCompleteAge; int luxBearCompleteAge;
   bool     luxBullFlip; bool luxBearFlip; int luxState; double luxTransitionScore;
   double   spectralSlopeATR; double spectralLowFrac; double spectralHighFrac;
   double   spectralConcentration; double spectralTransition;
   int      spectralDirection; int spectralState; double stateTransitionScore;
   int      m5ThesisDir; double m5ThesisScore; double m5ThesisSpreadATR; bool m5ThesisCrossUp; bool m5ThesisCrossDown;
   bool     fastTransition; int transitionDirection; bool transitionArmed;
   // V3 fast proof layer: M1 EMA 5/13 lead + M1 structure + participation.
   int      m1LeadDir; double m1LeadScore; double m1LeadSpreadATR; double m1LeadSlopeATR;
   bool     m1LeadCrossUp; bool m1LeadCrossDown; bool m1LeadConfirmed;
   double   m1LeadFreshness; bool m1StructureProof; bool m1DisplacementProof;
   bool     marketProof; bool stopProof;
   int      v4M5PrimaryDir; int v4M1TacticalDir; double v4M5PrimaryScore; double v4M1TacticalScore;
   bool     v4DualAligned; bool v4TransitionArmed; bool v4PostFillDefense; int v4DefenseDir;
   int      phase; int action; string actionText; string phaseText; string reason;
  };

struct S_StraddlePlan
  {
   int      buys, sells;
   double   buyMult, sellMult;
   double   slPrice, tpPrice, gap;
   bool     isExtreme, isJerk;
  };

struct S_Anchor
  {
   string   comment;
   double   requestedEntry;
   double   requestedSL;
   double   requestedTP;
   datetime t;
  };

struct S_StraddlePlanB
  {
   int      buys, sells;
   double   buyMult, sellMult;
   double   slDist, tpDist, gap;
   bool     isExtreme, isJerk;
  };

struct S_BGBIProfileLevel
  {
   double   price;
   double   rawPrice;
   double   score;
   double   evidence;
   bool     support;
   bool     active;
   datetime born;
  };

//===================================================================
// SECTION 3 — INPUTS
//===================================================================

//---------------- GENERAL -----------------------------------------
input group "═══ GENERAL ═══"
input ENUM_ACCOUNT_MODE AccountMode        = ACC_AUTO;
input string   BotMode                     = "V1_DEMO_TEST";
input string   ExpectedSymbolProfile       = "AUTO"; // prevent loading an instrument preset on the wrong symbol
input int      MagicNumber                 = 7770150;
input int      SlippagePoints              = 200;

//---------------- BINANCE BRIDGE ----------------------------------
input group "═══ BINANCE BRIDGE (LIVE) ═══"
input bool     UseBinanceFlow              = true;
input string   BinanceBaseURL              = "http://127.0.0.1:8787";
input int      BinanceHttpTimeoutMs        = 900;
input int      BinancePollSeconds          = 1;
input int      BinanceMaxAgeSeconds        = 5;
input double   BinanceMinFlowScore         = 18.0;
input double   BinanceStrongFlowScore      = 45.0;
input double   BinanceMinPersistence       = 0.20;
input double   CVDAccelMin                 = 0.05;
input ENUM_FLOW_MODE FlowMode              = FLOW_CONFIRM;
input int      BridgeAuxPollSeconds        = 3;
input int      BridgeVPINPollSeconds       = 5;

//---------------- USD LIVE HYBRID BRIDGE ---------------------------
// Separate from Binance crypto-flow bridge. This bridge supplies soft FX/gold
// direction context plus a risk scalar that can ONLY reduce requested lots.
// The existing monetary-risk governor remains final authority.
input group "═══ USD LIVE HYBRID BRIDGE ═══"
input bool     UseUSDHybridBridge          = false;
input string   USDHybridBaseURL            = "http://127.0.0.1:8797";
input int      USDHybridPollSeconds        = 15;
input int      USDHybridMaxAgeSeconds      = 180;
input double   USDHybridDirectionWeight    = 0.08;

//---------------- BGBI PAIR INTELLIGENCE / NATIVE QUOTE PRESSURE ----------------
// For non-crypto symbols this is a broker-quote-pressure proxy, NOT true aggressor volume.
// For crypto it is only a fallback when the matching exchange bridge is unavailable.
input group "═══ BGBI PAIR INTELLIGENCE (DEMO VALIDATION) ═══"
input bool     UseNativePairFlow                         = true;
input bool     AllowNativePairFlowFallbackWhenBridgeDown = true;
input int      PairFlowLookbackTicks                     = 12;
input int      PairFlowMinSamples                        = 12;
input int      PairFlowMaxAgeMs                          = 5000;
input double   PairFlowMinConfirmScore                   = 12.0;
input double   PairFlowStrongConfirmScore                = 35.0;
input double   PairFlowMaxCounterPressure                = 45.0;
input int      PairFlowMinPersistenceSamples             = 1;
// Supporting evidence only for a strong one-sided directional STOP pre-arm; not a stand-alone signal.
input double   PairFlowAbsorptionMinScore                     = 65.0;
input double   PairFlowAbsorptionMaxCounterReturnPct          = 0.03;
input bool     UseCryptoFastReaction                     = true;
input int      CryptoFastSignalMaxAgeMs                  = 1800;
input double   CryptoFastMinScore                        = 74.0;

input bool     UseUSDHybridRiskScaling     = true;

//---------------- DATA HEALTH GATE ---------------------------------
input group "═══ DATA HEALTH GATE ═══"
input bool     UseHealthGate               = true;
input int      HealthMaxAge_Flow           = 5;
input int      HealthMaxAge_VP             = 10;
input int      HealthMaxAge_VROC           = 10;
input int      HealthMaxAge_VWAPZ          = 15;
input int      HealthMaxAge_VPIN           = 15;
input int      HealthMaxAge_Walls          = 10;
input int      HealthMaxAge_Funding        = 90;

//---------------- REGIME SUPERVISOR --------------------------------
input group "═══ REGIME — 7-STATE AR ═══"
input bool     UseRegimeSupervisor         = true;
input int      Regime_ER_Period            = 20;
input int      Regime_Hurst_Lookback       = 100;
input int      Regime_Autocorr_Window      = 50;
input double   Regime_ER_Weight            = 2.0;
input double   Regime_Hurst_Weight         = 1.0;
input double   Regime_AC_Weight            = 2.0;
input double   Regime_VROC_Weight          = 2.0;
input double   Regime_ATR_Weight           = 1.0;
input int      AdaptiveRegimeStickySec     = 90;
input double   StrongADXThreshold          = 30.0;
input double   WeakADXThreshold            = 20.0;
input double   StrongERThreshold           = 0.45;
input double   WeakERThreshold             = 0.25;
input double   ExpansionATRRatio           = 1.75;
input double   CompressionATRRatio         = 0.70;
input double   CompressionERThreshold      = 0.20;
input bool     UseHMMLikePosterior         = true;
input double   HMMOldStateWeight           = 0.75;

//---------------- CUSUM --------------------------------------------
input group "═══ CUSUM CHANGE-POINT ═══"
input bool     UseCUSUM                    = true;
input int      CUSUMWindow                 = 30;
input double   CUSUMDrift                  = 0.15;
input double   CUSUMThreshold              = 4.00;
input int      CUSUMPauseSeconds           = 120;
input bool     UseFlowCUSUMAugment         = true;
input int      CUSUMFreshSeconds           = 60;    // [A3] bypass regime gate if fresh

//---------------- RISK & SIZING ------------------------------------
input group "═══ RISK & SIZING ═══"
input bool     UsePercentRisk              = true;
input double   RiskPct_Swing               = 1.00;   // legacy fallback only
input double   RiskPct_Monster             = 1.00;   // legacy fallback only
input double   RiskPct_Range               = 0.75;   // legacy fallback only
input double   RiskPct_Reversal            = 1.00;   // legacy fallback only
input double   CapPerOrderDivisor          = 500.0;
input double   CapPerOrderMax              = 0.50;
input double   CapPerOrderMin              = 0.05;
input double   CapTotalLots_Divisor        = 250.0;
input double   CapTotalLots_Max            = 1.00;
input double   Range_Lot                   = 0.05;
input double   Swing_Lot                   = 0.07;
input double   Monster_Lot                 = 0.10;
input double   Reversal_Lot                = 0.05;

//---------------- SL / TP ------------------------------------------
input group "═══ SL / TP ═══"
input double   SL_ATR_Swing                = 1.80;
input double   SL_ATR_Monster              = 1.50;
input double   SL_ATR_Range                = 1.50;
input double   SL_ATR_Reversal             = 1.50;
input double   TP_RR_Swing                 = 3.50;
input double   TP_RR_Monster               = 6.00;
input double   TP_RR_Range                 = 1.50;
input double   TP_RR_Reversal              = 2.00;
input double   SL_SpreadMultiplier         = 2.0;
input double   SL_MinATR                   = 0.65;
input double   SL_MaxUSC                   = 1500.0;

//---------------- SPREAD SAFETY [S1,S2,S3,S4] ---------------------
input group "═══ SPREAD SAFETY (S1–S4) ═══"
input double   SpreadMultiplier_SL         = 3.0;   // SL must exceed 3× current spread
input double   SpreadMultiplier_TP         = 2.0;   // TP must exceed 2× current spread
input double   SpreadMultiplier_Trail      = 1.5;   // trail buffer ≥ 1.5× spread
input double   SpreadMultiplier_Basket     = 2.0;   // basket BE ≥ 2× spread × positions
input double   SpreadMinSLPoints           = 500.0; // absolute floor

//---------------- INDICATORS ---------------------------------------
input group "═══ INDICATORS ═══"
input int      ATR_Period                  = 14;
input int      EMA_Fast_M15                = 10;
input int      EMA_Slow_M15                = 20;
input int      EMA_Base_M15                = 50;
input int      RSI_Period_M15              = 14;
input int      ADX_Period_M15              = 14;
input int      EMA_Fast_M5                 = 8;
input int      EMA_Slow_M5                 = 21;
input int      EMA_Base_M5                 = 50;
input int      RSI_Period_M5               = 14;
input int      ADX_Period_M5               = 14;
input int      KAMA_Length                 = 21;
input int      KAMA_SlopeBars              = 5;
input double   KAMA_SlopeMin               = 0.30;

//---------------- VWAP / VP ----------------------------------------
input group "═══ VWAP / VOLUME PROFILE ═══"
input bool     UseVWAP                     = true;
input int      VWAP_Lookback               = 20;
input double   VWAP_Stdev_Entry            = 1.28;
input int      VP_LookbackBars             = 200;
input int      VP_Bins                     = 30;
input double   VP_ValueAreaPct             = 70.0;
input double   VP_CompressMaxPct           = 0.60;

//---------------- M1 PRICE ACTION ----------------------------------
input group "═══ M1 PRICE ACTION ═══"
input bool     UseM1PA                     = true;
input int      M1PA_SwingLookback          = 30;
input int      M1PA_SwingStrength          = 2;
input double   M1PA_MinSweepATR            = 0.08;
input double   M1PA_MinDisplATR            = 0.70;
input double   M1PA_MinBodyRatio           = 0.55;
input double   M1PA_BoostScore             = 65.0;
input double   M1PA_OverrideScore          = 88.0;
input double   M1PA_FVG_MinATR             = 0.05;

//---------------- M5 CONFIRMATION ----------------------------------
input group "═══ M5 CONFIRMATION ═══"
input bool     UseM5Confirm                = true;
input int      M5SwingLookback             = 20;

//---------------- M15 / H1 VETO ------------------------------------
input group "═══ M15 / H1 VETO ═══"
input bool     UseM15Veto                  = true;
input bool     UseH1Veto                   = false;
input int      M15VetoEventAgeMin          = 15;
input int      H1VetoEventAgeMin           = 30;
input double   M15VetoADXMin               = 25.0;
input double   M15VetoATRChaosMult         = 4.5;
input bool     UseSessionVeto              = false;
input int      VetoSkipHour1Start          = 0;
input int      VetoSkipHour1End            = 6;
input int      VetoSkipHour2Start          = 20;
input int      VetoSkipHour2End            = 21;

//---------------- SMC ---------------------------------------------
input group "═══ SMC STRUCTURE ═══"
input bool     UseSMCStructure             = true;
input int      SMC_M15Lookback             = 80;
input int      SMC_M5Lookback              = 80;
input int      SMC_M1Lookback              = 30;
input int      SMC_InternalPivotLeft       = 2;
input int      SMC_InternalPivotRight      = 2;
input int      SMC_SwingPivotLeft          = 4;
input int      SMC_SwingPivotRight         = 3;
input double   SMC_ZoneDistanceATR         = 1.25;
input double   SMC_MinMonsterScore         = 0.55;
input double   SMC_MinSwingScore           = 0.55;
input double   SMC_MinReversalScore        = 0.52;
input bool     UseEqualLiquidity           = true;
input int      EqualLookback               = 40;
input double   EqualToleranceATR           = 0.10;

//---------------- QUALITY GATE -------------------------------------
input group "═══ QUALITY GATE ═══"
input bool     UseQualityGate              = true;
input double   QualityBase                 = 0.20;
input double   QualityMinMonster           = 0.58;
input double   QualityMinSwing             = 0.55;
input double   QualityMinRange             = 0.50;
input double   QualityMinReversal          = 0.55;

//---------------- MTF CONFLUENCE -----------------------------------
input group "═══ MTF CONFLUENCE ═══"
input bool     UseMTFConfluence            = true;
input double   MTFM5Weight                 = 0.60;
input double   MTFM1Weight                 = 0.40;
input double   MTFMinMonsterConfidence     = 0.55;
input double   MTFMinSwingConfidence       = 0.52;
input double   MTFMaxRangeTrendConf        = 0.66;
input bool     UseBayesianConfluence       = true;
input bool     UseKalmanM1Filter           = true;
input double   KalmanProcessNoise          = 0.02;
input double   KalmanMeasurementNoise      = 0.12;
input bool     UseEntropyFilter            = true;
input double   EntropyHighThreshold        = 0.92;
input bool     UseMutualInformation        = true;
input int      FeatureInfoWindow           = 60;
input int      FractionalDiffWindow        = 30;

//---------------- OU RANGE -----------------------------------------
input group "═══ OU RANGE ENGINE ═══"
input bool     UseOURange                  = true;
input int      OURangeWindow               = 48;
input double   OUMinTheta                  = 0.015;
input double   OUMinAbsZ                   = 1.10;
input double   OUMaxHalfLifeBars           = 45.0;
input double   OURangeMinProbability       = 0.58;
input double   ORangeTargetFraction        = 1.00;
input bool     ORangeAbortOnExpansion      = true;
input int      Range_WindowBars            = 8;
input double   Range_MinWidthATR           = 2.0;
input double   Range_MaxWidthATR           = 20.0;
input int      Range_PendingLifetimeMin    = 8;
input double   Range_GapATR                = 1.5;

//---------------- KILLSHOT -----------------------------------------
input group "═══ KILLSHOT ═══"
input bool     UseKillShot                 = true;
input double   KillShotMinStrength         = 60.0;
input double   KillShotTP_RR               = 4.0;
input double   KillShotSL_Shrink           = 0.75;

//---------------- MONSTER ------------------------------------------
input group "═══ MONSTER LIFECYCLE ═══"
input int      Monster_MaxPyramid          = 2;
input int      Monster_PyramidCooldownS    = 90;
input double   Monster_PyramidMinR         = 1.50;
input double   Monster_HarvestMinR         = 3.50;
input int      Monster_HarvestClosePct     = 25;
input double   Monster_TrailGivebackR      = 1.00;
input int      Monster_HardMaxHoldMin      = 240;

//---------------- ORDER MODE ---------------------------------------
input group "═══ ORDER MODE ═══"
input ENUM_ORDER_MODE OrderMode            = OMODE_DYNAMIC;

//---------------- RETIRED LEGACY FAST ENGINE CONTROLS -----------------
// The retired standalone fast-engine switches are compile-time disabled and not user inputs.
// V1's active fast execution is owned by Genesis + the V1 Super Hybrid router below.
const bool UseLegacyFastBaseline = false;
const bool UseLegacyFastFairContinuation = false;
const int  LegacyFastFairPendingCount = 4;
const double LegacyFastFairGapBaseATR = 0.10;
const double LegacyFastFairGapStep2 = 1.80;
const double LegacyFastFairGapStep3 = 2.70;
const double LegacyFastFairGapStep4 = 3.80;
const double LegacyFastFairMinGapSpreadMult = 1.50;
const double LegacyFastFairMaxDistanceATR = 0.55;
const double LegacyFastStarterRiskFraction = 0.35;
const int LegacyFastPendingLifetimeMin = 15;
const bool LegacyFastCancelPendingsOnFlip = true;
const bool UseLegacyFastPathEngine = false;
const int LegacyFastPathLookbackBars = 10;
const double LegacyFastPathMinEfficiency = 0.58;
const double LegacyFastPathMinNetATR = 0.55;
const double LegacyFastPathMinDirectionalPct = 0.60;
const double LegacyFastPathMinContextScore = 0.45;
const double LegacyFastPathRiskFraction = 0.60;
const bool LegacyFastExpansionOverride = false;
const double LegacyFastExpansionATRRatio = 1.35;
const double LegacyFastExpansionPathEfficiency = 0.48;
const double LegacyFastExpansionVolumeRatio = 1.25;
const bool LegacyFastMonsterQualityGate = false;
const int LegacyFastMonsterMinEvidence = 2;
const double LegacyFastMonsterVolumeRatioMin = 1.15;
const double LegacyFastMonsterStrongFlowMin = 35.0;
const double LegacyFastMonsterPathEfficiency = 0.45;

//---------------- RETIRED LEGACY CAMPAIGN -----------------------
// The retired campaign controller is compile-time disabled and hidden from MT5 Inputs.
// These compile-time constants remain only so old helper code can be safely compiled;
// no entry/exit route is permitted to activate this campaign in V1.
const bool V1LegacyCampaignEnabled = false;
const bool LegacyCampaignBlockLegacyEngines = false;
const int LegacyCampaignInitialBuyOrders = 0;
const int LegacyCampaignInitialSellOrders = 0;
const double LegacyCampaignBaseLot = 0.05;
const double LegacyCampaignReinforceLot = 0.05;
const double LegacyCampaignMinGapPrice = 75.0;
const double LegacyCampaignMaxGapPrice = 100.0;
const double LegacyCampaignGapATRFactor = 0.25;
const int LegacyCampaignMaxPendingOrders = 12;
const int LegacyCampaignMaxOpenPositions = 12;
const double LegacyCampaignMaxTotalLots = 1.00;
const double LegacyCampaignSLPrice = 200.0;
const double LegacyCampaignTPPrice = 500.0;
const int LegacyCampaignPendingLifetimeMin = 20;
const int LegacyCampaignRearmCooldownSec = 30;
const int LegacyCampaignReinforceCooldownSec = 8;
const int LegacyCampaignMaxReinforcements = 20;
const double LegacyCampaignMinArmScore = 50.0;
const double LegacyCampaignMinReinforceScore = 55.0;
const double LegacyCampaignCounterOverrideScore = 78.0;
const double LegacyCampaignLiveImpulseATR = 0.40;
const double LegacyCampaignLiveBodyRatio = 0.55;
const double LegacyCampaignLiveCloseLocation = 0.70;
const bool LegacyCampaignBasketUsePercent = false;
const double LegacyCampaignBasketBEUSD = 50.0;
const double LegacyCampaignBasketTrailStartUSD = 80.0;
const double LegacyCampaignBasketTrailStepUSD = 20.0;
const double LegacyCampaignBasketLossUSD = -100.0;
const double LegacyCampaignBasketBE_Pct = 5.0;
const double LegacyCampaignBasketTrailStart_Pct = 8.0;
const double LegacyCampaignBasketTrailStep_Pct = 2.0;
const double LegacyCampaignBasketLoss_Pct = -10.0;
const double LegacyCampaignBasketSpreadFloorMult = 0.0;
const double LegacyCampaignBasketStepSpreadMult = 0.0;
const double LegacyCampaignBEOffsetPrice = 10.0;
const double LegacyCampaignPositionTrailPrice = 60.0;
const double LegacyCampaignPositionTrailSpreadMult = 1.50;

//---------------- GENESIS BABA — INTELLIGENCE ENGINE ----------------
// ONE decision brain: regime + directional control + volatility phase +
// exhaustion/reversal + location + live flow + MTF coherence. Legacy engines
// remain compiled for fallback/reference but do not compete when this master is ON.
input group "═══ GENESIS BABA — INTELLIGENCE ═══"
input bool     UseGenesisIntelligence         = true;
input bool     GenesisIntelBlockLegacy       = true;
input bool     GenesisIntelUseDynamicRouter   = true;
input bool     GenesisIntelAllowRangeTrade    = true;
input int      GenesisIntelUpdateSeconds      = 1;
input int      GenesisIntelEntryCooldownSec   = 45;
input int      GenesisIntelPendingLifetimeMin   = 5;
input int      GenesisIntelMaxEntriesCampaign = 5;
input int      GenesisIntelMaxPositions       = 4;
input double   GenesisIntelBaseLot            = 0.05;
input double   GenesisIntelTrendLot           = 0.07;
input double   GenesisIntelMonsterLot         = 0.10;
input double   GenesisIntelMaxLot             = 0.15;
input double   GenesisIntelAttackMinConf      = 64.0;
input double   GenesisIntelContinuationConf    = 72.0;
input double   GenesisIntelReversalMinConf    = 70.0;
input double   GenesisIntelRangeMinConf       = 66.0;
input double   GenesisIntelMinDirection       = 66.0;
input double   GenesisIntelMinFlowBridge      = 35.0;
input double   GenesisIntelStrongFlowBridge   = 55.0;
input double   GenesisIntelIgnitionMin        = 60.0;
input double   GenesisIntelMaxExhaustionChase  = 68.0;
input double   GenesisIntelReversalTrigger    = 72.0;
input double   GenesisIntelReversalExhaustion = 68.0;
input double   GenesisIntelMonsterConf        = 84.0;
input double   GenesisIntelShockATR           = 1.45;
input double   GenesisIntelShockVolume        = 1.25;
input double   GenesisIntelTrendATR           = 1.10;
input double   GenesisIntelCompressionATR     = 0.78;
input double   GenesisIntelTransitionGap      = 18.0;
input double   GenesisIntelLimitPullbackATR   = 0.30;
input double   GenesisIntelStopBufferATR      = 0.08;
input double   GenesisIntelSL_ATR_Normal       = 1.25;
input double   GenesisIntelSL_ATR_Trend        = 1.55;
input double   GenesisIntelSL_ATR_Monster      = 1.90;
input double   GenesisIntelSL_ATR_Reversal     = 1.45;
input double   GenesisIntelTP_RR_Normal        = 2.20;
input double   GenesisIntelTP_RR_Trend         = 3.50;
input double   GenesisIntelTP_RR_Monster       = 5.50;
input double   GenesisIntelTP_RR_Reversal      = 3.00;
input bool     GenesisIntelUseFlowOnBridge     = true;
input bool     GenesisIntelFlowCanConfirmOnly   = false;
input bool     GenesisIntelRequireMTFOnAttack   = true;
input bool     GenesisIntelAllowCounterTrendReversal = true;

input group "═══ GENESIS V2 CORE — STATE TRANSITION ═══"
input bool     GenesisIntelUseLuxPhase           = true;
input ENUM_TIMEFRAMES GenesisIntelLuxTF          = PERIOD_M1;
input int      GenesisIntelLuxLookback           = 60;
input double   GenesisIntelLuxExhaustionWarn     = 8.0;
input double   GenesisIntelLuxExhaustionHigh     = 11.0;
input double   GenesisIntelLuxFlipBoost          = 18.0;

input bool     GenesisIntelUseSpectral            = true;
input ENUM_TIMEFRAMES GenesisIntelSpectralTF      = PERIOD_M5;
input int      GenesisIntelSpectralWindow         = 64;
input double   GenesisIntelSpectralSlopeMinATR    = 0.04;
input double   GenesisIntelSpectralLowFracMin     = 0.42;
input double   GenesisIntelSpectralHighFracMax    = 0.30;
input double   GenesisIntelSpectralFlipGap        = 0.08;
input double   GenesisIntelSpectralNoiseHigh      = 0.48;

input group "═══ GENESIS V2 — FAST THESIS + TRANSITION EXECUTION ═══"
input bool     GenesisIntelUseM5EMAThesis          = true;
input int      GenesisIntelM5EMAFastLen             = 5;
input int      GenesisIntelM5EMASlowLen             = 13;
input bool     GenesisIntelM5EMAConfirmCandle       = true;
input double   GenesisIntelM5EMASpreadBoostATR      = 0.08;
input double   GenesisIntelM5EMAFlipBoost           = 18.0;
input double   GenesisIntelFastTransitionMin        = 72.0;
input double   GenesisIntelFastTransitionFlow       = 55.0;
input double   GenesisIntelFastTransitionFlowGap    = 8.0;
input double   GenesisIntelFastTransitionExhaust    = 45.0;
input double   GenesisIntelFastTransitionReversal   = 60.0;
input double   GenesisIntelTransitionStopBufferATR  = 0.10;
input double   GenesisIntelTransitionStopMaxDistATR = 0.75;
input int      GenesisIntelTransitionPendingMin     = 3;
input double   GenesisIntelMarketMaxExtensionATR    = 0.45;
input double   GenesisIntelIgnitionMarketMinConf    = 78.0;
input double   GenesisIntelStopMaxDistanceATR       = 0.80;
input bool     GenesisIntelUseTransitionStops       = true;
input bool     GenesisIntelUseM5ThesisAsHardGate    = false;
input double   GenesisIntelTransitionStopMinConf    = 58.0;
input bool     GenesisIntelOneMarketShotCampaign    = true;

input int      GenesisIntelNormalMaxPositions      = 2;
input int      GenesisIntelExpansionMaxPositions   = 3;
input int      GenesisIntelMonsterMaxPositions     = 4;
input int      GenesisIntelReversalMaxPositions    = 2;
input int      GenesisIntelNormalMaxEntries        = 3;
input int      GenesisIntelExpansionMaxEntries     = 4;
input int      GenesisIntelMonsterMaxEntries       = 5;
input int      GenesisIntelReversalMaxEntries      = 3;

input bool     GenesisIntelUseDirectionFlipGuard   = true;
input double   GenesisIntelFlipGuardTransition     = 72.0;
input double   GenesisIntelFlipGuardDirectionGap   = 16.0;
input double   GenesisIntelFlipGuardReversal       = 68.0;

//---------------- GENESIS V3 — PROOF-BASED DUAL-SIDE EXECUTION ------
// M1 is the fast directional lead; M5 remains the tactical thesis.
// Market execution requires proof. Otherwise V3 prepares a short-lived stop.
input bool     GenesisV3UseM1EMALead                 = true;
input int      GenesisV3M1EMAFastLen                = 5;
input int      GenesisV3M1EMASlowLen                = 13;
input bool     GenesisV3M1EMAConfirmCandle          = true;
input double   GenesisV3M1LeadMinForStop             = 62.0;
input double   GenesisV3M1LeadMinForMarket           = 74.0;
input double   GenesisV3M1LeadStrong                 = 82.0;
input double   GenesisV3M1LeadSpreadATR              = 0.04;
input double   GenesisV3M1LeadSlopeATR               = 0.012;
input double   GenesisV3MarketMinFlow                = 50.0;
input double   GenesisV3MarketFlowGap                = 6.0;
input double   GenesisV3MarketMaxChase               = 45.0;
input double   GenesisV3MarketMaxExhaustion          = 68.0;
input double   GenesisV3ProofStopMinIgnition         = 48.0;
input double   GenesisV3ProofStopMinTransition       = 55.0;
input double   GenesisV3ProofStopBufferATR            = 0.10;
input double   GenesisV3ProofStopMaxDistanceATR       = 0.70;
input int      GenesisV3ProofPendingLifetimeMin       = 2;
input bool     GenesisV3UseOppositeTransitionStops   = true;
input bool     GenesisV3LockOldDirectionOnTransition = true;
input bool     GenesisV3OneProofStopPerCampaign       = true;

//---------------- GENESIS V4 — DUAL DIRECTION + DEFENSIVE EXECUTION --
// V4 keeps Genesis as the core brain. M5 owns tactical thesis, M1 price
// action provides timing, and pending stops are the default execution.
input bool     GenesisV4Enable                         = true;
input bool     GenesisV4M5OwnsDirectionalThesis        = true;
input double   GenesisV4M5ThesisMinScore               = 65.0;
input double   GenesisV4M1TacticalMinScore              = 65.0;
input bool     GenesisV4RequireM5ForContinuation        = true;
input bool     GenesisV4StopFirstExecution              = false; // V2: normal dynamic routing; market still requires full proof
input double   GenesisV4MarketShockMinVolatility        = 85.0;
input double   GenesisV4MarketShockMinIgnition          = 82.0;
input double   GenesisV4MarketShockMinFlow              = 65.0;
input double   GenesisV4MarketMaxExtensionATR           = 0.30;
input double   GenesisV4StopBufferATR                   = 0.10;
input double   GenesisV4StopMaxDistanceATR              = 0.60;
input double   GenesisV4MaxCycleExtensionATR            = 1.20;
input int      GenesisV4SignalFreshnessSec              = 45;
input int      GenesisV4PendingLifetimeSec              = 75;
input bool     GenesisV4CancelOnM5Conflict              = true;
input bool     GenesisV4PostFillDefenseEnable            = true;
input int      GenesisV4PostFillWatchSec                = 90;
input double   GenesisV4PostFillM1OppScore              = 70.0;
input double   GenesisV4PostFillFlowScore               = 58.0;
input double   GenesisV4PostFillFlowGap                 = 12.0;
input double   GenesisV4PostFillReversalScore           = 78.0;
input double   GenesisV4PostFillM5ReversalScore         = 70.0;
input bool     GenesisV4CancelSameSidePendings          = true;
input bool     GenesisV4ArmOppositeAfterDefense         = true;
input double   GenesisV4OppositeStopBufferATR           = 0.10;
input double   GenesisV4OppositeStopMaxDistanceATR      = 0.55;
input int      GenesisV4MaxContinuationStops            = 1;
input bool     GenesisV4UseAlphaPyramidDiscipline       = true;
input double   GenesisV4ReinforceMinCampaignR           = 0.25;
input double   GenesisV4ReinforceMinConfidence          = 82.0;
input int      GenesisV4ReinforceCooldownSec            = 90;
input bool     GenesisV4LogDecisions                    = true;

// M15 remains context, never an unconditional veto. When M1 price action and
// the Genesis M5 thesis agree against M15 bias, arm a bounded two-sided stop

//---------------- BGBI V1 — universal route -----------------------------
// M15 is context; closed M5 defines meaningful boundaries; M1 times entries.
// CHOP uses independent edge LIMITs; directional transitions can arm one stop.
input int      V1RangeLookbackM5                    = 8;
input double   V1RangeMinATR                        = 0.70;
input double   V1RangeMaxATR                        = 3.20;
input double   V1RangeStopBufferATR                 = 0.10;
input double   V1RangeMaxEntryDistanceATR           = 2.80;
input double   V1RangeSL_ATR                         = 1.10;
input double   V1RangeTP_RR                         = 1.70;
input bool     V1UseM5DirectionalPrearm             = true;
input double   V1TransitionRangeExitThreshold         = 45.0;
input double   V1DirectionalM5MinScore              = 72.0;
input double   V1DirectionalM1MinScore              = 60.0;
input double   V1DirectionalStrongM5Score           = 84.0;
input double   V1DirectionalStopBufferATR            = 0.10;
input double   V1DirectionalMaxDistanceATR           = 1.20;
input double   V1DirectionalLotFraction              = 0.50;
input int      V1RouterLogCooldownSec                = 30;
input group "═══ V1 FAST EXPANSION / IMPULSE PRE-ARM ═══"

//---------------- BGBI SUPER HYBRID — Hyper-style MTF entry confirmation --------
// M5 features are read from closed candles (shift 1+). M1 remains the live trigger.
// This is a quality gate for directional entries only; structural range straddles
// remain pre-armed, and very strong, explicitly proven shocks may bypass this gate.
input group "═══ BGBI SUPER HYBRID — MTF ENTRY GATE ═══"
input bool     V1UseMTFCandleGate                    = true;
input double   V1M5SetupMinScore                     = 66.0;
input double   V1M5MinRangeATR                       = 0.45;
input double   V1M5MinBodyRatio                      = 0.38;
input double   V1M5VolumeMin                         = 0.90;
input int      V1M5VolumeLookback                    = 20;
input double   V1M1MinTriggerScore                   = 55.0;
input bool     V1RequireDirectionalM5Candle          = true;
input bool     V1AllowStrongShockBypass               = true;
input double   V1ShockBypassMinIgnition               = 88.0;
input double   V1ShockBypassMinVolatility             = 80.0;

//---------------- BUYER/SELLER PROFILE INTELLIGENCE -----------------
// Concept adapted for private evaluation from Zeiierman's
// "Buyers & Sellers Profile + Dynamic S/R" (CC BY-NC-SA 4.0).
// This EA-side implementation uses broker candle/tick volume and estimates
// aggressor-side pressure from candle close location; it is NOT true bid/ask flow.
input group "═══ BUYER/SELLER PROFILE INTELLIGENCE ═══"
input bool     UseBGBIProfileIntel          = true;
input ENUM_TIMEFRAMES BGBIProfileTF         = PERIOD_M1;
input int      BGBIProfileLookback          = 600;
input int      BGBIProfileRows              = 48;
input int      BGBIProfileSwingLen          = 5;
input double   BGBIProfileSearchATR         = 1.20;
input double   BGBIProfileNodeMin            = 0.08;
input double   BGBIProfileEvidenceMin        = 0.22;
input double   BGBIProfileScoreMin           = 30.0;
input double   BGBIProfilePullMax            = 0.85;
input double   BGBIProfileMergeATR           = 0.16;
input double   BGBIProfileBreakATR           = 0.10;
input double   BGBIProfileInfluence          = 0.30; // soft influence on location score; never an entry veto

//---------------- GENESIS BABA — CANDLE-AWARE CAMPAIGN -------------
// The old fixed-dollar basket trail is deliberately replaced by an R-based
// campaign governor. A violent M1 candle can travel sharply against the EA
// and then continue in the original direction; Genesis therefore freezes the
// campaign MFE floor while the shock candle is still forming.
input bool     GenesisUseCandleAwareMFE       = true;
input double   GenesisShockRangeATR           = 1.25;
input double   GenesisShockBodyRatio           = 0.55;
input double   GenesisShockVolumeRatio         = 1.25;
input double   GenesisShockFlowScore           = 35.0;
input double   GenesisShockCVDAccel            = 0.05;
input int      GenesisShockSettleSeconds      = 15;
input double   GenesisMFEArmR                 = 1.25;
input double   GenesisNormalLockPct           = 45.0;
input double   GenesisMinimumLockR             = 0.25;
input double   GenesisShockLockPct             = 25.0;
input double   GenesisShockHarvestArmR         = 2.50;
input int      GenesisShockHarvestPct          = 20;
input double   GenesisShockHarvestPullbackR    = 0.60;
input double   GenesisShockFullExitGivebackR   = 1.50;
input double   GenesisShockFullExitMinR        = 0.75;
input bool     GenesisUseM5TrueReversal       = true;
input int      GenesisM5ReversalConfirmations = 2;
input double   GenesisM5ReversalScore         = 70.0;
input bool     GenesisAllowStrongShockEntry   = true;
input double   GenesisShockEntryMaxATR        = 2.50;
input double   GenesisShockEntryMinFlow       = 35.0;
input double   GenesisShockEntryMinVolume     = 1.25;
input bool     GenesisNoFixedDollarBasket     = true;

// Candle intent: strongest source-supported patterns only. These are
// evidence, never standalone vetoes. M1 structure/sweep remains primary.
const bool LegacyCampaignUseCandleIntent = false;
const int LegacyCampaignCandleTrendBars = 5;
const double LegacyCampaignMinPatternScore = 10.0;

//---------------- HHLL / SUPERTREND --------------------------------
input group "═══ HHLL / SUPERTREND ═══"
input bool     UseHHLL                     = false;
input ENUM_TIMEFRAMES HHLL_TF              = PERIOD_H1;
input int      HHLL_LB                     = 5;
input int      HHLL_RB                     = 5;
input int      HHLL_MaxAge                 = 200;
input bool     UseSupertrend               = false;
input ENUM_TIMEFRAMES ST_TF                = PERIOD_M15;
input int      ST_ATR                      = 10;
input double   ST_Mult                     = 3.0;

//---------------- MSS M15 ------------------------------------------
input group "═══ MSS M15 ═══"
input bool     UseMSS                      = true;
input int      MSS_LeftBars                = 2;
input int      MSS_RightBars               = 2;
input int      MSS_ConfirmMin              = 15;

//---------------- OB / FVG -----------------------------------------
input group "═══ ORDER BLOCKS / FVG ═══"
input bool     UseOB                       = true;
input int      OB_Periods                  = 5;
input int      OB_MaxStored                = 8;
input bool     UseFVG                      = true;
input double   FVG_MinSizePts              = 500.0;
input int      FVG_MaxStored               = 8;

//---------------- LIQUIDITY SESSIONS -------------------------------
input group "═══ LIQUIDITY SESSIONS ═══"
input bool     UseLiquiditySessions        = false;
input int      LS_SessionStartUTC          = 6;
input int      LS_SessionEndUTC            = 22;
input bool     LS_UseAsian                 = true;
input bool     LS_UseLondon                = true;
input bool     LS_UsePDHPDL                = true;
input bool     LS_UseSwings                = true;
input double   LS_MinWickATR               = 0.5;

//---------------- SPREAD -------------------------------------------
input group "═══ SPREAD ═══"
input double   HardMaxSpreadPoints         = 2000.0;
input double   SoftSpreadPoints            = 800.0;
input bool     RejectIfSpreadExpands       = true;

//---------------- SAFETY -------------------------------------------
input group "═══ SAFETY ═══"
input bool     UseDailyHalt                = true;
input double   DailyLossLimitPct           = 4.0;
input bool     UseGlobalHalt               = false;
input double   GlobalLossLimitPct          = 10.0;
input bool     UsePeakGiveback             = true;
input double   PeakGivebackPct             = 20.0;
input int      PeakGivebackPauseHrs        = 1;
input bool     UseLossStreak               = true;
input int      MaxConsecutiveLosses        = 4;
input int      LossStreakPauseMin          = 60;
input bool     UseWickPause                = true;
input double   ViolentCandleMult           = 2.0;
input int      PostWickPauseSec            = 90;
input bool     UseWickAbort                = false;   // V1 exit controller owns manual exits
input double   WickAbortPct                = 70.0;
input bool     AvoidRollover               = false;

//---------------- ANTI-CHURN ---------------------------------------
input group "═══ ANTI-CHURN ═══"
input int      Cooldown_Loss               = 180;
input int      Cooldown_Win                = 20;
input int      Cooldown_EngineAfterLoss    = 1800;
input int      MinSecondsBetweenPlaces     = 10;
input int      MaxPendingTotal             = 12;
input int      StaleOrderMinutes           = 60;

//---------------- FLOATING BUDGETS ---------------------------------
input group "═══ FLOATING BUDGETS ═══"
input bool     UseFloatingBudget           = false;
input double   SwingBudgetPct              = -5.00;
input double   MonsterBudgetPct            = -8.00;
input double   RangeBudgetPct              = -1.75;
input double   ReversalBudgetPct           = -2.50;

//---------------- BASKET R-TARGETS ---------------------------------
input group "═══ BASKET R-TARGETS ═══"
input bool     UseBasketRiskTargets        = true;
input double   SwingBasketBE_R             = 1.50;
input double   SwingBasketTrail_R          = 2.25;
input double   SwingBasketStep_R           = 0.75;
input double   MonsterBasketBE_R           = 1.80;
input double   MonsterBasketTrail_R        = 2.75;
input double   MonsterBasketStep_R         = 1.25;
input double   RangeBasketBE_R             = 0.90;
input double   RangeBasketTrail_R          = 1.30;
input double   RangeBasketStep_R           = 0.40;
input double   ReversalBasketBE_R          = 1.25;
input double   ReversalBasketTrail_R       = 1.75;
input double   ReversalBasketStep_R        = 0.50;

//---------------- BASKET %-TARGETS ---------------------------------
input group "═══ BASKET %-TARGETS ═══"
input double   BasketBE_Pct                = 5.00;
input double   BasketTrailStart_Pct        = 8.00;
input double   BasketTrailStep_Pct         = 2.00;
input double   BasketSL_Pct                = -10.00;
input bool     UseBasketManagement         = false;  // one exit controller

//---------------- TIER 1 — REGIME GATE -----------------------------
input group "═══ TIER 1 — REGIME DIRECTION GATE ═══"
input bool     UseRegimeDirectionGate      = true;
input double   RegimeGateOppositeSizeMult  = 0.50;
input bool     RegimeGateRequiresFastTrend = true;

//---------------- TIER 1 — FASTTRENDSCORE --------------------------
input group "═══ TIER 1 — FASTTRENDSCORE ═══"
input bool     UseFastTrendScore           = true;
input int      FastTrend_PrimeThreshold    = 60;
input int      FastTrend_ChopThreshold     = 40;
input double   FastTrend_FlowWeight        = 35.0;
input double   FastTrend_M5Weight          = 35.0;
input double   FastTrend_VPWeight          = 20.0;
input double   FastTrend_M15Weight         = 10.0;
input double   FastTrend_DonchianSlopeMin  = 0.20;
input double   FastTrend_DonchianWidthATR  = 3.0;

//---------------- TIER 1 — REVERSAL HARDENING ----------------------
input group "═══ TIER 1 — REVERSAL HARDENING ═══"
input bool     RevRequireSessionSweep      = true;
input bool     RevRequireCVDFlipHardGate   = true;
input bool     RevBlockOnFastTrendOppose   = true;
input int      Rev_WatchMaxMinutes         = 15;

//---------------- TIER 2 — STRADDLE ---------------------------------
input group "═══ TIER 2 — BIASED STRADDLE ═══"
input bool     UseBiasedStraddle           = false; // Legacy route disabled; Genesis is the only entry owner
input int      StraddleStrongOrders        = 3;
input int      StraddleWeakOrders          = 1;
input int      StraddleJerkOrders          = 5; // broker message-cap conscious reduction from MT4 7
input int      StraddleExtremeOrders       = 7; // V2: Monster uses 7 one-sided orders
input double   StraddleStrongLotMult       = 1.50;
input double   StraddleWeakLotMult         = 0.50;
input double   StraddleJerkLotMult         = 2.50;
input double   StraddleExtremeLotMult      = 4.00; // V2: 5 Jerk orders, 7 Monster orders

input double   StraddleGapATR              = 1.00; // legacy fallback only
input int      StraddleMessageCapWarn      = 2500;
input double   StraddleNormalGapPrice       = 15.0;
input double   StraddleChopGapPrice         = 30.0;
input double   StraddleImpulseGapPrice      = 15.0;

//---------------- TIER 2 — WIN-GATED GRID ---------------------------
input group "═══ TIER 2 — WIN-GATED GRID ═══"
input bool     UseWinGatedGrid             = false; // V1 uses one central router; no independent grid engine
input int      GridMaxLevelsV2             = 5;
input double   GridLotMultV2               = 1.25;
input int      GridMinConsecutiveWins      = 1;
input int      GridCooldownSecV2           = 60;
input bool     GridRequireTrendRegime      = true;
input double   GridGapATRMult              = 1.0;

//---------------- TIER 2 — CONTINUOUS COMPOUNDING -------------------
input group "═══ TIER 2 — CONTINUOUS COMPOUNDING ═══"
input bool     UseContinuousCompoundingV2  = false; // fixed requested lot; centralized risk manager sizes final order
input double   CompoundingExponentV2       = 0.50;
input double   CompoundingMaxMult          = 8.0;

//---------------- TIER 2 — TIGHT BE + TRAIL -------------------------
input group "═══ TIER 2 — TIGHT BE + TRAIL ═══"
input bool     UseTightBEV2                = false;  // one exit controller
input double   TightBE_ATR_Mult_V2         = 0.10;
input double   TightBE_MinPoints_V2        = 2.0;
input double   TightBE_MaxPoints_V2        = 80.0;
input bool     UseTightTrailV2             = false;  // one exit controller
input double   TightTrail_StartR_V2        = 0.20;
input double   TightTrail_StepR_V2         = 0.15;
input double   TightTrail_MinImprovePts_V2 = 2.0;
input double   TrailMinImprovePts          = 2.0;

//---------------- TIER 2 — SESSION SCORE ----------------------------
input group "═══ TIER 2 — SESSION SCORE ═══"
input bool     UseSessionScoreV2           = true;
input int      SessionPrimeStartUTC        = 13;
input int      SessionPrimeEndUTC          = 16;
input double   SessionPrimeBoost           = 1.30;
input double   SessionOffWindowCut         = 0.75;

//---------------- TIER 2 — BASKET DOLLAR MODE -----------------------
input group "═══ TIER 2 — BASKET DOLLAR MODE ═══"
input bool     UseBasketDollarMode         = false;
input double   BasketBE_USD_PctOfStart     = 5.00;
input double   BasketTrailStart_USD_Pct    = 8.00;
input double   BasketTrailStep_USD_Pct     = 2.00;
input double   BasketSL_USD_Pct            = -10.00;

//---------------- TIER 3 — EXECUTION ---------------------------------
input group "═══ TIER 3 — EXECUTION ═══"
input bool     UseOrderCheckBeforeSendV2   = true;
input bool     UseSlippageReAnchorV2       = true;
input double   SlippageReAnchorTriggerPts  = 3.0;
input bool     UseTransientRetryV2         = true;
input int      TransientMaxRetries         = 3;
input int      TransientRetryDelayMs       = 400;

//---------------- TIER 3 — VWAP CHOP --------------------------------
input group "═══ TIER 3 — VWAP CHOP MODE ═══"
input bool     UseVWAPChopStraddle         = false;
input int      VWAPChopBuyOrders           = 2;
input int      VWAPChopSellOrders          = 2;
input double   VWAPChopLotMult             = 0.50;

//---------------- TIER 3 — CLEANUP ----------------------------------
input group "═══ TIER 3 — CLEANUP ═══"
input int      StaleOrderMinutesV2         = 15;
input bool     UseHourlyStraddleReset      = true;

//---------------- TIER 3 — KILLSHOT BOOST ---------------------------
input group "═══ TIER 3 — KILLSHOT BOOST ═══"
input bool     UseKillShotPrimeBoost       = true;
input double   KillShotPrimeSizeMult       = 1.20;

//---------------- TIER 4 — RECOVERY ---------------------------------
input group "═══ TIER 4 — RECOVERY (OPT-IN) ═══"
input bool     UseRecoveryModeV2           = false;
input double   RecoveryTargetUSD           = 5.0;
input double   RecoveryMaxRiskPctEquity    = 2.0;
input int      RecoveryMaxStreak           = 4;
input bool     RecoveryResetOnAnyWin       = true;

//---------------- MESSAGE BUDGET [B1–B4] ----------------------------
input group "═══ MESSAGE BUDGET [B1–B4] ═══"
input bool     UseMsgBudget                = true;
input int      MsgBudgetHardLimit          = 1900; // shared account + server + broker-server day; new-entry cap reserves room for protection requests
input int      MsgBudgetSoftLimit          = 1400; // shared account + server + broker-server day
input int      MsgBudgetWarnEvery          = 100;

//---------------- FACTOR B — FALLBACK ENGINE ------------------------
input group "═══ FACTOR B — V106A FALLBACK ═══"
input bool     UseFactorBFallback          = true;
input bool     FB_ShowDashboard            = true;
input double   FB_Chop_Lot                 = 0.05;
input double   FB_Trend_Lot                = 0.05;
input double   FB_Monster_Lot              = 0.08;
input double   FB_Reversal_Lot             = 0.05;
input int      FB_Chop_SL_Pts              = 20000;
input int      FB_Chop_TP_Pts              = 40000;
input int      FB_Chop_Gap_Pts             = 3000; // ~30 price units on 0.01-point symbols
input int      FB_Trend_SL_Pts             = 25000;
input int      FB_Trend_TP_Pts             = 55000;
input int      FB_Trend_Gap_Pts            = 8000; // V2: ~80 BTC price units on 0.01-point symbols
input int      FB_Monster_SL_Pts           = 30000;
input int      FB_Monster_TP_Pts           = 80000;
input int      FB_Monster_Gap_Pts          = 7500; // V2: ~75 BTC price units on 0.01-point symbols
input int      FB_Reversal_SL_Pts          = 20000;
input int      FB_Reversal_TP_Pts          = 44000;
input double   FB_VROC_TrendMin            = 2.5;
input double   FB_VROC_MonsterMin          = 4.5;
input double   FB_RE_TrendMin              = 1.5;
input double   FB_RE_MonsterMin            = 2.2;
input double   FB_VWAP_SlopeMin            = 3.0;
input int      FB_OB_MaxStored             = 8;
input int      FB_OB_MinDistPts            = 3000;
input int      FB_OB_MaxAgeBars            = 300;
input int      FB_FVG_MaxStored            = 8;
input double   FB_FVG_MinSizePts           = 500.0;
input int      FB_MSS_LeftBars             = 2;
input int      FB_MSS_RightBars            = 2;
input int      FB_MSS_ConfirmWindowMin     = 15;
input bool     FB_ReqM1Sweep               = true;
input bool     FB_ReqM1MSS                 = true;
input bool     FB_ReqM1Displ               = true;
input bool     FB_ReqZoneProximity         = true;
input int      FB_TrendLadderDepth         = 3;
input int      FB_MonsterLadderDepth       = 7; // V2: message-cap conscious Monster ladder
input double   FB_BasketBE_Pct             = 5.0;
input double   FB_BasketTrail_Pct          = 8.0;
input double   FB_BasketStep_Pct           = 2.0;
input double   FB_BasketSL_Pct             = -10.0;
input int      FB_MinSecondsBetweenPlaces  = 30;
input int      FB_MaxPendingTotal          = 8;
input int      FB_Cooldown_Loss            = 180;
input int      FB_Cooldown_Win             = 20;

//---------------- DISPLAY ------------------------------------------
input group "═══ DISPLAY ═══"
input bool     ShowDisplay                 = true;
input bool     ShowTelemetry               = true;
input bool     VerboseFlow                 = false;

//---------------- TIER 5 — GENERIC PARTIAL EXIT --------------------
input group "═══ TIER 5 — GENERIC PARTIAL EXIT ═══"
input bool     UseGenericPartial            = false;  // one exit controller
input double   PartialRR_Swing              = 1.50;
input double   PartialRR_Monster            = 2.00;
input double   PartialRR_Range              = 1.20;
input double   PartialRR_Reversal           = 1.50;
input double   PartialClosePct_Swing        = 50.0;
input double   PartialClosePct_Monster      = 50.0;
input double   PartialClosePct_Range        = 50.0;
input double   PartialClosePct_Reversal     = 50.0;
input double   FibBreakoutFactor            = 0.10;  // confirmation without waiting for exhaustion

//---------------- TIER 5 — DISCRETE GROWTH TIERS ------------------
input group "═══ TIER 5 — DISCRETE GROWTH TIERS ═══"
input bool     UseDiscreteGrowth            = false;  // no step-up risk
input double   DiscreteTier1_Growth         = 1.25;
input double   DiscreteTier1_Mult           = 1.10;
input double   DiscreteTier2_Growth         = 1.50;
input double   DiscreteTier2_Mult           = 1.25;
input double   DiscreteTier3_Growth         = 2.00;
input double   DiscreteTier3_Mult           = 1.50;

//---------------- TIER 5 — M5 THESIS LOCK -------------------------
input group "═══ TIER 5 — M5 THESIS LOCK ═══"
input bool     UseM5ThesisLock              = true;
input double   M5ThesisMinScore             = 38.0;
input bool     M5ThesisBlockCounterTrend    = true;
input bool     M5ThesisSkipRangeReversal    = true;  // Range/Reversal bypass lock

//---------------- V2.1 — TRADABILITY RELEASE -----------------------
input group "═══ V2.1 — TRADABILITY RELEASE ═══"
input bool     V1TradabilityRelease       = true;
// Allows a proven aligned setup to enter without waiting for the
// universal Fib breakout veto. Engine-specific structure/quality,
// M5 thesis and anti-chase gates still remain active.
input double   V1ReleaseM5Score           = 55.0;
input double   V1ReleaseM1PAScore         = 65.0;
input double   V1ReleaseFastTrendMin      = 35.0;
input double   V1ReleaseMinFlowScore      = -45.0;
input bool     V1ReleaseForSwing           = true;
input bool     V1ReleaseForMonster         = true;

//---------------- V1 CASH-RISK LAYER ------------------
// V3 DESIGN: centralized risk reservation DISABLED. Entry safety uses
// individual SL, position/pending/total-lot caps, message budget,
// daily/global loss halts and LegacyCampaign peak-profit protection.
input group "═══ V1 EQUITY-ADAPTIVE LOT SIZING ═══"
input bool     V1EquityAdaptiveSizing = true;
input double   V1ReferenceEquityUSD = 1000.0;
input double   V1MaximumLotScale = 10.0;

input group "═══ V1 CASH-RISK LAYER ═══"
const bool V1RiskLayerEnabled = true;
input double   V1CampaignRiskPct      = 1.00; // account-wide initial SL risk reserved across V1 positions + pending orders
input double   V1CryptoBasketRiskPct   = 0.50; // hard combined initial SL risk ceiling for crypto symbols
input double   V1PerEntryRiskPct      = 0.25; // HARD per-entry ceiling; engine risk may be lower
input double   V1RiskPct_Swing        = 0.15; // proposed V1 trial budget, % equity
input double   V1RiskPct_Monster      = 0.20; // proposed V1 trial budget, % equity
input double   V1RiskPct_Range        = 0.10; // proposed V1 trial budget, % equity
input double   V1RiskPct_Reversal     = 0.15; // proposed V1 trial budget, % equity
input double   V1RiskPct_Fallback     = 0.10; // proposed V1 trial budget, % equity
// account-wide hard ceiling
input int      V1MaxMarketEntries     = 2;  // per chart/pair
// account-wide hard ceiling
input bool     V1AdaptiveOrderDensity = true;
input double   V1MicroEquityMaxUSD    = 250.0;
input double   V1SmallEquityMaxUSD    = 1000.0;
input int      V1MicroMaxPositions    = 1;
input int      V1SmallMaxPositions    = 2;
input int      V1MicroMaxPending      = 2;
input int      V1SmallMaxPending      = 3;
input int      V1PairMaxPositions     = 2;
input int      V1PairMaxPendingOrders = 4;
input bool     V1AllowSingleLegRangeFallback = true;
input bool     V1BlockOppositeEntries = false;
input bool     V1AllowProvenBoosts   = false; // no compounding/boost multipliers in V1 baseline
input double   V1MarketMaxExtensionATR = 0.30;  // hard anti-chase distance for MARKET entries
input double   V1MarketHardExtensionATR= 0.60;  // emergency hard block for extremely late MARKET entries
input double   V1ContinuationStopBufferATR = 0.10; // breakout confirmation buffer
input double   V1ContinuationMaxDistanceATR= 0.75; // do not place a very distant continuation stop
input bool     V1CoreFlowSurvivesAuxStale = true; // do not abandon Factor A for stale auxiliary feeds
input bool     V1CUSUMOneShot           = true;  // one thesis reset per CUSUM event

//---------------- V1 EXIT-PROTECTION PARAMETERS --------------------
input group "═══ V1 EXIT-PROTECTION PARAMETERS ═══"
const bool V1SingleExitControllerEnabled = true;
input int      V1NoiseImmunitySec     = 20;
input double   V1ExitFlowScore        = 45.0;
input double   V1ExitMinPersistence   = 0.50;
input int      V1AdverseConfirmations = 2;
input double   V1BE_R                 = 0.75;
input double   V1Protect_R            = 1.00;
input double   V1Trail_R              = 1.25;
input double   V1TrailGivebackR        = 0.50;
input double   V1ProtectLockR          = 0.20;

//---------------- V1 SINGLE EXIT CONTROLLER ----------------
// One owner manages all V1 positions for this symbol/magic. Values are candidate demo settings.
input group "═══ V1 COORDINATED EXIT CONTROLLER ═══"
input double   V1BE_ATRMult              = 1.10; // BE requires max(R threshold, ATR/noise threshold)
input double   V1TrailStepATR            = 0.50; // discrete trailing step
input double   V1TrailStepR              = 0.20; // discrete trailing step
input double   V1PeakMinHoldR            = 0.05; // positive-R floor for peak exit
input double   ExitExpectedRoundTurnCostPerLot  = 0.00; // account currency/lot; configure from broker commission data
input double   ExitExpectedCloseCostPerLot      = 0.00; // expected closing-side commission/fee per lot in deposit currency
input double   ExitExpectedSlippagePoints       = 10.0; // expected protective-exit slippage, distinct from order deviation

//---------------- UNIVERSAL PAIR BASKET ----------------------------
// Common algorithm, scoped to the chart's current symbol + MagicNumber.
// Each instrument .set supplies its own maintenance thresholds.
input group "═══ UNIVERSAL PAIR BASKET ═══"
input bool     V1PairBasketManagementEnabled       = true;
input double   V1PairBasketTakeProfitPctBalance    = 0.30;
input double   V1PairBasketTrailArmPctBalance      = 0.20;
input double   V1PairBasketGivebackPctBalance      = 0.08;
input double   V1PairBasketMaxLossPctBalance       = 0.50;
input double   V1PairBasketMinCostMultiple         = 2.0;
input int      V1RangeLimitPendingLifetimeMin      = 12;
input double   V1RangeLimitMinRR                   = 1.10;

//---------------- V1 ACCOUNT SAFETY -------------------
input group "═══ V1 ACCOUNT SAFETY ═══"
input double   V1DailyLossPct         = 4.0;
input double   V1GlobalLossPct        = 10.0;
input int      V1LossPauseMin         = 60;

//---------------- V1 AUTOMATIC INSTRUMENT PROFILES ------------------
// AUTO detects symbol family, including common broker suffixes. These parameters
// are demo-starting profiles; calibrate them per broker/instrument after testing.

//---------------- CLOSED-M1 TRIGGER-FLIP PEAK PROFIT PROTECTION -----
// No fixed dollar arm/floor. Track each position's highest net floating P/L.
// Only activate after a confirmed direction flip on a CLOSED M1 candle against the position.
// After activation, ratchet broker SL to preserve a configurable share of the peak net P/L.
input group "═══ CLOSED-M1 FLIP PEAK PROFIT PROTECTION ═══"
input bool     V1PeakFlipProtectionEnabled = true;
input double   V1PeakFlipRetainFraction    = 0.50; // preserve 50% of peak net profit; proportional, not fixed dollars
input double   V1PeakFlipStopStepATR       = 0.10; // minimum improvement between broker-side SL updates
input bool     V1StopLossCooldownEnabled   = true;
input int      V1StopLossCooldownMinutes   = 1; // V2: brief post-stop pause; symbol entry cooldowns still apply


// Absolute USD floors complement the percentage targets below. Targets grow with equity
// whenever the percentage amount exceeds the fixed USD floor.
input double   V1PairBasketTakeProfitUSD     = 50.0;
input double   V1PairBasketTrailArmUSD       = 35.0;
input double   V1PairBasketGivebackUSD       = 15.0;

//---------------- GENESIS OCO RANGE BREAKOUT ENGINE -----------------
// OCO here means a matched BUY STOP / SELL STOP pair around the completed-M5 box.
// It is used only in range/compression contexts. On the first fill, the sibling is
// cancelled immediately via OnTradeTransaction; terminal/broker OCO is not atomic.
input group "═══ GENESIS OCO RANGE BREAKOUT ═══"
input bool     V1OCOEngineEnabled          = true;
input int      V1OCOBoxLookbackM5           = 8;
input double   V1OCOStopBufferATR           = 0.12;
input double   V1OCOSL_ATR                  = 1.10;
input double   V1OCOTP_RR                   = 1.50;
input int      V1OCOPendingLifetimeMin      = 8;
input double   V1OCOMinRangeATR             = 0.60;
input double   V1OCOMaxRangeATR             = 6.00;

input group "═══ V1 AUTO INSTRUMENT PROFILES ═══"
input bool V1AutoInstrumentProfile = true;
input ENUM_V1_ASSET_CLASS V1AssetClassOverride = V1_ASSET_AUTO;
input bool V1UseATRNormalizedSpreadGuard = true;
input bool V1LogAssetProfile = true;
input double V1MaxSpreadATR_Crypto = 0.35;
input double V1MaxSpreadATR_Forex  = 0.30;
input double V1MaxSpreadATR_Metal  = 0.25;
input double V1MaxSpreadATR_Index  = 0.30;
input double V1MaxSpreadATR_Other  = 0.20;
input double V1GenesisSLScale_Crypto = 1.00;
input double V1GenesisSLScale_Forex  = 0.95;
input double V1GenesisSLScale_Metal  = 1.10;
input double V1GenesisSLScale_Index  = 1.05;
input double V1GenesisSLScale_Other  = 1.00;
input double V1GenesisTPScale_Crypto = 1.00;
input double V1GenesisTPScale_Forex  = 1.00;
input double V1GenesisTPScale_Metal  = 1.10;
input double V1GenesisTPScale_Index  = 1.05;
input double V1GenesisTPScale_Other  = 1.00;

input group "═══ V1 RANGE PROFILE — CRYPTO ═══"
input int    V1CryptoRangeLookbackM5       = 8;
input double V1CryptoRangeMinWidthATR      = 0.60;
input double V1CryptoRangeMaxWidthATR      = 8.00;
input double V1CryptoRangeLimitRetracePct = 0.18;
input double V1CryptoRangeStopBufferATR   = 0.15;
input double V1CryptoRangeLimitSL_ATR     = 0.95;
input double V1CryptoRangeStopSL_ATR      = 1.10;
input double V1CryptoRangeLimitTP_RR      = 1.35;
input double V1CryptoRangeStopTP_RR       = 1.80;

input group "═══ V1 RANGE PROFILE — FOREX ═══"
input int    V1ForexRangeLookbackM5       = 12;
input double V1ForexRangeMinWidthATR      = 0.60;
input double V1ForexRangeMaxWidthATR      = 5.00;
input double V1ForexRangeLimitRetracePct = 0.18;
input double V1ForexRangeStopBufferATR   = 0.08;
input double V1ForexRangeLimitSL_ATR     = 0.85;
input double V1ForexRangeStopSL_ATR      = 1.00;
input double V1ForexRangeLimitTP_RR      = 1.20;
input double V1ForexRangeStopTP_RR       = 1.50;

input group "═══ V1 RANGE PROFILE — METALS ═══"
input int    V1MetalRangeLookbackM5       = 10;
input double V1MetalRangeMinWidthATR      = 0.70;
input double V1MetalRangeMaxWidthATR      = 5.50;
input double V1MetalRangeLimitRetracePct = 0.18;
input double V1MetalRangeStopBufferATR   = 0.12;
input double V1MetalRangeLimitSL_ATR     = 1.05;
input double V1MetalRangeStopSL_ATR      = 1.20;
input double V1MetalRangeLimitTP_RR      = 1.30;
input double V1MetalRangeStopTP_RR       = 1.70;

input group "═══ V1 RANGE PROFILE — INDICES ═══"
input int    V1IndexRangeLookbackM5       = 8;
input double V1IndexRangeMinWidthATR      = 0.75;
input double V1IndexRangeMaxWidthATR      = 6.00;
input double V1IndexRangeLimitRetracePct = 0.16;
input double V1IndexRangeStopBufferATR   = 0.10;
input double V1IndexRangeLimitSL_ATR     = 1.00;
input double V1IndexRangeStopSL_ATR      = 1.15;
input double V1IndexRangeLimitTP_RR      = 1.25;
input double V1IndexRangeStopTP_RR       = 1.60;

input group "═══ BTC CHOP A/B/C RANGE SAMPLE ═══"
input bool   V1BTCChopABCEnabled           = false;
input int    V1BTCChopLookbackM5            = 8;
input double V1BTCChopA_MaxRangeUSD         = 250.0;
input double V1BTCChopB_MaxRangeUSD         = 350.0;
input double V1BTCChopC_MaxRangeUSD         = 500.0;
// Base lot preferences at $1,000 reference equity. At $10,000 they scale to
// 0.50 / 0.25 / 0.10 requested lots respectively, before hard risk checks.
input double V1BTCChopA_LotAtReferenceEquity = 0.05;
input double V1BTCChopB_LotAtReferenceEquity = 0.025;
input double V1BTCChopC_LotAtReferenceEquity = 0.01;
input double V1BTCChopEdgeFraction          = 0.12;
input double V1BTCChopMinRR                 = 1.10;
input double V1BTCChopStopBufferATR         = 0.15;
input int    V1BTCChopPendingLifetimeMin    = 8;

//===================================================================
// SECTION 4 — GLOBAL STATE
//===================================================================
S_Flow         gFlow;

// Native short-window quote-pressure proxy for symbols without exchange aggressor data.
// A ring buffer of midpoint observations is used; it must never be labeled true traded volume.
double gPairFlowMid[64];
long   gPairFlowTimeMs[64];
int    gPairFlowHead=0;
int    gPairFlowCount=0;
long   gPairFlowLastReceiveMs=0;
datetime gPairFlowLastEvalSec=0;
int    gPairFlowLastDir=0;
int    gPairFlowPersistence=0;
double gPairFlowCachedScore=0.0;

// Crypto fast-reaction bridge signal (/fast).
bool   gCryptoFastValid=false;
int    gCryptoFastDir=0;
double gCryptoFastScore=0.0;
long   gCryptoFastReceiveMs=0;
long   gCryptoFastSignalAgeMs=999999;
datetime LastCryptoFastPoll=0;

S_USDHybrid    gUSDHybrid;
datetime       LastUSDHybridPoll = 0;
S_VP           gBinVP;
S_Aux          gBinAux;
S_NativeVP     g_NVP;
S_SMC          g_SMC;
S_OU           g_OU;
S_SignalPack   g_Sig;
S_Health       g_Health[8];
int            g_HealthCount = 0;

datetime LastFlowPoll   = 0;
datetime LastVPPoll     = 0;
datetime LastAuxPoll    = 0;
datetime LastVPINPoll   = 0;

double   PreviousCVD              = 0.0;
double   PreviousCVDVelocity      = 0.0;
datetime PreviousCVDTime          = 0;
double   LocalCVDVelocity         = 0.0;
double   LocalCVDAcceleration     = 0.0;
double   CVDVelocityNormalized    = 0.0;
double   CVDAccelerationNormalized= 0.0;

double FlowRateHistory[60];
int    FlowRateCount = 0;
int    FlowRateIndex = 0;

ENUM_HEALTH g_HealthState = HEALTH_GREEN;
string      g_HealthReason = "";

ENUM_REGIME7 g_R7                 = R7_CHOP;
ENUM_REGIME7 g_R7Pending          = R7_CHOP;
datetime     g_R7Since            = 0;
datetime     g_R7PendingSince     = 0;
double       g_R7Confidence       = 0.50;
double       g_R7_ER              = 0.0;
double       g_R7_Hurst           = 0.0;
double       g_R7_AC              = 0.0;
double       g_R7_VROC            = 0.0;
double       g_R7_ATR             = 0.0;
double       g_R7Score            = 0.0;
datetime     g_LastRegimeCalcM15  = 0;
double       g_HMMProb[7];
int          g_HMMRegime          = 4;

double   g_CUSUMBull          = 0.0;
double   g_CUSUMBear          = 0.0;
int      g_CUSUMDir           = 0;
datetime g_CUSUMLastFire      = 0;
datetime g_CUSUMOverrideUntil = 0;

ENUM_MONSTER_PHASE g_MonsterPhase        = MP_IDLE;
datetime           g_MonsterStart        = 0;
int                g_MonsterDir          = 0;
int                g_MonsterPyramidCount = 0;
double             g_MonsterPeakR        = 0.0;
datetime           g_LastPyramidAt       = 0;

ENUM_REV_STATE g_RevState         = REV_IDLE;
datetime       g_RevWatchSince    = 0;
int            g_RevDir           = 0;
int            g_RevConfirmCount  = 0;

double g_KalmanPrice    = 0.0;
double g_KalmanVelocity = 0.0;
double g_KalmanP00      = 1.0;
double g_KalmanP01      = 0.0;
double g_KalmanP10      = 0.0;
double g_KalmanP11      = 1.0;
datetime g_KalmanTime   = 0;

double g_VNEntropy       = 0.0;
double g_SignalMI_M5M15  = 0.0;
double g_FractDiff       = 0.0;

int hATR_M1     = INVALID_HANDLE;
int hATR_M5     = INVALID_HANDLE;
int hATR_M15    = INVALID_HANDLE;
int hEMA10_M15  = INVALID_HANDLE;
int hEMA20_M15  = INVALID_HANDLE;
int hEMA50_M15  = INVALID_HANDLE;
int hRSI_M15    = INVALID_HANDLE;
int hADX_M15    = INVALID_HANDLE;
int hMACD_M15   = INVALID_HANDLE;
int hEMA10_M5   = INVALID_HANDLE;
int hEMA8_M5    = INVALID_HANDLE;
int hEMA21_M5   = INVALID_HANDLE;
int hEMA50_M5   = INVALID_HANDLE;
int hRSI_M5     = INVALID_HANDLE;
int hADX_M5     = INVALID_HANDLE;
int hMACD_M5    = INVALID_HANDLE;
int hMom14_M5   = INVALID_HANDLE;
int hADX_M30    = INVALID_HANDLE;
int hGI_M5EMA5  = INVALID_HANDLE;
int hGI_M5EMA13 = INVALID_HANDLE;
int hGI_M1EMA5  = INVALID_HANDLE;
int hGI_M1EMA13 = INVALID_HANDLE;

double CurrentATR1  = 0.0;
double CurrentATR5  = 0.0;
double CurrentATR15 = 0.0;
double NormalATR1   = 0.0;
double NormalATR5   = 0.0;
double NormalATR15  = 0.0;

double CurrentSpreadPoints = 0.0;
double SpreadAveragePoints = 0.0;
double SpreadHistory[60];
int    SpreadCount = 0;
int    SpreadIndex = 0;

int    M15Direction      = 0;
int    M5Direction       = 0;
int    CombinedDirection = 0;
int    Jerk_M15          = 0;
int    Jerk_M5           = 0;
int    VWAP_Bias         = 0;
int    HHLL_State        = 0;

double KAMA_M15       = 0.0;
double KAMA_M15_Slope = 0.0;
double VWAP_Value     = 0.0;
double VWAP_Upper     = 0.0;
double VWAP_Lower     = 0.0;

double   MSS_LastHigh      = 0.0;
double   MSS_LastLow       = 0.0;
datetime MSS_LastHighTime  = 0;
datetime MSS_LastLowTime   = 0;
int      MSS_LastDir       = 0;
datetime MSS_LastEventTime = 0;
int      MSS_LastEventDir  = 0;

S_OrderBlock BullOBs[8];
S_OrderBlock BearOBs[8];
int BullOBCount = 0, BearOBCount = 0;
S_FVG BullFVGs[8];
S_FVG BearFVGs[8];
int BullFVGCount = 0, BearFVGCount = 0;

double   AsianHigh = 0.0, AsianLow = 0.0;
double   LondonHigh = 0.0, LondonLow = 0.0;
bool     AsianLocked = false, LondonLocked = false;
int      SessionDayOfYear = -1;

double   StartBalance    = 0.0;
double   DayStartEquity  = 0.0;
double   PeakEquity      = 0.0;
int      TodayStamp      = 0;
bool     DailyHalted     = false;
bool     GlobalHalted    = false;
datetime PauseUntil      = 0;
datetime LastLossTime    = 0;
datetime LastWinTime     = 0;
datetime LastViolentCandle = 0;
datetime LastTradeAction = 0;
datetime g_LastPlaceTime = 0;
datetime g_LastRangePlace= 0;

datetime g_EngineCooldown[4]   = {0,0,0,0};
int      g_EngineLossStreak[4] = {0,0,0,0};
int      g_EngineWinStreak[4]  = {0,0,0,0};
double   g_EnginePnLToday[4]   = {0,0,0,0};

int      g_LastEntryDir  = 0;
datetime g_LastEntryTime = 0;

//--- LegacyFast baseline state
datetime g_LegacyFastLastPathBar = 0;
datetime g_LegacyFastLastPendingCleanup = 0;
int      g_LegacyFastPathDir = 0;
double   g_LegacyFastPathEfficiency = 0.0;
double   g_LegacyFastPathNetATR = 0.0;
double   g_LegacyFastPathDirectionalPct = 0.0;

//--- LegacyFast LegacyCampaign campaign state
bool     g_TM_Active            = false;
datetime g_TM_Start             = 0;
datetime g_TM_LastClose         = 0;
datetime g_TM_LastReinforce     = 0;
int      g_TM_LastSignalDir     = 0;
double   g_TM_LastSignalScore   = 0.0;
double   g_TM_PeakPnL           = 0.0;
double   g_TM_TrailFloor        = 0.0;
bool     g_TM_BEArmed           = false;
bool     g_TM_TrailArmed        = false;
int      g_TM_Reinforcements    = 0;
int      g_TM_Sequence           = 0;

//--- Genesis unified campaign / MFE tracking
ulong    g_GenTrackTicket[64]   = {0};
double   g_GenTrackRiskMoney[64]= {0};
datetime g_GenTrackOpen[64]    = {0};
int      g_GenTrackCount        = 0;
datetime g_GenShockBar          = 0;
bool     g_GenShockActive       = false;
int      g_GenShockDir          = 0;
datetime g_GenShockUntil        = 0;
double   g_GenShockPeakR        = 0.0;
double   g_GenShockPeakPrice    = 0.0;
double   g_GenShockArmPnL       = 0.0;
bool     g_GenShockHarvested    = false;
bool     g_GenMFEArmed          = false;
double   g_GenPeakR             = 0.0;
double   g_GenTrailFloorR       = 0.0;

int      TradeCount        = 0;
int      WinCount          = 0;
int      LossCount         = 0;
int      ConsecutiveWins   = 0;
int      ConsecutiveLosses = 0;
double   TotalWinUSD       = 0.0;
double   TotalLossUSD      = 0.0;

bool   SwingBE         = false, SwingTrail    = false;
double SwingTrailHigh  = 0.0,   SwingTrailSL  = 0.0;
bool   MonsterBE       = false, MonsterTrail  = false;
double MonsterTrailHigh= 0.0,   MonsterTrailSL= 0.0;
bool   RangeBE         = false, RangeTrail    = false;
double RangeTrailHigh  = 0.0,   RangeTrailSL  = 0.0;
bool   ReversalBE      = false, ReversalTrail = false;
double ReversalTrailHigh= 0.0,  ReversalTrailSL = 0.0;
bool   ReversalPartial = false;
double BasketInitialRiskUSD[4] = {0.0,0.0,0.0,0.0};

ENUM_ACCOUNT_MODE g_ResolvedMode = ACC_DOLLAR;

double g_InternalVWAP    = 0.0;
double g_InternalVWAPSD  = 0.0;
double g_InternalVWAPZ   = 0.0;
bool   g_InternalExhaust = false;
datetime g_InternalVWAPTime = 0;

ENUM_ENGINE g_LastEngine = ENG_NONE;
string      g_LastModelEngine = "";

int    M1PA_Dir        = 0;
double M1PA_Score      = 0.0;
bool   M1PA_BullSweep  = false;
bool   M1PA_BearSweep  = false;
bool   M1PA_BullDisp   = false;
bool   M1PA_BearDisp   = false;
bool   M1PA_BullMSS    = false;
bool   M1PA_BearMSS    = false;
bool   M1PA_BullFVG    = false;
bool   M1PA_BearFVG    = false;

double g_MTF_buy_prob     = 0.50;
double g_MTF_sell_prob    = 0.50;
double g_MTF_confidence   = 0.50;
int    g_LastModelDir     = 0;
double g_LastSignalConfidence = 0.50;

double ER_Short_M5 = 0.0;
double ER_Med_M5   = 0.0;
double ER_Slow_M15 = 0.0;
double ATR15_Pct   = 0.0;

int    DC_Bias      = 0;
double DC_Upper     = 0.0;
double DC_Lower     = 0.0;
double DC_UpperPrev = 0.0;
double DC_LowerPrev = 0.0;
double DC_Slope     = 0.0;
double MA_Slope     = 0.0;

double DayRangeValue = 0.0;
double ER_M15        = 0.0;
double ADX_M30       = 0.0;
double CI_M30        = 0.0;

bool   VolSurgeBull_sig = false;
bool   VolSurgeBear_sig = false;
double OBV_Val          = 0.0;
double OBV_Sig          = 0.0;

int    CurrentMoveState       = 0;
int    CurrentDirection       = 0;
double CurrentMoveScore       = 0.0;
int    CurrentDirectionSource = 0;

S_GenesisIntelligence g_GI;
int      g_GI_EntriesCampaign = 0;
datetime g_GI_LastEntry       = 0;
int      g_GI_LastActionDir   = 0;
int      g_GI_LastAction       = GI_WAIT;
double   g_GI_LastConfidence   = 0.0;
double   g_GI_LastReversal     = 0.0;
double   g_GI_LastExhaustion   = 0.0;
double   g_GI_LastIgnition     = 0.0;
datetime g_GI_LastM1Bar       = 0;
double g_GI_PrevSpectralSlopeATR=0.0, g_GI_PrevSpectralLowFrac=0.0;
double g_GI_PrevSpectralHighFrac=0.0, g_GI_PrevSpectralConc=0.0;
int g_GI_PrevSpectralDir=0; datetime g_GI_SpectralUpdateTime=0;
int g_GI_LuxTransitionDir=0; datetime g_GI_LuxTransitionTime=0;
int g_GI_TransitionArmedDir=0; datetime g_GI_TransitionArmedTime=0;
ulong g_GI_TransitionPendingTicket=0; double g_GI_TransitionTrigger=0.0;
int g_GI_MarketShotCount=0;
int g_GI_M1LeadCrossDir=0; datetime g_GI_M1LeadCrossTime=0;

//--- BGBI V4 execution / defense state
int      g_V4_LastPosCount=0;
datetime g_V4_LastFillTime=0;
datetime g_V4_DefenseUntil=0;
int      g_V4_DefenseDir=0;
int      g_V4_LastPendingDir=0;
datetime g_V4_LastPendingTime=0;
int      g_V4_ContinuationArmCount=0;
int      g_V4_DefenseEvents=0;
int      g_V4_M15Bias=0;
int      g_V4_M15PreviousBias=0;
ENUM_V4_M15_PHASE g_V4_M15Phase=V4_M15_PHASE_UNKNOWN;
datetime g_V4_M15PhaseBar=0;
datetime g_V4_LastStraddleTime=0;
int      g_V4_StraddleBiasAtArm=0;
int      g_V4_StraddleCounterAtArm=0;
datetime g_V1Route_LastDecisionLog=0;
string   g_V1Route_LastDecision="INIT";
string   g_V1Route_State="IDLE";
bool     g_V2_LastEntryRequestFailed=false; // avoid same-tick alternate order after a rejected send

// Buyer/seller profile state. Fixed-size arrays avoid per-tick allocations.
S_BGBIProfileLevel g_BPILevels[40];
double g_BPIBinTotal[100];
double g_BPIBinBuy[100];
int    g_BPIBinRows=0;
bool   g_BPIValid=false;
double g_BPILow=0.0, g_BPIHigh=0.0, g_BPIBinStep=0.0;
double g_BPIPOC=0.0, g_BPIBuyShare=0.50, g_BPITotalVolume=0.0;
datetime g_BPILastBar=0;

int    ST_Dir = 0;

double g_LotMin    = 0.01;
double g_LotMax    = 100.0;
double g_LotStep   = 0.01;
int    g_LotDigits = 2;

//--- TIER 1-4 STATE ------------------------------------------------
double   g_FastTrendScore      = 0.0;
int      g_FastTrendDir        = 0;
datetime g_LastFastTrendCalc   = 0;

int      g_BrokerMsgCountToday = 0;
int      g_BrokerMsgResetDay   = 0;

double   g_RecoveryAccumulated = 0.0;
int      g_RecoveryStreak      = 0;

datetime g_LastStraddleReset   = 0;
datetime g_LastGridAddV2       = 0;

int      g_GridLevelV2         = 0;
bool     g_LastWasWin          = false;
bool     g_StraddleActive      = false;
int      g_StraddleDir         = 0;

int      g_DailyOpens          = 0;
int      g_DailyModifies       = 0;
int      g_DailyDeletes        = 0;

double   g_LastRequestedEntry  = 0.0;
ulong    g_LastTicketForAnchor = 0;

//--- SLIPPAGE ANCHOR MAP ------------------------------------------
S_Anchor g_AnchorMap[200];
int      g_AnchorCount = 0;

//--- ACCOUNT DETECTION [C1] ---------------------------------------
bool     g_IsCent       = false;
double   g_ContractSize = 0.0;
double   g_TickValue    = 0.0;
double   g_TickValueLoss= 0.0;
double   g_TickSize     = 0.0;
string   g_AcctCurrency = "";

//--- MESSAGE BUDGET [B1] ------------------------------------------
int      g_MsgBudgetCount     = 0;
int      g_MsgBudgetWarnCount = 0;
int      g_MsgBudgetResetDay  = 0;
datetime g_MsgBudgetLastWarn  = 0;

//--- FACTOR SWITCH [FB2] ------------------------------------------
ENUM_ACTIVE_FACTOR g_ActiveFactor     = FACTOR_A_BRIDGE;
ENUM_ACTIVE_FACTOR g_LastFactor       = FACTOR_A_BRIDGE;
datetime           g_LastFactorSwitch = 0;

//--- FACTOR B STATE [FB1] -----------------------------------------
int      g_FB_Mode            = -1;    // -1 none, 0 CHOP, 1 TREND, 2 MONSTER, 3 REVERSAL
int      g_FB_JerkM15         = 0;
int      g_FB_M15Dir          = 0;
int      g_FB_M5Dir           = 0;
double   g_FB_VROC            = 0.0;
double   g_FB_RangeExp        = 0.0;
double   g_FB_VWAP            = 0.0;
double   g_FB_VWAPSlope       = 0.0;
S_NativeVP g_FB_VP;
S_OrderBlock g_FB_BullOB[8], g_FB_BearOB[8];
int          g_FB_BullOBCount = 0, g_FB_BearOBCount = 0;
S_FVG        g_FB_BullFVG[8], g_FB_BearFVG[8];
int          g_FB_BullFVGCount = 0, g_FB_BearFVGCount = 0;
double   g_FB_MSS_LastHigh     = 0.0;
double   g_FB_MSS_LastLow      = 0.0;
datetime g_FB_MSS_LastHighTime = 0;
datetime g_FB_MSS_LastLowTime  = 0;
int      g_FB_MSS_LastDir      = 0;
datetime g_FB_MSS_LastEventTime= 0;
int      g_FB_MSS_LastEventDir = 0;
datetime g_FB_LastM15Time      = 0;
datetime g_FB_LastM5Time       = 0;
datetime g_FB_LastM1Time       = 0;
datetime g_FB_LastClose[4]     = {0,0,0,0};
bool     g_FB_BE[4]            = {false,false,false,false};
bool     g_FB_Trail[4]         = {false,false,false,false};
double   g_FB_TrailHigh[4]     = {0,0,0,0};
double   g_FB_TrailSL[4]       = {0,0,0,0};
datetime g_FB_LastPlaceTime    = 0;
datetime g_FB_LastLossTime     = 0;
datetime g_FB_LastWinTime      = 0;
int      g_FB_ConsecutiveLosses= 0;

//===================================================================
// BTC LEGACY FAST STATE
//===================================================================
bool     g_V1Risk_CampaignActive     = false;
int      g_V1Risk_CampaignDir        = 0;
datetime g_V1Risk_CampaignStart      = 0;
int      g_V1Risk_MarketEntries      = 0;
double g_V1Risk_CampaignPeakR = 0.0;
datetime g_V1Risk_LastCUSUMHandled = 0;

// Pair-scoped basket state: one common algorithm, isolated by current chart symbol + magic.
double g_V1PairBasketPeakProfit = 0.0;

bool   g_V1PairBasketTrailArmed = false;
int    g_V1PairBasketLastPositionCount = 0;

double V1_PositionCommissionAndFees(ulong positionIdentifier);

ulong    g_V1Risk_TrackTicket[64]    = {0};
double   g_V1Risk_TrackRisk[64]      = {0};
datetime g_V1Risk_TrackOpen[64]     = {0};
double   g_V1Risk_TrackPeakR[64]    = {0};
int      g_V1Risk_TrackAdverse[64]   = {0};


// True only while submitting a pre-sized OCO pair. The lot was risk-checked against
// the combined worst-case risk of BOTH legs before either request was sent.
bool g_V1OCO_PairLotPrevalidatedSubmit=false;

//===================================================================
// SECTION 5 — UTILITY HELPERS
//===================================================================
double Clamp(double v, double lo, double hi)
  {
   if(v < lo) return lo;
   if(v > hi) return hi;
   return v;
  }

double BidPrice() { return SymbolInfoDouble(_Symbol, SYMBOL_BID); }
double AskPrice() { return SymbolInfoDouble(_Symbol, SYMBOL_ASK); }

double MidPrice()
  {
   double b = BidPrice();
   double a = AskPrice();
   if(b <= 0.0 || a <= 0.0) return 0.0;
   return (b + a) * 0.5;
  }

double StopsLevelPrice()
  {
   double pts = (double)SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL);
   if(pts <= 0.0) pts = 5.0;
   return pts * _Point;
  }

double BufVal(int handle, int buffer, int shift)
  {
   if(handle == INVALID_HANDLE) return 0.0;
   double v[];
   if(CopyBuffer(handle, buffer, shift, 1, v) != 1) return 0.0;
   return v[0];
  }

double TfOpen(ENUM_TIMEFRAMES tf, int shift)
  {
   double v[];
   if(CopyOpen(_Symbol, tf, shift, 1, v) != 1) return 0.0;
   return v[0];
  }

double TfClose(ENUM_TIMEFRAMES tf, int shift)
  {
   double v[];
   if(CopyClose(_Symbol, tf, shift, 1, v) != 1) return 0.0;
   return v[0];
  }

double TfHigh(ENUM_TIMEFRAMES tf, int shift)
  {
   double v[];
   if(CopyHigh(_Symbol, tf, shift, 1, v) != 1) return 0.0;
   return v[0];
  }

double TfLow(ENUM_TIMEFRAMES tf, int shift)
  {
   double v[];
   if(CopyLow(_Symbol, tf, shift, 1, v) != 1) return 0.0;
   return v[0];
  }

long TfVolume(ENUM_TIMEFRAMES tf, int shift)
  {
   long v[];
   if(CopyTickVolume(_Symbol, tf, shift, 1, v) != 1) return 0;
   return v[0];
  }

datetime TfTime(ENUM_TIMEFRAMES tf, int shift)
  {
   datetime v[];
   if(CopyTime(_Symbol, tf, shift, 1, v) != 1) return 0;
   return v[0];
  }

string DirStr(int d)
  {
   if(d > 0) return "BUY";
   if(d < 0) return "SELL";
   return "—";
  }

string SignStr(double v, int digits = 1)
  {
   if(v > 0.0) return "+" + DoubleToString(v, digits);
   return DoubleToString(v, digits);
  }

string HealthStr()
  {
   switch(g_HealthState)
     {
      case HEALTH_GREEN:  return "GREEN";
      case HEALTH_YELLOW: return "YELLOW";
      case HEALTH_RED:    return "RED";
      case HEALTH_BLACK:  return "BLACK";
     }
   return "?";
  }

string Regime7Name(ENUM_REGIME7 r)
  {
   switch(r)
     {
      case R7_STRONG_UP:   return "STRONG_UP";
      case R7_STRONG_DOWN: return "STRONG_DOWN";
      case R7_WEAK_UP:     return "WEAK_UP";
      case R7_WEAK_DOWN:   return "WEAK_DOWN";
      case R7_CHOP:        return "CHOP";
      case R7_COMPRESSION: return "COMPRESSION";
      case R7_EXPANSION:   return "EXPANSION";
     }
   return "CHOP";
  }

string MonsterPhaseStr()
  {
   switch(g_MonsterPhase)
     {
      case MP_IDLE:         return "IDLE";
      case MP_IGNITION:     return "IGNITION";
      case MP_ACCELERATION: return "ACCEL";
      case MP_HARVEST:      return "HARVEST";
     }
   return "?";
  }

string RevStateStr()
  {
   switch(g_RevState)
     {
      case REV_IDLE:    return "IDLE";
      case REV_WATCH:   return "WATCH";
      case REV_ALERT:   return "ALERT";
      case REV_CONFIRM: return "CONFIRM";
     }
   return "?";
  }

string FlowStateStr()
  {
   if(PairFlow_UseNativeNow())
     {
      if(!PairFlow_NativeFresh()) return "LOCAL-WARMING/STALE";
      return (UseBinanceFlow ? "NATIVE-FALLBACK" : "LOCAL-QUOTE-PROXY");
     }
   if(!UseBinanceFlow)            return "OFF";
   if(MQLInfoInteger(MQL_TESTER)) return "TESTER";
   if(!gFlow.valid)               return "NO-DATA";
   if(!gFlow.healthy)             return "UNHEALTHY";
   if(gFlow.local_update == 0)    return "NO-DATA";
   if(TimeCurrent() - gFlow.local_update > BinanceMaxAgeSeconds) return "STALE";
   return "LIVE";
  }

string EngineName(ENUM_ENGINE e)
  {
   switch(e)
     {
      case ENG_REVERSAL: return "REVERSAL";
      case ENG_CUSUM:    return "CUSUM";
      case ENG_KILLSHOT: return "KILLSHOT";
      case ENG_MONSTER:  return "MONSTER";
      case ENG_TREND:    return "TREND";
      case ENG_RANGE:    return "RANGE";
      case ENG_STRADDLE: return "STRADDLE";
      default:           return "—";
     }
  }

string FactorStr(ENUM_ACTIVE_FACTOR f)
  {
   return (f == FACTOR_A_BRIDGE) ? "A" : "B";
  }

string FB_ModeName(int m)
  {
   if(m == 0) return "CHOP";
   if(m == 1) return "TREND";
   if(m == 2) return "MONSTER";
   if(m == 3) return "REVERSAL";
   return "?";
  }

//===================================================================
// SECTION 6 — NORMAL ATR
//===================================================================
double GetNormalATR1()
  {
   if(hATR_M1 == INVALID_HANDLE) return 0.0;
   double sum = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      double v = BufVal(hATR_M1, 0, i);
      if(v > 0.0) { sum += v; cnt++; }
     }
   return (cnt > 0) ? sum / (double)cnt : 0.0;
  }

double GetNormalATR5()
  {
   if(hATR_M5 == INVALID_HANDLE) return 0.0;
   double sum = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      double v = BufVal(hATR_M5, 0, i);
      if(v > 0.0) { sum += v; cnt++; }
     }
   return (cnt > 0) ? sum / (double)cnt : 0.0;
  }

double GetNormalATR15()
  {
   if(hATR_M15 == INVALID_HANDLE) return 0.0;
   double sum = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      double v = BufVal(hATR_M15, 0, i);
      if(v > 0.0) { sum += v; cnt++; }
     }
   return (cnt > 0) ? sum / (double)cnt : 0.0;
  }

//===================================================================
// SECTION 7 — EFFICIENCY RATIO
//===================================================================
double CalculateER_TF(ENUM_TIMEFRAMES tf, int period)
  {
   if(period < 2) return 0.0;
   double c0 = TfClose(tf, 0);
   double cN = TfClose(tf, period);
   if(c0 <= 0.0 || cN <= 0.0) return 0.0;

   double net = MathAbs(c0 - cN);
   double path = 0.0;
   for(int i = 0; i < period; i++)
     {
      double a = TfClose(tf, i);
      double b = TfClose(tf, i + 1);
      if(a > 0.0 && b > 0.0) path += MathAbs(a - b);
     }
   if(path <= 0.0) return 0.0;
   return Clamp(net / path, 0.0, 1.0);
  }

//===================================================================
// SECTION 8 — SPREAD SAFETY [S1–S4]
//===================================================================
double SpreadInPoints()
  {
   double b = BidPrice();
   double a = AskPrice();
   if(b <= 0.0 || a <= 0.0) return 0.0;
   double s = (a - b) / _Point;
   if(s < 0.0) s = 0.0;
   return s;
  }

double SafeSLDistance(double baseSLDistance)
  {
   double spreadPts = SpreadInPoints();
   double spreadFloor = spreadPts * SpreadMultiplier_SL * _Point;
   double absFloor = SpreadMinSLPoints * _Point;
   double result = MathMax(baseSLDistance, spreadFloor);
   if(result < absFloor) result = absFloor;
   return result;
  }

double SafeTPDistance(double baseTPDistance, double slDistance)
  {
   double spreadPts = SpreadInPoints();
   double spreadFloor = spreadPts * SpreadMultiplier_TP * _Point;
   double result = MathMax(baseTPDistance, spreadFloor);

   // Sanity: TP must exceed 1.2× SL
   if(result < slDistance * 1.2) result = slDistance * 1.2;
   return result;
  }

double SafeTrailBuffer()
  {
   double spreadPts = SpreadInPoints();
   double buf = spreadPts * SpreadMultiplier_Trail * _Point;

   // Absolute floor
   double absFloor = SpreadMinSLPoints * _Point * 0.6;   // 300 pts if SpreadMinSL=500
   if(buf < absFloor) buf = absFloor;
   return buf;
  }

//===================================================================
// SECTION 9 — MESSAGE BUDGET MANAGER [B1]
//===================================================================
//===================================================================
// SECTION 9 — ACCOUNT-WIDE DAILY BROKER MESSAGE BUDGET
// Shared by all BGBI charts/variants in this MT5 terminal for the same
// account + server + broker-server day. Symbol, chart, magic, and variant
// are deliberately excluded from the global key.
//===================================================================
string MsgBudget_GlobalKey()
  {
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(),dt);
   string server=AccountInfoString(ACCOUNT_SERVER);
   uint hash=5381;
   for(int i=0;i<StringLen(server);i++)
      hash=((hash<<5)+hash)^(uint)StringGetCharacter(server,i);
   string mode=(bool)MQLInfoInteger(MQL_TESTER) ? "T" : "L";
   return StringFormat("BGBI_%sMSG_%I64d_%u_%04d%02d%02d",mode,
                       AccountInfoInteger(ACCOUNT_LOGIN),hash,
                       dt.year,dt.mon,dt.day);
  }

bool MsgBudget_EnsureGlobal(const string key)
  {
   if(GlobalVariableCheck(key)) return true;
   // Serialize first-use initialization across charts. The lock is temporary,
   // but the daily counter itself is a persistent terminal global variable.
   string lockKey=key+"_I";
   if(!GlobalVariableCheck(lockKey)) GlobalVariableTemp(lockKey);
   for(int attempt=0;attempt<100;attempt++)
     {
      if(GlobalVariableSetOnCondition(lockKey,1.0,0.0))
        {
         if(!GlobalVariableCheck(key)) GlobalVariableSet(key,0.0);
         GlobalVariableSetOnCondition(lockKey,0.0,1.0);
         GlobalVariablesFlush();
         return GlobalVariableCheck(key);
        }
      if(GlobalVariableCheck(key)) return true;
      Sleep(1);
     }
   return GlobalVariableCheck(key);
  }

int MsgBudget_GlobalCount()
  {
   string key=MsgBudget_GlobalKey();
   if(!MsgBudget_EnsureGlobal(key)) return -1;
   double value=GlobalVariableGet(key);
   if(value<0.0) value=0.0;
   return (int)MathFloor(value+0.5);
  }

bool MsgBudget_AtomicAdd(const int delta,int &newCount)
  {
   newCount=-1;
   if(delta<=0) { newCount=MsgBudget_GlobalCount(); return (newCount>=0); }
   string key=MsgBudget_GlobalKey();
   if(!MsgBudget_EnsureGlobal(key)) return false;
   for(int attempt=0;attempt<100;attempt++)
     {
      double oldValue=GlobalVariableGet(key);
      if(oldValue<0.0) oldValue=0.0;
      if(GlobalVariableSetOnCondition(key,oldValue+(double)delta,oldValue))
        {
         newCount=(int)MathFloor(oldValue+(double)delta+0.5);
         g_MsgBudgetCount=newCount;
         // Checkpoint every 25 requests and on orderly shutdown; avoids doing
         // a disk flush for every market tick while limiting restart undercount.
         if((newCount%25)==0) GlobalVariablesFlush();
         return true;
        }
      Sleep(1);
     }
   PrintFormat("[ACCOUNT MSGBUDGET ERROR] unable to atomically update shared counter; new entries must fail closed");
   return false;
  }

int MsgBudget_EntryLimit()
  {
   int hard=MathMax(1,MsgBudgetHardLimit);
   int soft=MsgBudgetSoftLimit;
   if(soft<=0 || soft>hard) soft=hard;
   return soft;
  }

void MsgBudget_Init()
  {
   g_MsgBudgetResetDay=(int)(TimeCurrent()/86400);
   g_MsgBudgetCount=MsgBudget_GlobalCount();
   g_MsgBudgetWarnCount=0;
   PrintFormat("[ACCOUNT MSGBUDGET] shared counter initialized: account=%I64d server=%s count=%d entryCap=%d hardWarn=%d",
               AccountInfoInteger(ACCOUNT_LOGIN),AccountInfoString(ACCOUNT_SERVER),
               g_MsgBudgetCount,MsgBudget_EntryLimit(),MsgBudgetHardLimit);
  }

void MsgBudget_Tick()
  {
   int today=(int)(TimeCurrent()/86400);
   if(today!=g_MsgBudgetResetDay)
     {
      g_MsgBudgetResetDay=today;
      g_MsgBudgetWarnCount=0;
      PrintFormat("[ACCOUNT MSGBUDGET] broker-server day rollover; shared count=%d",MsgBudget_GlobalCount());
     }
   g_MsgBudgetCount=MsgBudget_GlobalCount();
  }

bool MsgBudget_CanSend()
  {
   // The legacy UseMsgBudget flag is retained for preset compatibility, but
   // cannot disable the account-wide broker-message guard.
   MsgBudget_Tick();
   int count=g_MsgBudgetCount;
   int entryCap=MsgBudget_EntryLimit();
   if(count<0 || count>=entryCap)
     {
      if(TimeCurrent()-g_MsgBudgetLastWarn>=300)
        {
         g_MsgBudgetLastWarn=TimeCurrent();
         PrintFormat("[ACCOUNT MSGBUDGET] symbol=%s account-wide count=%d; NEW entries paused at %d; position protection/exit/cleanup requests remain enabled and counted (hard warning=%d)",
                     _Symbol,count,entryCap,MsgBudgetHardLimit);
        }
      return false;
     }
   return true;
  }

bool MsgBudget_SoftThrottled()
  {
   int count=MsgBudget_GlobalCount();
   return (count<0 || count>=MsgBudget_EntryLimit());
  }

// Counts each outbound trade request attempt (accepted or rejected). It is
// intentionally independent of UseMsgBudget so every configured chart adds to
// the same account/server/day total.
void MsgBudget_Count(int n=1)
  {
   int count=-1;
   if(!MsgBudget_AtomicAdd(n,count)) return;
   g_MsgBudgetWarnCount++;
   if(count>=MsgBudgetHardLimit &&
      (g_MsgBudgetWarnCount%MathMax(1,MsgBudgetWarnEvery)==0))
      PrintFormat("[ACCOUNT MSGBUDGET WARNING] requests=%d reached hard warning=%d. New entries are already paused; required protective actions still run and are counted. Verify broker's actual request policy.",
                  count,MsgBudgetHardLimit);
   else if(count>=MsgBudget_EntryLimit() && count-n<MsgBudget_EntryLimit())
      PrintFormat("[ACCOUNT MSGBUDGET] entry cap reached at %d requests; new entries paused across this MT5 account/server",count);
  }

// Atomically reserves the shared budget for a new entry request, so two charts
// cannot both pass a stale per-chart pre-check at the entry threshold.
bool MsgBudget_ReserveEntryRequest(const string context)
  {
   int cap=MsgBudget_EntryLimit();
   string key=MsgBudget_GlobalKey();
   if(!MsgBudget_EnsureGlobal(key)) return false;
   for(int attempt=0;attempt<100;attempt++)
     {
      double oldValue=GlobalVariableGet(key);
      if(oldValue<0.0) oldValue=0.0;
      int current=(int)MathFloor(oldValue+0.5);
      if(current>=cap)
        {
         PrintFormat("[ACCOUNT MSGBUDGET] blocked new entry request: %s symbol=%s sharedCount=%d entryCap=%d",context,_Symbol,current,cap);
         g_MsgBudgetCount=current;
         return false;
        }
      // Compare-and-swap evaluates the ceiling and reserves the slot together,
      // preventing concurrent charts from overshooting the entry cap.
      if(GlobalVariableSetOnCondition(key,oldValue+1.0,oldValue))
        {
         int next=current+1;
         g_MsgBudgetCount=next;
         if((next%25)==0) GlobalVariablesFlush();
         if(next>=cap)
            PrintFormat("[ACCOUNT MSGBUDGET] entry cap reached at %d; new entries paused across all BGBI charts",next);
         return true;
        }
      Sleep(1);
     }
   PrintFormat("[ACCOUNT MSGBUDGET ERROR] reservation failed closed: %s symbol=%s",context,_Symbol);
   return false;
  }

int MsgBudget_GetCount() { return MsgBudget_GlobalCount(); }


//===================================================================
// SECTION 10 — ACCOUNT DETECTION [C1, C2]
//===================================================================
void DetectAccountType()
  {
   g_AcctCurrency  = AccountInfoString(ACCOUNT_CURRENCY);
   g_ContractSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_CONTRACT_SIZE);
   g_TickValue     = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   g_TickValueLoss = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE_LOSS);
   g_TickSize      = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);

   if(g_TickValueLoss <= 0.0) g_TickValueLoss = g_TickValue;
   if(g_TickSize <= 0.0)      g_TickSize = _Point;

   string acctUpper = g_AcctCurrency;
   StringToUpper(acctUpper);
   // Explicitly recognise the broker cent currency used by the project.
   // Do NOT infer cent mode merely from a trailing "C" because currencies
   // such as BTC also end with C.
   g_IsCent = (acctUpper == "USC");

   if(g_IsCent)
      PrintFormat("[ACCT] CENT account: cur=%s contract=%.4f tickVal=%.5f",
                  g_AcctCurrency, g_ContractSize, g_TickValue);
   else
      PrintFormat("[ACCT] DOLLAR account: cur=%s contract=%.4f tickVal=%.5f",
                  g_AcctCurrency, g_ContractSize, g_TickValue);
  }

//===================================================================
// SECTION 11 — FACTOR SELECTOR [FB2]
//===================================================================
bool V1CoreFlowReady()
  {
   if(!UseBinanceFlow) return false;
   if(MQLInfoInteger(MQL_TESTER)) return false;
   if(!gFlow.valid || !gFlow.healthy) return false;
   if(gFlow.local_update == 0) return false;
   return (TimeCurrent() - gFlow.local_update <= BinanceMaxAgeSeconds);
  }

ENUM_ACTIVE_FACTOR ActiveFactor()
  {
   if(!UseFactorBFallback) return FACTOR_A_BRIDGE;
   if(MQLInfoInteger(MQL_TESTER)) return FACTOR_B_FALLBACK;   // tester = B
   if(!UseBinanceFlow)            return FACTOR_B_FALLBACK;   // manually disabled

   // V2: auxiliary stale data (VPIN/VROC/walls/etc.) degrades confidence but
   // must not force a fallback when the core flow stream is still fresh.
   if(V1CoreFlowReady() && V1CoreFlowSurvivesAuxStale)
      return FACTOR_A_BRIDGE;

   if(!gFlow.valid || !gFlow.healthy) return FACTOR_B_FALLBACK;
   if(g_HealthState > HEALTH_YELLOW)  return FACTOR_B_FALLBACK;
   return FACTOR_A_BRIDGE;
  }

void LogFactorSwitchIfChanged()
  {
   ENUM_ACTIVE_FACTOR af = ActiveFactor();
   if(af != g_LastFactor)
     {
      PrintFormat("[FACTOR] %s -> %s (bridge=%s health=%d)",
                  FactorStr(g_LastFactor), FactorStr(af),
                  (gFlow.valid && gFlow.healthy ? "OK" : "DOWN"),
                  (int)g_HealthState);
      g_LastFactor = af;
      g_LastFactorSwitch = TimeCurrent();
     }
   g_ActiveFactor = af;
  }

//===================================================================
// END OF PART 1 OF 5
//===================================================================

//===================================================================
// SECTION 12 — JSON HELPERS
//===================================================================
int JsonFindValueStart(const string json, const string key)
  {
   string token = "\"" + key + "\"";
   int p = StringFind(json, token);
   if(p < 0) return -1;

   int colon = StringFind(json, ":", p + StringLen(token));
   if(colon < 0) return -1;

   int n = StringLen(json);
   int i = colon + 1;
   while(i < n)
     {
      ushort ch = StringGetCharacter(json, i);
      if(ch != ' ' && ch != '\t' && ch != '\r' && ch != '\n') break;
      i++;
     }
   return i;
  }

double JsonNumber(const string json, const string key, double fallback = 0.0)
  {
   int start = JsonFindValueStart(json, key);
   if(start < 0) return fallback;

   int n = StringLen(json);
   int end = start;
   while(end < n)
     {
      ushort ch = StringGetCharacter(json, end);
      bool numeric = ((ch >= '0' && ch <= '9') || ch == '-' || ch == '+' ||
                      ch == '.' || ch == 'e' || ch == 'E');
      if(!numeric) break;
      end++;
     }
   if(end <= start) return fallback;
   return StringToDouble(StringSubstr(json, start, end - start));
  }

bool JsonBool(const string json, const string key, bool fallback = false)
  {
   int start = JsonFindValueStart(json, key);
   if(start < 0) return fallback;
   string text = StringSubstr(json, start, 8);
   if(StringFind(text, "true")  >= 0) return true;
   if(StringFind(text, "false") >= 0) return false;
   return fallback;
  }

string JsonString(const string json, const string key, string fallback = "")
  {
   int start = JsonFindValueStart(json, key);
   if(start < 0) return fallback;
   if(StringGetCharacter(json, start) != '"') return fallback;

   int n = StringLen(json);
   int end = start + 1;
   while(end < n)
     {
      if(StringGetCharacter(json, end) == '"' &&
         StringGetCharacter(json, end - 1) != '\\') break;
      end++;
     }
   if(end >= n) return fallback;
   return StringSubstr(json, start + 1, end - start - 1);
  }

//===================================================================
// SECTION 13 — HTTP GET
//===================================================================
bool HttpGet(const string url, string &body)
  {
   body = "";
   if(MQLInfoInteger(MQL_TESTER)) return false;

   char data[];
   char result[];
   string headers = "";

   ResetLastError();
   int code = WebRequest("GET", url, "", "", BinanceHttpTimeoutMs,
                         data, 0, result, headers);
   if(code < 0)
     {
      if(VerboseFlow)
         PrintFormat("[HTTP] err=%d url=%s", GetLastError(), url);
      return false;
     }
   body = CharArrayToString(result, 0, -1, CP_UTF8);
   return (code >= 200 && code < 300 && StringLen(body) > 0);
  }

//===================================================================
// SECTION 13A — USD LIVE HYBRID BRIDGE (SOFT DIRECTION + RISK SCALAR)
//===================================================================
bool USDHybrid_SymbolSupported()
  {
   string s=_Symbol;
   StringToUpper(s);
   return (StringFind(s,"EURUSD")>=0 || StringFind(s,"GBPUSD")>=0 ||
           StringFind(s,"USDJPY")>=0 || StringFind(s,"USDCAD")>=0 ||
           StringFind(s,"XAUUSD")>=0 || StringFind(s,"DE40")>=0);
  }

bool USDHybrid_Fresh()
  {
   if(!UseUSDHybridBridge || !USDHybrid_SymbolSupported() || MQLInfoInteger(MQL_TESTER)) return false;
   if(!gUSDHybrid.valid || gUSDHybrid.local_update<=0) return false;
   return (TimeCurrent()-gUSDHybrid.local_update <= MathMax(30,USDHybridMaxAgeSeconds));
  }

double USDHybrid_DirectionBias()
  {
   if(!USDHybrid_Fresh()) return 0.0;
   return Clamp(gUSDHybrid.pair_score,-100.0,100.0);
  }

double USDHybrid_RiskMultiplier()
  {
   if(!UseUSDHybridRiskScaling || !USDHybrid_Fresh()) return 1.0;
   return Clamp(gUSDHybrid.risk_multiplier,0.50,1.0);
  }

double USDHybrid_ScaleRequestedLots(double requestedLots)
  {
   if(requestedLots<=0.0) return 0.0;
   double mult=USDHybrid_RiskMultiplier();
   if(mult<0.999 && VerboseFlow)
      PrintFormat("[USD HYBRID RISK] symbol=%s multiplier=%.3f requested=%.4f scaled=%.4f riskLevel=%.1f",
                  _Symbol,mult,requestedLots,requestedLots*mult,gUSDHybrid.risk_level);
   return requestedLots*mult;
  }

void PollUSDHybridBridge()
  {
   if(!UseUSDHybridBridge || !USDHybrid_SymbolSupported() || MQLInfoInteger(MQL_TESTER)) return;
   if(TimeCurrent()-LastUSDHybridPoll < MathMax(1,USDHybridPollSeconds)) return;
   LastUSDHybridPoll=TimeCurrent();
   string sym=_Symbol;
   StringToUpper(sym);
   string body="";
   if(!HttpGet(USDHybridBaseURL+"/signal?symbol="+sym,body))
     {
      if(gUSDHybrid.local_update<=0 || TimeCurrent()-gUSDHybrid.local_update>MathMax(30,USDHybridMaxAgeSeconds))
         gUSDHybrid.valid=false;
      if(VerboseFlow) PrintFormat("[USD HYBRID] HTTP unavailable url=%s",USDHybridBaseURL);
      return;
     }
   bool ok=JsonBool(body,"ok",false);
   bool stale=JsonBool(body,"stale",true);
   if(!ok || stale)
     {
      gUSDHybrid.valid=false;
      if(VerboseFlow) PrintFormat("[USD HYBRID] ignored unavailable/stale feed symbol=%s",_Symbol);
      return;
     }
   gUSDHybrid.pair_score=JsonNumber(body,"pair_score",0.0);
   gUSDHybrid.usd_strength_score=JsonNumber(body,"usd_strength_score",0.0);
   gUSDHybrid.usd_price_score=JsonNumber(body,"usd_price_score",0.0);
   gUSDHybrid.news_usd_score=JsonNumber(body,"news_usd_score",0.0);
   gUSDHybrid.news_confidence=JsonNumber(body,"news_confidence",0.0);
   gUSDHybrid.risk_level=JsonNumber(body,"risk_level",0.0);
   gUSDHybrid.risk_multiplier=JsonNumber(body,"adaptive_risk_multiplier",1.0);
   gUSDHybrid.price_feed_ok=JsonBool(body,"price_feed_ok",false);
   gUSDHybrid.news_feed_ok=JsonBool(body,"news_feed_ok",false);
   gUSDHybrid.symbol=JsonString(body,"symbol",_Symbol);
   gUSDHybrid.local_update=TimeCurrent();
   gUSDHybrid.valid=true;
   if(VerboseFlow)
      PrintFormat("[USD HYBRID] %s pairScore=%+.1f USD=%+.1f news=%+.1f risk=%.1f lotMult=%.2f price=%d newsOK=%d",
                  _Symbol,gUSDHybrid.pair_score,gUSDHybrid.usd_strength_score,
                  gUSDHybrid.news_usd_score,gUSDHybrid.risk_level,gUSDHybrid.risk_multiplier,
                  (int)gUSDHybrid.price_feed_ok,(int)gUSDHybrid.news_feed_ok);
  }

//===================================================================
// SECTION 14 — DATA HEALTH GATE [A4: log stale stream names]
//===================================================================
void Health_Register(string name, int maxAgeSec)
  {
   if(g_HealthCount >= 8) return;
   g_Health[g_HealthCount].name       = name;
   g_Health[g_HealthCount].maxAgeSec  = maxAgeSec;
   g_Health[g_HealthCount].healthy    = false;
   g_Health[g_HealthCount].lastUpdate = 0;
   g_HealthCount++;
  }

void Health_Init()
  {
   g_HealthCount = 0;
   Health_Register("flow",    HealthMaxAge_Flow);
   Health_Register("vp",      HealthMaxAge_VP);
   Health_Register("vroc",    HealthMaxAge_VROC);
   Health_Register("vwapz",   HealthMaxAge_VWAPZ);
   Health_Register("vpin",    HealthMaxAge_VPIN);
   Health_Register("walls",   HealthMaxAge_Walls);
   Health_Register("funding", HealthMaxAge_Funding);
  }

void Health_Tick(string name)
  {
   for(int i = 0; i < g_HealthCount; i++)
      if(g_Health[i].name == name)
        {
         g_Health[i].lastUpdate = TimeCurrent();
         return;
        }
  }

ENUM_HEALTH Health_Evaluate()
  {
   if(!UseHealthGate)
     { g_HealthState = HEALTH_GREEN; g_HealthReason = "disabled"; return g_HealthState; }
   if(MQLInfoInteger(MQL_TESTER))
     { g_HealthState = HEALTH_GREEN; g_HealthReason = "tester"; return g_HealthState; }

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0 || ask < bid)
     { g_HealthState = HEALTH_BLACK; g_HealthReason = "broker_offline"; return g_HealthState; }

   string hs=_Symbol; StringToUpper(hs);
   bool cryptoHealthSymbol=(StringFind(hs,"BTC")>=0 || StringFind(hs,"ETH")>=0 ||
                            StringFind(hs,"SOL")>=0 || StringFind(hs,"BNB")>=0 ||
                            StringFind(hs,"XRP")>=0 || StringFind(hs,"LTC")>=0 ||
                            StringFind(hs,"XLM")>=0 || StringFind(hs,"ADA")>=0 ||
                            StringFind(hs,"XTZ")>=0 || StringFind(hs,"DOG")>=0);
   if(!cryptoHealthSymbol && !UseBinanceFlow && UseNativePairFlow)
     {
      long qnow=(long)GetTickCount64();
      bool nativeFresh=(gPairFlowCount>=MathMax(3,PairFlowMinSamples) &&
                        gPairFlowLastReceiveMs>0 && qnow>=gPairFlowLastReceiveMs &&
                        qnow-gPairFlowLastReceiveMs<=MathMax(500,PairFlowMaxAgeMs));
      g_HealthState=(nativeFresh?HEALTH_GREEN:HEALTH_YELLOW);
      g_HealthReason=(nativeFresh?"native_quote_flow_fresh":"native_quote_flow_warming_or_stale");
      return g_HealthState;
     }

   datetime now = TimeCurrent();
   int failCount = 0;

   for(int i = 0; i < g_HealthCount; i++)
     {
      if(g_Health[i].lastUpdate == 0)
        { g_Health[i].healthy = false; failCount++; continue; }
      int age = (int)(now - g_Health[i].lastUpdate);
      bool ok = (age <= g_Health[i].maxAgeSec);
      g_Health[i].healthy = ok;
      if(!ok) failCount++;
     }

   if(failCount >= 3)      { g_HealthState = HEALTH_RED;    g_HealthReason = "multi_stale"; }
   else if(failCount == 2) { g_HealthState = HEALTH_YELLOW; g_HealthReason = "dual_stale"; }
   else if(failCount == 1) { g_HealthState = HEALTH_YELLOW; g_HealthReason = "single_stale"; }
   else                    { g_HealthState = HEALTH_GREEN;  g_HealthReason = "healthy"; }

   //--- [A4] Log which stream(s) are stale (once per 60s) ---------------
   static datetime lastHealthLog = 0;
   if(g_HealthState != HEALTH_GREEN && TimeCurrent() - lastHealthLog >= 60)
     {
      lastHealthLog = TimeCurrent();
      string stale = "";
      for(int i = 0; i < g_HealthCount; i++)
        {
         int age = (g_Health[i].lastUpdate == 0)
                   ? 99999
                   : (int)(now - g_Health[i].lastUpdate);
         if(age > g_Health[i].maxAgeSec)
            stale += g_Health[i].name
                   + "(age=" + IntegerToString(age)
                   + "/max=" + IntegerToString(g_Health[i].maxAgeSec) + ") ";
        }
      PrintFormat("[HEALTH-%d] stale: %s", (int)g_HealthState, stale);
     }

   return g_HealthState;
  }

bool Health_AllowsNewEntries()
  {
   if(MQLInfoInteger(MQL_TESTER)) return true;
   if(!UseFactorBFallback) return (g_HealthState <= HEALTH_YELLOW);

   // V2: a live core CVD/flow stream is sufficient to keep Factor A alive.
   // Auxiliary stale feeds reduce optional intelligence but are not a reason
   // to freeze the entire strategy.
   if(V1RiskLayerEnabled && V1CoreFlowSurvivesAuxStale && V1CoreFlowReady())
      return true;

   if(ActiveFactor() == FACTOR_B_FALLBACK) return true;
   return (g_HealthState <= HEALTH_YELLOW);
  }

double Health_SizeMult()
  {
   switch(g_HealthState)
     {
      case HEALTH_GREEN:  return 1.00;
      case HEALTH_YELLOW: return 0.50;
      default:            return 0.00;
     }
  }

//===================================================================
// SECTION 15 — LOT NORMALIZATION & ACCOUNT MODE
//===================================================================
void RefreshLotMeta()
  {
   g_LotMin = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   g_LotMax = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   g_LotStep= SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   if(g_LotMin <= 0.0) g_LotMin = 0.01;
   if(g_LotMax <= 0.0) g_LotMax = 100.0;
   if(g_LotStep<= 0.0) g_LotStep= 0.01;

   if(g_LotStep < 0.001)     g_LotDigits = 4;
   else if(g_LotStep < 0.01) g_LotDigits = 3;
   else                       g_LotDigits = 2;
  }

double NormalizeLots(double lots)
  {
   if(lots <= 0.0) return 0.0;
   double steps = MathFloor(lots / g_LotStep + 1e-9);
   lots = steps * g_LotStep;
   lots = NormalizeDouble(lots, g_LotDigits);
   if(lots < g_LotMin) return 0.0;
   if(lots > g_LotMax) lots = g_LotMax;
   return lots;
  }

double CapPerOrder()
  {
   double b = AccountInfoDouble(ACCOUNT_BALANCE);
   if(b <= 0.0) return g_LotMin;
   double c = b / CapPerOrderDivisor;
   if(c < CapPerOrderMin) c = CapPerOrderMin;
   if(c > CapPerOrderMax) c = CapPerOrderMax;
   return c;
  }

double CapTotalLots()
  {
   double b = AccountInfoDouble(ACCOUNT_BALANCE);
   if(b <= 0.0) return g_LotMin;
   double c = b / CapTotalLots_Divisor;
   if(c < g_LotMin) c = g_LotMin;
   if(c > CapTotalLots_Max) c = CapTotalLots_Max;
   return c;
  }

double ValidateLot(double lot)
  {
   if(lot <= 0.0) return 0.0;
   double em = CapPerOrder();
   if(g_LotMax < em) em = g_LotMax;
   if(em < g_LotMin) em = g_LotMin;

   double steps = MathFloor(lot / g_LotStep + 1e-9);
   lot = steps * g_LotStep;
   lot = NormalizeDouble(lot, g_LotDigits);
   if(lot < g_LotMin) lot = g_LotMin;

   if(lot > em)
     {
      steps = MathFloor(em / g_LotStep + 1e-9);
      lot = steps * g_LotStep;
      lot = NormalizeDouble(lot, g_LotDigits);
     }
   if(lot > g_LotMax) lot = g_LotMax;
   if(lot < g_LotMin) return 0.0;
   return lot;
  }

bool IsCentAccount()
  {
   string cur = AccountInfoString(ACCOUNT_CURRENCY);
   StringToUpper(cur);
   return (cur == "USC");
  }

string AccountModeLabel()
  {
   if(g_ResolvedMode == ACC_CENT)   return "CENT";
   if(g_ResolvedMode == ACC_DOLLAR) return "DOLLAR";
   return "?";
  }

//===================================================================
// SECTION 16 — SPREAD
//===================================================================
void UpdateSpread()
  {
   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0 || ask < bid) return;

   CurrentSpreadPoints = (ask - bid) / _Point;
   SpreadHistory[SpreadIndex % 60] = CurrentSpreadPoints;
   SpreadIndex++;
   if(SpreadCount < 60) SpreadCount++;

   double sum = 0.0;
   for(int i = 0; i < SpreadCount; i++) sum += SpreadHistory[i];
   SpreadAveragePoints = (SpreadCount > 0)
                         ? sum / (double)SpreadCount
                         : CurrentSpreadPoints;
  }

ENUM_V1_ASSET_CLASS V1_DetectAssetClass(string symbol)
  {
   StringToUpper(symbol);
   // Check crypto/metals/indices before FX to avoid substring collisions.
   if(StringFind(symbol,"BTC")>=0 || StringFind(symbol,"ETH")>=0 ||
      StringFind(symbol,"SOL")>=0 || StringFind(symbol,"XRP")>=0 ||
      StringFind(symbol,"BNB")>=0 || StringFind(symbol,"LTC")>=0 ||
      StringFind(symbol,"XLM")>=0 || StringFind(symbol,"ADA")>=0 ||
      StringFind(symbol,"DOG")>=0 || StringFind(symbol,"XTZ")>=0 ||
      StringFind(symbol,"AVAX")>=0 || StringFind(symbol,"DOT")>=0 ||
      StringFind(symbol,"LINK")>=0 || StringFind(symbol,"TRX")>=0)
      return V1_ASSET_CRYPTO;
   if(StringFind(symbol,"XAU")>=0 || StringFind(symbol,"XAG")>=0 ||
      StringFind(symbol,"GOLD")>=0 || StringFind(symbol,"SILVER")>=0)
      return V1_ASSET_METAL;
   if(StringFind(symbol,"DE40")>=0 || StringFind(symbol,"GER40")>=0 ||
      StringFind(symbol,"DAX")>=0 || StringFind(symbol,"US30")>=0 ||
      StringFind(symbol,"US100")>=0 || StringFind(symbol,"NAS100")>=0 ||
      StringFind(symbol,"USTEC")>=0 || StringFind(symbol,"SPX500")>=0 ||
      StringFind(symbol,"US500")>=0 || StringFind(symbol,"UK100")>=0 ||
      StringFind(symbol,"JP225")>=0 || StringFind(symbol,"AUS200")>=0 ||
      StringFind(symbol,"HK50")>=0)
      return V1_ASSET_INDEX;
   if(StringFind(symbol,"EURUSD")>=0 || StringFind(symbol,"GBPUSD")>=0 ||
      StringFind(symbol,"USDJPY")>=0 || StringFind(symbol,"USDCAD")>=0 ||
      StringFind(symbol,"AUDUSD")>=0 || StringFind(symbol,"NZDUSD")>=0 ||
      StringFind(symbol,"USDCHF")>=0 || StringFind(symbol,"EURGBP")>=0 ||
      StringFind(symbol,"EURJPY")>=0 || StringFind(symbol,"GBPJPY")>=0 ||
      StringFind(symbol,"EURCHF")>=0 || StringFind(symbol,"AUDJPY")>=0 ||
      StringFind(symbol,"CADJPY")>=0 || StringFind(symbol,"NZDJPY")>=0 ||
      StringFind(symbol,"CHFJPY")>=0 || StringFind(symbol,"EURAUD")>=0 ||
      StringFind(symbol,"GBPAUD")>=0 || StringFind(symbol,"EURCAD")>=0 ||
      StringFind(symbol,"GBPCAD")>=0 || StringFind(symbol,"AUDCAD")>=0 ||
      StringFind(symbol,"NZDCAD")>=0 || StringFind(symbol,"CADCHF")>=0 ||
      StringFind(symbol,"AUDNZD")>=0 || StringFind(symbol,"EURNZD")>=0 ||
      StringFind(symbol,"GBPNZD")>=0)
      return V1_ASSET_FOREX;
   return V1_ASSET_OTHER;
  }

ENUM_V1_ASSET_CLASS V1_ActiveAssetClass()
  {
   if(V1AssetClassOverride!=V1_ASSET_AUTO) return V1AssetClassOverride;
   if(V1AutoInstrumentProfile) return V1_DetectAssetClass(_Symbol);
   return V1_ASSET_OTHER;
  }

bool V1_IsBitcoinSymbol(string symbol)
  {
   StringToUpper(symbol);
   return (StringFind(symbol,"BTC")>=0);
  }

string V1_AssetClassName(ENUM_V1_ASSET_CLASS cls)
  {
   switch(cls)
     {
      case V1_ASSET_CRYPTO: return "CRYPTO";
      case V1_ASSET_FOREX:  return "FOREX";
      case V1_ASSET_METAL:  return "METAL";
      case V1_ASSET_INDEX:  return "INDEX";
      default:              return "OTHER";
     }
  }

double V1_Profile_MaxSpreadATR()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1MaxSpreadATR_Crypto;
      case V1_ASSET_FOREX:  return V1MaxSpreadATR_Forex;
      case V1_ASSET_METAL:  return V1MaxSpreadATR_Metal;
      case V1_ASSET_INDEX:  return V1MaxSpreadATR_Index;
      default:              return V1MaxSpreadATR_Other;
     }
  }

double V1_Profile_GenesisSLScale()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1GenesisSLScale_Crypto;
      case V1_ASSET_FOREX:  return V1GenesisSLScale_Forex;
      case V1_ASSET_METAL:  return V1GenesisSLScale_Metal;
      case V1_ASSET_INDEX:  return V1GenesisSLScale_Index;
      default:              return V1GenesisSLScale_Other;
     }
  }

double V1_Profile_GenesisTPScale()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1GenesisTPScale_Crypto;
      case V1_ASSET_FOREX:  return V1GenesisTPScale_Forex;
      case V1_ASSET_METAL:  return V1GenesisTPScale_Metal;
      case V1_ASSET_INDEX:  return V1GenesisTPScale_Index;
      default:              return V1GenesisTPScale_Other;
     }
  }

int V1_Profile_RangeLookbackM5()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1CryptoRangeLookbackM5;
      case V1_ASSET_FOREX:  return V1ForexRangeLookbackM5;
      case V1_ASSET_METAL:  return V1MetalRangeLookbackM5;
      case V1_ASSET_INDEX:  return V1IndexRangeLookbackM5;
      default:              return V1RangeLookbackM5;
     }
  }

double V1_Profile_RangeMinWidthATR()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1CryptoRangeMinWidthATR;
      case V1_ASSET_FOREX:  return V1ForexRangeMinWidthATR;
      case V1_ASSET_METAL:  return V1MetalRangeMinWidthATR;
      case V1_ASSET_INDEX:  return V1IndexRangeMinWidthATR;
      default:              return V1RangeMinATR;
     }
  }

double V1_Profile_RangeMaxWidthATR()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1CryptoRangeMaxWidthATR;
      case V1_ASSET_FOREX:  return V1ForexRangeMaxWidthATR;
      case V1_ASSET_METAL:  return V1MetalRangeMaxWidthATR;
      case V1_ASSET_INDEX:  return V1IndexRangeMaxWidthATR;
      default:              return V1RangeMaxATR;
     }
  }

double V1_Profile_RangeLimitRetracePct()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1CryptoRangeLimitRetracePct;
      case V1_ASSET_FOREX:  return V1ForexRangeLimitRetracePct;
      case V1_ASSET_METAL:  return V1MetalRangeLimitRetracePct;
      case V1_ASSET_INDEX:  return V1IndexRangeLimitRetracePct;
      default:              return 0.18;
     }
  }

double V1_Profile_RangeStopBufferATR()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1CryptoRangeStopBufferATR;
      case V1_ASSET_FOREX:  return V1ForexRangeStopBufferATR;
      case V1_ASSET_METAL:  return V1MetalRangeStopBufferATR;
      case V1_ASSET_INDEX:  return V1IndexRangeStopBufferATR;
      default:              return 0.15;
     }
  }

double V1_Profile_RangeLimitSL_ATR()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1CryptoRangeLimitSL_ATR;
      case V1_ASSET_FOREX:  return V1ForexRangeLimitSL_ATR;
      case V1_ASSET_METAL:  return V1MetalRangeLimitSL_ATR;
      case V1_ASSET_INDEX:  return V1IndexRangeLimitSL_ATR;
      default:              return 0.95;
     }
  }

double V1_Profile_RangeStopSL_ATR()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1CryptoRangeStopSL_ATR;
      case V1_ASSET_FOREX:  return V1ForexRangeStopSL_ATR;
      case V1_ASSET_METAL:  return V1MetalRangeStopSL_ATR;
      case V1_ASSET_INDEX:  return V1IndexRangeStopSL_ATR;
      default:              return 1.10;
     }
  }

double V1_Profile_RangeLimitTP_RR()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1CryptoRangeLimitTP_RR;
      case V1_ASSET_FOREX:  return V1ForexRangeLimitTP_RR;
      case V1_ASSET_METAL:  return V1MetalRangeLimitTP_RR;
      case V1_ASSET_INDEX:  return V1IndexRangeLimitTP_RR;
      default:              return 1.35;
     }
  }

double V1_Profile_RangeStopTP_RR()
  {
   switch(V1_ActiveAssetClass())
     {
      case V1_ASSET_CRYPTO: return V1CryptoRangeStopTP_RR;
      case V1_ASSET_FOREX:  return V1ForexRangeStopTP_RR;
      case V1_ASSET_METAL:  return V1MetalRangeStopTP_RR;
      case V1_ASSET_INDEX:  return V1IndexRangeStopTP_RR;
      default:              return 1.80;
     }
  }

bool SpreadOK()
  {
   if(CurrentSpreadPoints >= HardMaxSpreadPoints) return false;
   if(!V1UseATRNormalizedSpreadGuard) return true;
   double atr=CurrentATR5;
   if(atr<=0.0) atr=BufVal(hATR_M5,0,1);
   if(atr<=0.0) return true; // hard spread guard remains the fallback until ATR is available
   double spreadPrice=MathMax(0.0,CurrentSpreadPoints*_Point);
   double maxRatio=MathMax(0.01,V1_Profile_MaxSpreadATR());
   return (spreadPrice/atr <= maxRatio);
  }

double SpreadThrottle()
  {
   if(CurrentSpreadPoints <= SoftSpreadPoints)          return 1.00;
   if(CurrentSpreadPoints <= SoftSpreadPoints * 1.5)    return 0.85;
   if(CurrentSpreadPoints <= SoftSpreadPoints * 2.0)    return 0.55;
   if(CurrentSpreadPoints <= HardMaxSpreadPoints)       return 0.30;
   return 0.0;
  }

//===================================================================
// SECTION 17 — WICK PROTECTION
//===================================================================
void UpdateWickProtection()
  {
   if(!UseWickPause || CurrentATR1 <= 0.0) return;
   double range = TfHigh(PERIOD_M1, 1) - TfLow(PERIOD_M1, 1);
   if(range > CurrentATR1 * ViolentCandleMult)
      LastViolentCandle = TimeCurrent();
  }

bool WickPauseActive()
  {
   if(!UseWickPause || LastViolentCandle == 0) return false;
   return (TimeCurrent() - LastViolentCandle < PostWickPauseSec);
  }

//===================================================================
// SECTION 18 — SESSION / HOUR FILTERS
//===================================================================
bool SessionAllowed()
  {
   if(!AvoidRollover && !UseSessionVeto) return true;
   MqlDateTime dt;
   TimeToStruct(TimeGMT(), dt);
   if(AvoidRollover && (dt.hour == 23 || dt.hour < 1)) return false;
   return true;
  }

bool HourFilterOK()
  {
   if(!UseSessionVeto) return true;
   MqlDateTime dt;
   TimeToStruct(TimeGMT(), dt);
   if(dt.hour >= VetoSkipHour1Start && dt.hour < VetoSkipHour1End) return false;
   if(dt.hour >= VetoSkipHour2Start && dt.hour < VetoSkipHour2End) return false;
   return true;
  }

bool ChaosTriggered()
  {
   if(NormalATR15 <= 0.0 || CurrentATR15 <= 0.0) return false;
   return (CurrentATR15 / NormalATR15 >= M15VetoATRChaosMult);
  }

//===================================================================
// SECTION 19 — SESSION SCORE (Tier 2)
//===================================================================
double SessionSizeMult()
  {
   if(!UseSessionScoreV2) return 1.0;
   MqlDateTime dt;
   TimeToStruct(TimeGMT(), dt);
   int h = dt.hour;
   if(h >= SessionPrimeStartUTC && h < SessionPrimeEndUTC) return SessionPrimeBoost;
   return SessionOffWindowCut;
  }

//===================================================================
// SECTION 20 — RECOVERY STATE HELPERS (Tier 4)
//===================================================================
void Recovery_Reset()
  {
   g_RecoveryAccumulated = 0.0;
   g_RecoveryStreak      = 0;
  }

void Recovery_RegisterLoss(double lossUSD)
  {
   if(!UseRecoveryModeV2) return;
   g_RecoveryAccumulated += MathAbs(lossUSD);
   g_RecoveryStreak++;
   if(g_RecoveryStreak >= RecoveryMaxStreak)
      Recovery_Reset();
  }

void Recovery_RegisterWin()
  {
   if(!UseRecoveryModeV2) return;
   if(RecoveryResetOnAnyWin) Recovery_Reset();
  }

double Recovery_RiskUSD(double baseRiskUSD)
  {
   if(!UseRecoveryModeV2) return baseRiskUSD;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   double cap = eq * RecoveryMaxRiskPctEquity / 100.0;
   double want = g_RecoveryAccumulated + RecoveryTargetUSD;
   if(want <= 0.0) want = baseRiskUSD;
   return MathMin(want, cap);
  }

//===================================================================
// SECTION 21 — MESSAGE BUDGET TICK HELPERS (Tier 3 — legacy compat)
//===================================================================
void MsgBudget_TickOpen()
  {
   // Telemetry only; MsgBudget_ReserveEntryRequest counts the actual request attempt.
   g_DailyOpens++;
  }

void MsgBudget_TickModify()
  {
   // Telemetry only; MsgBudget_Count records the request before it is sent.
   g_DailyModifies++;
  }

void MsgBudget_TickDelete()
  {
   // Telemetry only; MsgBudget_Count records the request before it is sent.
   g_DailyDeletes++;
  }

bool MsgBudget_CanTrade()
  {
   return MsgBudget_CanSend();
  }

void MsgBudget_DailyReset()
  {
   int today = (int)(TimeCurrent() / 86400);
   if(today == g_MsgBudgetResetDay) return;
   g_MsgBudgetResetDay   = today;
   g_DailyOpens          = 0;
   g_DailyModifies       = 0;
   g_DailyDeletes        = 0;
   g_MsgBudgetCount      = MsgBudget_GlobalCount();
   g_MsgBudgetWarnCount  = 0;
  }

//===================================================================
// SECTION 22 — SLIPPAGE ANCHOR MAP (Tier 3)
//===================================================================
void Anchor_Store(string cmt, double reqEntry, double reqSL, double reqTP)
  {
   if(g_AnchorCount >= 200)
     {
      for(int i = 0; i < 199; i++) g_AnchorMap[i] = g_AnchorMap[i + 1];
      g_AnchorCount = 199;
     }
   g_AnchorMap[g_AnchorCount].comment        = cmt;
   g_AnchorMap[g_AnchorCount].requestedEntry = reqEntry;
   g_AnchorMap[g_AnchorCount].requestedSL    = reqSL;
   g_AnchorMap[g_AnchorCount].requestedTP    = reqTP;
   g_AnchorMap[g_AnchorCount].t              = TimeCurrent();
   g_AnchorCount++;
  }

int Anchor_Find(string cmt)
  {
   for(int i = g_AnchorCount - 1; i >= 0; i--)
     {
      if(g_AnchorMap[i].comment == cmt) return i;
      if(TimeCurrent() - g_AnchorMap[i].t > 600) return -1; // 10 min expiry
     }
   return -1;
  }

//===================================================================
// SECTION 23 — BRIDGE POLLING (LIVE) — FLOW
//===================================================================
void ResetFlowState()
  {
   gFlow.valid=false; gFlow.healthy=false; gFlow.local_update=0;
   gFlow.price=0.0; gFlow.flow_score=0.0; gFlow.buy_pct=0.0; gFlow.sell_pct=0.0;
   gFlow.d5=0.0; gFlow.d15=0.0; gFlow.cvd=0.0; gFlow.book=0.0; gFlow.depth=0.0;
   gFlow.trade_rate=0.0; gFlow.buy_rate=0.0; gFlow.sell_rate=0.0;
   gFlow.spread_bps=0.0; gFlow.persistence=0.0; gFlow.velocity=0.0;
   gFlow.acceleration=0.0; gFlow.ofi=0.0; gFlow.persistence_count=0; gFlow.action="";
  }

void ParseFlowJSON(const string json)
  {
   // Reject a crypto flow response unless its market symbol matches this chart profile.
   if(UseBinanceFlow && !MQLInfoInteger(MQL_TESTER))
     {
      string srcSym=JsonString(json,"symbol",""); StringToUpper(srcSym);
      string expectedSym=PairFlow_ExpectedCryptoBridgeSymbol();
      if(expectedSym=="" || srcSym!=expectedSym)
        {
         gFlow.valid=false; gFlow.healthy=false; gFlow.local_update=0;
         PrintFormat("[PAIR FLOW] rejected wrong/missing bridge symbol chart=%s expected=%s received=%s",_Symbol,expectedSym,srcSym);
         return;
        }
     }
   gFlow.valid   = true;
   gFlow.healthy = JsonBool(json, "ok", true);
   gFlow.price = JsonNumber(json, "price", JsonNumber(json, "btc", 0.0));
   gFlow.flow_score = JsonNumber(json, "flow_score", JsonNumber(json, "flow", 0.0));
   gFlow.buy_pct = JsonNumber(json, "buy_pct", JsonNumber(json, "buy", 0.0));
   gFlow.sell_pct = JsonNumber(json, "sell_pct", JsonNumber(json, "sell", 0.0));
   gFlow.d5  = JsonNumber(json, "delta_5s",  JsonNumber(json, "d5", 0.0));
   gFlow.d15 = JsonNumber(json, "delta_15s", JsonNumber(json, "d15", 0.0));
   gFlow.absorption_score = JsonNumber(json, "absorption_score", 0.0);
   gFlow.price_return_5 = JsonNumber(json, "price_return_5", 0.0);
   gFlow.price_return_15 = JsonNumber(json, "price_return_15", 0.0);
   gFlow.cvd = JsonNumber(json, "cvd", 0.0);
   gFlow.book  = JsonNumber(json, "book_imbalance",  JsonNumber(json, "book", 0.0));
   gFlow.depth = JsonNumber(json, "depth_imbalance", JsonNumber(json, "depth", 0.0));
   gFlow.trade_rate = JsonNumber(json, "trade_rate",
                        JsonNumber(json, "trades_per_sec",
                        JsonNumber(json, "tps", 0.0)));
   gFlow.buy_rate  = JsonNumber(json, "buy_rate",  JsonNumber(json, "buy_per_sec", 0.0));
   gFlow.sell_rate = JsonNumber(json, "sell_rate", JsonNumber(json, "sell_per_sec", 0.0));
   gFlow.spread_bps = JsonNumber(json, "spread_bps", 0.0);
   gFlow.persistence = JsonNumber(json, "flow_persistence",
                        JsonNumber(json, "persistence", 0.0));
   gFlow.velocity = JsonNumber(json, "price_velocity",
                     JsonNumber(json, "velocity", 0.0));
   gFlow.acceleration = JsonNumber(json, "price_acceleration",
                         JsonNumber(json, "acceleration", 0.0));
   gFlow.persistence_count = (int)JsonNumber(json, "flow_persistence_count",
                                 JsonNumber(json, "persistence_count", 0.0));
   gFlow.ofi = JsonNumber(json, "ofi", 0.0);
   gFlow.action = JsonString(json, "action", "");
   gFlow.local_update = TimeCurrent();
  }

void PollBinanceFlow()
  {
   if(!UseBinanceFlow) { ResetFlowState(); return; }
   if(MQLInfoInteger(MQL_TESTER)) { ResetFlowState(); return; }
   if(TimeCurrent() - LastFlowPoll < BinancePollSeconds) return;
   LastFlowPoll = TimeCurrent();

   string sig="";
   if(!HttpGet(BinanceBaseURL + "/signal", sig))
     { gFlow.valid=false; gFlow.healthy=false; return; }
   ParseFlowJSON(sig);
   Health_Tick("flow");

   // Optional state endpoint enrichment
   string state="";
   if(HttpGet(BinanceBaseURL + "/state", state))
     {
      if(gFlow.cvd==0.0)        gFlow.cvd        = JsonNumber(state, "cvd", 0.0);
      if(gFlow.price==0.0)      gFlow.price      = JsonNumber(state, "price", 0.0);
      if(gFlow.trade_rate==0.0) gFlow.trade_rate = JsonNumber(state, "trade_rate", 0.0);
     }

   datetime now = TimeCurrent();
   if(PreviousCVDTime > 0 && now > PreviousCVDTime)
     {
      double dt = (double)(now - PreviousCVDTime);
      LocalCVDVelocity = (gFlow.cvd - PreviousCVD) / dt;
      if(PreviousCVDVelocity != 0.0)
         LocalCVDAcceleration = (LocalCVDVelocity - PreviousCVDVelocity) / dt;
      else
         LocalCVDAcceleration = 0.0;
      double scale = MathMax(1.0, MathAbs(gFlow.d15) / 15.0);
      CVDVelocityNormalized     = Clamp(LocalCVDVelocity     / scale, -3.0, 3.0) / 3.0;
      CVDAccelerationNormalized = Clamp(LocalCVDAcceleration / scale, -3.0, 3.0) / 3.0;
     }
   PreviousCVD = gFlow.cvd;
   PreviousCVDVelocity = LocalCVDVelocity;
   PreviousCVDTime = now;
   gFlow.velocity = LocalCVDVelocity;
   gFlow.acceleration = LocalCVDAcceleration;

   FlowRateHistory[FlowRateIndex % 60] = gFlow.trade_rate;
   FlowRateIndex++;
   if(FlowRateCount < 60) FlowRateCount++;

   if(VerboseFlow)
      PrintFormat("[FLOW] ok=%d price=%.2f flow=%.1f CVDv=%.3f CVDa=%.3f persist=%.2f",
                  (int)gFlow.healthy, gFlow.price, gFlow.flow_score,
                  CVDVelocityNormalized, CVDAccelerationNormalized, gFlow.persistence);
  }

//===================================================================
// SECTION 24 — BRIDGE POLLING — VOLUME PROFILE (bridge-fed)
//===================================================================
void PollBinanceVP()
  {
   if(!UseBinanceFlow || MQLInfoInteger(MQL_TESTER)) return;
   if(TimeCurrent() - LastVPPoll < 5) return;
   LastVPPoll = TimeCurrent();

   string body="";
   if(!HttpGet(BinanceBaseURL + "/vp", body)) { gBinVP.valid=false; return; }

   gBinVP.poc       = JsonNumber(body, "poc", 0.0);
   gBinVP.vah       = JsonNumber(body, "vah", 0.0);
   gBinVP.val       = JsonNumber(body, "val", 0.0);
   gBinVP.width_pct = JsonNumber(body, "width_pct", 0.0);
   gBinVP.min_p     = JsonNumber(body, "min_p", 0.0);
   gBinVP.max_p     = JsonNumber(body, "max_p", 0.0);
   gBinVP.valid     = (gBinVP.poc > 0.0 && gBinVP.vah > gBinVP.val);
   gBinVP.local_update = TimeCurrent();
   if(gBinVP.valid) Health_Tick("vp");
  }

//===================================================================
// SECTION 25 — ADVANCED FLOW PARSER
//===================================================================
void VNParseAdvancedFlowJSON(const string json)
  {
   if(json == "") return;
   gBinAux.long_short_ratio = JsonNumber(json, "long_short_ratio",
                              JsonNumber(json, "ls_ratio", gBinAux.long_short_ratio));
   double lb = JsonNumber(json, "liquidation_buy",
                JsonNumber(json, "liq_buy",  gBinAux.liquidation_buy));
   double ls = JsonNumber(json, "liquidation_sell",
                JsonNumber(json, "liq_sell", gBinAux.liquidation_sell));
   gBinAux.liquidation_buy  = lb;
   gBinAux.liquidation_sell = ls;
   double denom = MathAbs(lb) + MathAbs(ls);
   if(denom > 0.0) gBinAux.liquidation_imbalance = (lb - ls) / denom;
   else            gBinAux.liquidation_imbalance = 0.0;
  }

//===================================================================
// SECTION 26 — BRIDGE POLLING — AUX (vroc / vwap / walls / funding)
//===================================================================
void PollBinanceAux()
  {
   if(!UseBinanceFlow || MQLInfoInteger(MQL_TESTER)) return;
   if(TimeCurrent() - LastAuxPoll < BridgeAuxPollSeconds) return;
   LastAuxPoll = TimeCurrent();

   string b="";

   if(HttpGet(BinanceBaseURL + "/vroc", b))
     {
      gBinAux.vroc           = JsonNumber(b, "vroc", 0.0);
      gBinAux.range_exp      = JsonNumber(b, "range_exp", 0.0);
      gBinAux.atr_m1         = JsonNumber(b, "atr_m1", 0.0);
      gBinAux.vroc_sustained = JsonBool  (b, "vroc_sustained", false);
      Health_Tick("vroc");
     }

   if(HttpGet(BinanceBaseURL + "/vwap", b))
     {
      gBinAux.vwap       = JsonNumber(b, "vwap", 0.0);
      gBinAux.vwap_slope = JsonNumber(b, "slope", 0.0);
     }

   if(HttpGet(BinanceBaseURL + "/walls", b))
     {
      gBinAux.bid_wall_price = JsonNumber(b, "bid_wall_price", 0.0);
      gBinAux.bid_wall_size  = JsonNumber(b, "bid_wall_size", 0.0);
      gBinAux.ask_wall_price = JsonNumber(b, "ask_wall_price", 0.0);
      gBinAux.ask_wall_size  = JsonNumber(b, "ask_wall_size", 0.0);
      Health_Tick("walls");
     }

   if(HttpGet(BinanceBaseURL + "/funding", b))
     {
      gBinAux.funding     = JsonNumber(b, "funding", 0.0);
      gBinAux.oi          = JsonNumber(b, "oi", 0.0);
      gBinAux.oi_delta_1m = JsonNumber(b, "oi_delta_1m", 0.0);
      VNParseAdvancedFlowJSON(b);
      Health_Tick("funding");
     }

   if(HttpGet(BinanceBaseURL + "/futures", b))
      VNParseAdvancedFlowJSON(b);

   if(HttpGet(BinanceBaseURL + "/liquidations", b))
      VNParseAdvancedFlowJSON(b);

   gBinAux.valid = (gBinAux.vroc > 0.0 || gBinAux.vwap > 0.0);
   gBinAux.local_update = TimeCurrent();
  }

//===================================================================
// SECTION 27 — BRIDGE POLLING — VPIN / OI REGIME / NAKED POC / VWAP-Z
//===================================================================
void PollBinanceVPIN()
  {
   if(!UseBinanceFlow || MQLInfoInteger(MQL_TESTER)) return;
   if(TimeCurrent() - LastVPINPoll < BridgeVPINPollSeconds) return;
   LastVPINPoll = TimeCurrent();

   string b="";

   if(HttpGet(BinanceBaseURL + "/vpin", b))
     {
      gBinAux.vpin          = JsonNumber(b, "vpin", 0.0);
      gBinAux.vpin_pct      = JsonNumber(b, "vpin_pct", 0.0);
      gBinAux.vpin_pressure = JsonNumber(b, "pressure", 50.0);
      string regime = JsonString(b, "regime", "Quiet");
      if(regime=="Burst")         gBinAux.vpin_regime=3;
      else if(regime=="Elevated") gBinAux.vpin_regime=2;
      else if(regime=="Normal")   gBinAux.vpin_regime=1;
      else                         gBinAux.vpin_regime=0;
      Health_Tick("vpin");
     }

   if(HttpGet(BinanceBaseURL + "/oiregime", b))
     {
      string regime = JsonString(b, "regime", "NEUTRAL");
      if(regime=="NEW_LONGS")             gBinAux.oi_regime=1;
      else if(regime=="SHORT_COVERING")   gBinAux.oi_regime=2;
      else if(regime=="NEW_SHORTS")       gBinAux.oi_regime=3;
      else if(regime=="LONG_LIQUIDATION") gBinAux.oi_regime=4;
      else                                 gBinAux.oi_regime=0;
     }

   if(HttpGet(BinanceBaseURL + "/nakedpoc", b))
     {
      gBinAux.naked_above = JsonNumber(b, "nearest_above", 0.0);
      gBinAux.naked_below = JsonNumber(b, "nearest_below", 0.0);
      gBinAux.naked_count = (int)JsonNumber(b, "count", 0.0);
     }

   if(HttpGet(BinanceBaseURL + "/vwapz", b))
     {
      gBinAux.rolling_vwap   = JsonNumber(b, "vwap", 0.0);
      gBinAux.vwap_stdev     = JsonNumber(b, "stdev", 0.0);
      gBinAux.vwap_z         = JsonNumber(b, "z", 0.0);
      gBinAux.vwap_exhausted = JsonBool  (b, "exhausted", false);
      Health_Tick("vwapz");
     }
  }

//===================================================================
// SECTION 28 — FLOW COMPOSITE / FRESHNESS / GATES
//===================================================================
//---------------- BGBI PAIR FLOW ADAPTER ---------------------------
bool PairFlow_IsCryptoChart()
  {
   return (V1_DetectAssetClass(_Symbol)==V1_ASSET_CRYPTO);
  }

string PairFlow_ExpectedCryptoBridgeSymbol()
  {
   string s=ExpectedSymbolProfile;
   StringToUpper(s);
   if(s=="" || s=="AUTO") s=_Symbol;
   StringToUpper(s);
   // Trim broker suffix at first supported delimiter.
   int n=StringLen(s);
   for(int i=0;i<n;i++)
     {
      ushort ch=StringGetCharacter(s,i);
      if(ch=='.' || ch=='_' || ch=='-' || ch=='#') { s=StringSubstr(s,0,i); break; }
     }
   if(s=="BTCUSD") return "BTCUSDT";
   if(s=="ETHUSD") return "ETHUSDT";
   if(s=="SOLUSD") return "SOLUSDT";
   if(s=="BNBUSD") return "BNBUSDT";
   if(s=="XRPUSD") return "XRPUSDT";
   if(s=="LTCUSD") return "LTCUSDT";
   if(s=="XLMUSD") return "XLMUSDT";
   if(s=="ADAUSD") return "ADAUSDT";
   if(s=="XTZUSD") return "XTZUSDT";
   if(s=="DOGUSD" || s=="DOGEUSD") return "DOGEUSDT";
   return "";
  }

bool PairFlow_NativeFresh()
  {
   if(!UseNativePairFlow || gPairFlowCount<MathMax(3,PairFlowMinSamples) || gPairFlowLastReceiveMs<=0) return false;
   long now=(long)GetTickCount64();
   if(now<gPairFlowLastReceiveMs) return false;
   return (now-gPairFlowLastReceiveMs <= MathMax(500,PairFlowMaxAgeMs));
  }

void PairFlow_UpdateNative()
  {
   if(!UseNativePairFlow) return;
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol,tick)) return;
   if(tick.bid<=0.0 || tick.ask<tick.bid) return;
   double mid=(tick.bid+tick.ask)*0.5;
   if(mid<=0.0) return;
   long now=(long)GetTickCount64();
   gPairFlowLastReceiveMs=now;
   gPairFlowMid[gPairFlowHead]=mid;
   gPairFlowTimeMs[gPairFlowHead]=now;
   gPairFlowHead=(gPairFlowHead+1)%64;
   if(gPairFlowCount<64) gPairFlowCount++;

   datetime sec=TimeCurrent();
   if(sec!=gPairFlowLastEvalSec)
     {
      gPairFlowLastEvalSec=sec;
      double sc=PairFlow_NativeScore();
      int side=(sc>=PairFlowMinConfirmScore)?1:((sc<=-PairFlowMinConfirmScore)?-1:0);
      if(side!=0 && side==gPairFlowLastDir) gPairFlowPersistence++;
      else if(side!=0) { gPairFlowLastDir=side; gPairFlowPersistence=1; }
      else { gPairFlowLastDir=0; gPairFlowPersistence=0; }
      gPairFlowCachedScore=sc;
     }
  }

double PairFlow_NativeScore()
  {
   if(gPairFlowCount<3) return 0.0;
   int n=MathMax(3,MathMin(PairFlowLookbackTicks,MathMin(63,gPairFlowCount-1)));
   int last=(gPairFlowHead-1+64)%64;
   int up=0,down=0;
   for(int k=n;k>=1;k--)
     {
      int a=(last-k+64)%64;
      int b=(last-k+1+64)%64;
      double d=gPairFlowMid[b]-gPairFlowMid[a];
      double dead=_Point*0.05;
      if(d>dead) up++; else if(d< -dead) down++;
     }
   double tape=0.0;
   if(up+down>0) tape=100.0*(double)(up-down)/(double)(up+down);
   int oldest=(last-n+64)%64;
   double move=gPairFlowMid[last]-gPairFlowMid[oldest];
   double atr=(CurrentATR1>0.0)?CurrentATR1:((CurrentATR5>0.0)?CurrentATR5:0.0);
   double spread=MathMax(0.0,CurrentSpreadPoints*_Point);
   double scale=MathMax(MathMax(atr*0.08,spread*2.0),_Point*3.0);
   double momentum=(scale>0.0)?Clamp(move/scale*40.0,-100.0,100.0):0.0;
   return Clamp(tape*0.62+momentum*0.38,-100.0,100.0);
  }

bool PairFlow_UseNativeNow()
  {
   if(!UseNativePairFlow) return false;
   if(!UseBinanceFlow || MQLInfoInteger(MQL_TESTER)) return true;
   bool extFresh=(gFlow.valid && gFlow.healthy && gFlow.local_update>0 &&
                  TimeCurrent()-gFlow.local_update<=BinanceMaxAgeSeconds);
   return (!extFresh && AllowNativePairFlowFallbackWhenBridgeDown);
  }

double PairFlow_ScoreForSide(int dir)
  {
   if(dir==0) return 0.0;
   if(PairFlow_UseNativeNow()) return PairFlow_NativeScore()*(double)dir;
   if(UseBinanceFlow && gFlow.valid && gFlow.healthy && gFlow.local_update>0 &&
      TimeCurrent()-gFlow.local_update<=BinanceMaxAgeSeconds) return FlowComposite()*(double)dir;
   return 0.0;
  }

bool PairFlow_AbsorptionSupportsDirection(int dir)
  {
   if(dir==0 || !UseBinanceFlow || MQLInfoInteger(MQL_TESTER)) return false;
   if(!gFlow.valid || !gFlow.healthy || gFlow.local_update<=0 ||
      TimeCurrent()-gFlow.local_update>BinanceMaxAgeSeconds) return false;
   if(gFlow.absorption_score<PairFlowAbsorptionMinScore) return false;
   // The bridge's absorption_score is a proxy (not hidden-liquidity truth). It may
   // support a strong pending STOP only if price is not already moving hard against it.
   if(dir==1) return (gFlow.price_return_5 >= -MathAbs(PairFlowAbsorptionMaxCounterReturnPct));
   return (gFlow.price_return_5 <= MathAbs(PairFlowAbsorptionMaxCounterReturnPct));
  }

bool PairFlow_AllowsDirection(int dir,int setupType)
  {
   // setupType: 0 continuation/impulse, 1 reversal, 2 range rotation.
   if(dir==0) return false;
   if(FlowMode==FLOW_OFF) return true;

   long fastNow=(long)GetTickCount64();
   bool fastSupport=(setupType==0 && UseCryptoFastReaction && UseBinanceFlow &&
                     !MQLInfoInteger(MQL_TESTER) && PairFlow_IsCryptoChart() &&
                     gCryptoFastValid && gCryptoFastDir==dir && gCryptoFastScore>=CryptoFastMinScore &&
                     gCryptoFastReceiveMs>0 && fastNow>=gCryptoFastReceiveMs &&
                     fastNow-gCryptoFastReceiveMs<=MathMax(500,CryptoFastSignalMaxAgeMs));

   if(PairFlow_UseNativeNow())
     {
      if(!PairFlow_NativeFresh()) return (FlowMode!=FLOW_REQUIRED);
      double side=PairFlow_NativeScore()*(double)dir;
      bool persistent=(gPairFlowPersistence>=MathMax(1,PairFlowMinPersistenceSamples));
      bool supported=((side>=PairFlowMinConfirmScore && persistent) || side>=PairFlowStrongConfirmScore);
      if(setupType==0)
        {
         if(FlowMode==FLOW_REQUIRED) return (supported || fastSupport);
         if(FlowMode==FLOW_VETO) return (side>-55.0);
         // FLOW_CONFIRM: quote-pressure neutrality is not a veto; strong counterpressure is.
         return (side>-PairFlowMaxCounterPressure || fastSupport);
        }
      if(setupType==1)
        {
         if(FlowMode==FLOW_REQUIRED) return (supported || g_GI.reversalProbability>=GenesisIntelReversalTrigger);
         return (side>-PairFlowMaxCounterPressure || g_GI.reversalProbability>=GenesisIntelReversalTrigger);
        }
      if(FlowMode==FLOW_REQUIRED) return supported;
      if(FlowMode==FLOW_VETO) return (side>-55.0);
      return (side>-PairFlowMaxCounterPressure);
     }

   if(UseBinanceFlow && !MQLInfoInteger(MQL_TESTER))
     {
      bool fresh=(gFlow.valid && gFlow.healthy && gFlow.local_update>0 &&
                  TimeCurrent()-gFlow.local_update<=BinanceMaxAgeSeconds);
      if(!fresh) return (FlowMode!=FLOW_REQUIRED);
      double side=FlowComposite()*(double)dir;
      bool supported=((side>=BinanceMinFlowScore && gFlow.persistence>=BinanceMinPersistence) ||
                     side>=BinanceStrongFlowScore);
      if(setupType==0)
        {
         if(FlowMode==FLOW_REQUIRED) return (supported || fastSupport);
         if(FlowMode==FLOW_VETO) return (side>-55.0);
         return (side>-PairFlowMaxCounterPressure || fastSupport);
        }
      if(setupType==1)
        {
         if(FlowMode==FLOW_REQUIRED) return (supported || g_GI.reversalProbability>=GenesisIntelReversalTrigger);
         return (side>-PairFlowMaxCounterPressure || g_GI.reversalProbability>=GenesisIntelReversalTrigger);
        }
      if(FlowMode==FLOW_REQUIRED) return supported;
      if(FlowMode==FLOW_VETO) return (side>-55.0);
      return (side>-PairFlowMaxCounterPressure);
     }

   // No usable flow source: only FLOW_REQUIRED blocks on unavailability.
   return (FlowMode!=FLOW_REQUIRED);
  }

bool PairFlow_CryptoFastSupports(int dir)
  {
   if(!UseCryptoFastReaction || !UseBinanceFlow || MQLInfoInteger(MQL_TESTER) || !PairFlow_IsCryptoChart()) return false;
   if(!gCryptoFastValid || gCryptoFastDir!=dir || gCryptoFastScore<CryptoFastMinScore) return false;
   long now=(long)GetTickCount64();
   return (gCryptoFastReceiveMs>0 && now>=gCryptoFastReceiveMs && now-gCryptoFastReceiveMs<=MathMax(500,CryptoFastSignalMaxAgeMs));
  }

void PollCryptoFastReaction()
  {
   if(!UseCryptoFastReaction || !UseBinanceFlow || MQLInfoInteger(MQL_TESTER) || !PairFlow_IsCryptoChart())
     { gCryptoFastValid=false; gCryptoFastDir=0; return; }
   if(TimeCurrent()-LastCryptoFastPoll<1) return;
   LastCryptoFastPoll=TimeCurrent();
   string body="";
   if(!HttpGet(BinanceBaseURL+"/fast",body)) { gCryptoFastValid=false; gCryptoFastDir=0; return; }
   string src=JsonString(body,"symbol","");
   StringToUpper(src);
   string expected=PairFlow_ExpectedCryptoBridgeSymbol();
   if(expected=="" || src!=expected)
     { gCryptoFastValid=false; gCryptoFastDir=0; PrintFormat("[PAIR FLOW] fast-symbol mismatch chart=%s expected=%s received=%s",_Symbol,expected,src); return; }
   bool ok=JsonBool(body,"ok",false);
   string act=JsonString(body,"active_action","NEUTRAL");
   long age=(long)JsonNumber(body,"signal_age_ms",999999.0);
   double score=JsonNumber(body,"score",0.0);
   int dir=0;
   if(act=="BUY_CANDIDATE") dir=1;
   else if(act=="SELL_CANDIDATE") dir=-1;
   if(!ok || age>MathMax(500,CryptoFastSignalMaxAgeMs) || dir==0 || score<CryptoFastMinScore)
     { gCryptoFastValid=false; gCryptoFastDir=0; gCryptoFastScore=score; gCryptoFastSignalAgeMs=age; return; }
   gCryptoFastValid=true; gCryptoFastDir=dir; gCryptoFastScore=score;
   gCryptoFastReceiveMs=(long)GetTickCount64(); gCryptoFastSignalAgeMs=age;
  }

bool FlowFresh()
  {
   if(!UseBinanceFlow) return (UseNativePairFlow ? PairFlow_NativeFresh() : true);
   if(MQLInfoInteger(MQL_TESTER)) return (UseNativePairFlow ? PairFlow_NativeFresh() : true);
   if(!gFlow.valid || !gFlow.healthy) return false;
   if(gFlow.local_update == 0) return false;
   return (TimeCurrent() - gFlow.local_update <= BinanceMaxAgeSeconds);
  }

bool BridgeReady()
  {
   if(MQLInfoInteger(MQL_TESTER))    return false;
   if(!UseBinanceFlow)                return false;
   if(!gBinAux.valid)                 return false;
   if(!FlowFresh())                   return false;
   if(g_HealthState > HEALTH_YELLOW)  return false;
   return true;
  }

double FlowComposite()
  {
   if(PairFlow_UseNativeNow()) return PairFlow_NativeScore();
   if(!gFlow.valid) return 0.0;
   double bridge = gFlow.flow_score;
   double book   = gFlow.book  * 100.0;
   double depth  = gFlow.depth * 100.0;
   double cvd    = CVDVelocityNormalized * 100.0;
   const double wB = 0.60, wK = 0.15, wD = 0.15, wC = 0.10;
   double denom = wB + wK + wD + wC;
   double result = (bridge*wB + book*wK + depth*wD + cvd*wC) / denom;
   result += CVDAccelerationNormalized * 5.0;
   return Clamp(result, -100.0, 100.0);
  }

int FlowDirection()
  {
   double score = FlowComposite();
   if(score >=  BinanceMinFlowScore) return  1;
   if(score <= -BinanceMinFlowScore) return -1;
   return 0;
  }

bool Flow_Agrees(int dir, bool strong)
  {
   if(FlowMode==FLOW_OFF || dir==0) return true;
   if(PairFlow_UseNativeNow())
     {
      if(!PairFlow_NativeFresh()) return (FlowMode==FLOW_VETO);
      double fc=PairFlow_NativeScore()*(double)dir;
      double threshold=strong?PairFlowStrongConfirmScore:PairFlowMinConfirmScore;
      bool persistent=(gPairFlowPersistence>=MathMax(1,PairFlowMinPersistenceSamples));
      if((fc>=threshold && persistent) || fc>=PairFlowStrongConfirmScore) return true;
      return (FlowMode==FLOW_VETO);
     }
   if(!UseBinanceFlow) return true;
   if(MQLInfoInteger(MQL_TESTER)) return true;
   if(!FlowFresh()) return (FlowMode==FLOW_VETO);
   double fc=FlowComposite()*(double)dir;
   double threshold=strong?BinanceStrongFlowScore:BinanceMinFlowScore;
   if(fc>=threshold && gFlow.persistence>=BinanceMinPersistence) return true;
   if(FlowMode==FLOW_CONFIRM && fc>-BinanceStrongFlowScore) return true;
   if(FlowMode==FLOW_VETO) return true;
   return false;
  }

bool Flow_NotOpposed(int dir)
  {
   if(dir==0 || FlowMode==FLOW_OFF) return true;
   if(PairFlow_UseNativeNow())
     {
      if(!PairFlow_NativeFresh()) return (FlowMode==FLOW_VETO);
      return (PairFlow_NativeScore()*(double)dir > -PairFlowMaxCounterPressure);
     }
   if(!UseBinanceFlow) return true;
   if(MQLInfoInteger(MQL_TESTER)) return true;
   if(!FlowFresh()) return (FlowMode==FLOW_VETO);
   return (FlowComposite()*(double)dir > -BinanceStrongFlowScore);
  }

bool FlowVetoes(int dir)
  {
   if(dir==0 || FlowMode==FLOW_OFF) return false;
   if(PairFlow_UseNativeNow())
     {
      if(!PairFlow_NativeFresh()) return false;
      return (PairFlow_NativeScore()*(double)dir <= -PairFlowMaxCounterPressure);
     }
   if(!UseBinanceFlow || MQLInfoInteger(MQL_TESTER) || !FlowFresh()) return false;
   return (FlowComposite()*(double)dir <= -55.0);
  }

double AverageFlowTradeRate()
  {
   if(FlowRateCount <= 0) return 0.0;
   double sum = 0.0;
   for(int i = 0; i < FlowRateCount; i++) sum += FlowRateHistory[i];
   return sum / (double)FlowRateCount;
  }

bool VNFlowTradeRateSurge()
  {
   if(!FlowFresh()) return false;
   if(gFlow.trade_rate <= 0.0 || FlowRateCount < 10) return false;
   double avg = AverageFlowTradeRate();
   if(avg <= 0.0) return false;
   return (gFlow.trade_rate >= avg * 1.40);
  }

bool VNFlowCVDAccelerationStrong(int dir)
  {
   if(!FlowFresh() || dir == 0) return false;
   return (CVDAccelerationNormalized * (double)dir >= 0.20);
  }

bool VNFlowCascade(int dir)
  {
   if(!BridgeReady() || dir == 0) return false;
   double liq = gBinAux.liquidation_imbalance * (double)dir;
   if(MathAbs(gBinAux.liquidation_imbalance) > 0.0 && liq > 0.25) return true;
   if(gBinAux.vpin_regime >= 3 && VNFlowTradeRateSurge()) return true;
   return false;
  }

bool WallInPath(int dir)
  {
   if(!BridgeReady()) return false;
   double mid = MidPrice();
   if(mid <= 0.0) return false;
   if(dir ==  1 && gBinAux.ask_wall_price > 0.0)
     {
      double d = (gBinAux.ask_wall_price - mid) / _Point;
      if(d > 0.0 && d < 150.0) return true;
     }
   if(dir == -1 && gBinAux.bid_wall_price > 0.0)
     {
      double d = (mid - gBinAux.bid_wall_price) / _Point;
      if(d > 0.0 && d < 150.0) return true;
     }
   return false;
  }

//===================================================================
// SECTION 29 — VWAP HELPERS (bridge + internal fallback)
//===================================================================
double GetVWAPZ()
  {
   if(gBinAux.valid && gBinAux.rolling_vwap > 0.0) return gBinAux.vwap_z;
   return g_InternalVWAPZ;
  }

double GetVWAPValue()
  {
   if(gBinAux.valid && gBinAux.rolling_vwap > 0.0) return gBinAux.rolling_vwap;
   return g_InternalVWAP;
  }

bool GetVWAPExhausted()
  {
   if(gBinAux.valid && gBinAux.rolling_vwap > 0.0) return gBinAux.vwap_exhausted;
   return g_InternalExhaust;
  }

//===================================================================
// SECTION 30 — VOLUME PROFILE HELPERS
//===================================================================
bool VPCompressed()
  {
   if(gBinVP.valid) return (gBinVP.width_pct < VP_CompressMaxPct);
   if(g_NVP.valid)  return (g_NVP.vaWidthPct < VP_CompressMaxPct);
   return false;
  }

bool VPPriceInVA()
  {
   double mid = MidPrice();
   if(mid <= 0.0) return false;
   if(gBinVP.valid) return (mid >= gBinVP.val && mid <= gBinVP.vah);
   if(g_NVP.valid)  return (mid >= g_NVP.val && mid <= g_NVP.vah);
   return false;
  }

double VPPositionInVA()
  {
   double mid = MidPrice();
   if(mid <= 0.0) return -1.0;
   if(gBinVP.valid)
     {
      double width = gBinVP.vah - gBinVP.val;
      if(width <= 0.0) return -1.0;
      return (mid - gBinVP.val) / width;
     }
   if(g_NVP.valid)
     {
      double width = g_NVP.vah - g_NVP.val;
      if(width <= 0.0) return -1.0;
      return (mid - g_NVP.val) / width;
     }
   return -1.0;
  }

//===================================================================
// SECTION 31 — FUNDING / OI / LS HELPERS
//===================================================================
int FundingBias()
  {
   if(!gBinAux.valid) return 0;
   if(gBinAux.funding >  0.0005) return -1;
   if(gBinAux.funding < -0.0005) return  1;
   return 0;
  }

bool NearNakedPOC(int dir)
  {
   if(!gBinAux.valid) return false;
   if(gBinAux.naked_count <= 0) return false;
   double mid = MidPrice();
   if(mid <= 0.0) return false;
   double atr = CurrentATR5;
   if(atr <= 0.0) atr = CurrentATR1;
   if(atr <= 0.0) return false;
   double threshold = atr * 0.3;

   if(dir == 1 && gBinAux.naked_below > 0.0)
      if(mid - gBinAux.naked_below <= threshold &&
         mid >= gBinAux.naked_below) return true;

   if(dir == -1 && gBinAux.naked_above > 0.0)
      if(gBinAux.naked_above - mid <= threshold &&
         mid <= gBinAux.naked_above) return true;

   return false;
  }

//===================================================================
// SECTION 32 — NATIVE VOLUME PROFILE (200-bar M1 build)
//===================================================================
void BuildNativeVP()
  {
   g_NVP.valid = false;
   int bins = MathMin(VP_Bins, 40);
   if(Bars(_Symbol, PERIOD_M1) < VP_LookbackBars + 10) return;

   double high = -1e18, low = 1e18;
   for(int i = 0; i < VP_LookbackBars; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      if(h <= 0.0 || l <= 0.0) continue;
      if(h > high) high = h;
      if(l < low)  low  = l;
     }
   if(high <= low) return;

   g_NVP.minP = low;
   g_NVP.maxP = high;
   g_NVP.binSize = (high - low) / (double)bins;
   for(int i = 0; i < bins; i++) g_NVP.bins[i] = 0.0;
   g_NVP.totalVol = 0.0;

   for(int i = 0; i < VP_LookbackBars; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      double v = (double)TfVolume(PERIOD_M1, i);
      if(h <= l || v <= 0.0) continue;
      double barRange = h - l;
      for(int b = 0; b < bins; b++)
        {
         double binLo = g_NVP.minP + b * g_NVP.binSize;
         double binHi = binLo + g_NVP.binSize;
         double ovl   = MathMin(h, binHi) - MathMax(l, binLo);
         if(ovl > 0.0) g_NVP.bins[b] += v * (ovl / barRange);
        }
     }

   double maxVol = 0.0;
   int pocIdx = 0;
   for(int i = 0; i < bins; i++)
     {
      g_NVP.totalVol += g_NVP.bins[i];
      if(g_NVP.bins[i] > maxVol) { maxVol = g_NVP.bins[i]; pocIdx = i; }
     }
   if(g_NVP.totalVol <= 0.0) return;
   g_NVP.poc = g_NVP.minP + (pocIdx + 0.5) * g_NVP.binSize;

   double target = g_NVP.totalVol * VP_ValueAreaPct / 100.0;
   int left = pocIdx, right = pocIdx;
   double cum = g_NVP.bins[pocIdx];
   while(cum < target && (left > 0 || right < bins - 1))
     {
      double lv = (left  > 0)        ? g_NVP.bins[left - 1]  : -1.0;
      double rv = (right < bins - 1) ? g_NVP.bins[right + 1] : -1.0;
      if(rv >= lv && right < bins - 1) { right++; cum += g_NVP.bins[right]; }
      else if(left > 0)                 { left--;  cum += g_NVP.bins[left]; }
      else break;
     }
   g_NVP.val = g_NVP.minP + left * g_NVP.binSize;
   g_NVP.vah = g_NVP.minP + (right + 1) * g_NVP.binSize;
   if(g_NVP.poc > 0.0) g_NVP.vaWidthPct = (g_NVP.vah - g_NVP.val) / g_NVP.poc * 100.0;
   else                g_NVP.vaWidthPct = 100.0;
   g_NVP.valid = true;
  }

bool NativeVPPriceInVA()
  {
   if(!g_NVP.valid) return false;
   double m = MidPrice();
   return (m >= g_NVP.val && m <= g_NVP.vah);
  }

bool NativeVPCompressed()
  {
   if(!g_NVP.valid) return false;
   return (g_NVP.vaWidthPct < VP_CompressMaxPct);
  }

double NativeVPPositionInVA()
  {
   if(!g_NVP.valid) return -1.0;
   double width = g_NVP.vah - g_NVP.val;
   if(width <= 0.0) return -1.0;
   return (MidPrice() - g_NVP.val) / width;
  }

//===================================================================
// SECTION 33 — INTERNAL VWAP-Z (fallback when bridge silent)
//===================================================================
void ComputeInternalVWAPZ()
  {
   datetime nowBar = TfTime(PERIOD_M1, 0);
   if(nowBar == 0 || nowBar == g_InternalVWAPTime) return;
   g_InternalVWAPTime = nowBar;
   if(Bars(_Symbol, PERIOD_M1) < 80) return;

   double pv=0.0, volSum=0.0;
   double typicals[60];
   for(int i = 0; i < 60; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      double c = TfClose(PERIOD_M1, i);
      long   v = TfVolume(PERIOD_M1, i);
      if(h<=0.0||l<=0.0||c<=0.0||v<=0) return;
      double t = (h + l + c) / 3.0;
      typicals[i] = t;
      pv += t * (double)v;
      volSum += (double)v;
     }
   if(volSum <= 0.0) return;
   double vwap = pv / volSum;

   double varSum = 0.0;
   for(int i = 0; i < 60; i++)
     {
      long v = TfVolume(PERIOD_M1, i);
      double diff = typicals[i] - vwap;
      varSum += diff * diff * (double)v;
     }
   double variance = varSum / volSum;
   double sd = (variance > 0.0) ? MathSqrt(variance) : 0.0;

   double price = MidPrice();
   if(price <= 0.0) return;
   double z = (sd > 0.0) ? (price - vwap) / sd : 0.0;

   double avgVol = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      long v = TfVolume(PERIOD_M1, i);
      if(v > 0) { avgVol += (double)v; cnt++; }
     }
   if(cnt > 0) avgVol /= (double)cnt;
   long curVol = TfVolume(PERIOD_M1, 0);
   bool exhausted = (avgVol > 0.0 && (double)curVol < avgVol * 0.5);

   g_InternalVWAP    = vwap;
   g_InternalVWAPSD  = sd;
   g_InternalVWAPZ   = z;
   g_InternalExhaust = exhausted;
  }

//===================================================================
// SECTION 34 — M5 VWAP + KAMA + OBV + VOL SURGE + JERK
//===================================================================
void CalculateVWAP()
  {
   if(!UseVWAP) return;
   double pv=0.0, pv2=0.0, vol=0.0;
   for(int i = 0; i < VWAP_Lookback; i++)
     {
      double h = TfHigh(PERIOD_M5, i);
      double l = TfLow(PERIOD_M5, i);
      double c = TfClose(PERIOD_M5, i);
      double v = (double)TfVolume(PERIOD_M5, i);
      if(h <= 0.0 || l <= 0.0 || c <= 0.0 || v <= 0.0) continue;
      double typical = (h + l + c) / 3.0;
      pv  += typical * v;
      pv2 += typical * typical * v;
      vol += v;
     }
   if(vol <= 0.0) return;
   VWAP_Value = pv / vol;
   double variance = MathMax(0.0, pv2 / vol - VWAP_Value * VWAP_Value);
   double stdev = MathSqrt(variance);
   VWAP_Upper = VWAP_Value + VWAP_Stdev_Entry * stdev;
   VWAP_Lower = VWAP_Value - VWAP_Stdev_Entry * stdev;
  }

int GetVWAPBias()
  {
   if(!UseVWAP) return 0;
   CalculateVWAP();
   double price = MidPrice();
   if(VWAP_Upper <= 0.0 || VWAP_Lower <= 0.0) return 0;
   if(price > VWAP_Upper) return -1;
   if(price < VWAP_Lower) return  1;
   return 0;
  }

double GetKAMA_M15(int shift)
  {
   int period = KAMA_Length;
   double fast = 2.0 / 3.0;
   double slow = 2.0 / 31.0;
   double net = MathAbs(TfClose(PERIOD_M15, shift) - TfClose(PERIOD_M15, shift + period));
   double path = 0.0;
   for(int i = shift; i < shift + period; i++)
      path += MathAbs(TfClose(PERIOD_M15, i) - TfClose(PERIOD_M15, i + 1));
   double eff = (path > 0.0) ? net / path : 0.0;
   double sm  = MathPow(eff * (fast - slow) + slow, 2.0);
   double kama = TfClose(PERIOD_M15, shift + period);
   for(int j = shift + period - 1; j >= shift; j--)
      kama = kama + sm * (TfClose(PERIOD_M15, j) - kama);
   return kama;
  }

double KAMASlope_M15()
  {
   if(CurrentATR15 <= 0.0) return 0.0;
   double cur  = GetKAMA_M15(0);
   double prev = GetKAMA_M15(KAMA_SlopeBars);
   return (cur - prev) / (CurrentATR15 * (double)KAMA_SlopeBars);
  }

bool ComputeVolSurgeBull()
  {
   double avg = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      long v = TfVolume(PERIOD_M15, i);
      if(v > 0) { avg += (double)v; cnt++; }
     }
   if(cnt <= 0) return false;
   avg /= (double)cnt;
   double cur = (double)TfVolume(PERIOD_M15, 1);
   double c1 = TfClose(PERIOD_M15, 1);
   double c2 = TfClose(PERIOD_M15, 2);
   if(avg <= 0.0 || cur <= avg * 2.0) return false;
   if(c1 <= c2) return false;
   double b1 = MathAbs(c1 - TfOpen(PERIOD_M15, 1));
   double b2 = MathAbs(c2 - TfOpen(PERIOD_M15, 2));
   return (b1 > b2 * 2.0);
  }

bool ComputeVolSurgeBear()
  {
   double avg = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      long v = TfVolume(PERIOD_M15, i);
      if(v > 0) { avg += (double)v; cnt++; }
     }
   if(cnt <= 0) return false;
   avg /= (double)cnt;
   double cur = (double)TfVolume(PERIOD_M15, 1);
   double c1 = TfClose(PERIOD_M15, 1);
   double c2 = TfClose(PERIOD_M15, 2);
   if(avg <= 0.0 || cur <= avg * 2.0) return false;
   if(c1 >= c2) return false;
   double b1 = MathAbs(c1 - TfOpen(PERIOD_M15, 1));
   double b2 = MathAbs(c2 - TfOpen(PERIOD_M15, 2));
   return (b1 > b2 * 2.0);
  }

double GetOBV_M15(int shift)
  {
   double val = 0.0;
   for(int i = shift + 21; i >= shift; i--)
     {
      double c  = TfClose(PERIOD_M15, i);
      double pc = TfClose(PERIOD_M15, i + 1);
      double v  = (double)TfVolume(PERIOD_M15, i);
      if(c <= 0.0 || pc <= 0.0) continue;
      if(c > pc)      val += v;
      else if(c < pc) val -= v;
     }
   return val;
  }

double GetOBVSig_M15(int shift)
  {
   double sum = 0.0; int cnt = 0;
   for(int i = shift; i < shift + 21; i++) { sum += GetOBV_M15(i); cnt++; }
   return (cnt > 0) ? sum / (double)cnt : 0.0;
  }

int DetectM15Jerk()
  {
   double adx  = BufVal(hADX_M15, 0, 1);
   double pdi  = BufVal(hADX_M15, 1, 1);
   double mdi  = BufVal(hADX_M15, 2, 1);
   double macd = BufVal(hMACD_M15, 0, 1);
   double sig  = BufVal(hMACD_M15, 1, 1);
   int hi = iHighest(_Symbol, PERIOD_M15, MODE_HIGH, 3, 1);
   int lo = iLowest (_Symbol, PERIOD_M15, MODE_LOW,  3, 1);
   if(hi < 0 || lo < 0) return 0;
   double range = TfHigh(PERIOD_M15, hi) - TfLow(PERIOD_M15, lo);
   bool vB = ComputeVolSurgeBull();
   bool vS = ComputeVolSurgeBear();
   double obv  = GetOBV_M15(0);
   double osig = GetOBVSig_M15(0);
   if(adx > 25.0 && pdi > mdi && macd > sig &&
      range > 150.0 * _Point && vB && obv > osig) return 1;
   if(adx > 25.0 && mdi > pdi && macd < sig &&
      range > 150.0 * _Point && vS && obv < osig) return -1;
   return 0;
  }

int DetectM5Jerk()
  {
   double adx = BufVal(hADX_M5, 0, 1);
   double pdi = BufVal(hADX_M5, 1, 1);
   double mdi = BufVal(hADX_M5, 2, 1);
   double avgVol = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      long v = TfVolume(PERIOD_M5, i);
      if(v > 0) { avgVol += (double)v; cnt++; }
     }
   if(cnt <= 0) return 0;
   avgVol /= (double)cnt;
   double curVol = (double)TfVolume(PERIOD_M5, 1);
   int hi = iHighest(_Symbol, PERIOD_M5, MODE_HIGH, 3, 1);
   int lo = iLowest (_Symbol, PERIOD_M5, MODE_LOW,  3, 1);
   if(hi < 0 || lo < 0) return 0;
   double range = TfHigh(PERIOD_M5, hi) - TfLow(PERIOD_M5, lo);
   if(adx > 25.0 && pdi > mdi && curVol > avgVol * 2.0 &&
      range > 50.0 * _Point) return 1;
   if(adx > 25.0 && mdi > pdi && curVol > avgVol * 2.0 &&
      range > 50.0 * _Point) return -1;
   return 0;
  }

//===================================================================
// SECTION 35 — M1 PRICE ACTION STACK
//===================================================================
bool M1RecentSwingHigh(double &price)
  {
   int maxShift = MathMax(M1PA_SwingLookback, 10);
   for(int shift = M1PA_SwingStrength + 1; shift < maxShift; shift++)
     {
      double h = TfHigh(PERIOD_M1, shift);
      if(h <= 0.0) continue;
      bool ok = true;
      for(int j = 1; j <= M1PA_SwingStrength; j++)
         if(TfHigh(PERIOD_M1, shift - j) >= h || TfHigh(PERIOD_M1, shift + j) >= h)
           { ok = false; break; }
      if(ok) { price = h; return true; }
     }
   return false;
  }

bool M1RecentSwingLow(double &price)
  {
   int maxShift = MathMax(M1PA_SwingLookback, 10);
   for(int shift = M1PA_SwingStrength + 1; shift < maxShift; shift++)
     {
      double l = TfLow(PERIOD_M1, shift);
      if(l <= 0.0) continue;
      bool ok = true;
      for(int j = 1; j <= M1PA_SwingStrength; j++)
         if(TfLow(PERIOD_M1, shift - j) <= l || TfLow(PERIOD_M1, shift + j) <= l)
           { ok = false; break; }
      if(ok) { price = l; return true; }
     }
   return false;
  }

bool M1BullSweep()
  {
   if(CurrentATR1 <= 0.0) return false;
   double swing = 0.0;
   if(!M1RecentSwingLow(swing)) return false;
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double range = h - l;
   if(range <= 0.0) return false;
   double lowerWick = (MathMin(o, c) - l) / range;
   return (l < swing - CurrentATR1 * MathMax(M1PA_MinSweepATR, 0.08) &&
           c > swing && lowerWick >= 0.30);
  }

bool M1BearSweep()
  {
   if(CurrentATR1 <= 0.0) return false;
   double swing = 0.0;
   if(!M1RecentSwingHigh(swing)) return false;
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double range = h - l;
   if(range <= 0.0) return false;
   double upperWick = (h - MathMax(o, c)) / range;
   return (h > swing + CurrentATR1 * MathMax(M1PA_MinSweepATR, 0.08) &&
           c < swing && upperWick >= 0.30);
  }

bool M1BullDisplacement()
  {
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double range = h - l;
   if(CurrentATR1 <= 0.0 || range <= 0.0 || c <= o) return false;
   double body = (c - o) / range;
   double closePos = (c - l) / range;
   return (range >= CurrentATR1 * MathMax(M1PA_MinDisplATR, 0.70) &&
           body >= M1PA_MinBodyRatio && closePos >= 0.70);
  }

bool M1BearDisplacement()
  {
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double range = h - l;
   if(CurrentATR1 <= 0.0 || range <= 0.0 || c >= o) return false;
   double body = (o - c) / range;
   double closePos = (c - l) / range;
   return (range >= CurrentATR1 * MathMax(M1PA_MinDisplATR, 0.70) &&
           body >= M1PA_MinBodyRatio && closePos <= 0.30);
  }

bool M1BullMSS()
  {
   double swing = 0.0;
   if(!M1RecentSwingHigh(swing)) return false;
   return (CurrentATR1 > 0.0 && TfClose(PERIOD_M1, 1) > swing + CurrentATR1 * 0.05);
  }

bool M1BearMSS()
  {
   double swing = 0.0;
   if(!M1RecentSwingLow(swing)) return false;
   return (CurrentATR1 > 0.0 && TfClose(PERIOD_M1, 1) < swing - CurrentATR1 * 0.05);
  }

bool M1BullFVG()
  {
   if(CurrentATR1 <= 0.0) return false;
   double gap = TfLow(PERIOD_M1, 1) - TfHigh(PERIOD_M1, 3);
   return (gap >= CurrentATR1 * MathMax(M1PA_FVG_MinATR, 0.05));
  }

bool M1BearFVG()
  {
   if(CurrentATR1 <= 0.0) return false;
   double gap = TfLow(PERIOD_M1, 3) - TfHigh(PERIOD_M1, 1);
   return (gap >= CurrentATR1 * MathMax(M1PA_FVG_MinATR, 0.05));
  }

bool M1Exhaustion()
  {
   if(CurrentATR1 <= 0.0) return false;
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double range = h - l;
   if(range <= 0.0 || range < CurrentATR1 * 1.80) return false;
   double body = MathAbs(c - o) / range;
   double upperWick = (h - MathMax(o, c)) / range;
   double lowerWick = (MathMin(o, c) - l) / range;
   return (body <= 0.35 && (upperWick >= 0.55 || lowerWick >= 0.55));
  }

bool IsExplosiveBar(int &outDir, double &outStrength)
  {
   outDir = 0; outStrength = 0.0;
   if(CurrentATR1 <= 0.0) return false;
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   if(o <= 0.0 || c <= 0.0 || h <= 0.0 || l <= 0.0) return false;
   double r = h - l;
   if(r <= 0.0) return false;
   double body = MathAbs(c - o) / r;
   double bodyATR = MathAbs(c - o) / CurrentATR1;
   double closePos = (c - l) / r;
   double avgVol = 0.0; int cnt = 0;
   for(int i = 2; i <= 21; i++)
     {
      long v = TfVolume(PERIOD_M1, i);
      if(v > 0) { avgVol += (double)v; cnt++; }
     }
   if(cnt > 0) avgVol /= (double)cnt;
   double volRatio = (avgVol > 0.0) ? (double)TfVolume(PERIOD_M1, 1) / avgVol : 1.0;
   bool bull = (c > o && body >= 0.64 && bodyATR >= 1.20 && closePos >= 0.74);
   bool bear = (c < o && body >= 0.64 && bodyATR >= 1.20 && closePos <= 0.26);
   if(!bull && !bear) return false;
   double volBoost = Clamp(volRatio, 0.50, 3.50);
   outDir = bull ? 1 : -1;
   outStrength = body * 35.0 + MathMin(bodyATR, 4.0) * 15.0 + volBoost * 8.0;
   return (outStrength >= 48.0);
  }

void UpdateM1PA()
  {
   M1PA_Dir = 0; M1PA_Score = 0.0;
   M1PA_BullSweep = false; M1PA_BearSweep = false;
   M1PA_BullDisp  = false; M1PA_BearDisp  = false;
   M1PA_BullMSS   = false; M1PA_BearMSS   = false;
   M1PA_BullFVG   = false; M1PA_BearFVG   = false;

   if(!UseM1PA) return;

   M1PA_BullSweep = M1BullSweep();
   M1PA_BearSweep = M1BearSweep();
   M1PA_BullDisp  = M1BullDisplacement();
   M1PA_BearDisp  = M1BearDisplacement();
   M1PA_BullMSS   = M1BullMSS();
   M1PA_BearMSS   = M1BearMSS();
   M1PA_BullFVG   = M1BullFVG();
   M1PA_BearFVG   = M1BearFVG();

   double bull = 0.0, bear = 0.0;
   if(M1PA_BullSweep) bull += 35.0;
   if(M1PA_BullDisp)  bull += 35.0;
   if(M1PA_BullMSS)   bull += 30.0;
   if(M1PA_BullFVG)   bull += 10.0;
   if(M1PA_BearSweep) bear += 35.0;
   if(M1PA_BearDisp)  bear += 35.0;
   if(M1PA_BearMSS)   bear += 30.0;
   if(M1PA_BearFVG)   bear += 10.0;

   if(bull >= bear && bull >= M1PA_BoostScore)
     { M1PA_Dir =  1; M1PA_Score = MathMin(100.0, bull); }
   else if(bear > bull && bear >= M1PA_BoostScore)
     { M1PA_Dir = -1; M1PA_Score = MathMin(100.0, bear); }
  }

//===================================================================
// SECTION 36 — M5 DIRECTION / SUPER8 / DONCHIAN / MA SLOPE
//===================================================================
int CalcM15Direction()
  {
   int score = 0;
   double fast = BufVal(hEMA10_M15, 0, 1);
   double slow = BufVal(hEMA20_M15, 0, 1);
   double base = BufVal(hEMA50_M15, 0, 1);
   double adx  = BufVal(hADX_M15,   0, 1);
   double pdi  = BufVal(hADX_M15,   1, 1);
   double mdi  = BufVal(hADX_M15,   2, 1);
   double price = TfClose(PERIOD_M15, 1);
   if(fast > slow) score += 2; else if(fast < slow) score -= 2;
   if(price > base) score += 2; else if(price < base) score -= 2;
   if(adx >= 20.0)
     {
      if(pdi > mdi) score += (adx >= StrongADXThreshold ? 2 : 1);
      else if(mdi > pdi) score -= (adx >= StrongADXThreshold ? 2 : 1);
     }
   if(KAMA_M15_Slope >  KAMA_SlopeMin) score += 1;
   else if(KAMA_M15_Slope < -KAMA_SlopeMin) score -= 1;
   if(score >= 3) return 1;
   if(score <= -3) return -1;
   return 0;
  }

int CalcM5Direction()
  {
   int score = 0;
   double fast = BufVal(hEMA8_M5,  0, 1);
   double slow = BufVal(hEMA21_M5, 0, 1);
   double base = BufVal(hEMA50_M5, 0, 1);
   double rsi  = BufVal(hRSI_M5,   0, 1);
   double mom  = BufVal(hMom14_M5, 0, 1);
   double price = TfClose(PERIOD_M5, 1);
   if(fast > slow) score += 2; else if(fast < slow) score -= 2;
   if(price > base) score += 2; else if(price < base) score -= 2;
   if(mom > 100.0) score += 1; else if(mom > 0.0 && mom < 100.0) score -= 1;
   if(rsi > 55.0) score += 1; else if(rsi < 45.0) score -= 1;
   if(score >= 3) return 1;
   if(score <= -3) return -1;
   return 0;
  }

int GetSuper8()
  {
   double emaF = BufVal(hEMA10_M5, 0, 0);
   double emaS = BufVal(hEMA50_M5, 0, 0);
   if(emaF <= 0.0 || emaS <= 0.0) return 0;
   double adx = BufVal(hADX_M5, 0, 0);
   double pdi = BufVal(hADX_M5, 1, 0);
   double mdi = BufVal(hADX_M5, 2, 0);
   double macdM = BufVal(hMACD_M5, 0, 0);
   double macdS = BufVal(hMACD_M5, 1, 0);
   double volSum = 0.0; int cnt = 0;
   for(int i = 0; i < 20; i++)
     {
      long v = TfVolume(PERIOD_M5, i);
      if(v > 0) { volSum += (double)v; cnt++; }
     }
   double volSMA = (cnt > 0) ? volSum / (double)cnt : 0.0;
   long volNow = TfVolume(PERIOD_M5, 0);
   double c = TfClose(PERIOD_M5, 0);
   double o = TfOpen (PERIOD_M5, 0);
   int bull = 0, bear = 0;
   if(emaF > emaS) bull++; else bear++;
   if(adx > 15.0) { if(pdi > mdi) bull += 2; if(mdi > pdi) bear += 2; }
   if(macdM > macdS) bull++; else bear++;
   if(volSMA > 0.0 && (double)volNow > volSMA * 0.4)
     {
      if(c > o) bull++;
      if(c < o) bear++;
     }
   if(bull > bear) return  1;
   if(bear > bull) return -1;
   return 0;
  }

void UpdateDonchian()
  {
   int N = 20;
   if(Bars(_Symbol, PERIOD_M5) < N + 5) return;
   double hiHigh = 0.0;
   double loLow  = 1e20;
   for(int i = 1; i <= N; i++)
     {
      double h = TfHigh(PERIOD_M5, i);
      double l = TfLow(PERIOD_M5, i);
      if(h > hiHigh) hiHigh = h;
      if(l < loLow && l > 0.0) loLow = l;
     }
   if(hiHigh <= 0.0 || loLow <= 0.0) return;
   DC_UpperPrev = DC_Upper;
   DC_LowerPrev = DC_Lower;
   DC_Upper = hiHigh;
   DC_Lower = loLow;
   if(DC_UpperPrev > 0.0 && DC_LowerPrev > 0.0)
     {
      double wN = DC_Upper - DC_Lower;
      double wP = DC_UpperPrev - DC_LowerPrev;
      DC_Slope = (wP > 0.0) ? (wN - wP) / wP : 0.0;
     }
  }

void UpdateMA_Slope()
  {
   double emaNow  = BufVal(hEMA50_M5, 0, 0);
   double emaPrev = BufVal(hEMA50_M5, 0, 5);
   if(emaNow <= 0.0 || emaPrev <= 0.0) { MA_Slope = 0.0; return; }
   double atr5 = CurrentATR5;
   if(atr5 <= 0.0) atr5 = CurrentATR1;
   if(atr5 <= 0.0) { MA_Slope = 0.0; return; }
   MA_Slope = (emaNow - emaPrev) / (atr5 * 5.0);
  }

void UpdateTrendBias()
  {
   UpdateDonchian();
   UpdateMA_Slope();
   double price = MidPrice();
   if(price <= 0.0 || DC_Upper <= 0.0 || DC_Lower <= 0.0) { DC_Bias = 0; return; }
   double adx = BufVal(hADX_M15, 0, 1);
   bool trendExists = (adx > 16.0);
   bool brokeUpper = (price >= DC_UpperPrev && DC_UpperPrev > 0.0);
   bool brokeLower = (price <= DC_LowerPrev && DC_LowerPrev > 0.0);
   if(trendExists && brokeUpper && MA_Slope >  0.02) DC_Bias = 1;
   else if(trendExists && brokeLower && MA_Slope < -0.02) DC_Bias = -1;
   else DC_Bias = 0;
   if(DC_Bias == 0 && trendExists)
     {
      double width = DC_Upper - DC_Lower;
      if(CurrentATR5 > 0.0 && width > CurrentATR5 * 3.0)
        {
         if(MA_Slope >  0.20) DC_Bias =  1;
         if(MA_Slope < -0.20) DC_Bias = -1;
        }
     }
  }

//===================================================================
// END OF PART 2 OF 5
//===================================================================

//===================================================================
// SECTION 37 — HHLL / SUPERTREND / MSS M15
//===================================================================
int GetHHLLStructure(ENUM_TIMEFRAMES tf, int leftBars, int rightBars, int maxAge)
  {
   int bars = Bars(_Symbol, tf);
   if(bars < maxAge + leftBars + rightBars + 10) return 0;
   double h1=0,h2=0,l1=0,l2=0;
   int hc=0, lc=0;
   for(int i = rightBars; i < maxAge && (hc < 2 || lc < 2); i++)
     {
      if(hc < 2)
        {
         double h = TfHigh(tf, i);
         bool ok = true;
         for(int j = 1; j <= leftBars; j++)
            if(TfHigh(tf, i + j) >= h) { ok = false; break; }
         if(ok) for(int j = 1; j <= rightBars; j++)
            if(TfHigh(tf, i - j) >= h) { ok = false; break; }
         if(ok && h > 0.0) { if(hc==0) h1=h; else h2=h; hc++; }
        }
      if(lc < 2)
        {
         double l = TfLow(tf, i);
         bool ok = true;
         for(int j = 1; j <= leftBars; j++)
            if(TfLow(tf, i + j) <= l) { ok = false; break; }
         if(ok) for(int j = 1; j <= rightBars; j++)
            if(TfLow(tf, i - j) <= l) { ok = false; break; }
         if(ok && l > 0.0) { if(lc==0) l1=l; else l2=l; lc++; }
        }
     }
   if(hc < 2 || lc < 2) return 0;
   if(h1 > h2 && l1 > l2) return  1;
   if(h1 < h2 && l1 < l2) return -1;
   return 0;
  }

int GetSupertrend()
  {
   int bars = Bars(_Symbol, ST_TF);
   if(bars < ST_ATR + 50) return 0;
   int count = MathMin(200, bars - ST_ATR - 5);
   if(count < 10) return 0;
   double upper[200], lower[200], atr[200];
   int trend[200];
   int hAtrST = iATR(_Symbol, ST_TF, ST_ATR);
   if(hAtrST == INVALID_HANDLE) return 0;
   for(int i = 0; i < count; i++) atr[i] = BufVal(hAtrST, 0, i);
   IndicatorRelease(hAtrST);
   int oldest = count - 1;
   double hl2 = (TfHigh(ST_TF, oldest) + TfLow(ST_TF, oldest)) / 2.0;
   upper[oldest] = hl2 - ST_Mult * atr[oldest];
   lower[oldest] = hl2 + ST_Mult * atr[oldest];
   trend[oldest] = 1;
   for(int i = oldest - 1; i >= 0; i--)
     {
      double middle = (TfHigh(ST_TF, i) + TfLow(ST_TF, i)) / 2.0;
      if(atr[i] <= 0.0)
        { upper[i]=upper[i+1]; lower[i]=lower[i+1]; trend[i]=trend[i+1]; continue; }
      double rawUpper = middle - ST_Mult * atr[i];
      double rawLower = middle + ST_Mult * atr[i];
      double prevC = TfClose(ST_TF, i + 1);
      upper[i] = (prevC > upper[i+1]) ? MathMax(rawUpper, upper[i+1]) : rawUpper;
      lower[i] = (prevC < lower[i+1]) ? MathMin(rawLower, lower[i+1]) : rawLower;
      double curC = TfClose(ST_TF, i);
      if(trend[i+1] == -1 && curC > lower[i+1]) trend[i] = 1;
      else if(trend[i+1] == 1 && curC < upper[i+1]) trend[i] = -1;
      else trend[i] = trend[i+1];
     }
   return trend[0];
  }

int DetectMSS_Event()
  {
   int bars = Bars(_Symbol, PERIOD_M15);
   if(bars < MSS_LeftBars + MSS_RightBars + 10) return 0;
   int depth = MathMin(100, bars - MSS_LeftBars - MSS_RightBars - 1);
   double pH=0, pL=0;
   datetime tH=0, tL=0;
   for(int i = MSS_RightBars; i < depth; i++)
     {
      double h = TfHigh(PERIOD_M15, i);
      if(h > 0.0)
        {
         bool ok = true;
         for(int j=1;j<=MSS_LeftBars;j++) if(TfHigh(PERIOD_M15,i+j)>=h){ok=false;break;}
         if(ok) for(int j=1;j<=MSS_RightBars;j++) if(TfHigh(PERIOD_M15,i-j)>=h){ok=false;break;}
         if(ok && pH == 0.0) { pH = h; tH = TfTime(PERIOD_M15, i); }
        }
      double l = TfLow(PERIOD_M15, i);
      if(l > 0.0)
        {
         bool ok = true;
         for(int j=1;j<=MSS_LeftBars;j++) if(TfLow(PERIOD_M15,i+j)<=l){ok=false;break;}
         if(ok) for(int j=1;j<=MSS_RightBars;j++) if(TfLow(PERIOD_M15,i-j)<=l){ok=false;break;}
         if(ok && pL == 0.0) { pL = l; tL = TfTime(PERIOD_M15, i); }
        }
      if(pH > 0.0 && pL > 0.0) break;
     }
   if(pH > 0.0 && tH > MSS_LastHighTime) { MSS_LastHigh = pH; MSS_LastHighTime = tH; }
   if(pL > 0.0 && tL > MSS_LastLowTime)  { MSS_LastLow  = pL; MSS_LastLowTime  = tL; }
   double closed = TfClose(PERIOD_M15, 1);
   if(closed <= 0.0) return 0;
   int dir = 0;
   if(MSS_LastHigh > 0.0 && closed > MSS_LastHigh && MSS_LastDir !=  1) dir =  1;
   else if(MSS_LastLow  > 0.0 && closed < MSS_LastLow  && MSS_LastDir != -1) dir = -1;
   if(dir != 0)
     {
      MSS_LastDir = dir;
      MSS_LastEventDir = dir;
      MSS_LastEventTime = TimeCurrent();
     }
   return dir;
  }

bool MSSFresh(int direction)
  {
   if(MSS_LastEventDir != direction || MSS_LastEventTime == 0) return false;
   return (TimeCurrent() - MSS_LastEventTime <= M15VetoEventAgeMin * 60);
  }

//===================================================================
// SECTION 38 — OB / FVG / SESSIONS / LIQUIDITY SWEEP
//===================================================================
void StoreBullOB(double high, double low, datetime t)
  {
   int maxKeep = MathMin(OB_MaxStored, 8);
   if(maxKeep < 1) return;
   if(BullOBCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) BullOBs[i]=BullOBs[i-1]; BullOBCount=maxKeep-1; }
   else
     { for(int i=BullOBCount;i>0;i--) BullOBs[i]=BullOBs[i-1]; }
   BullOBs[0].high=high; BullOBs[0].low=low; BullOBs[0].avg=(high+low)/2.0;
   BullOBs[0].dir=1; BullOBs[0].t=t; BullOBs[0].mitigated=false;
   BullOBCount++;
  }

void StoreBearOB(double high, double low, datetime t)
  {
   int maxKeep = MathMin(OB_MaxStored, 8);
   if(maxKeep < 1) return;
   if(BearOBCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) BearOBs[i]=BearOBs[i-1]; BearOBCount=maxKeep-1; }
   else
     { for(int i=BearOBCount;i>0;i--) BearOBs[i]=BearOBs[i-1]; }
   BearOBs[0].high=high; BearOBs[0].low=low; BearOBs[0].avg=(high+low)/2.0;
   BearOBs[0].dir=-1; BearOBs[0].t=t; BearOBs[0].mitigated=false;
   BearOBCount++;
  }

void ScanOB()
  {
   if(Bars(_Symbol, PERIOD_M15) < OB_Periods + 10) return;
   double o = TfOpen(PERIOD_M15, 1);
   double c = TfClose(PERIOD_M15, 1);
   double h = TfHigh(PERIOD_M15, 1);
   double l = TfLow(PERIOD_M15, 1);
   datetime t = TfTime(PERIOD_M15, 1);
   if(o<=0.0||c<=0.0||h<=0.0||l<=0.0||t==0) return;

   int bullCnt=0, bearCnt=0;
   for(int i = 2; i <= OB_Periods + 1; i++)
     {
      double bo = TfOpen(PERIOD_M15, i);
      double bc = TfClose(PERIOD_M15, i);
      if(bc > bo)      bullCnt++;
      else if(bc < bo) bearCnt++;
     }
   if(c < o && bullCnt == OB_Periods)
     {
      bool ex=false;
      for(int i=0;i<BullOBCount;i++) if(BullOBs[i].t==t){ex=true;break;}
      if(!ex) StoreBullOB(o, l, t);
     }
   if(c > o && bearCnt == OB_Periods)
     {
      bool ex=false;
      for(int i=0;i<BearOBCount;i++) if(BearOBs[i].t==t){ex=true;break;}
      if(!ex) StoreBearOB(h, o, t);
     }
   double current = TfClose(PERIOD_M15, 0);
   for(int i=0;i<BullOBCount;i++)
      if(!BullOBs[i].mitigated && current < BullOBs[i].low) BullOBs[i].mitigated=true;
   for(int i=0;i<BearOBCount;i++)
      if(!BearOBs[i].mitigated && current > BearOBs[i].high) BearOBs[i].mitigated=true;
  }

void StoreBullFVG(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FVG_MaxStored, 8);
   if(maxKeep < 1) return;
   if(BullFVGCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) BullFVGs[i]=BullFVGs[i-1]; BullFVGCount=maxKeep-1; }
   else
     { for(int i=BullFVGCount;i>0;i--) BullFVGs[i]=BullFVGs[i-1]; }
   BullFVGs[0].high=high; BullFVGs[0].low=low; BullFVGs[0].mid=(high+low)/2.0;
   BullFVGs[0].dir=1; BullFVGs[0].t=t; BullFVGs[0].mitigated=false;
   BullFVGCount++;
  }

void StoreBearFVG(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FVG_MaxStored, 8);
   if(maxKeep < 1) return;
   if(BearFVGCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) BearFVGs[i]=BearFVGs[i-1]; BearFVGCount=maxKeep-1; }
   else
     { for(int i=BearFVGCount;i>0;i--) BearFVGs[i]=BearFVGs[i-1]; }
   BearFVGs[0].high=high; BearFVGs[0].low=low; BearFVGs[0].mid=(high+low)/2.0;
   BearFVGs[0].dir=-1; BearFVGs[0].t=t; BearFVGs[0].mitigated=false;
   BearFVGCount++;
  }

void ScanFVG()
  {
   if(Bars(_Symbol, PERIOD_M5) < 20) return;
   double h1 = TfHigh(PERIOD_M5, 1);
   double l1 = TfLow(PERIOD_M5, 1);
   double h3 = TfHigh(PERIOD_M5, 3);
   double l3 = TfLow(PERIOD_M5, 3);
   double c2 = TfClose(PERIOD_M5, 2);
   datetime t = TfTime(PERIOD_M5, 1);
   if(h1<=0.0||l1<=0.0||h3<=0.0||l3<=0.0||c2<=0.0) return;
   if(l1 > h3 && c2 > h3 && ((l1-h3)/_Point) >= FVG_MinSizePts)
     {
      bool ex=false;
      for(int i=0;i<BullFVGCount;i++) if(BullFVGs[i].t==t){ex=true;break;}
      if(!ex) StoreBullFVG(l1, h3, t);
     }
   if(h1 < l3 && c2 < l3 && ((l3-h1)/_Point) >= FVG_MinSizePts)
     {
      bool ex=false;
      for(int i=0;i<BearFVGCount;i++) if(BearFVGs[i].t==t){ex=true;break;}
      if(!ex) StoreBearFVG(l3, h1, t);
     }
   double current = TfClose(PERIOD_M5, 0);
   for(int i=0;i<BullFVGCount;i++)
      if(!BullFVGs[i].mitigated && current < BullFVGs[i].low) BullFVGs[i].mitigated=true;
   for(int i=0;i<BearFVGCount;i++)
      if(!BearFVGs[i].mitigated && current > BearFVGs[i].high) BearFVGs[i].mitigated=true;
  }

bool NearStoredZone(int dir, double distanceATR)
  {
   double price = MidPrice();
   if(price <= 0.0 || CurrentATR1 <= 0.0) return false;
   if(dir > 0)
     {
      for(int i=0;i<BullOBCount;i++)
        {
         if(BullOBs[i].mitigated) continue;
         double d = 0.0;
         if(price < BullOBs[i].low) d = BullOBs[i].low - price;
         else if(price > BullOBs[i].high) d = price - BullOBs[i].high;
         if(d <= CurrentATR1 * distanceATR) return true;
        }
      for(int i=0;i<BullFVGCount;i++)
        {
         if(BullFVGs[i].mitigated) continue;
         double d = 0.0;
         if(price < BullFVGs[i].low) d = BullFVGs[i].low - price;
         else if(price > BullFVGs[i].high) d = price - BullFVGs[i].high;
         if(d <= CurrentATR1 * distanceATR) return true;
        }
     }
   else
     {
      for(int i=0;i<BearOBCount;i++)
        {
         if(BearOBs[i].mitigated) continue;
         double d = 0.0;
         if(price < BearOBs[i].low) d = BearOBs[i].low - price;
         else if(price > BearOBs[i].high) d = price - BearOBs[i].high;
         if(d <= CurrentATR1 * distanceATR) return true;
        }
      for(int i=0;i<BearFVGCount;i++)
        {
         if(BearFVGs[i].mitigated) continue;
         double d = 0.0;
         if(price < BearFVGs[i].low) d = BearFVGs[i].low - price;
         else if(price > BearFVGs[i].high) d = price - BearFVGs[i].high;
         if(d <= CurrentATR1 * distanceATR) return true;
        }
     }
   return false;
  }

void UpdateLiquiditySessions()
  {
   MqlDateTime dt;
   TimeToStruct(TimeGMT(), dt);
   if(dt.day_of_year != SessionDayOfYear)
     {
      SessionDayOfYear = dt.day_of_year;
      AsianHigh=0.0; AsianLow=0.0; LondonHigh=0.0; LondonLow=0.0;
      AsianLocked=false; LondonLocked=false;
     }
   double h = TfHigh(PERIOD_M5, 1);
   double l = TfLow(PERIOD_M5, 1);
   if(h<=0.0 || l<=0.0) return;
   if(dt.hour >= 0 && dt.hour < 8)
     {
      if(AsianHigh == 0.0 || h > AsianHigh) AsianHigh = h;
      if(AsianLow  == 0.0 || l < AsianLow)  AsianLow  = l;
     }
   else if(!AsianLocked && AsianHigh > 0.0 && AsianLow > 0.0) AsianLocked = true;
   if(dt.hour >= 8 && dt.hour < 12)
     {
      if(LondonHigh == 0.0 || h > LondonHigh) LondonHigh = h;
      if(LondonLow  == 0.0 || l < LondonLow)  LondonLow  = l;
     }
   else if(!LondonLocked && LondonHigh > 0.0 && LondonLow > 0.0) LondonLocked = true;
  }

int DetectLiquiditySweep(string &source)
  {
   source = "";
   double c = TfClose(PERIOD_M5, 1);
   double h = TfHigh(PERIOD_M5, 1);
   double l = TfLow(PERIOD_M5, 1);
   if(c<=0.0 || h<=0.0 || l<=0.0) return 0;
   double minWick = CurrentATR5 * LS_MinWickATR;
   if(minWick <= 0.0) minWick = 500.0 * _Point;

   if(LS_UseAsian && AsianLocked)
     {
      if(l < AsianLow && c > AsianLow && AsianLow - l >= minWick) { source="AsianLow"; return 1; }
      if(h > AsianHigh && c < AsianHigh && h - AsianHigh >= minWick) { source="AsianHigh"; return -1; }
     }
   if(LS_UseLondon && LondonLocked)
     {
      if(l < LondonLow && c > LondonLow && LondonLow - l >= minWick) { source="LondonLow"; return 1; }
      if(h > LondonHigh && c < LondonHigh && h - LondonHigh >= minWick) { source="LondonHigh"; return -1; }
     }
   if(LS_UsePDHPDL)
     {
      double pdh = TfHigh(PERIOD_D1, 1);
      double pdl = TfLow(PERIOD_D1, 1);
      if(pdl > 0.0 && l < pdl && c > pdl && pdl - l >= minWick) { source="PDL"; return 1; }
      if(pdh > 0.0 && h > pdh && c < pdh && h - pdh >= minWick) { source="PDH"; return -1; }
     }
   if(LS_UseSwings)
     {
      int hi = iHighest(_Symbol, PERIOD_M5, MODE_HIGH, 10, 2);
      int lo = iLowest (_Symbol, PERIOD_M5, MODE_LOW,  10, 2);
      if(hi >= 0 && lo >= 0)
        {
         double sh = TfHigh(PERIOD_M5, hi);
         double sl = TfLow(PERIOD_M5, lo);
         if(sl > 0.0 && l < sl && c > sl && sl - l >= minWick) { source="SwingLow"; return 1; }
         if(sh > 0.0 && h > sh && c < sh && h - sh >= minWick) { source="SwingHigh"; return -1; }
        }
     }
   return 0;
  }

//===================================================================
// SECTION 39 — SMC STRUCTURE (M15/M5/M1 bias + events)
//===================================================================
bool VNSMC_FindSwings(ENUM_TIMEFRAMES tf, int lookback, int leftBars, int rightBars,
                      double &lastHigh, double &prevHigh,
                      double &lastLow,  double &prevLow)
  {
   lastHigh=prevHigh=lastLow=prevLow=0.0;
   int bars = Bars(_Symbol, tf);
   if(bars < lookback + leftBars + rightBars + 10) return false;
   int highCount=0, lowCount=0;
   int maxShift = (int)MathMin(lookback, bars - leftBars - rightBars - 2);
   for(int shift = rightBars + 1; shift <= maxShift; shift++)
     {
      double h = TfHigh(tf, shift);
      bool isHigh = (h > 0.0);
      if(isHigh)
        {
         for(int j=1;j<=leftBars && isHigh;j++) if(TfHigh(tf,shift+j)>=h) isHigh=false;
         for(int j=1;j<=rightBars && isHigh;j++) if(TfHigh(tf,shift-j)>=h) isHigh=false;
        }
      if(isHigh)
        {
         if(highCount==0) lastHigh=h; else if(highCount==1) prevHigh=h;
         highCount++;
        }
      double l = TfLow(tf, shift);
      bool isLow = (l > 0.0);
      if(isLow)
        {
         for(int j=1;j<=leftBars && isLow;j++) if(TfLow(tf,shift+j)<=l) isLow=false;
         for(int j=1;j<=rightBars && isLow;j++) if(TfLow(tf,shift-j)<=l) isLow=false;
        }
      if(isLow)
        {
         if(lowCount==0) lastLow=l; else if(lowCount==1) prevLow=l;
         lowCount++;
        }
      if(highCount >= 2 && lowCount >= 2) break;
     }
   return (highCount >= 2 && lowCount >= 2);
  }

int VNSMC_StructureBias(ENUM_TIMEFRAMES tf, int lookback, int &eventDir,
                        double &lastHigh, double &lastLow, datetime &eventTime)
  {
   eventDir = 0; eventTime = 0;
   double prevHigh=0.0, prevLow=0.0;
   int useLeft  = (tf == PERIOD_M1) ? SMC_InternalPivotLeft  : SMC_SwingPivotLeft;
   int useRight = (tf == PERIOD_M1) ? SMC_InternalPivotRight : SMC_SwingPivotRight;
   if(!VNSMC_FindSwings(tf, lookback, useLeft, useRight, lastHigh, prevHigh, lastLow, prevLow))
      return 0;
   int bias = 0;
   if(lastHigh > prevHigh && lastLow > prevLow) bias = 1;
   else if(lastHigh < prevHigh && lastLow < prevLow) bias = -1;
   double c1 = TfClose(tf, 1);
   double c2 = TfClose(tf, 2);
   if(c1 > 0.0 && c2 > 0.0 && lastHigh > 0.0 && c1 > lastHigh && c2 <= lastHigh)
     { eventDir = 1; eventTime = TfTime(tf, 1); if(bias <= 0) bias = 1; }
   else if(c1 > 0.0 && c2 > 0.0 && lastLow > 0.0 && c1 < lastLow && c2 >= lastLow)
     { eventDir = -1; eventTime = TfTime(tf, 1); if(bias >= 0) bias = -1; }
   return bias;
  }

bool VNSMC_FindEqualLiquidity(ENUM_TIMEFRAMES tf, int lookback,
                              double &eqHigh, double &eqLow)
  {
   eqHigh = 0.0; eqLow = 0.0;
   if(!UseEqualLiquidity) return false;
   int bars = Bars(_Symbol, tf);
   if(bars < lookback + SMC_SwingPivotLeft + SMC_SwingPivotRight + 10) return false;
   int maxShift = (int)MathMin(lookback, bars - SMC_SwingPivotLeft - SMC_SwingPivotRight - 2);
   double tol = MathMax(CurrentATR1, _Point * 10.0) * EqualToleranceATR;
   if(tf == PERIOD_M5  && CurrentATR5  > 0.0) tol = CurrentATR5  * EqualToleranceATR;
   if(tf == PERIOD_M15 && CurrentATR15 > 0.0) tol = CurrentATR15 * EqualToleranceATR;
   if(tol <= 0.0) tol = 20.0 * _Point;

   double bestHighA=0,bestHighB=0;
   for(int shift = SMC_SwingPivotRight + 1; shift <= maxShift; shift++)
     {
      double h = TfHigh(tf, shift);
      bool isH = h > 0.0;
      for(int j=1;j<=SMC_SwingPivotLeft && isH;j++) if(TfHigh(tf,shift+j)>=h) isH=false;
      for(int j=1;j<=SMC_SwingPivotRight && isH;j++) if(TfHigh(tf,shift-j)>=h) isH=false;
      if(isH)
        {
         for(int s = shift + 1; s <= maxShift; s++)
           {
            double h2 = TfHigh(tf, s);
            bool isH2 = h2 > 0.0;
            for(int j=1;j<=SMC_SwingPivotLeft && isH2;j++) if(TfHigh(tf,s+j)>=h2) isH2=false;
            for(int j=1;j<=SMC_SwingPivotRight && isH2;j++) if(TfHigh(tf,s-j)>=h2) isH2=false;
            if(isH2 && MathAbs(h - h2) <= tol) { bestHighA=h; bestHighB=h2; break; }
           }
         if(bestHighA > 0.0) break;
        }
     }

   double bestLowA=0,bestLowB=0;
   for(int shift = SMC_SwingPivotRight + 1; shift <= maxShift; shift++)
     {
      double l = TfLow(tf, shift);
      bool isL = l > 0.0;
      for(int j=1;j<=SMC_SwingPivotLeft && isL;j++) if(TfLow(tf,shift+j)<=l) isL=false;
      for(int j=1;j<=SMC_SwingPivotRight && isL;j++) if(TfLow(tf,shift-j)<=l) isL=false;
      if(isL)
        {
         for(int s = shift + 1; s <= maxShift; s++)
           {
            double l2 = TfLow(tf, s);
            bool isL2 = l2 > 0.0;
            for(int j=1;j<=SMC_SwingPivotLeft && isL2;j++) if(TfLow(tf,s+j)<=l2) isL2=false;
            for(int j=1;j<=SMC_SwingPivotRight && isL2;j++) if(TfLow(tf,s-j)<=l2) isL2=false;
            if(isL2 && MathAbs(l - l2) <= tol) { bestLowA=l; bestLowB=l2; break; }
           }
         if(bestLowA > 0.0) break;
        }
     }
   if(bestHighA > 0.0) eqHigh = 0.5 * (bestHighA + bestHighB);
   if(bestLowA  > 0.0) eqLow  = 0.5 * (bestLowA  + bestLowB);
   return (eqHigh > 0.0 || eqLow > 0.0);
  }

bool VNSMC_EqualLiquiditySweep(int dir, double level)
  {
   if(level <= 0.0) return false;
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   if(h<=0.0 || l<=0.0 || c<=0.0) return false;
   double buffer = MathMax(_Point * 2.0, CurrentATR1 * 0.03);
   if(dir == 1)  return (l < level - buffer && c > level);
   if(dir == -1) return (h > level + buffer && c < level);
   return false;
  }

void VNSMC_Update()
  {
   if(!UseSMCStructure) return;
   g_SMC.m15_bias = VNSMC_StructureBias(PERIOD_M15, SMC_M15Lookback,
                                         g_SMC.m15_event, g_SMC.m15_high, g_SMC.m15_low,
                                         g_SMC.m15_event_time);
   g_SMC.m5_bias  = VNSMC_StructureBias(PERIOD_M5, SMC_M5Lookback,
                                         g_SMC.m5_event, g_SMC.m5_high, g_SMC.m5_low,
                                         g_SMC.m5_event_time);
   g_SMC.m1_bias  = VNSMC_StructureBias(PERIOD_M1, SMC_M1Lookback,
                                         g_SMC.m1_event, g_SMC.m1_high, g_SMC.m1_low,
                                         g_SMC.m1_event_time);
   double rHigh=0.0, rLow=0.0, rPrevH=0.0, rPrevL=0.0;
   if(VNSMC_FindSwings(PERIOD_M5, 24, 2, 2, rHigh, rPrevH, rLow, rPrevL) && rHigh > rLow)
     {
      double mid = 0.5 * (rHigh + rLow);
      double span = rHigh - rLow;
      double price = MidPrice();
      g_SMC.pd_location = (span > 0.0) ? (price - mid) / span : 0.0;
     }
   else g_SMC.pd_location = 0.0;

   g_SMC.bull_zone_near = NearStoredZone(1, SMC_ZoneDistanceATR);
   g_SMC.bear_zone_near = NearStoredZone(-1, SMC_ZoneDistanceATR);
   g_SMC.bull_liq_sweep = M1BullSweep();
   g_SMC.bear_liq_sweep = M1BearSweep();

   double eqH=0.0, eqL=0.0;
   VNSMC_FindEqualLiquidity(PERIOD_M5, EqualLookback, eqH, eqL);
   g_SMC.eq_high_level = eqH;
   g_SMC.eq_low_level  = eqL;
   g_SMC.eq_high_active = (eqH > 0.0);
   g_SMC.eq_low_active  = (eqL > 0.0);
   if(g_SMC.eq_low_active  && VNSMC_EqualLiquiditySweep(1,  eqL)) g_SMC.bull_liq_sweep = true;
   if(g_SMC.eq_high_active && VNSMC_EqualLiquiditySweep(-1, eqH)) g_SMC.bear_liq_sweep = true;
  }

double VNSMC_StructureScore(int dir, string engine)
  {
   if(!UseSMCStructure || dir == 0) return 0.50;
   double score = 0.10;
   if(g_SMC.m15_bias == dir) score += 0.22;
   if(g_SMC.m5_bias  == dir) score += 0.25;
   if(g_SMC.m1_bias  == dir) score += 0.15;
   if(g_SMC.m15_event == dir) score += 0.10;
   if(g_SMC.m5_event  == dir) score += 0.12;
   if(g_SMC.m1_event  == dir) score += 0.08;
   if(dir ==  1 && g_SMC.bull_zone_near) score += 0.08;
   if(dir == -1 && g_SMC.bear_zone_near) score += 0.08;
   if(dir ==  1 && g_SMC.bull_liq_sweep) score += 0.10;
   if(dir == -1 && g_SMC.bear_liq_sweep) score += 0.10;
   if(dir ==  1 && g_SMC.pd_location <= -0.20) score += 0.08;
   if(dir == -1 && g_SMC.pd_location >=  0.20) score += 0.08;
   if(engine == "RANGE")
     {
      if(g_SMC.m15_bias == -dir) score -= 0.18;
      if(g_SMC.m5_bias  == -dir) score -= 0.18;
     }
   return Clamp(score, 0.0, 1.0);
  }

bool VNSMC_TrendBreak(int dir)
  {
   if(dir == 0 || !UseSMCStructure) return false;
   if(dir == 1)  return (g_SMC.m1_event == 1  || g_SMC.m5_event == 1);
   return (g_SMC.m1_event == -1 || g_SMC.m5_event == -1);
  }

//===================================================================
// SECTION 40 — QUALITY GATE
//===================================================================
double QualityTriggerScore(int dir)
  {
   int c = 0;
   if(dir ==  1) { if(M1PA_BullDisp) c++; if(M1PA_BullMSS) c++; if(M1PA_BullSweep) c++; if(M1PA_BullFVG) c++; }
   if(dir == -1) { if(M1PA_BearDisp) c++; if(M1PA_BearMSS) c++; if(M1PA_BearSweep) c++; if(M1PA_BearFVG) c++; }
   if(c >= 3) return 1.00;
   if(c == 2) return 0.85;
   if(c == 1) return 0.65;
   return 0.45;
  }

double ComputeQualityScore(string engine, int dir)
  {
   if(dir == 0) return 0.0;
   double smc = VNSMC_StructureScore(dir, engine);
   double trig = QualityTriggerScore(dir);
   double loc = 0.50;
   if(dir ==  1 && g_SMC.bull_zone_near) loc = 0.85;
   if(dir == -1 && g_SMC.bear_zone_near) loc = 0.85;
   if(dir ==  1 && g_SMC.bull_liq_sweep) loc = MathMax(loc, 0.85);
   if(dir == -1 && g_SMC.bear_liq_sweep) loc = MathMax(loc, 0.85);
   double volRatio = (NormalATR1 > 0.0) ? CurrentATR1 / NormalATR1 : 1.0;
   double volScore = Clamp(0.50 + (volRatio - 1.0) * 0.30, 0.25, 1.00);
   double flowScore = 0.50;
   if(BridgeReady())
     {
      double fc = FlowComposite() * (double)dir;
      flowScore = Clamp(0.50 + fc / 200.0, 0.20, 0.85);
      if(VNFlowCVDAccelerationStrong(dir)) flowScore += 0.10;
      if(VNFlowCascade(dir))               flowScore += 0.05;
      flowScore = Clamp(flowScore, 0.0, 1.0);
     }
   double q = QualityBase + smc * 0.30 + trig * 0.20 + loc * 0.10 +
              volScore * 0.10 + flowScore * 0.05;
   if(g_R7 == R7_EXPANSION && engine == "MONSTER") q += 0.05;
   if(g_R7 == R7_CHOP      && engine == "RANGE")   q += 0.05;
   return Clamp(q, 0.0, 1.0);
  }

double QualityFloorForEngine(string engine)
  {
   if(engine == "MONSTER")  return QualityMinMonster;
   if(engine == "SWING")    return QualityMinSwing;
   if(engine == "RANGE")    return QualityMinRange;
   if(engine == "REVERSAL") return QualityMinReversal;
   return QualityMinSwing;
  }

bool QualityGateAllows(string engine, int dir)
  {
   if(!UseQualityGate) return true;
   return (ComputeQualityScore(engine, dir) >= QualityFloorForEngine(engine));
  }

//===================================================================
// SECTION 41 — STATISTICAL HELPERS
//===================================================================
double VNLogistic(double x)
  {
   x = Clamp(x, -35.0, 35.0);
   return 1.0 / (1.0 + MathExp(-x));
  }

double VNBayesUpdate(double prior, double evidenceProb, double weight)
  {
   prior        = Clamp(prior, 0.001, 0.999);
   evidenceProb = Clamp(evidenceProb, 0.001, 0.999);
   weight       = MathMax(0.0, weight);
   double priorOdds = prior / (1.0 - prior);
   double evOdds    = evidenceProb / (1.0 - evidenceProb);
   double postOdds  = priorOdds * MathPow(evOdds, weight);
   return Clamp(postOdds / (1.0 + postOdds), 0.001, 0.999);
  }

double VNEntropyM1(int lookback)
  {
   if(lookback < 8) lookback = 8;
   if(Bars(_Symbol, PERIOD_M1) < lookback + 5) return 1.0;
   int up=0, down=0, flat=0;
   for(int i = 1; i <= lookback; i++)
     {
      double c0 = TfClose(PERIOD_M1, i);
      double c1 = TfClose(PERIOD_M1, i + 1);
      if(c0 <= 0.0 || c1 <= 0.0) continue;
      double r = c0 - c1;
      if(r > 0.0) up++; else if(r < 0.0) down++; else flat++;
     }
   double total = (double)(up + down + flat);
   if(total <= 0.0) return 1.0;
   double h = 0.0;
   if(up > 0)   { double p = up   / total; h -= p * MathLog(p); }
   if(down > 0) { double p = down / total; h -= p * MathLog(p); }
   if(flat > 0) { double p = flat / total; h -= p * MathLog(p); }
   double maxH = MathLog(3.0);
   if(maxH <= 0.0) return 1.0;
   return Clamp(h / maxH, 0.0, 1.0);
  }

double VNMutualInformationM5M15(int lookback)
  {
   if(lookback < 12) lookback = 12;
   if(Bars(_Symbol, PERIOD_M5) < lookback + 5 ||
      Bars(_Symbol, PERIOD_M15) < (lookback / 3) + 5) return 0.0;
   int count[3][3];
   ArrayInitialize(count, 0);
   for(int i = 1; i <= lookback; i++)
     {
      double m5c0 = TfClose(PERIOD_M5, i);
      double m5c1 = TfClose(PERIOD_M5, i + 1);
      datetime t  = TfTime(PERIOD_M5, i);
      if(m5c0 <= 0.0 || m5c1 <= 0.0 || t == 0) continue;
      int a = 1;
      double r5 = m5c0 - m5c1;
      if(r5 > 0.0) a = 2; else if(r5 < 0.0) a = 0;
      int sh15 = iBarShift(_Symbol, PERIOD_M15, t, false);
      if(sh15 < 1) continue;
      double m15c0 = TfClose(PERIOD_M15, sh15);
      double m15c1 = TfClose(PERIOD_M15, sh15 + 1);
      if(m15c0 <= 0.0 || m15c1 <= 0.0) continue;
      int b = 1;
      double r15 = m15c0 - m15c1;
      if(r15 > 0.0) b = 2; else if(r15 < 0.0) b = 0;
      count[a][b]++;
     }
   double total = 0.0;
   for(int i=0;i<3;i++) for(int j=0;j<3;j++) total += (double)count[i][j];
   if(total <= 0.0) return 0.0;
   double px[3]={0,0,0}, py[3]={0,0,0};
   for(int i=0;i<3;i++) for(int j=0;j<3;j++) { px[i]+=count[i][j]; py[j]+=count[i][j]; }
   double mi = 0.0;
   for(int i=0;i<3;i++) for(int j=0;j<3;j++)
     {
      if(count[i][j] <= 0 || px[i] <= 0.0 || py[j] <= 0.0) continue;
      double pxy = (double)count[i][j] / total;
      double denom = (px[i] / total) * (py[j] / total);
      if(denom > 0.0) mi += pxy * MathLog(pxy / denom);
     }
   return Clamp(mi / MathLog(3.0), 0.0, 1.0);
  }

double VNFracDiffCurrent(int window, double d)
  {
   if(window < 4) window = 4;
   if(window > 60) window = 60;
   if(Bars(_Symbol, PERIOD_M1) < window + 5) return 0.0;
   double w[];
   ArrayResize(w, window);
   w[0] = 1.0;
   for(int k = 1; k < window; k++)
      w[k] = -w[k - 1] * ((d - (double)k + 1.0) / (double)k);
   double result = 0.0;
   double c0 = TfClose(PERIOD_M1, 1);
   if(c0 <= 0.0) return 0.0;
   double scale = MathAbs(c0);
   if(scale <= 0.0) return 0.0;
   for(int k = 0; k < window; k++)
     {
      double c = TfClose(PERIOD_M1, k + 1);
      if(c <= 0.0) continue;
      result += w[k] * (c / scale);
     }
   return result;
  }

double VNFracDiffFromBars(int window, double d)
  {
   return VNFracDiffCurrent(window, d);
  }

//===================================================================
// SECTION 42 — KALMAN FILTER
//===================================================================
void VNKalmanUpdate()
  {
   datetime bar = TfTime(PERIOD_M1, 1);
   if(bar == 0 || bar == g_KalmanTime) return;
   double z = TfClose(PERIOD_M1, 1);
   if(z <= 0.0) return;
   g_KalmanTime = bar;
   if(g_KalmanPrice <= 0.0)
     {
      g_KalmanPrice = z; g_KalmanVelocity = 0.0;
      g_KalmanP00 = 1.0; g_KalmanP01 = 0.0;
      g_KalmanP10 = 0.0; g_KalmanP11 = 1.0;
      return;
     }
   double q = MathMax(0.000001, KalmanProcessNoise);
   double r = MathMax(0.000001, KalmanMeasurementNoise);
   double x0 = g_KalmanPrice + g_KalmanVelocity;
   double x1 = g_KalmanVelocity;
   double p00 = g_KalmanP00 + g_KalmanP01 + g_KalmanP10 + g_KalmanP11 + q;
   double p01 = g_KalmanP01 + g_KalmanP11;
   double p10 = g_KalmanP10 + g_KalmanP11;
   double p11 = g_KalmanP11 + q;
   double s = p00 + r;
   if(s <= 0.0) return;
   double k0 = p00 / s;
   double k1 = p10 / s;
   double innov = z - x0;
   g_KalmanPrice    = x0 + k0 * innov;
   g_KalmanVelocity = x1 + k1 * innov;
   g_KalmanP00 = (1.0 - k0) * p00;
   g_KalmanP01 = (1.0 - k0) * p01;
   g_KalmanP10 = p10 - k1 * p00;
   g_KalmanP11 = p11 - k1 * p01;
  }

//===================================================================
// SECTION 43 — OU MEAN REVERSION MODEL
//===================================================================
bool VNComputeOU()
  {
   g_OU.valid=false; g_OU.mu=0.0; g_OU.theta=0.0; g_OU.sigma=0.0;
   g_OU.z=0.0; g_OU.half_life=999.0; g_OU.reversion_prob=0.0;
   int n = OURangeWindow;
   if(n < 20) n = 20;
   if(n > 180) n = 180;
   if(Bars(_Symbol, PERIOD_M1) < n + 5) return false;
   double x[]; ArrayResize(x, n);
   double sum = 0.0;
   for(int i = 0; i < n; i++)
     {
      double c = TfClose(PERIOD_M1, i + 1);
      if(c <= 0.0) return false;
      x[i] = c; sum += c;
     }
   double mu = sum / (double)n;
   if(BridgeReady() && gBinAux.rolling_vwap > 0.0) mu = gBinAux.rolling_vwap;
   else if(g_InternalVWAP > 0.0) mu = g_InternalVWAP;
   double num=0.0, den=0.0;
   for(int i = 1; i < n; i++)
     {
      double a = x[i-1] - mu;
      double b = x[i]   - mu;
      num += a * b;
      den += b * b;
     }
   if(den <= 0.0) return false;
   double phi = Clamp(num / den, -0.999, 0.999);
   double rss=0.0; int rc=0;
   for(int i = 1; i < n; i++)
     {
      double expected = mu + phi * (x[i] - mu);
      double e = x[i-1] - expected;
      rss += e * e; rc++;
     }
   if(rc <= 2) return false;
   double sigma = MathSqrt(rss / (double)rc);
   if(sigma <= 0.0) return false;
   if(phi <= 0.0 || phi >= 1.0) return false;
   double theta = -MathLog(phi);
   if(theta <= 0.0) return false;
   double price = MidPrice();
   if(price <= 0.0) return false;
   double z = (price - mu) / sigma;
   double halfLife = MathLog(2.0) / theta;
   double quality = MathAbs(z) * MathMin(3.0, theta / MathMax(0.000001, OUMinTheta));
   double prob = VNLogistic((quality - 1.2) * 1.4);
   g_OU.valid=true; g_OU.mu=mu; g_OU.theta=theta; g_OU.sigma=sigma;
   g_OU.z=z; g_OU.half_life=halfLife; g_OU.reversion_prob=Clamp(prob, 0.0, 1.0);
   return true;
  }

bool VNOUAllowsRange(int dir)
  {
   if(!UseOURange) return true;
   if(dir == 0 || !g_OU.valid) return false;
   if(MathAbs(g_OU.z) < OUMinAbsZ) return false;
   if(g_OU.theta < OUMinTheta) return false;
   if(g_OU.half_life > OUMaxHalfLifeBars) return false;
   if(g_OU.reversion_prob < OURangeMinProbability) return false;
   if(dir ==  1 && g_OU.z >= 0.0) return false;
   if(dir == -1 && g_OU.z <= 0.0) return false;
   if(g_R7 == R7_EXPANSION || g_R7 == R7_COMPRESSION) return false;
   if(g_CUSUMDir != 0 && TimeCurrent() <= g_CUSUMOverrideUntil) return false;
   if(M15Direction != 0 && M5Direction == M15Direction &&
      (g_R7 == R7_STRONG_UP || g_R7 == R7_STRONG_DOWN)) return false;
   return true;
  }

//===================================================================
// SECTION 44 — CUSUM CHANGE-POINT [A3: bypass regime when fresh]
//===================================================================
bool VNUpdateCUSUM()
  {
   if(!UseCUSUM) return false;
   static datetime lastBar = 0;
   datetime bar = TfTime(PERIOD_M1, 1);
   if(bar == 0 || bar == lastBar) return false;
   lastBar = bar;
   int n = CUSUMWindow;
   if(n < 10) n = 10;
   if(n > 80) n = 80;
   if(Bars(_Symbol, PERIOD_M1) < n + 5) return false;
   double sum=0.0, sq=0.0; int cnt=0;
   for(int i = 2; i < n + 2; i++)
     {
      double c0 = TfClose(PERIOD_M1, i);
      double c1 = TfClose(PERIOD_M1, i + 1);
      if(c0 <= 0.0 || c1 <= 0.0) continue;
      double r = MathLog(c0 / c1);
      sum += r; sq += r * r; cnt++;
     }
   if(cnt < 8) return false;
   double mean = sum / (double)cnt;
   double var = MathMax(0.0, sq / (double)cnt - mean * mean);
   double sd = MathSqrt(var);
   if(sd <= 0.0) return false;
   double cNow0 = TfClose(PERIOD_M1, 1);
   double cNow1 = TfClose(PERIOD_M1, 2);
   if(cNow0 <= 0.0 || cNow1 <= 0.0) return false;
   double zr = (MathLog(cNow0 / cNow1) - mean) / sd;
   double drift = MathMax(0.0, CUSUMDrift);
   g_CUSUMBull = MathMax(0.0, g_CUSUMBull + zr - drift);
   g_CUSUMBear = MathMax(0.0, g_CUSUMBear - zr - drift);
   bool fired = false;
   if(g_CUSUMBull >= CUSUMThreshold)
     {
      g_CUSUMDir = 1;
      g_CUSUMLastFire = TimeCurrent();
      g_CUSUMOverrideUntil = TimeCurrent() + CUSUMPauseSeconds;
      g_CUSUMBull = 0.0; g_CUSUMBear = 0.0;
      fired = true;
     }
   else if(g_CUSUMBear >= CUSUMThreshold)
     {
      g_CUSUMDir = -1;
      g_CUSUMLastFire = TimeCurrent();
      g_CUSUMOverrideUntil = TimeCurrent() + CUSUMPauseSeconds;
      g_CUSUMBull = 0.0; g_CUSUMBear = 0.0;
      fired = true;
     }
   else if(TimeCurrent() > g_CUSUMOverrideUntil)
      g_CUSUMDir = 0;
   if(fired)
      PrintFormat("[CUSUM] change-point dir=%s", DirStr(g_CUSUMDir));
   return fired;
  }

bool VNFlowCUSUMAugmented()
  {
   if(!UseFlowCUSUMAugment) return false;
   if(!BridgeReady()) return false;
   if(g_CUSUMDir == 0) return false;
   if(TimeCurrent() > g_CUSUMOverrideUntil) return false;
   bool catalyst = VNFlowTradeRateSurge() ||
                   VNFlowCVDAccelerationStrong(g_CUSUMDir) ||
                   VNFlowCascade(g_CUSUMDir);
   if(catalyst)
     {
      datetime newUntil = TimeCurrent() + 60;
      if(newUntil > g_CUSUMOverrideUntil) g_CUSUMOverrideUntil = newUntil;
      return true;
     }
   return false;
  }

bool VNShockEligible(int dir)
  {
   if(!UseCUSUM || dir == 0) return false;
   if(g_CUSUMDir != dir) return false;
   if(TimeCurrent() > g_CUSUMOverrideUntil) return false;
   bool pa = (dir == 1)
             ? (M1BullDisplacement() || M1BullMSS() || M1BullSweep())
             : (M1BearDisplacement() || M1BearMSS() || M1BearSweep());
   return pa;
  }

//===================================================================
// SECTION 45 — 7-STATE REGIME + HMM POSTERIOR
//===================================================================
double CRG_ComputeHurst(ENUM_TIMEFRAMES tf, int N)
  {
   if(N < 20) return 0.5;
   if(Bars(_Symbol, tf) < N + 5) return 0.5;
   double r[]; ArrayResize(r, N);
   double sum = 0.0;
   for(int i = 0; i < N; i++)
     {
      double c0 = TfClose(tf, i);
      double c1 = TfClose(tf, i + 1);
      if(c0 <= 0.0 || c1 <= 0.0) return 0.5;
      double lr = MathLog(c0 / c1);
      r[i] = lr; sum += lr;
     }
   double mean = sum / (double)N;
   double varSum = 0.0;
   for(int i = 0; i < N; i++) { double d = r[i] - mean; varSum += d * d; }
   double sd = MathSqrt(varSum / (double)N);
   if(sd <= 0.0) return 0.5;
   double cum=0.0, cumMin=1e18, cumMax=-1e18;
   for(int i = 0; i < N; i++)
     {
      cum += r[i] - mean;
      if(cum < cumMin) cumMin = cum;
      if(cum > cumMax) cumMax = cum;
     }
   double R = cumMax - cumMin;
   if(R <= 0.0) return 0.5;
   double H = MathLog(R / sd) / MathLog((double)N / 2.0);
   return Clamp(H, 0.0, 1.0);
  }

double CRG_ComputeAutocorr(ENUM_TIMEFRAMES tf, int N)
  {
   if(N < 10) return 0.0;
   if(Bars(_Symbol, tf) < N + 5) return 0.0;
   double r[]; ArrayResize(r, N);
   double sum = 0.0;
   for(int i = 0; i < N; i++)
     {
      double c0 = TfClose(tf, i);
      double c1 = TfClose(tf, i + 1);
      if(c0 <= 0.0 || c1 <= 0.0) return 0.0;
      r[i] = MathLog(c0 / c1);
      sum += r[i];
     }
   double mean = sum / (double)N;
   double num=0.0, den=0.0;
   for(int i = 0; i < N - 1; i++) num += (r[i] - mean) * (r[i+1] - mean);
   for(int i = 0; i < N; i++)     { double d = r[i] - mean; den += d * d; }
   if(den <= 0.0) return 0.0;
   return num / den;
  }

double CalculateATR15_Pct()
  {
   double atrNow = BufVal(hATR_M15, 0, 1);
   if(atrNow <= 0.0) return 0.0;
   double sum = 0.0; int c = 0;
   for(int i = 1; i <= 100; i++)
     {
      double v = BufVal(hATR_M15, 0, i);
      if(v > 0.0) { sum += v; c++; }
     }
   if(c <= 0) return 0.0;
   double avg = sum / c;
   if(avg <= 0.0) return 0.0;
   return atrNow / avg;
  }

void ComputeAdaptiveRegimeMetrics()
  {
   ER_Short_M5 = CalculateER_TF(PERIOD_M5, 10);
   ER_Med_M5   = CalculateER_TF(PERIOD_M5, 30);
   ER_Slow_M15 = CalculateER_TF(PERIOD_M15, 30);
   ATR15_Pct   = CalculateATR15_Pct();
  }

ENUM_REGIME7 ComputeRegime7()
  {
   if(!UseRegimeSupervisor) return R7_CHOP;

   double adx15 = BufVal(hADX_M15, 0, 1);
   double adx5  = BufVal(hADX_M5,  0, 1);
   double er15  = Clamp(CalculateER_TF(PERIOD_M15, Regime_ER_Period), 0.0, 1.0);
   double atrRatio = (NormalATR5 > 0.0 && CurrentATR5 > 0.0)
                     ? CurrentATR5 / NormalATR5 : 1.0;
   double m5Range = TfHigh(PERIOD_M5, 1) - TfLow(PERIOD_M5, 1);
   double m5RangeAtr = (CurrentATR5 > 0.0) ? m5Range / CurrentATR5 : 1.0;

   bool expansion = (atrRatio >= ExpansionATRRatio || m5RangeAtr >= 1.75 ||
                     VNFlowTradeRateSurge() ||
                     (gBinAux.valid && gBinAux.range_exp >= 2.0));
   bool compression = (atrRatio <= CompressionATRRatio &&
                       er15 <= CompressionERThreshold &&
                       adx5 < WeakADXThreshold);

   ENUM_REGIME7 next = R7_CHOP;

   if(expansion)         next = R7_EXPANSION;
   else if(compression)  next = R7_COMPRESSION;
   else
     {
      bool bull = (M15Direction == 1 && M5Direction == 1);
      bool bear = (M15Direction == -1 && M5Direction == -1);
      if(bull && adx15 >= StrongADXThreshold && adx5 >= StrongADXThreshold &&
         er15 >= StrongERThreshold) next = R7_STRONG_UP;
      else if(bear && adx15 >= StrongADXThreshold && adx5 >= StrongADXThreshold &&
              er15 >= StrongERThreshold) next = R7_STRONG_DOWN;
      else if(bull || (M15Direction == 1  && adx15 >= WeakADXThreshold)) next = R7_WEAK_UP;
      else if(bear || (M15Direction == -1 && adx15 >= WeakADXThreshold)) next = R7_WEAK_DOWN;
      else next = R7_CHOP;
     }

   if(g_CUSUMDir != 0 && TimeCurrent() <= g_CUSUMOverrideUntil)
      next = R7_EXPANSION;

   datetime now = TimeCurrent();
   if(g_R7Since == 0) g_R7Since = now;

   if(next != g_R7)
     {
      if(next != g_R7Pending)
        { g_R7Pending = next; g_R7PendingSince = now; }
      else if(now - g_R7PendingSince >= AdaptiveRegimeStickySec)
        {
         PrintFormat("[REGIME] %s -> %s ATRr=%.2f ER=%.2f ADX15=%.1f ADX5=%.1f",
                     Regime7Name(g_R7), Regime7Name(next),
                     atrRatio, er15, adx15, adx5);
         g_R7 = next;
         g_R7Since = now;
         g_R7Pending = R7_CHOP;
        }
     }
   else
      g_R7Pending = R7_CHOP;

   return g_R7;
  }

void VNUpdateHMMPosterior()
  {
   if(!UseHMMLikePosterior) return;
   double emission[7];
   double atrRatio = (NormalATR5 > 0.0 && CurrentATR5 > 0.0)
                     ? CurrentATR5 / NormalATR5 : 1.0;
   int rdir = 0;
   if(g_R7 == R7_STRONG_UP || g_R7 == R7_WEAK_UP)     rdir =  1;
   if(g_R7 == R7_STRONG_DOWN || g_R7 == R7_WEAK_DOWN) rdir = -1;
   double align = 0.0;
   if(M15Direction != 0 && M5Direction == M15Direction) align = (double)M15Direction;
   for(int i = 0; i < 7; i++)
     {
      double e = 0.05;
      if(i == (int)g_R7) e += 0.55;
      if(i == (int)g_R7 && rdir != 0) e += 0.10;
      if(i == (int)R7_EXPANSION   && atrRatio > 1.4) e += 0.25;
      if(i == (int)R7_COMPRESSION && atrRatio < 0.8) e += 0.25;
      if(i == (int)R7_STRONG_UP   && align > 0.0) e += 0.20;
      if(i == (int)R7_STRONG_DOWN && align < 0.0) e += 0.20;
      if(i == (int)R7_CHOP        && g_VNEntropy > 0.90) e += 0.15;
      emission[i] = MathMax(0.0001, e);
     }
   double sum = 0.0;
   double out[7];
   for(int i = 0; i < 7; i++)
     {
      out[i] = g_HMMProb[i] * HMMOldStateWeight + emission[i] * (1.0 - HMMOldStateWeight);
      sum += out[i];
     }
   if(sum <= 0.0) return;
   int best = 0; double bestP = 0.0;
   for(int i = 0; i < 7; i++)
     {
      g_HMMProb[i] = out[i] / sum;
      if(g_HMMProb[i] > bestP) { bestP = g_HMMProb[i]; best = i; }
     }
   g_HMMRegime = best;
   g_R7Confidence = bestP;
  }

double Regime_SizeMult()
  {
   switch(g_R7)
     {
      case R7_EXPANSION:   return 1.15;
      case R7_STRONG_UP:
      case R7_STRONG_DOWN: return 1.00;
      case R7_WEAK_UP:
      case R7_WEAK_DOWN:   return 0.90;
      case R7_CHOP:        return 0.80;
      case R7_COMPRESSION: return 0.70;
     }
   return 0.80;
  }

bool Regime_AllowsEngine(string engine)
  {
   if(!UseRegimeSupervisor) return true;
   switch(g_R7)
     {
      case R7_EXPANSION:
         return (engine == "MONSTER" || engine == "SWING" || engine == "REVERSAL");
      case R7_STRONG_UP:
      case R7_STRONG_DOWN:
         return (engine == "MONSTER" || engine == "SWING");
      case R7_WEAK_UP:
      case R7_WEAK_DOWN:
         return (engine == "SWING" || engine == "REVERSAL" || engine == "RANGE");
      case R7_CHOP:
         return (engine == "RANGE" || engine == "REVERSAL" || engine == "SWING");
      case R7_COMPRESSION:
         return (engine == "RANGE");
     }
   return true;
  }

//===================================================================
// SECTION 46 — FASTTRENDSCORE
//===================================================================
double ComputeFastTrendScore()
  {
   double score = 0.0;
   int    dirSum = 0;

   //--- Component 1: Bridge flow
   double flowScore = 0.0;
   int    flowDir   = 0;
   if(BridgeReady())
     {
      double fc = FlowComposite();
      int flowSign = 0;
      if(fc >  BinanceMinFlowScore) flowSign =  1;
      if(fc < -BinanceMinFlowScore) flowSign = -1;

      if(flowSign != 0)
        {
         flowScore += 15.0;
         if(MathAbs(fc) >= BinanceStrongFlowScore) flowScore += 10.0;
        }
      if(VNFlowCVDAccelerationStrong(1))  { flowScore += 10.0; flowSign =  1; }
      if(VNFlowCVDAccelerationStrong(-1)) { flowScore += 10.0; flowSign = -1; }

      if(gBinAux.oi_regime == 1 || gBinAux.oi_regime == 4) { if(flowSign == 0) flowSign =  1; }
      if(gBinAux.oi_regime == 2 || gBinAux.oi_regime == 3) { if(flowSign == 0) flowSign = -1; }

      if(flowScore > FastTrend_FlowWeight) flowScore = FastTrend_FlowWeight;
      flowDir = flowSign;
     }

   //--- Component 2: M5 structure
   double m5Score = 0.0;
   int    m5Dir   = 0;
   {
      bool trendExists = (BufVal(hADX_M15, 0, 1) > 16.0);
      bool brokeUpper  = (MidPrice() >= DC_UpperPrev && DC_UpperPrev > 0.0);
      bool brokeLower  = (MidPrice() <= DC_LowerPrev && DC_LowerPrev > 0.0);

      if(trendExists && brokeUpper && MA_Slope >  FastTrend_DonchianSlopeMin)
        { m5Score += 20.0; m5Dir =  1; }
      else if(trendExists && brokeLower && MA_Slope < -FastTrend_DonchianSlopeMin)
        { m5Score += 20.0; m5Dir = -1; }

      double width = DC_Upper - DC_Lower;
      if(CurrentATR5 > 0.0 && width > CurrentATR5 * FastTrend_DonchianWidthATR)
         m5Score += 5.0;

      if(g_SMC.m5_bias != 0 && g_SMC.m5_bias == M15Direction)
        { m5Score += 10.0; if(m5Dir == 0) m5Dir = g_SMC.m5_bias; }

      if(m5Score > FastTrend_M5Weight) m5Score = FastTrend_M5Weight;
     }

   //--- Component 3: VP acceptance
   double vpScore = 0.0;
   int    vpDir   = 0;
   {
      double price = MidPrice();
      if(g_NVP.valid)
        {
         double buffer = CurrentATR5 * 0.5;
         if(buffer <= 0.0) buffer = CurrentATR1 * 0.5;
         if(price > g_NVP.vah + buffer) { vpScore += 10.0; vpDir =  1; }
         if(price < g_NVP.val - buffer) { vpScore += 10.0; vpDir = -1; }
         if(g_NVP.vaWidthPct > VP_CompressMaxPct * 1.5) vpScore += 10.0;
        }
      if(vpScore > FastTrend_VPWeight) vpScore = FastTrend_VPWeight;
     }

   //--- Component 4: M15 SMC
   double m15Score = 0.0;
   int    m15Dir   = 0;
   {
      if(g_SMC.m15_bias != 0)
        {
         m15Score = 10.0;
         m15Dir   = g_SMC.m15_bias;
        }
      if(m15Score > FastTrend_M15Weight) m15Score = FastTrend_M15Weight;
     }

   //--- Compose
   score = flowScore + m5Score + vpScore + m15Score;
   score = Clamp(score, 0.0, 100.0);

   dirSum = flowDir * 4 + m5Dir * 3 + vpDir * 2 + m15Dir * 1;
   int finalDir = 0;
   if(dirSum >  1) finalDir =  1;
   if(dirSum < -1) finalDir = -1;

   g_FastTrendScore = score;
   g_FastTrendDir   = finalDir;
   return score;
  }

int FastTrendDir() { return g_FastTrendDir; }

//===================================================================
// SECTION 47 — REGIME DIRECTION GATE
//===================================================================
bool RegimeGateAllows(int dir, string engine)
  {
   if(!UseRegimeDirectionGate) return true;
   if(dir == 0) return false;

   if(g_R7 == R7_CHOP || g_R7 == R7_COMPRESSION) return true;

   if(g_R7 == R7_STRONG_UP || g_R7 == R7_WEAK_UP)
     {
      if(dir == 1) return true;
      if(!RegimeGateRequiresFastTrend) return true;
      if(UseFastTrendScore && g_FastTrendScore >= FastTrend_PrimeThreshold) return false;
      bool smcOppose = (g_SMC.m15_bias == -1 || g_SMC.m5_bias == -1);
      bool flowOppose = !BridgeReady() || (FlowComposite() < -BinanceMinFlowScore);
      return (smcOppose && flowOppose);
     }

   if(g_R7 == R7_STRONG_DOWN || g_R7 == R7_WEAK_DOWN)
     {
      if(dir == -1) return true;
      if(!RegimeGateRequiresFastTrend) return true;
      if(UseFastTrendScore && g_FastTrendScore >= FastTrend_PrimeThreshold) return false;
      bool smcOppose = (g_SMC.m15_bias == 1 || g_SMC.m5_bias == 1);
      bool flowOppose = !BridgeReady() || (FlowComposite() > BinanceMinFlowScore);
      return (smcOppose && flowOppose);
     }

   return true;
  }

double RegimeGateSizeMult(int dir)
  {
   if(!UseRegimeDirectionGate) return 1.0;
   if(g_R7 == R7_STRONG_UP || g_R7 == R7_WEAK_UP)
      return (dir == 1) ? 1.0 : RegimeGateOppositeSizeMult;
   if(g_R7 == R7_STRONG_DOWN || g_R7 == R7_WEAK_DOWN)
      return (dir == -1) ? 1.0 : RegimeGateOppositeSizeMult;
   return 1.0;
  }

//===================================================================
// SECTION 48 — LEGACY CAMPAIGN STATISTICAL UPDATE
//===================================================================
void VNAdvancedMarketUpdate()
  {
   VNKalmanUpdate();
   g_VNEntropy      = VNEntropyM1(FeatureInfoWindow);
   g_SignalMI_M5M15 = VNMutualInformationM5M15(FeatureInfoWindow);
   g_FractDiff      = VNFracDiffFromBars(FractionalDiffWindow, 0.40);
   VNComputeOU();
   VNUpdateCUSUM();
   if(BridgeReady()) VNFlowCUSUMAugmented();
   ComputeRegime7();
   VNUpdateHMMPosterior();
   if(UseFastTrendScore) ComputeFastTrendScore();
  }

//===================================================================
// SECTION 49 — DIRECTION CALC (M1 + M5 vote, M15/H1 veto)
//===================================================================
int LegacyFinalDirection(int &source)
  {
   source = 0;
   if(UseM1PA && M1PA_Dir != 0 && M1PA_Score >= M1PA_OverrideScore)
     { source = 5; return M1PA_Dir; }
   if(Jerk_M15 != 0) { source = 1; return Jerk_M15; }
   if(Jerk_M5  != 0) { source = 2; return Jerk_M5;  }
   if(CombinedDirection == 0)
     {
      if(UseM1PA && M1PA_Dir != 0 && M1PA_Score >= M1PA_BoostScore)
        { source = 5; return M1PA_Dir; }
      return 0;
     }
   int direction = (CombinedDirection > 0) ? 1 : -1;
   if(direction ==  1 && KAMA_M15_Slope < -KAMA_SlopeMin) { source = 4; return -1; }
   if(direction == -1 && KAMA_M15_Slope >  KAMA_SlopeMin) { source = 4; return  1; }
   if(UseM1PA && M1PA_Dir == direction && M1PA_Score >= M1PA_BoostScore) source = 5;
   else source = 3;
   return direction;
  }

int FastDirection()
  {
   int dirV = 0;
   double vroc = (BridgeReady() && gBinAux.vroc > 0.0) ? gBinAux.vroc : 0.0;
   if(vroc >= 2.5)
     {
      double o = TfOpen(PERIOD_M1, 0);
      double c = TfClose(PERIOD_M1, 0);
      if(o > 0.0 && c > 0.0)
        {
         if(c > o + 5 * _Point) dirV =  1;
         if(c < o - 5 * _Point) dirV = -1;
        }
     }
   int dirC = 0;
   if(FlowFresh())
     {
      if(CVDAccelerationNormalized >  0.05 && CVDVelocityNormalized > 0) dirC =  1;
      if(CVDAccelerationNormalized < -0.05 && CVDVelocityNormalized < 0) dirC = -1;
     }
   int dirW = 0;
   if(gBinAux.valid)
     {
      if(gBinAux.vwap_slope >  3.0) dirW =  1;
      if(gBinAux.vwap_slope < -3.0) dirW = -1;
     }
   else
     {
      if(VWAP_Bias != 0) dirW = VWAP_Bias;
     }

   if(MQLInfoInteger(MQL_TESTER))
     {
      if(dirV ==  1 && dirW >= 0) return  1;
      if(dirV == -1 && dirW <= 0) return -1;
      return 0;
     }
   int votes = dirV + dirC + dirW;
   if(dirV ==  1 && votes >=  1) return  1;
   if(dirV == -1 && votes <= -1) return -1;
   return 0;
  }

void RefreshLegacyContext(bool force = false)
  {
   static datetime lastM15 = 0;
   static datetime lastM5  = 0;
   static datetime lastH1  = 0;
   datetime curM15 = TfTime(PERIOD_M15, 0);
   datetime curM5  = TfTime(PERIOD_M5,  0);
   datetime curH1  = TfTime(PERIOD_H1,  0);

   if(force || (curM15 > 0 && curM15 != lastM15))
     {
      lastM15 = curM15;
      Jerk_M15 = DetectM15Jerk();
      M15Direction = CalcM15Direction();
      VolSurgeBull_sig = ComputeVolSurgeBull();
      VolSurgeBear_sig = ComputeVolSurgeBear();
      OBV_Val = GetOBV_M15(0);
      OBV_Sig = GetOBVSig_M15(0);
      KAMA_M15 = GetKAMA_M15(0);
      KAMA_M15_Slope = KAMASlope_M15();
      VWAP_Bias = GetVWAPBias();
      DetectMSS_Event();
      ScanOB();
      UpdateTrendBias();
     }
   if(force || (curM5 > 0 && curM5 != lastM5))
     {
      lastM5 = curM5;
      Jerk_M5 = DetectM5Jerk();
      M5Direction = CalcM5Direction();
      CombinedDirection = 0;
      if(M15Direction > 0 && M5Direction > 0)      CombinedDirection =  2;
      else if(M15Direction < 0 && M5Direction < 0) CombinedDirection = -2;
      else if(M15Direction != 0)                   CombinedDirection = M15Direction;
      else                                         CombinedDirection = M5Direction;
      VWAP_Bias = GetVWAPBias();
      UpdateTrendBias();
      ScanFVG();
     }
   if(force || (curH1 > 0 && curH1 != lastH1))
     {
      lastH1 = curH1;
      if(UseHHLL) HHLL_State = GetHHLLStructure(HHLL_TF, HHLL_LB, HHLL_RB, HHLL_MaxAge);
      if(UseSupertrend) ST_Dir = GetSupertrend();
     }
  }

//===================================================================
// SECTION 50 — MOVE STATE
//===================================================================
void DetectMoveState()
  {
   RefreshLegacyContext();
   UpdateM1PA();

   int m15Direction = M15Direction;
   int m5Direction  = M5Direction;

   bool bullSweep = M1BullSweep();
   bool bearSweep = M1BearSweep();
   bool bullDisplacement = M1BullDisplacement();
   bool bearDisplacement = M1BearDisplacement();
   bool bullMSS = M1BullMSS();
   bool bearMSS = M1BearMSS();
   bool bullFVG = M1BullFVG();
   bool bearFVG = M1BearFVG();

   double previousRange = TfHigh(PERIOD_M1, 1) - TfLow(PERIOD_M1, 1);
   double normalATR = (NormalATR1 > 0.0) ? NormalATR1 : CurrentATR1;
   double rangeRatio = (normalATR > 0.0) ? previousRange / normalATR : 0.0;

   double flowScore = FlowComposite();
   int flowDirection = FlowDirection();
   double averageTradeRate = AverageFlowTradeRate();
   bool tradeRateSurge = (gFlow.trade_rate >=
                          MathMax(2.0, averageTradeRate * 1.40));

   CurrentMoveState = 0; CurrentDirection = 0;
   CurrentMoveScore = 20.0; CurrentDirectionSource = 0;

   // REVERSAL
   if((bullSweep && bullMSS && bullDisplacement) ||
      (bearSweep && bearMSS && bearDisplacement))
     {
      int direction = (bullSweep && bullMSS && bullDisplacement) ? 1 : -1;
      double score = 50.0;
      if((direction ==  1 && bullFVG) || (direction == -1 && bearFVG)) score += 8.0;
      if(direction == m5Direction)  score += 6.0;
      if(direction == m15Direction) score += 6.0;
      if(MSSFresh(direction))       score += 7.0;
      if(Flow_Agrees(direction, false)) score += 18.0;
      if(Flow_Agrees(direction, true))  score += 6.0;
      if(NearStoredZone(direction, 1.50)) score += 5.0;
      CurrentMoveState = 6;
      CurrentDirection = direction;
      CurrentMoveScore = Clamp(score, 0.0, 100.0);
      CurrentDirectionSource = 1;
      return;
     }

   // MONSTER
   bool liveFlow = UseBinanceFlow && !MQLInfoInteger(MQL_TESTER) && FlowFresh();
   bool monsterCondition = (rangeRatio >= 1.35) &&
     (((liveFlow && tradeRateSurge && MathAbs(flowScore) >= BinanceStrongFlowScore)) ||
      ((!liveFlow) && (Jerk_M15 != 0 || Jerk_M5 != 0 || bullDisplacement || bearDisplacement)));

   if(monsterCondition)
     {
      int direction = 0;
      if(g_R7 == R7_STRONG_UP)   direction =  1;
      if(g_R7 == R7_STRONG_DOWN) direction = -1;
      if(g_R7 == R7_EXPANSION && DC_Bias != 0) direction = DC_Bias;

      if(direction == 0 && liveFlow)
         direction = (flowScore > 0.0) ? 1 : -1;

      if(direction == 0)
        {
         if(bullDisplacement && !bearDisplacement) direction =  1;
         else if(bearDisplacement && !bullDisplacement) direction = -1;
         else if(Jerk_M15 != 0) direction = Jerk_M15;
         else direction = Jerk_M5;
        }

      if(direction != 0)
        {
         double dayOpen  = TfOpen(PERIOD_D1, 0);
         double dayClose = TfClose(PERIOD_D1, 0);
         if(dayOpen > 0.0 && dayClose > 0.0)
           {
            if((dayClose - dayOpen) > CurrentATR15 * 0.50 && direction == -1) direction = 1;
            if((dayOpen - dayClose) > CurrentATR15 * 0.50 && direction ==  1) direction = -1;
           }
        }

      if(direction != 0)
        {
         double score = 58.0;
         if(direction == m15Direction) score += 8.0;
         if(direction == m5Direction)  score += 8.0;
         if((direction ==  1 && bullDisplacement) || (direction == -1 && bearDisplacement)) score += 12.0;
         if((direction ==  1 && bullMSS) || (direction == -1 && bearMSS)) score += 6.0;
         if(liveFlow && gFlow.persistence >= 0.50) score += 7.0;
         if(liveFlow && (CVDVelocityNormalized * direction) >= 0.20) score += 5.0;
         CurrentMoveState = 3;
         CurrentDirection = direction;
         CurrentMoveScore = Clamp(score, 0.0, 100.0);
         CurrentDirectionSource = 2;
         return;
        }
     }

   // BREAKOUT
   if(rangeRatio >= 1.15)
     {
      int direction = 0;
      if(bullDisplacement && !bearDisplacement) direction =  1;
      else if(bearDisplacement && !bullDisplacement) direction = -1;
      else direction = flowDirection;

      if(direction != 0)
        {
         double score = 48.0;
         if(direction == m15Direction) score += 10.0;
         if(direction == m5Direction)  score += 10.0;
         if((direction ==  1 && bullMSS) || (direction == -1 && bearMSS)) score += 8.0;
         if(Flow_Agrees(direction, false)) score += 18.0;
         if(NearStoredZone(direction, 1.0)) score += 4.0;
         CurrentMoveState = 3;
         CurrentDirection = direction;
         CurrentMoveScore = Clamp(score, 0.0, 100.0);
         CurrentDirectionSource = 3;
         return;
        }
     }

   // CONTINUATION
   if(m15Direction != 0 && m5Direction == m15Direction &&
      ((m15Direction == 1 && bullDisplacement) || (m15Direction == -1 && bearDisplacement)))
     {
      int direction = m15Direction;
      double score = 48.0;
      if((direction ==  1 && bullMSS) || (direction == -1 && bearMSS)) score += 8.0;
      if((direction ==  1 && bullFVG) || (direction == -1 && bearFVG)) score += 6.0;
      if(Flow_Agrees(direction, false)) score += 18.0;
      if(CombinedDirection == 2 || CombinedDirection == -2) score += 5.0;
      CurrentMoveState = 4;
      CurrentDirection = direction;
      CurrentMoveScore = Clamp(score, 0.0, 100.0);
      CurrentDirectionSource = 4;
      return;
     }

   // COMPRESSION / LIQUIDITY
   double averageRange = 0.0; int rangeCount = 0;
   for(int i = 1; i <= 8; i++)
     {
      double range = TfHigh(PERIOD_M1, i) - TfLow(PERIOD_M1, i);
      if(range > 0.0) { averageRange += range; rangeCount++; }
     }
   if(rangeCount > 0) averageRange /= rangeCount;
   bool compression = (normalATR > 0.0 && averageRange <= normalATR * 0.85);

   if(compression)
     {
      bool liquidity = (MathAbs(flowScore) >= BinanceMinFlowScore) ||
                       (averageTradeRate > 0.0 && gFlow.trade_rate > averageTradeRate);
      CurrentMoveState = liquidity ? 2 : 1;
      if(flowDirection != 0) CurrentDirection = flowDirection;
      else if(m5Direction != 0) CurrentDirection = m5Direction;
      else CurrentDirection = m15Direction;
      CurrentMoveScore = liquidity ? 50.0 : 35.0;
      CurrentDirectionSource = 5;
      return;
     }

   // EXHAUSTION
   if(rangeRatio >= 1.80 && M1Exhaustion())
     {
      CurrentMoveState = 5;
      CurrentDirection = flowDirection;
      CurrentMoveScore = 55.0;
      CurrentDirectionSource = 6;
      return;
     }

   CurrentMoveState = 0;
   CurrentDirection = (flowDirection != 0) ? flowDirection
                     : ((m5Direction != 0) ? m5Direction : m15Direction);
   CurrentMoveScore = 20.0;
   CurrentDirectionSource = 7;
  }

int DetectMode()
  {
   bool bSweep = M1BullSweep(); bool sSweep = M1BearSweep();
   bool bMSS   = M1BullMSS();   bool sMSS   = M1BearMSS();
   bool bDisp  = M1BullDisplacement(); bool sDisp = M1BearDisplacement();

   if(bSweep && bMSS && bDisp) return 3;
   if(sSweep && sMSS && sDisp) return 3;

   double vroc = (BridgeReady() && gBinAux.vroc > 0.0) ? gBinAux.vroc : 0.0;
   double re   = (BridgeReady() && gBinAux.range_exp > 0.0) ? gBinAux.range_exp : 0.0;

   if(vroc >= 4.5 && re >= 2.2) return 2;
   if(vroc >= 2.5 && re >= 1.5) return 1;

   if(g_NVP.valid && NativeVPPriceInVA()) return 0;
   if(gBinVP.valid && VPPriceInVA())      return 0;

   return 1;
  }

//===================================================================
// END OF PART 3 OF 5
//===================================================================

//===================================================================
// SECTION 51 — HARD GATES
//===================================================================
bool HardGatesPass(string engine, int dir)
  {
   if(dir == 0) return false;

   if(UseSMCStructure)
     {
      double smc = VNSMC_StructureScore(dir, engine);
      double floor = SMC_MinSwingScore;
      if(engine == "MONSTER")  floor = SMC_MinMonsterScore;
      if(engine == "REVERSAL") floor = SMC_MinReversalScore;
      if(smc < floor) return false;
     }

   if(!QualityGateAllows(engine, dir)) return false;
   bool freshCusumMonster = (engine == "MONSTER" && UseCUSUM && g_CUSUMDir == dir &&
                             TimeCurrent() <= g_CUSUMOverrideUntil);
   if(!Regime_AllowsEngine(engine) && !freshCusumMonster) return false;

   if(BridgeReady())
     {
      if(gBinAux.oi_regime != 0)
        {
         if(dir ==  1 && gBinAux.oi_regime == 2) return false;
         if(dir == -1 && gBinAux.oi_regime == 4) return false;
        }
      if(gBinAux.vpin_regime >= 3) return false;

      if(WallInPath(dir)) return false;

      double fundAbs = MathAbs(gBinAux.funding) * 100.0;
      if(fundAbs >= 0.05)
        {
         if(dir ==  1 && gBinAux.funding > 0.0) return false;
         if(dir == -1 && gBinAux.funding < 0.0) return false;
        }

      if(gBinAux.long_short_ratio > 0.0)
        {
         if(dir ==  1 && gBinAux.long_short_ratio >= 2.00) return false;
         if(dir == -1 && gBinAux.long_short_ratio <= 0.50) return false;
        }
     }
   return true;
  }

//===================================================================
// SECTION 52 — SIZING (continuous compounding + session + recovery)
//===================================================================
double ContinuousGrowthMultiplier()
  {
   if(UseDiscreteGrowth) return DiscreteGrowthMultiplier();
   if(!UseContinuousCompoundingV2 || StartBalance <= 0.0) return 1.0;
   double growth = AccountInfoDouble(ACCOUNT_BALANCE) / StartBalance;
   if(growth <= 1.0) return 1.0;
   double mult = MathPow(growth, CompoundingExponentV2);
   return Clamp(mult, 1.0, CompoundingMaxMult);
  }

double RiskPercentForEngine(string engine)
  {
   if(engine == "MONSTER")  return MathMin(RiskPct_Monster,  10.0);
   if(engine == "SWING")    return MathMin(RiskPct_Swing,    10.0);
   if(engine == "RANGE")    return MathMin(RiskPct_Range,    10.0);
   if(engine == "REVERSAL") return MathMin(RiskPct_Reversal, 10.0);
   return MathMin(RiskPct_Swing, 10.0);
  }

double BaseLotForEngine(string engine)
  {
   if(engine == "SWING")    return Swing_Lot;
   if(engine == "MONSTER")  return Monster_Lot;
   if(engine == "RANGE")    return Range_Lot;
   if(engine == "REVERSAL") return Reversal_Lot;
   return Swing_Lot;
  }

double V1Risk_EngineRiskPct(string engine)
  {
   string e=engine;
   StringToUpper(e);
   if(StringFind(e,"MONSTER")>=0 || StringFind(e,"KILLSHOT")>=0) return MathMin(V1RiskPct_Monster,V1PerEntryRiskPct);
   if(StringFind(e,"RANGE")>=0 || StringFind(e,"CHOP")>=0) return MathMin(V1RiskPct_Range,V1PerEntryRiskPct);
   if(StringFind(e,"REV")>=0) return MathMin(V1RiskPct_Reversal,V1PerEntryRiskPct);
   if(StringFind(e,"SWING")>=0 || StringFind(e,"TREND")>=0) return MathMin(V1RiskPct_Swing,V1PerEntryRiskPct);
   return MathMin(V1RiskPct_Fallback,V1PerEntryRiskPct);
  }

// Comment-based classification means direct market/pending routes receive the same engine budget.
double V1Risk_EngineRiskPctFromComment(string comment)
  {
   return V1Risk_EngineRiskPct(comment);
  }

// Equity tiers change how many orders may be active, not the cash-risk math.
double V1Risk_EquityUSDForDensity()
  {
   double eq=AccountInfoDouble(ACCOUNT_EQUITY);
   string cur=AccountInfoString(ACCOUNT_CURRENCY);
   StringToUpper(cur);
   if(cur=="USC" || cur=="USCENT" || cur=="US CENT") eq/=100.0;
   return MathMax(0.0,eq);
  }

int V1Risk_EffectivePairMaxPositions()
  {
   int cap=MathMax(1,V1PairMaxPositions);
   if(!V1AdaptiveOrderDensity) return cap;
   double eq=V1Risk_EquityUSDForDensity();
   if(eq<V1MicroEquityMaxUSD) return MathMax(1,MathMin(cap,V1MicroMaxPositions));
   if(eq<V1SmallEquityMaxUSD) return MathMax(1,MathMin(cap,V1SmallMaxPositions));
   return cap;
  }

int V1Risk_EffectivePairMaxPendingOrders()
  {
   int cap=MathMax(1,V1PairMaxPendingOrders);
   if(!V1AdaptiveOrderDensity) return cap;
   double eq=V1Risk_EquityUSDForDensity();
   if(eq<V1MicroEquityMaxUSD) return MathMax(1,MathMin(cap,V1MicroMaxPending));
   if(eq<V1SmallEquityMaxUSD) return MathMax(1,MathMin(cap,V1SmallMaxPending));
   return cap;
  }

double MoneyRiskPerLot(double stopDistance)
  {
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE_LOSS);
   if(tickValue <= 0.0) tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || stopDistance <= 0.0) return 0.0;
   return (stopDistance / tickSize) * tickValue;
  }

double V1Risk_AccountRiskMoney(double pct)
  {
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   if(equity <= 0.0 || pct <= 0.0) return 0.0;
   return equity * pct / 100.0;
  }

// Convert a fallback P/L estimate from the symbol's profit currency into the
// account currency. Prefer OrderCalcProfit/tick-value metadata; this conversion
// is only used when the terminal does not provide those calculations.
double V1Risk_ConvertProfitCurrencyToAccount(string symbol, double amountInProfitCurrency)
  {
   if(symbol=="" || amountInProfitCurrency<=0.0) return 0.0;
   string from=SymbolInfoString(symbol,SYMBOL_CURRENCY_PROFIT);
   string account=AccountInfoString(ACCOUNT_CURRENCY);
   StringToUpper(from);
   StringToUpper(account);
   if(from=="") return 0.0;

   bool centAccount=(account=="USC" || account=="USCENT" || account=="US CENT");
   string target=centAccount ? "USD" : account;
   double amount=amountInProfitCurrency;
   if(from==target)
      return centAccount ? amount*100.0 : amount;

   // USDT/USDC are used as USD-peg approximations only as a last-resort
   // contract-size fallback. 1.01 is deliberately conservative for risk sizing.
   if((from=="USDT" || from=="USDC") && target=="USD")
      return amount*1.01*(centAccount ? 100.0 : 1.0);

   int total=SymbolsTotal(false);
   for(int i=0;i<total;i++)
     {
      string conv=SymbolName(i,false);
      if(conv=="") continue;
      string base=SymbolInfoString(conv,SYMBOL_CURRENCY_BASE);
      string quote=SymbolInfoString(conv,SYMBOL_CURRENCY_PROFIT);
      StringToUpper(base);
      StringToUpper(quote);
      if(!((base==from && quote==target) || (base==target && quote==from))) continue;
      if(!SymbolSelect(conv,true)) continue;
      MqlTick qt;
      if(!SymbolInfoTick(conv,qt) || qt.bid<=0.0 || qt.ask<=0.0) continue;
      double converted=0.0;
      // Conservative execution-side conversion: bid when selling FROM,
      // ask when the conversion quote is inverted.
      if(base==from && quote==target) converted=amount*qt.bid;
      else if(base==target && quote==from) converted=amount/qt.ask;
      if(converted>0.0)
         return centAccount ? converted*100.0 : converted;
     }
   return 0.0;
  }

double V1Risk_OrderRiskMoneyForSymbol(string symbol, ENUM_ORDER_TYPE type, double entry, double sl, double lots)
  {
   if(symbol=="" || entry<=0.0 || sl<=0.0 || lots<=0.0 || MathAbs(entry-sl)<=0.0) return 0.0;

   // Select/warm the actual broker symbol before asking MT5 to calculate P/L.
   // Stop-order types must be converted to market direction for OrderCalcProfit.
   if(!SymbolSelect(symbol,true))
      V1_LogGateOnce(symbol+"|RISK_SYMBOL_SELECT","[BGBI V1 RISK] SymbolSelect failed for "+symbol,30);
   ENUM_ORDER_TYPE calcType=type;
   if(type==ORDER_TYPE_BUY_LIMIT || type==ORDER_TYPE_BUY_STOP || type==ORDER_TYPE_BUY_STOP_LIMIT) calcType=ORDER_TYPE_BUY;
   if(type==ORDER_TYPE_SELL_LIMIT || type==ORDER_TYPE_SELL_STOP || type==ORDER_TYPE_SELL_STOP_LIMIT) calcType=ORDER_TYPE_SELL;

   MqlTick currentTick;
   bool tickReady=SymbolInfoTick(symbol,currentTick) && currentTick.bid>0.0 && currentTick.ask>0.0;
   double profit=0.0;
   ResetLastError();
   if(OrderCalcProfit(calcType,symbol,lots,entry,sl,profit) && MathAbs(profit)>0.0 && MathIsValidNumber(profit))
      return MathAbs(profit);
   int calcError=GetLastError();

   // One retry after refreshing the selected symbol quote. This is useful when
   // a secondary chart/profile was initialized before its first tradable tick.
   if(!tickReady) tickReady=SymbolInfoTick(symbol,currentTick) && currentTick.bid>0.0 && currentTick.ask>0.0;
   ResetLastError();
   profit=0.0;
   if(OrderCalcProfit(calcType,symbol,lots,entry,sl,profit) && MathAbs(profit)>0.0 && MathIsValidNumber(profit))
      return MathAbs(profit);
   if(GetLastError()!=0) calcError=GetLastError();

   // Prefer the broker's monetary tick values if OrderCalcProfit is unavailable.
   double tickSize=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
   double tvLoss=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE_LOSS);
   double tvProfit=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE_PROFIT);
   double tvGeneric=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE);
   double tickValue=MathMax(tvLoss,MathMax(tvProfit,tvGeneric));
   if(tickSize>0.0 && tickValue>0.0 && MathIsValidNumber(tickValue))
      return (MathAbs(entry-sl)/tickSize)*tickValue*lots;

   // Final fallback: contract-size P/L in the symbol's profit currency, then
   // convert to deposit currency. Never guess if conversion data is unavailable.
   double contract=SymbolInfoDouble(symbol,SYMBOL_TRADE_CONTRACT_SIZE);
   if(contract>0.0 && MathIsValidNumber(contract))
     {
      double profitCurrencyRisk=MathAbs(entry-sl)*contract*lots;
      double converted=V1Risk_ConvertProfitCurrencyToAccount(symbol,profitCurrencyRisk);
      if(converted>0.0 && MathIsValidNumber(converted)) return converted;
     }

   V1_LogGateOnce(symbol+"|RISK_CALC_UNAVAILABLE|"+IntegerToString((int)type),
      StringFormat("[BGBI V1 RISK BLOCK] cannot estimate SL risk symbol=%s type=%d entry=%.*f sl=%.*f tickReady=%d err=%d tickSize=%.10f tvLoss=%.10f tvProfit=%.10f tv=%.10f contract=%.4f profitCcy=%s accountCcy=%s; entry rejected fail-closed",
                   symbol,(int)type,(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS),entry,
                   (int)SymbolInfoInteger(symbol,SYMBOL_DIGITS),sl,(int)tickReady,calcError,
                   tickSize,tvLoss,tvProfit,tvGeneric,contract,
                   SymbolInfoString(symbol,SYMBOL_CURRENCY_PROFIT),AccountInfoString(ACCOUNT_CURRENCY)),30);
   return 0.0;
  }

double V1Risk_OrderRiskMoney(ENUM_ORDER_TYPE type, double entry, double sl, double lots)
  {
   return V1Risk_OrderRiskMoneyForSymbol(_Symbol,type,entry,sl,lots);
  }

double V1Risk_OpenRiskMoney()
  {
   double total=0.0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0) continue;
      if((long)PositionGetInteger(POSITION_MAGIC)!=MagicNumber) continue;
      string symbol=PositionGetString(POSITION_SYMBOL);
      double open=PositionGetDouble(POSITION_PRICE_OPEN);
      double sl=PositionGetDouble(POSITION_SL);
      double vol=PositionGetDouble(POSITION_VOLUME);
      if(open<=0.0 || vol<=0.0 || symbol=="") continue;
      if(sl<=0.0) return V1Risk_AccountRiskMoney(V1CampaignRiskPct);
      ENUM_ORDER_TYPE type=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
      double risk=V1Risk_OrderRiskMoneyForSymbol(symbol,type,open,sl,vol);
      if(risk<=0.0) return V1Risk_AccountRiskMoney(V1CampaignRiskPct);
      total+=risk;
     }
   return total;
  }

double V1Risk_PendingRiskMoney()
  {
   double total=0.0;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0) continue;
      if((long)OrderGetInteger(ORDER_MAGIC)!=MagicNumber) continue;
      ENUM_ORDER_TYPE type=(ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      bool supported=(type==ORDER_TYPE_BUY_STOP || type==ORDER_TYPE_SELL_STOP ||
                      type==ORDER_TYPE_BUY_LIMIT || type==ORDER_TYPE_SELL_LIMIT ||
                      type==ORDER_TYPE_BUY_STOP_LIMIT || type==ORDER_TYPE_SELL_STOP_LIMIT);
      if(!supported) continue;
      string symbol=OrderGetString(ORDER_SYMBOL);
      double entry=OrderGetDouble(ORDER_PRICE_OPEN);
      double sl=OrderGetDouble(ORDER_SL);
      double vol=OrderGetDouble(ORDER_VOLUME_CURRENT);
      if(entry<=0.0 || vol<=0.0 || symbol=="") continue;
      if(sl<=0.0) return V1Risk_AccountRiskMoney(V1CampaignRiskPct);
      double risk=V1Risk_OrderRiskMoneyForSymbol(symbol,type,entry,sl,vol);
      if(risk<=0.0) return V1Risk_AccountRiskMoney(V1CampaignRiskPct);
      total+=risk;
     }
   return total;
  }

bool V1Risk_IsCryptoSymbol(string symbol)
  {
   string s=symbol;
   StringToUpper(s);
   string tokens[]={"BTC","ETH","SOL","BNB","XRP","LTC","XLM","ADA","XTZ","DOGE","DOG"};
   for(int i=0;i<ArraySize(tokens);i++)
      if(StringFind(s,tokens[i])>=0) return true;
   return false;
  }

double V1Risk_CryptoReservedRiskMoney()
  {
   double total=0.0;
   double failClosed=V1Risk_AccountRiskMoney(V1CryptoBasketRiskPct);
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0) continue;
      if((long)PositionGetInteger(POSITION_MAGIC)!=MagicNumber) continue;
      string symbol=PositionGetString(POSITION_SYMBOL);
      if(!V1Risk_IsCryptoSymbol(symbol)) continue;
      double open=PositionGetDouble(POSITION_PRICE_OPEN);
      double sl=PositionGetDouble(POSITION_SL);
      double vol=PositionGetDouble(POSITION_VOLUME);
      if(open<=0.0 || vol<=0.0 || sl<=0.0) return failClosed;
      ENUM_ORDER_TYPE type=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
      double risk=V1Risk_OrderRiskMoneyForSymbol(symbol,type,open,sl,vol);
      if(risk<=0.0) return failClosed;
      total+=risk;
     }
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0) continue;
      if((long)OrderGetInteger(ORDER_MAGIC)!=MagicNumber) continue;
      ENUM_ORDER_TYPE type=(ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      bool supported=(type==ORDER_TYPE_BUY_STOP || type==ORDER_TYPE_SELL_STOP ||
                      type==ORDER_TYPE_BUY_LIMIT || type==ORDER_TYPE_SELL_LIMIT ||
                      type==ORDER_TYPE_BUY_STOP_LIMIT || type==ORDER_TYPE_SELL_STOP_LIMIT);
      if(!supported) continue;
      string symbol=OrderGetString(ORDER_SYMBOL);
      if(!V1Risk_IsCryptoSymbol(symbol)) continue;
      double entry=OrderGetDouble(ORDER_PRICE_OPEN);
      double sl=OrderGetDouble(ORDER_SL);
      double vol=OrderGetDouble(ORDER_VOLUME_CURRENT);
      if(entry<=0.0 || vol<=0.0 || sl<=0.0) return failClosed;
      double risk=V1Risk_OrderRiskMoneyForSymbol(symbol,type,entry,sl,vol);
      if(risk<=0.0) return failClosed;
      total+=risk;
     }
   return total;
  }

double V1Risk_ReservedRiskMoney()
  {
   if(!V1RiskLayerEnabled) return 0.0;
   return V1Risk_OpenRiskMoney() + V1Risk_PendingRiskMoney();
  }

double V1Risk_CampaignBudgetMoney()
  {
   if(!V1RiskLayerEnabled) return 0.0;
   return V1Risk_AccountRiskMoney(V1CampaignRiskPct);
  }

double V1Risk_RemainingRiskMoney()
  {
   double budget = V1Risk_CampaignBudgetMoney();
   if(budget <= 0.0) return 0.0;
   double rem = budget - V1Risk_ReservedRiskMoney();
   return MathMax(0.0, rem);
  }

bool V1Risk_DirectionAllowed(int dir, string comment)
  {
   if(!V1RiskLayerEnabled || !V1BlockOppositeEntries || dir == 0) return true;

   bool reversal = (StringFind(comment, "REVERSAL_") >= 0 ||
                    StringFind(comment, "FB_REV_") >= 0);
   if(reversal) return true;

   int existingDir = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      existingDir = (posInfo.PositionType() == POSITION_TYPE_BUY) ? 1 : -1;
      break;
     }
   if(existingDir != 0 && existingDir != dir) return false;
   return true;
  }

void V1_LogGateOnce(string key, string message, int cooldownSeconds=30)
  {
   static string lastKey="";
   static datetime lastAt=0;
   datetime now=TimeCurrent();
   if(key==lastKey && now-lastAt<MathMax(1,cooldownSeconds)) return;
   Print(message);
   lastKey=key;
   lastAt=now;
  }

double V1_EquityLotScale()
  {
   if(!V1EquityAdaptiveSizing) return 1.0;
   double equity=V1Risk_EquityUSDForDensity();
   double reference=MathMax(100.0,V1ReferenceEquityUSD);
   double maxScale=MathMax(1.0,V1MaximumLotScale);
   if(equity<=0.0) return 1.0;
   return Clamp(equity/reference,0.10,maxScale);
  }

double V1_EquityScaledLot(double baseLot)
  {
   if(baseLot<=0.0) return 0.0;
   return baseLot*V1_EquityLotScale();
  }

double V1Risk_RiskLimitedLots(ENUM_ORDER_TYPE type, double entry, double sl,
                          double requestedLots, double engineRiskPct=0.0)
  {
   if(requestedLots <= 0.0 || entry <= 0.0 || sl <= 0.0) return 0.0;
   if(!V1RiskLayerEnabled) return ValidateLot(requestedLots);

   // Order-count limits are PAIR-LOCAL. Do not block this symbol because another
   // chart has used its pending/position slots. Cross-pair protection remains
   // the shared monetary-risk reservation below.
   if(CountOurPositions()>=V1Risk_EffectivePairMaxPositions())
     { V1_LogGateOnce(_Symbol+"|PAIR_POSITION_CAP",StringFormat("[V1 PAIR CAP] %s positions=%d cap=%d",_Symbol,CountOurPositions(),V1Risk_EffectivePairMaxPositions())); return 0.0; }
   if(CountPendingTotal()>=V1Risk_EffectivePairMaxPendingOrders())
     { V1_LogGateOnce(_Symbol+"|PAIR_PENDING_CAP",StringFormat("[V1 PAIR CAP] %s pending=%d cap=%d",_Symbol,CountPendingTotal(),V1Risk_EffectivePairMaxPendingOrders())); return 0.0; }

   // Fail closed if the risk budget is not configured or broker risk math is unavailable.
   double campaignBudget=V1Risk_CampaignBudgetMoney();
   double requestedRiskPct=(engineRiskPct>0.0 ? MathMin(engineRiskPct,V1PerEntryRiskPct) : V1PerEntryRiskPct);
   double perEntryBudget=V1Risk_AccountRiskMoney(requestedRiskPct);
   if(campaignBudget<=0.0 || perEntryBudget<=0.0)
     {
      PrintFormat("[BGBI V1 RISK BLOCK] invalid risk budget campaignPct=%.2f entryPct=%.2f",
                  V1CampaignRiskPct,V1PerEntryRiskPct);
      return 0.0;
     }

   double lossPerLot=V1Risk_OrderRiskMoney(type,entry,sl,1.0);
   if(lossPerLot<=0.0)
     {
      V1_LogGateOnce(_Symbol+"|RISK_LIMIT_UNAVAILABLE|"+IntegerToString((int)type),
         StringFormat("[BGBI V1 RISK BLOCK] cannot estimate SL risk symbol=%s type=%d entry=%.*f sl=%.*f; see RISK_CALC_UNAVAILABLE diagnostic; order rejected fail-closed",
                      _Symbol,(int)type,_Digits,entry,_Digits,sl),30);
      return 0.0;
     }

   double reserved=V1Risk_ReservedRiskMoney();
   double remaining=MathMax(0.0,campaignBudget-reserved);
   double allowed=MathMin(perEntryBudget,remaining);
   if(V1Risk_IsCryptoSymbol(_Symbol))
     {
      double cryptoBudget=V1Risk_AccountRiskMoney(V1CryptoBasketRiskPct);
      double cryptoRemaining=MathMax(0.0,cryptoBudget-V1Risk_CryptoReservedRiskMoney());
      allowed=MathMin(allowed,cryptoRemaining);
     }
   if(allowed<=0.0)
     {
      V1_LogGateOnce(_Symbol+"|CASH_RISK_CAP",StringFormat("[V1 CASH RISK BLOCK] no risk capacity symbol=%s crypto=%d reserved=%.2f campaign=%.2f",
                  _Symbol,(int)V1Risk_IsCryptoSymbol(_Symbol),reserved,campaignBudget));
      return 0.0;
     }

   double riskLimited=allowed/lossPerLot;
   double lots=ValidateLot(MathMin(requestedLots,riskLimited));
   if(lots<=0.0) return 0.0;

   // ValidateLot() respects the broker minimum, which can round UP. Never allow
   // that minimum volume to exceed the money budget.
   double actualRisk=V1Risk_OrderRiskMoney(type,entry,sl,lots);
   if(actualRisk<=0.0 || actualRisk>allowed+0.01)
     {
      V1_LogGateOnce(_Symbol+"|MIN_LOT_RISK",StringFormat("[V1 MIN LOT RISK SKIP] symbol=%s minimum executable lot risk=%.2f exceeds entry budget=%.2f; other symbols remain eligible",
                  _Symbol,actualRisk,allowed));
      return 0.0;
     }
   if(lots+1e-9<requestedLots)
      PrintFormat("[BGBI V1 RISK SIZE] requested=%.3f allowed=%.3f reserved=%.2f/%.2f orderRisk=%.2f/%.2f",
                  requestedLots,lots,reserved,campaignBudget,actualRisk,allowed);
   return lots;
  }

double CalcLots(string engine, int direction, double slDistance)
  {
   if(slDistance <= 0.0 || direction == 0) return 0.0;

   double entry = (direction > 0) ? AskPrice() : BidPrice();
   if(entry <= 0.0) return 0.0;
   ENUM_ORDER_TYPE type = (direction > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;

   if(V1RiskLayerEnabled)
     {
      // V1 scales the instrument/engine preference with equity, then limits it
      // against per-entry, total-campaign and crypto-basket cash risk.
      double requested=V1_EquityScaledLot(BaseLotForEngine(engine));
      double stop=(direction>0) ? entry-slDistance : entry+slDistance;
      return V1Risk_RiskLimitedLots(type,entry,stop,requested,V1Risk_EngineRiskPct(engine));
     }
   // Legacy fallback mode when the V1 risk layer is explicitly disabled.
   if(!UsePercentRisk)
     {
      double base   = BaseLotForEngine(engine);
      double lots   = base * ContinuousGrowthMultiplier() * SpreadThrottle();
      lots *= Regime_SizeMult();
      lots *= Health_SizeMult();
      lots *= SessionSizeMult();
      lots *= RegimeGateSizeMult(direction);
      return ValidateLot(lots);
     }

   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   if(equity <= 0.0) return 0.0;
   double riskPct = RiskPercentForEngine(engine);
   double moneyRisk = equity * riskPct / 100.0;
   if(UseRecoveryModeV2) moneyRisk = Recovery_RiskUSD(moneyRisk);
   if(moneyRisk <= 0.0) return 0.0;

   double stop = (direction > 0) ? entry - slDistance : entry + slDistance;
   double lossPerLot = V1Risk_OrderRiskMoney(type, entry, stop, 1.0);
   if(lossPerLot <= 0.0) return 0.0;
   return ValidateLot(moneyRisk / lossPerLot);
  }

//===================================================================
// SECTION 53 — SL / TP COMPUTATION [S1: spread-aware]
//===================================================================
double SL_ATR_Mult_ForEngine(string engine)
  {
   if(engine == "TREND" || engine == "SWING") return SL_ATR_Swing;
   if(engine == "MONSTER")  return SL_ATR_Monster;
   if(engine == "RANGE")    return SL_ATR_Range;
   if(engine == "REVERSAL") return SL_ATR_Reversal;
   return SL_ATR_Swing;
  }

double SL_Floor_USC(string engine)
  {
   if(engine == "TREND" || engine == "SWING") return 400.0;
   if(engine == "MONSTER")  return 700.0;
   if(engine == "RANGE")    return 250.0;
   if(engine == "REVERSAL") return 150.0;
   return 400.0;
  }

double ComputeSLDistance(string engine)
  {
   double atr = CurrentATR5;
   if(atr <= 0.0) atr = CurrentATR1;
   if(atr <= 0.0) atr = 100.0 * _Point;
   double slByATR    = atr * SL_ATR_Mult_ForEngine(engine);
   double slBySpread = (CurrentSpreadPoints + SlippagePoints) * _Point * SL_SpreadMultiplier;
   double slByMin    = atr * SL_MinATR;
   double sl = MathMax(slByATR, MathMax(slBySpread, slByMin));
   double cap = SL_MaxUSC * _Point * 100.0;
   if(sl > cap) sl = cap;

   //--- [S1] spread floor: SL ≥ 3× current spread
   sl = SafeSLDistance(sl);
   return sl;
  }

double TP_RR_ForEngine(string engine)
  {
   if(engine == "SWING")    return TP_RR_Swing;
   if(engine == "MONSTER")  return TP_RR_Monster;
   if(engine == "RANGE")    return TP_RR_Range;
   if(engine == "REVERSAL") return TP_RR_Reversal;
   return TP_RR_Swing;
  }

double ComputeTPDistance(string engine, double slDistance)
  {
   double tp = slDistance * TP_RR_ForEngine(engine);
   double minTp = StopsLevelPrice() * 1.5;
   if(tp < minTp) tp = minTp;

   //--- [S1] spread floor: TP ≥ 2× current spread
   tp = SafeTPDistance(tp, slDistance);
   return tp;
  }

//===================================================================
// SECTION 54 — EXPOSURE COUNTERS
//===================================================================
int CountOurPositions()
  {
   int c = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      c++;
     }
   return c;
  }

double TotalOurLots()
  {
   double lots = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      lots += posInfo.Volume();
     }
   return lots;
  }

int CountEnginePositions(string prefix)
  {
   int c = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), prefix) >= 0) c++;
     }
   return c;
  }

int CountEngineOrders(string prefix)
  {
   int c = 0;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol) continue;
      if(ordInfo.Magic() != MagicNumber) continue;
      if(StringFind(ordInfo.Comment(), prefix) >= 0) c++;
     }
   return c;
  }

int CountPendingTotal()
  {
   int c = 0;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol) continue;
      if(ordInfo.Magic() != MagicNumber) continue;
      c++;
     }
   return c;
  }

double PrefixFloatingPnL(string prefix)
  {
   double pnl = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), prefix) < 0) continue;
      pnl += posInfo.Profit() + posInfo.Swap() + V1_PositionCommissionAndFees(posInfo.Identifier());
     }
   return pnl;
  }

void CloseEnginePositions(string prefix)
  {
   DeleteOrdersPrefix(prefix);
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), prefix) < 0) continue;
      MsgBudget_Count(1); // shared account-wide outbound request
      trade.PositionClose(posInfo.Ticket());
     }
  }

void CancelOtherEnginePendingOrders(string activePrefix)
  {
   string all[4] = {"SWING_","MONSTER_","RANGE_","REVERSAL_"};
   for(int i = 0; i < 4; i++)
     {
      if(all[i] == activePrefix) continue;
      DeleteOrdersPrefix(all[i]);
     }
  }

void CancelOppositePendingOrders(string prefix, int filledDirection)
  {
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol) continue;
      if(ordInfo.Magic() != MagicNumber) continue;
      if(StringFind(ordInfo.Comment(), prefix) < 0) continue;
      ENUM_ORDER_TYPE ot = ordInfo.OrderType();
      bool opposite = false;
      if(filledDirection ==  1 && (ot == ORDER_TYPE_SELL_STOP || ot == ORDER_TYPE_SELL_LIMIT))
         opposite = true;
      if(filledDirection == -1 && (ot == ORDER_TYPE_BUY_STOP  || ot == ORDER_TYPE_BUY_LIMIT))
         opposite = true;
      if(opposite)
        { MsgBudget_Count(1); trade.OrderDelete(ordInfo.Ticket()); }
     }
  }

int EngineIndexFromName(string engine)
  {
   if(engine == "SWING")    return 0;
   if(engine == "MONSTER")  return 1;
   if(engine == "RANGE")    return 2;
   if(engine == "REVERSAL") return 3;
   return -1;
  }

int EngineIndexFromComment(string comment)
  {
   if(StringFind(comment, "SWING_")    >= 0) return 0;
   if(StringFind(comment, "MONSTER_")  >= 0) return 1;
   if(StringFind(comment, "RANGE_")    >= 0) return 2;
   if(StringFind(comment, "REVERSAL_") >= 0) return 3;
   return -1;
  }

double CalculateBasketRiskUSD(string prefix)
  {
   double risk = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), prefix) < 0) continue;
      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(open <= 0.0 || stop <= 0.0) continue;
      double vol = posInfo.Volume();
      double loss = 0.0;
      ENUM_ORDER_TYPE type = (posInfo.PositionType() == POSITION_TYPE_BUY)
                             ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
      if(OrderCalcProfit(type, _Symbol, vol, open, stop, loss)) risk += MathAbs(loss);
     }
   return risk;
  }

int BasketEngineIndex(string engine) { return EngineIndexFromName(engine); }

double EngineBasketRiskR(string engine, int which)
  {
   if(engine == "SWING")
     {
      if(which == 0) return SwingBasketBE_R;
      if(which == 1) return SwingBasketTrail_R;
      return SwingBasketStep_R;
     }
   if(engine == "MONSTER")
     {
      if(which == 0) return MonsterBasketBE_R;
      if(which == 1) return MonsterBasketTrail_R;
      return MonsterBasketStep_R;
     }
   if(engine == "RANGE")
     {
      if(which == 0) return RangeBasketBE_R;
      if(which == 1) return RangeBasketTrail_R;
      return RangeBasketStep_R;
     }
   if(which == 0) return ReversalBasketBE_R;
   if(which == 1) return ReversalBasketTrail_R;
   return ReversalBasketStep_R;
  }

bool EngineBudgetOK(string engine)
  {
   int idx = EngineIndexFromName(engine);
   if(idx < 0) return true;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(eq <= 0.0) return true;
   double lossPct = g_EnginePnLToday[idx] / eq * 100.0;
   double limit = -100.0;
   if(idx == 0) limit = SwingBudgetPct;
   if(idx == 1) limit = MonsterBudgetPct;
   if(idx == 2) limit = RangeBudgetPct;
   if(idx == 3) limit = ReversalBudgetPct;
   return (lossPct > limit);
  }

bool EngineCooldownOK(string engine)
  {
   int idx = EngineIndexFromName(engine);
   if(idx < 0) return true;
   return (TimeCurrent() >= g_EngineCooldown[idx]);
  }

void RecordEngineWin(string engine)
  {
   int idx = EngineIndexFromName(engine);
   if(idx < 0) return;
   g_EngineLossStreak[idx] = 0;
   g_EngineWinStreak[idx]++;
  }

void RecordEngineLoss(string engine)
  {
   int idx = EngineIndexFromName(engine);
   if(idx < 0) return;
   g_EngineLossStreak[idx]++;
   g_EngineWinStreak[idx] = 0;
   if(g_EngineLossStreak[idx] >= 3)
     {
      g_EngineCooldown[idx] = TimeCurrent() + Cooldown_EngineAfterLoss;
      g_EngineLossStreak[idx] = 0;
      PrintFormat("[COOLDOWN] %s paused %d min", engine, Cooldown_EngineAfterLoss / 60);
     }
  }

//===================================================================
// SECTION 54B — TRADABILITY RELEASE [V2.1]
//   Purpose: preserve the existing execution style while preventing a
//   redundant universal Fib gate from freezing an already aligned setup.
//   This is NOT a free-entry path: M5 thesis + engine structure/quality,
//   anti-chase, risk and the remaining safety gates still apply.
//===================================================================
bool V1TradabilityReleaseAllows(int dir, string engine)
  {
   if(!V1TradabilityRelease || dir == 0) return false;

   if(engine == "SWING" && !V1ReleaseForSwing) return false;
   if(engine == "MONSTER" && !V1ReleaseForMonster) return false;
   if(engine != "SWING" && engine != "MONSTER") return false;

   if(g_M5ThesisDir != dir || g_M5ThesisScore < V1ReleaseM5Score)
      return false;

   // Strong M1 structure is the normal release condition.
   bool m1Strong = false;
   if(M1PA_Dir == dir && M1PA_Score >= V1ReleaseM1PAScore)
      m1Strong = true;

   // FastTrend can substitute for a strong M1 score when the
   // M5 thesis is strong and the direction agrees.
   bool trendStrong = (UseFastTrendScore &&
                       g_FastTrendDir == dir &&
                       g_FastTrendScore >= V1ReleaseFastTrendMin);

   // M5/SMC structure can also release the redundant Fib veto. This is
   // deliberately stricter than a naked thesis: the M5 thesis must be
   // strong and at least one independent M5 structural context must agree.
   bool m5StructureStrong = false;
   if(g_M5ThesisScore >= V1ReleaseM5Score)
     {
      bool m5Ctx = (M5Direction == dir || g_SMC.m5_bias == dir);
      bool mtfCtx = (g_MTF_confidence >= 0.55 || M15Direction == dir);
      m5StructureStrong = (m5Ctx && mtfCtx);
     }

   if(!m1Strong && !trendStrong && !m5StructureStrong)
      return false;

   // Never use this release path against strongly opposed live flow.
   if(BridgeReady())
     {
      double fc = FlowComposite() * (double)dir;
      if(fc < V1ReleaseMinFlowScore) return false;
     }

   return true;
  }

//===================================================================
// SECTION 55 — LEGACY CAMPAIGN ENTRY GATE [B4: msg budget gate]
//===================================================================
string V1_StopCooldownGlobalKey()
  {
   return StringFormat("BGSLC_%I64d_%s_%I64d",
                       (long)AccountInfoInteger(ACCOUNT_LOGIN), _Symbol, (long)MagicNumber);
  }

bool V1_StopCooldownActive(int &secondsRemaining)
  {
   secondsRemaining=0;
   if(!V1StopLossCooldownEnabled || V1StopLossCooldownMinutes<=0) return false;
   string key=V1_StopCooldownGlobalKey();
   if(!GlobalVariableCheck(key)) return false;
   datetime until=(datetime)GlobalVariableGet(key);
   if(until<=TimeCurrent())
     { GlobalVariableDel(key); return false; }
   secondsRemaining=(int)(until-TimeCurrent());
   return true;
  }

void V1_StartStopLossCooldown()
  {
   if(!V1StopLossCooldownEnabled || V1StopLossCooldownMinutes<=0) return;
   datetime until=TimeCurrent()+V1StopLossCooldownMinutes*60;
   GlobalVariableSet(V1_StopCooldownGlobalKey(),(double)until);
   PrintFormat("[POST-STOP COOLDOWN] symbol=%s magic=%I64d until=%s minutes=%d; cancel pending re-entry",
               _Symbol,(long)MagicNumber,TimeToString(until,TIME_DATE|TIME_SECONDS),V1StopLossCooldownMinutes);
  }

bool EntryAllowed(string engine, double lots, int dir)
  {
   int v1CooldownRemaining=0;
   if(V1_StopCooldownActive(v1CooldownRemaining)) return false;
   // --- GENESIS ANTI-CHASE / SHOCK OVERRIDE ---
   // Normal M1 entries do not chase a candle that has already travelled.
   // A genuine shock may override this guard only when price expansion,
   // volume and live pressure agree. This preserves the ability to hunt a
   // real BTC impulse without blindly buying/selling an exhausted candle.
   double currentRange = TfHigh(PERIOD_M1, 0) - TfLow(PERIOD_M1, 0);
   bool shockOverride = false;
   if(GenesisAllowStrongShockEntry && CurrentATR1 > 0.0 && currentRange > CurrentATR1 * 1.5)
     {
      double o0 = TfOpen(PERIOD_M1,0), c0 = TfClose(PERIOD_M1,0);
      double h0 = TfHigh(PERIOD_M1,0), l0 = TfLow(PERIOD_M1,0);
      double br = (h0-l0 > 0.0) ? MathAbs(c0-o0)/(h0-l0) : 0.0;
      double avgVol = 0.0; int vcnt = 0;
      for(int vi=2; vi<=21; vi++)
        {
         long vv = TfVolume(PERIOD_M1,vi);
         if(vv>0) { avgVol += (double)vv; vcnt++; }
        }
      if(vcnt>0) avgVol /= (double)vcnt;
      double vr = (avgVol>0.0) ? (double)TfVolume(PERIOD_M1,0)/avgVol : 0.0;
      int candleDir = (c0>o0 ? 1 : (c0<o0 ? -1 : 0));
      double flowAligned = (candleDir!=0 ? FlowComposite()*(double)candleDir : 0.0);
      bool pressure = (flowAligned >= GenesisShockEntryMinFlow) ||
                      (g_CUSUMDir == candleDir && g_CUSUMDir != 0) ||
                      (VNFlowTradeRateSurge() && candleDir != 0);
      shockOverride = (candleDir != 0 &&
                       currentRange <= CurrentATR1*GenesisShockEntryMaxATR &&
                       br >= GenesisShockBodyRatio &&
                       vr >= GenesisShockEntryMinVolume &&
                       pressure);
     }
   if(CurrentATR1 > 0.0 && currentRange > CurrentATR1 * 1.5 && !shockOverride)
      return false;
   //--- [TIER 5] M5 Thesis Lock gate
   if(!M5ThesisAllows(dir, engine))
     {
      PrintFormat("[BLOCK] %s: m5_thesis (dir=%s thesis=%s)",
                  engine, DirStr(dir), DirStr(g_M5ThesisDir));
      return false;
     }
     
      //--- [FIB FACTOR] Breakout confirmation
   // V2.1: keep the Fib test as the normal path, but allow an already
   // aligned SWING/MONSTER setup to proceed through the same execution
   // machinery when the extra universal breakout veto would otherwise
   // freeze it. Engine-specific structure/quality and anti-chase remain.
   if(engine != "REVERSAL")
     {
      double swH = GetRecentSwingHigh(20);
      double swL = GetRecentSwingLow(20);
      if(swH > 0.0 && swL > 0.0 && swH > swL)
        {
         bool fibOK = IsConfirmedBreakout(dir, swH, swL);
         if(!fibOK)
           {
            bool release = V1TradabilityReleaseAllows(dir, engine);
            if(!release)
              {
               PrintFormat("[BLOCK] %s: fib_breakout (dir=%s swH=%.2f swL=%.2f)",
                           engine, DirStr(dir), swH, swL);
               return false;
              }

            PrintFormat("[V2.1 RELEASE] %s fib bypassed: M5=%.1f M1PA=%.1f FastT=%.1f dir=%s",
                        engine, g_M5ThesisScore, M1PA_Score,
                        g_FastTrendScore, DirStr(dir));
           }
        }
     }
   
   static datetime lastLog[4] = {0,0,0,0};
   int dbgIdx = EngineIndexFromName(engine);
   datetime nowT = TimeCurrent();

   #define BLOCK_LOG(reason) \
      if(dbgIdx >= 0 && nowT - lastLog[dbgIdx] > 5) \
        { PrintFormat("[BLOCK] %s: %s", engine, reason); lastLog[dbgIdx] = nowT; }

   if(!Health_AllowsNewEntries())                { BLOCK_LOG("health");       return false; }
   if(TimeCurrent() < PauseUntil)                { BLOCK_LOG("pause");        return false; }
   if(DailyHalted)                               { BLOCK_LOG("daily_halt");   return false; }
   if(GlobalHalted)                              { BLOCK_LOG("global_halt");  return false; }

   if(BridgeReady() && gBinAux.vpin_regime >= 3) { BLOCK_LOG("vpin_burst");   return false; }

   if(CurrentSpreadPoints > HardMaxSpreadPoints) { BLOCK_LOG("spread_hard");  return false; }
   if(RejectIfSpreadExpands && SpreadAveragePoints > 0.0 &&
      CurrentSpreadPoints > SpreadAveragePoints * 1.80)
     { BLOCK_LOG("spread_expand"); return false; }

   if(!SessionAllowed()) { BLOCK_LOG("session");    return false; }
   if(!HourFilterOK())   { BLOCK_LOG("hour");       return false; }
   if(WickPauseActive()) { BLOCK_LOG("wick_pause"); return false; }

   if(M1Exhaustion() && engine != "MONSTER")
     { BLOCK_LOG("m1_exhaust"); return false; }

   int dtMaxPos = V1RiskLayerEnabled ? V1Risk_EffectivePairMaxPositions() : 2;
   int dtMaxPend = V1RiskLayerEnabled ? V1Risk_EffectivePairMaxPendingOrders() : MaxPendingTotal;
   if(CountOurPositions() >= dtMaxPos)             { BLOCK_LOG("pair_position_cap"); return false; }
   if(CountEnginePositions(engine + "_") >= 1)    { BLOCK_LOG("engine_pos");        return false; }
   if(CountPendingTotal() >= dtMaxPend)            { BLOCK_LOG("pair_pending_cap");  return false; }
   if(TotalOurLots() + lots > CapTotalLots() + 1e-12)
     { BLOCK_LOG("total_lots"); return false; }

   if(g_LastPlaceTime > 0 && TimeCurrent() - g_LastPlaceTime < MinSecondsBetweenPlaces)
     { BLOCK_LOG("min_seconds"); return false; }

   if(LastLossTime > 0 && TimeCurrent() - LastLossTime < Cooldown_Loss)
     { BLOCK_LOG("loss_cooldown"); return false; }
   if(LastWinTime  > 0 && TimeCurrent() - LastWinTime  < Cooldown_Win)
     { BLOCK_LOG("win_cooldown");  return false; }

   //--- Tier 1: regime direction gate
   //--- V2: a fresh CUSUM Monster event is an explicit change-point override.
   bool freshCusumMonster = (engine == "MONSTER" && UseCUSUM && g_CUSUMDir == dir &&
                             TimeCurrent() <= g_CUSUMOverrideUntil);
   if(!RegimeGateAllows(dir, engine) && !freshCusumMonster)
     { BLOCK_LOG("regime_gate"); return false; }

   if(!M15VetoAllows(dir)) { BLOCK_LOG("m15_veto"); return false; }
   if(!H1VetoAllows(dir))  { BLOCK_LOG("h1_veto");  return false; }
   if(ChaosTriggered())    { BLOCK_LOG("chaos");    return false; }

   //--- [B4] msg budget gate
   if(!MsgBudget_CanTrade()) { BLOCK_LOG("msg_budget"); return false; }

   return true;

   #undef BLOCK_LOG
  }

//===================================================================
// SECTION 56 — VETO LAYER (M15 / H1)
//===================================================================
bool M15VetoAllows(int dir)
  {
   if(!UseM15Veto || dir == 0) return true;

   if(UseSMCStructure)
     {
      bool biasOpp = (g_SMC.m15_bias == -dir);
      bool freshOpp = (g_SMC.m15_event == -dir) &&
                      (TimeCurrent() - g_SMC.m15_event_time <= M15VetoEventAgeMin * 60);
      if(biasOpp && freshOpp) return false;
     }

   double adx15 = BufVal(hADX_M15, 0, 1);
   double pdi   = BufVal(hADX_M15, 1, 1);
   double mdi   = BufVal(hADX_M15, 2, 1);
   if(adx15 >= M15VetoADXMin)
     {
      if(dir ==  1 && mdi > pdi) return false;
      if(dir == -1 && pdi > mdi) return false;
     }

   if(MSSFresh(-dir)) return false;

   return true;
  }

bool H1VetoAllows(int dir)
  {
   if(!UseH1Veto || dir == 0) return true;
   static datetime h1BiasTime = 0;
   static int      h1Bias     = 0;
   datetime h1Bar = TfTime(PERIOD_H1, 0);
   if(h1Bar != h1BiasTime)
     {
      h1BiasTime = h1Bar;
      double h1_high=0, h1_prevH=0, h1_low=0, h1_prevL=0;
      int evt; datetime evtT;
      h1Bias = VNSMC_StructureBias(PERIOD_H1, 60, evt, h1_high, h1_low, evtT);
     }
   if(h1Bias == -dir) return false;
   return true;
  }

//===================================================================
// SECTION 57 — TRADE RESULT / FILLING HELPERS
//===================================================================
bool TradeResultOK(bool requestResult)
  {
   uint rc = trade.ResultRetcode();
   return (requestResult &&
          (rc == TRADE_RETCODE_DONE ||
           rc == TRADE_RETCODE_DONE_PARTIAL ||
           rc == TRADE_RETCODE_PLACED));
  }

bool IsFillingAllowed(int symFillConst)
  {
   int filling = (int)SymbolInfoInteger(_Symbol, SYMBOL_FILLING_MODE);
   return ((filling & symFillConst) == symFillConst);
  }

bool IsTransientRetcode(uint rc)
  {
   return (rc == TRADE_RETCODE_REQUOTE       ||
           rc == TRADE_RETCODE_REJECT        ||
           rc == TRADE_RETCODE_PRICE_CHANGED ||
           rc == TRADE_RETCODE_PRICE_OFF     ||
           rc == TRADE_RETCODE_TIMEOUT       ||
           rc == TRADE_RETCODE_CONNECTION    ||
           rc == TRADE_RETCODE_TOO_MANY_REQUESTS);
  }

//===================================================================
// SECTION 58 — REQUEST BUILDER
//===================================================================
void BuildReq(MqlTradeRequest &req,
              ENUM_TRADE_REQUEST_ACTIONS act,
              ENUM_ORDER_TYPE type,
              double price,
              double lots,
              double sl,
              double tp,
              string cmt)
  {
   ZeroMemory(req);
   req.action    = act;
   req.symbol    = _Symbol;
   req.type      = type;
   req.volume    = lots;
   req.price     = price;
   req.sl        = sl;
   req.tp        = tp;
   req.deviation = (ulong)SlippagePoints;
   req.magic     = (ulong)MagicNumber;
   req.comment   = cmt;

   if(act == TRADE_ACTION_PENDING)
     {
      req.type_time  = ORDER_TIME_GTC;
      req.expiration = 0;

      if(IsFillingAllowed(SYMBOL_FILLING_FOK))
         req.type_filling = ORDER_FILLING_FOK;
      else if(IsFillingAllowed(SYMBOL_FILLING_IOC))
         req.type_filling = ORDER_FILLING_IOC;
      else
         req.type_filling = ORDER_FILLING_RETURN;
     }
   else
     {
      if(IsFillingAllowed(SYMBOL_FILLING_FOK))
         req.type_filling = ORDER_FILLING_FOK;
      else if(IsFillingAllowed(SYMBOL_FILLING_IOC))
         req.type_filling = ORDER_FILLING_IOC;
      else
         req.type_filling = ORDER_FILLING_RETURN;
     }
  }

bool OrderCheckPass(MqlTradeRequest &req)
  {
   if(!UseOrderCheckBeforeSendV2) return true;

   MqlTradeCheckResult check;
   ZeroMemory(check);
   if(!OrderCheck(req, check))
     {
      PrintFormat("[ORDERCHECK] %s ret=%u", check.comment, check.retcode);
      return false;
     }
   return true;
  }

//===================================================================
// SECTION 59 — MARKET ENTRY LOCATION GUARD [V2]
// Prevent MARKET entries after the move has already travelled.
//===================================================================
double V1Risk_MarketExtensionATR(int dir, double entryPrice, string cmt)
  {
   if(dir == 0 || entryPrice <= 0.0) return 0.0;
   bool impulse = (StringFind(cmt, "MONSTER") >= 0 ||
                  StringFind(cmt, "KILLSHOT") >= 0 ||
                  StringFind(cmt, "CUSUM") >= 0 ||
                  StringFind(cmt, "SHOCK") >= 0);
   if(!impulse) return 0.0;

   double signalClose = TfClose(PERIOD_M1, 1);
   double atr = CurrentATR1;
   if(signalClose <= 0.0 || atr <= 0.0) return 0.0;
   double ext = (dir > 0) ? (entryPrice - signalClose) / atr
                          : (signalClose - entryPrice) / atr;
   return MathMax(0.0, ext);
  }

bool V1Risk_MarketEntryLocationAllowed(int dir, double entryPrice, string cmt)
  {
   if(!V1RiskLayerEnabled) return true;
   double extension = V1Risk_MarketExtensionATR(dir, entryPrice, cmt);
   if(extension <= V1MarketMaxExtensionATR) return true;

   if(extension > V1MarketHardExtensionATR)
     {
      PrintFormat("[V1 ANTI-CHASE HARD] %s ext=%.2fATR > %.2f",
                  cmt, extension, V1MarketHardExtensionATR);
      return false;
     }

   PrintFormat("[LEGACY FAST ANTI-CHASE] %s ext=%.2fATR > %.2f — MARKET blocked; continuation STOP will be attempted",
               cmt, extension, V1MarketMaxExtensionATR);
   return false;
  }

bool V1Risk_PlaceContinuationStop(int dir, double requestedLots, double sl, double tp, string cmt)
  {
   if(!V1RiskLayerEnabled || dir == 0 || requestedLots <= 0.0) return false;

   double atr = CurrentATR1;
   if(atr <= 0.0) atr = CurrentATR5;
   if(atr <= 0.0) return false;

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return false;

   double recent = (dir > 0) ? -1e100 : 1e100;
   for(int i=1; i<=5; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      if(dir > 0 && h > recent) recent = h;
      if(dir < 0 && l < recent) recent = l;
     }
   if((dir > 0 && recent < 0) || (dir < 0 && recent > 1e99)) return false;

   double minDist = StopsLevelPrice();
   double buffer = atr * V1ContinuationStopBufferATR;
   double entry = (dir > 0) ? MathMax(ask + minDist, recent + buffer)
                            : MathMin(bid - minDist, recent - buffer);

   double curEntry = (dir > 0) ? ask : bid;
   double maxDist = atr * V1ContinuationMaxDistanceATR;
   if(MathAbs(entry-curEntry) > maxDist)
     {
      PrintFormat("[V1 CONTINUATION BLOCK] %s distance=%.2fATR > %.2f",
                  cmt, MathAbs(entry-curEntry)/atr, V1ContinuationMaxDistanceATR);
      return false;
     }

   double slDist = MathAbs(curEntry - sl);
   double tpDist = MathAbs(tp - curEntry);
   if(slDist <= 0.0 || tpDist <= 0.0) return false;

   double newSL = (dir > 0) ? entry - slDist : entry + slDist;
   double newTP = (dir > 0) ? entry + tpDist : entry - tpDist;

   bool ok = SendStopV2(dir > 0, NormalizeDouble(entry, _Digits), requestedLots,
                         NormalizeDouble(newSL, _Digits),
                         NormalizeDouble(newTP, _Digits), cmt + "_DELAYED");
   if(ok)
      PrintFormat("[V1 CONVERT] %s MARKET->STOP entry=%.2f dist=%.2fATR",
                  cmt, entry, MathAbs(entry-curEntry)/atr);
   return ok;
  }

//===================================================================
// LEGACY CAMPAIGN HANDOFF FORWARD DECLARATIONS
//===================================================================
string LegacyCampaign_EnginePrefixFromComment(string cmt);
void   LegacyCampaign_CancelCompetingPendings(string activePrefix);

//===================================================================
// SECTION 59 — MARKET ORDER SENDER (V2) [B2: msg budget]
//===================================================================
bool SendMarketV2(int type, double lots, double sl, double tp, string cmt)
  {
   if(lots <= 0.0) return false;

   int dir = (type == ORDER_TYPE_BUY) ? 1 : -1;
   double locationEntry = (type == ORDER_TYPE_BUY) ? AskPrice() : BidPrice();
   if(!V1Risk_MarketEntryLocationAllowed(dir, locationEntry, cmt))
     {
      double ext = V1Risk_MarketExtensionATR(dir, locationEntry, cmt);
      if(ext <= V1MarketHardExtensionATR)
         return V1Risk_PlaceContinuationStop(dir, lots, sl, tp, cmt);
      return false;
     }
   if(!V1Risk_DirectionAllowed(dir, cmt))
     { PrintFormat("[V1] opposite market blocked %s", cmt); return false; }
   if(V1RiskLayerEnabled && g_V1Risk_MarketEntries >= V1MaxMarketEntries)
     { PrintFormat("[V1] market cap %d", V1MaxMarketEntries); return false; }

   lots=USDHybrid_ScaleRequestedLots(lots);
   if(lots<=0.0) return false;
   double entryRiskRef = (type == ORDER_TYPE_BUY) ? AskPrice() : BidPrice();
   if(V1RiskLayerEnabled)
     {
      lots = V1Risk_RiskLimitedLots((ENUM_ORDER_TYPE)type, entryRiskRef, sl, lots, V1Risk_EngineRiskPctFromComment(cmt));
      if(lots <= 0.0)
        { PrintFormat("[V1] lot sizing rejected MARKET %s", cmt); return false; }
     }

   //--- [B2] msg budget check
   if(!MsgBudget_CanSend())
     {
      PrintFormat("[MSGBUDGET] blocked MARKET %s", cmt);
      return false;
     }

   // V2: only replace competing pending inventory after all entry gates pass.
   if(V1LegacyCampaignEnabled)
     {
      string activePrefix = LegacyCampaign_EnginePrefixFromComment(cmt);
      if(activePrefix != "") LegacyCampaign_CancelCompetingPendings(activePrefix);
     }

   int attempts = UseTransientRetryV2 ? TransientMaxRetries : 1;
   double entryRef = (type == ORDER_TYPE_BUY) ? AskPrice() : BidPrice();

   for(int a = 0; a < attempts; a++)
     {
      MqlTradeRequest req;
      BuildReq(req, TRADE_ACTION_DEAL, (ENUM_ORDER_TYPE)type,
               entryRef, lots, sl, tp, cmt);

      if(!OrderCheckPass(req)) return false;

      MqlTradeResult res;
      ZeroMemory(res);
      if(!MsgBudget_ReserveEntryRequest(cmt)) return false;
      bool ok = OrderSend(req, res);
      if(ok && (res.retcode == TRADE_RETCODE_DONE ||
                res.retcode == TRADE_RETCODE_PLACED ||
                res.retcode == TRADE_RETCODE_DONE_PARTIAL))
        {
         MsgBudget_TickOpen();

         if(UseSlippageReAnchorV2)
            Anchor_Store(cmt, entryRef, sl, tp);

         if(V1RiskLayerEnabled)
           {
            g_V1Risk_CampaignActive = true;
            if(g_V1Risk_CampaignStart == 0) g_V1Risk_CampaignStart = TimeCurrent();
            g_V1Risk_CampaignDir = dir;
            g_V1Risk_MarketEntries++;
           }
         return true;
        }

      if(IsTransientRetcode(res.retcode) && a < attempts - 1)
        {
         PrintFormat("[RETRY %d/%d] %s ret=%u %s",
                     a + 1, attempts, cmt, res.retcode, res.comment);
         Sleep(TransientRetryDelayMs);
         continue;
        }

      PrintFormat("[MARKET FAIL] %s ret=%u %s",
                  cmt, res.retcode, res.comment);
      return false;
     }
   return false;
  }

//===================================================================
// SECTION 60 — PENDING STOP SENDER (V2) [B2: msg budget]
//===================================================================
bool SendStopV2(bool isBuy, double price, double lots,
                double sl, double tp, string cmt)
  {
   if(lots <= 0.0) return false;

   int dir = isBuy ? 1 : -1;
   if(!V1Risk_DirectionAllowed(dir, cmt))
     { PrintFormat("[V1] opposite STOP blocked %s", cmt); return false; }
   if(V1RiskLayerEnabled && CountPendingTotal() >= V1Risk_EffectivePairMaxPendingOrders())
     { V1_LogGateOnce(_Symbol+"|PAIR_PENDING_CAP_SEND",StringFormat("[V1 PAIR CAP] %s pending=%d cap=%d",_Symbol,CountPendingTotal(),V1Risk_EffectivePairMaxPendingOrders())); return false; }

   bool ocoPrevalidated=(g_V1OCO_PairLotPrevalidatedSubmit &&
                         StringFind(cmt,"GENESIS_INTEL_OCO_TREND_")>=0);
   if(ocoPrevalidated)
     {
      // Use the exact same broker-normalized lot for both OCO legs. Risk was
      // preflighted as a pair, counting BOTH legs against campaign/crypto risk.
      lots=ValidateLot(lots);
      if(lots<=0.0) { PrintFormat("[OCO LEG BLOCK] symbol=%s comment=%s stage=pair_lot_validation",_Symbol,cmt); return false; }
     }
   else
     {
      lots=USDHybrid_ScaleRequestedLots(lots);
      if(lots<=0.0) return false;
      if(V1RiskLayerEnabled)
        {
         lots = V1Risk_RiskLimitedLots(isBuy ? ORDER_TYPE_BUY_STOP : ORDER_TYPE_SELL_STOP,
                                   price, sl, lots, V1Risk_EngineRiskPctFromComment(cmt));
         if(lots <= 0.0)
           { PrintFormat("[V1] lot sizing rejected STOP %s", cmt); return false; }
        }
     }

   double minDist = StopsLevelPrice();
   if(isBuy && (price - AskPrice() < minDist))
     {
      PrintFormat("[STOP REJECT] %s buy dist=%.0f min=%.0f",
                  cmt, (price - AskPrice())/_Point, minDist/_Point);
      return false;
     }
   if(!isBuy && (BidPrice() - price < minDist))
     {
      PrintFormat("[STOP REJECT] %s sell dist=%.0f min=%.0f",
                  cmt, (BidPrice() - price)/_Point, minDist/_Point);
      return false;
     }

   //--- [B2] msg budget check
   if(!MsgBudget_CanSend())
     {
      PrintFormat("[MSGBUDGET] blocked STOP %s", cmt);
      return false;
     }

   // V2: only replace competing pending inventory after all entry gates pass.
   if(V1LegacyCampaignEnabled)
     {
      string activePrefix = LegacyCampaign_EnginePrefixFromComment(cmt);
      if(activePrefix != "") LegacyCampaign_CancelCompetingPendings(activePrefix);
     }

   ENUM_ORDER_TYPE type = isBuy ? ORDER_TYPE_BUY_STOP : ORDER_TYPE_SELL_STOP;
   int attempts = UseTransientRetryV2 ? TransientMaxRetries : 1;

   for(int a = 0; a < attempts; a++)
     {
      MqlTradeRequest req;
      BuildReq(req, TRADE_ACTION_PENDING, type, price, lots, sl, tp, cmt);

      if(!OrderCheckPass(req))
        {
         if(StringFind(cmt,"GENESIS_INTEL_OCO_")>=0)
            PrintFormat("[OCO LEG BLOCK] symbol=%s comment=%s stage=OrderCheck type=%d price=%.*f lots=%.4f sl=%.*f tp=%.*f",
                        _Symbol,cmt,(int)type,_Digits,price,lots,_Digits,sl,_Digits,tp);
         return false;
        }

      MqlTradeResult res;
      ZeroMemory(res);
      if(!MsgBudget_ReserveEntryRequest(cmt)) return false;
      bool ok = OrderSend(req, res);
      if(ok && (res.retcode == TRADE_RETCODE_DONE ||
                res.retcode == TRADE_RETCODE_PLACED))
        {
         MsgBudget_TickOpen();

         if(UseSlippageReAnchorV2)
            Anchor_Store(cmt, price, sl, tp);

         if(V1RiskLayerEnabled)
           {
            g_V1Risk_CampaignActive = true;
            if(g_V1Risk_CampaignStart == 0) g_V1Risk_CampaignStart = TimeCurrent();
           }
         return true;
        }

      if(IsTransientRetcode(res.retcode) && a < attempts - 1)
        {
         Sleep(TransientRetryDelayMs);
         continue;
        }

      PrintFormat("[STOP FAIL] %s ret=%u %s",
                  cmt, res.retcode, res.comment);
      return false;
     }
   return false;
  }

//===================================================================
// SECTION 61 — PENDING LIMIT SENDER (V2) [B2: msg budget]
//===================================================================
bool SendLimitV2(bool isBuy, double price, double lots,
                 double sl, double tp, string cmt)
  {
   if(lots <= 0.0) return false;

   int dir = isBuy ? 1 : -1;
   if(!V1Risk_DirectionAllowed(dir, cmt))
     { PrintFormat("[V1] opposite LIMIT blocked %s", cmt); return false; }
   if(V1RiskLayerEnabled && CountPendingTotal() >= V1Risk_EffectivePairMaxPendingOrders())
     { V1_LogGateOnce(_Symbol+"|PAIR_PENDING_CAP_SEND",StringFormat("[V1 PAIR CAP] %s pending=%d cap=%d",_Symbol,CountPendingTotal(),V1Risk_EffectivePairMaxPendingOrders())); return false; }

   lots=USDHybrid_ScaleRequestedLots(lots);
   if(lots<=0.0) return false;
   if(V1RiskLayerEnabled)
     {
      lots = V1Risk_RiskLimitedLots(isBuy ? ORDER_TYPE_BUY_LIMIT : ORDER_TYPE_SELL_LIMIT,
                                price, sl, lots, V1Risk_EngineRiskPctFromComment(cmt));
      if(lots <= 0.0)
        { PrintFormat("[V1] lot sizing rejected LIMIT %s", cmt); return false; }
     }

   double minDist = StopsLevelPrice();
   if(isBuy && (BidPrice() - price < minDist))
     {
      PrintFormat("[LIMIT REJECT] %s buy dist=%.0f min=%.0f",
                  cmt, (BidPrice() - price)/_Point, minDist/_Point);
      return false;
     }
   if(!isBuy && (price - AskPrice() < minDist))
     {
      PrintFormat("[LIMIT REJECT] %s sell dist=%.0f min=%.0f",
                  cmt, (price - AskPrice())/_Point, minDist/_Point);
      return false;
     }

   //--- [B2] msg budget check
   if(!MsgBudget_CanSend())
     {
      PrintFormat("[MSGBUDGET] blocked LIMIT %s", cmt);
      return false;
     }

   // V2: only replace competing pending inventory after all entry gates pass.
   if(V1LegacyCampaignEnabled)
     {
      string activePrefix = LegacyCampaign_EnginePrefixFromComment(cmt);
      if(activePrefix != "") LegacyCampaign_CancelCompetingPendings(activePrefix);
     }

   ENUM_ORDER_TYPE type = isBuy ? ORDER_TYPE_BUY_LIMIT : ORDER_TYPE_SELL_LIMIT;
   int attempts = UseTransientRetryV2 ? TransientMaxRetries : 1;

   for(int a = 0; a < attempts; a++)
     {
      MqlTradeRequest req;
      BuildReq(req, TRADE_ACTION_PENDING, type, price, lots, sl, tp, cmt);

      if(!OrderCheckPass(req)) return false;

      MqlTradeResult res;
      ZeroMemory(res);
      if(!MsgBudget_ReserveEntryRequest(cmt)) return false;
      bool ok = OrderSend(req, res);
      if(ok && (res.retcode == TRADE_RETCODE_DONE ||
                res.retcode == TRADE_RETCODE_PLACED))
        {
         MsgBudget_TickOpen();

         if(UseSlippageReAnchorV2)
            Anchor_Store(cmt, price, sl, tp);

         if(V1RiskLayerEnabled)
           {
            g_V1Risk_CampaignActive = true;
            if(g_V1Risk_CampaignStart == 0) g_V1Risk_CampaignStart = TimeCurrent();
           }
         return true;
        }

      if(IsTransientRetcode(res.retcode) && a < attempts - 1)
        {
         Sleep(TransientRetryDelayMs);
         continue;
        }

      PrintFormat("[LIMIT FAIL] %s ret=%u %s",
                  cmt, res.retcode, res.comment);
      return false;
     }
   return false;
  }

//===================================================================
// SECTION 61b — BACKWARD-COMPAT WRAPPERS
//===================================================================
bool SendMarket(int type, double lots, double sl, double tp, string comment)
  { return SendMarketV2(type, lots, sl, tp, comment); }

bool SendBuyStop(double price, double lots, double sl, double tp, string comment)
  { return SendStopV2(true, price, lots, sl, tp, comment); }

bool SendSellStop(double price, double lots, double sl, double tp, string comment)
  { return SendStopV2(false, price, lots, sl, tp, comment); }

bool SendBuyLimit(double price, double lots, double sl, double tp, string comment)
  { return SendLimitV2(true, price, lots, sl, tp, comment); }

bool SendSellLimit(double price, double lots, double sl, double tp, string comment)
  { return SendLimitV2(false, price, lots, sl, tp, comment); }

//===================================================================
// SECTION 62 — SAFE MODIFY [A1 + S2: hardened + spread-aware]
//===================================================================
bool SafeModify(ulong ticket, double sl, double tp)
  {
   // Safety/exit management is never disabled by the NEW-entry budget.
   if(!PositionSelectByTicket(ticket)) return false;

   double currentSL=PositionGetDouble(POSITION_SL);
   double currentTP=PositionGetDouble(POSITION_TP);
   if(MathAbs(sl-currentSL)<_Point*0.5 && MathAbs(tp-currentTP)<_Point*0.5)
      return true; // avoid repeated no-op broker requests

   long type = PositionGetInteger(POSITION_TYPE);
   double bid = BidPrice(), ask = AskPrice();

   //--- [S2] spread-aware minimum distance (1.5× spread floor)
   double minDist = SafeTrailBuffer();

   //--- [A1] PRE-FLIGHT: reject clearly-invalid modify
   if(type == POSITION_TYPE_BUY)
     {
      if(sl > 0.0 && (bid - sl) < minDist) return false;
      if(tp > 0.0 && (tp - ask) < minDist) return false;
      if(sl > 0.0 && tp > 0.0 && tp <= sl)  return false;
     }
   else if(type == POSITION_TYPE_SELL)
     {
      if(sl > 0.0 && (sl - ask) < minDist) return false;
      if(tp > 0.0 && (bid - tp) < minDist) return false;
      if(sl > 0.0 && tp > 0.0 && tp >= sl)  return false;
     }

   //--- SL-TP gap must exceed 2× buffer
   if(sl > 0.0 && tp > 0.0 && MathAbs(tp - sl) < minDist * 2.0) return false;

   //--- Attempt modify
   trade.SetExpertMagicNumber(MagicNumber);
   MsgBudget_Count(1); // shared account-wide outbound request
   uint result = trade.PositionModify(ticket, sl, tp);
   bool ok = (result == TRADE_RETCODE_DONE ||
              result == TRADE_RETCODE_PLACED ||
              result == TRADE_RETCODE_DONE_PARTIAL);
   if(ok) MsgBudget_TickModify();
   return ok;
  }

//===================================================================
// SECTION 63 — CLOSE POSITION (V2)
//===================================================================
bool ClosePosition(ulong ticket)
  {
   if(!PositionSelectByTicket(ticket)) return false;
   trade.SetExpertMagicNumber(MagicNumber);
   MsgBudget_Count(1); // shared account-wide outbound request
   bool ok = TradeResultOK(trade.PositionClose(ticket));
   return ok;
  }

//===================================================================
// SECTION 64 — DELETE ORDERS BY PREFIX
//===================================================================
void DeleteOrdersPrefix(string prefix)
  {
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol) continue;
      if(ordInfo.Magic() != MagicNumber) continue;
      if(StringFind(ordInfo.Comment(), prefix) < 0) continue;
      MsgBudget_Count(1); // shared account-wide outbound request
      bool ok = trade.OrderDelete(ordInfo.Ticket());
      if(ok) MsgBudget_TickDelete();
     }
  }

//===================================================================
// SECTION 65 — SLIPPAGE RE-ANCHOR [A7: no round-number snap]
//===================================================================
void ReAnchorStopsAfterFill(ulong positionTicket, string comment)
  {
   if(!UseSlippageReAnchorV2) return;
   if(!PositionSelectByTicket(positionTicket)) return;

   int idx = Anchor_Find(comment);
   if(idx < 0) return;

   double reqEntry = g_AnchorMap[idx].requestedEntry;
   double reqSL    = g_AnchorMap[idx].requestedSL;
   double reqTP    = g_AnchorMap[idx].requestedTP;

   double fillPrice = PositionGetDouble(POSITION_PRICE_OPEN);
   if(fillPrice <= 0.0 || reqEntry <= 0.0) return;

   double slipPts = MathAbs(fillPrice - reqEntry) / _Point;
   if(slipPts < SlippageReAnchorTriggerPts) return;

   double slipDelta = fillPrice - reqEntry;
   bool isBuy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);

   //--- [A7] Do NOT snap to round numbers — preserve broker precision
   double newSL = reqSL;
   double newTP = reqTP;
   if(reqSL > 0.0) newSL = reqSL + slipDelta;
   if(reqTP > 0.0) newTP = reqTP + slipDelta;

   // Sanity checks
   if(isBuy)
     {
      if(newSL > 0.0 && newSL >= fillPrice) return;
      if(newTP > 0.0 && newTP <= fillPrice) return;
     }
   else
     {
      if(newSL > 0.0 && newSL <= fillPrice) return;
      if(newTP > 0.0 && newTP >= fillPrice) return;
     }

   double curSL = PositionGetDouble(POSITION_SL);
   double curTP = PositionGetDouble(POSITION_TP);

   SafeModify(positionTicket, newSL, newTP);

   PrintFormat("[RE-ANCHOR] tkt=%I64u slip=%.0fpts SL %.5f->%.5f TP %.5f->%.5f",
               positionTicket, slipPts, curSL, newSL, curTP, newTP);
  }

//===================================================================
// SECTION 66 — BASKET USD HELPERS [S3: spread-aware floor]
//===================================================================
double BasketBEUSD(string engine)
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   double pctTarget = 0.0;

   if(UseBasketDollarMode)
      pctTarget = base * BasketBE_USD_PctOfStart / 100.0;
   else
     {
      int bi = BasketEngineIndex(engine);
      if(UseBasketRiskTargets && bi >= 0 && BasketInitialRiskUSD[bi] > 0.0)
         pctTarget = BasketInitialRiskUSD[bi] * EngineBasketRiskR(engine, 0);
      else
         pctTarget = base * BasketBE_Pct / 100.0;
     }

   //--- [S3] spread floor: BE must exceed 2× spread across all positions
   int posCount = MathMax(1, CountEnginePositions(engine + "_"));
   double lotTotal = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), engine + "_") < 0) continue;
      lotTotal += posInfo.Volume();
     }
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double spreadUSD = SpreadInPoints() * posCount * lotTotal * tickValue;
   double spreadFloor = spreadUSD * SpreadMultiplier_Basket;

   return MathMax(pctTarget, spreadFloor);
  }

double BasketTrailStartUSD(string engine)
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   double pctTarget = 0.0;

   if(UseBasketDollarMode)
      pctTarget = base * BasketTrailStart_USD_Pct / 100.0;
   else
     {
      int bi = BasketEngineIndex(engine);
      if(UseBasketRiskTargets && bi >= 0 && BasketInitialRiskUSD[bi] > 0.0)
         pctTarget = BasketInitialRiskUSD[bi] * EngineBasketRiskR(engine, 1);
      else
         pctTarget = base * BasketTrailStart_Pct / 100.0;
     }

   //--- [S3] Trail start must exceed BE by at least 50%
   double be = BasketBEUSD(engine);
   if(pctTarget < be * 1.5) pctTarget = be * 1.5;
   return pctTarget;
  }

double BasketTrailStepUSD(string engine)
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   double pctTarget = 0.0;

   if(UseBasketDollarMode)
      pctTarget = base * BasketTrailStep_USD_Pct / 100.0;
   else
     {
      int bi = BasketEngineIndex(engine);
      if(UseBasketRiskTargets && bi >= 0 && BasketInitialRiskUSD[bi] > 0.0)
         pctTarget = BasketInitialRiskUSD[bi] * EngineBasketRiskR(engine, 2);
      else
         pctTarget = base * BasketTrailStep_Pct / 100.0;
     }

   //--- [S3] Step must exceed 1.5× spread
   int posCount = MathMax(1, CountEnginePositions(engine + "_"));
   double lotTotal = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), engine + "_") < 0) continue;
      lotTotal += posInfo.Volume();
     }
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double spreadUSD = SpreadInPoints() * posCount * lotTotal * tickValue;
   double spreadFloor = spreadUSD * SpreadMultiplier_Basket * 0.75;

   return MathMax(pctTarget, spreadFloor);
  }

double BasketSLUSD(string engine)
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   if(UseBasketDollarMode)
      return base * BasketSL_USD_Pct / 100.0;

   return -base * MathAbs(BasketSL_Pct) / 100.0;
  }

//===================================================================
// SECTION 67 — MOVE PREFIX TO BREAKEVEN [S2: spread-aware offset]
//===================================================================
void MovePrefixToBE(string prefix)
  {
   double buf = SafeTrailBuffer();   // [S2] 1.5× spread minimum

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), prefix) < 0) continue;

      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      double take = posInfo.TakeProfit();
      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);

      if(isBuy)
        {
         double ns = NormalizeDouble(open + buf, _Digits);
         if(ns > stop && ns < BidPrice() - buf) SafeModify(posInfo.Ticket(), ns, take);
        }
      else
        {
         double ns = NormalizeDouble(open - buf, _Digits);
         if(ns < stop && ns > AskPrice() + buf) SafeModify(posInfo.Ticket(), ns, take);
        }
     }
  }

//===================================================================
// SECTION 68 — BASKET MANAGEMENT (R-based + dollar-based) [S3]
//===================================================================
void ManageBasket(string engine,
                  bool   &beDone, bool &trailOn,
                  double &trailHigh, double &trailSL)
  {
   if(!UseBasketManagement) return;
   string prefix = engine + "_";
   int posCount = CountEnginePositions(prefix);
   int ordCount = CountEngineOrders(prefix);
   int basketIdx = BasketEngineIndex(engine);

   if(posCount <= 0)
     {
      if(ordCount == 0)
        {
         beDone = false; trailOn = false;
         trailHigh = 0.0; trailSL = 0.0;
         if(basketIdx >= 0) BasketInitialRiskUSD[basketIdx] = 0.0;
        }
      return;
     }

   if(basketIdx >= 0 && BasketInitialRiskUSD[basketIdx] <= 0.0)
     {
      double br = CalculateBasketRiskUSD(prefix);
      if(br > 0.0) BasketInitialRiskUSD[basketIdx] = br;
     }

   double pnl    = PrefixFloatingPnL(prefix);
   double beUSD  = BasketBEUSD(engine);
   double tsUSD  = BasketTrailStartUSD(engine);
   double tstUSD = BasketTrailStepUSD(engine);
   double slUSD  = BasketSLUSD(engine);

   if(pnl <= slUSD)
     {
      DeleteOrdersPrefix(prefix);
      CloseEnginePositions(prefix);
      beDone = false; trailOn = false;
      trailHigh = 0.0; trailSL = 0.0;
      if(basketIdx >= 0) BasketInitialRiskUSD[basketIdx] = 0.0;
      PrintFormat("[BASKET SL] %s pnl=%.2f <= %.2f", engine, pnl, slUSD);
      return;
     }

   if(!beDone && pnl >= beUSD)
     {
      MovePrefixToBE(prefix);
      beDone = true;
      PrintFormat("[BASKET BE] %s pnl=%.2f", engine, pnl);
     }

   if(!trailOn && pnl >= tsUSD)
     {
      trailOn = true;
      trailHigh = pnl;
      trailSL = pnl - tstUSD;
      PrintFormat("[BASKET TRAIL START] %s pnl=%.2f", engine, pnl);
     }

   if(trailOn)
     {
      if(pnl > trailHigh) { trailHigh = pnl; trailSL = pnl - tstUSD; }
      if(pnl <= trailSL && pnl > 0.0)
        {
         DeleteOrdersPrefix(prefix);
         CloseEnginePositions(prefix);
         beDone = false; trailOn = false;
         trailHigh = 0.0; trailSL = 0.0;
         if(basketIdx >= 0) BasketInitialRiskUSD[basketIdx] = 0.0;
         PrintFormat("[BASKET TRAIL] %s pnl=%.2f", engine, pnl);
        }
     }
  }

//===================================================================
// SECTION 69 — FLOATING BUDGETS
//===================================================================
void CheckFloatingBudgets()
  {
   // V2: V1 campaign/exit controller owns live loss management.
   // Legacy per-engine floating budgets remain available only when the
   // unified governor is disabled.
   if(V1RiskLayerEnabled) return;
   if(!UseFloatingBudget) return;
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return;
   double swingLimit   = base * SwingBudgetPct    / 100.0;
   double monsterLimit = base * MonsterBudgetPct  / 100.0;
   double rangeLimit   = base * RangeBudgetPct    / 100.0;
   double revLimit     = base * ReversalBudgetPct / 100.0;

   if(CountEnginePositions("SWING_") > 0 && PrefixFloatingPnL("SWING_") <= swingLimit)
     { CloseEnginePositions("SWING_");   Print("[BUDGET] SWING closed"); }
   if(CountEnginePositions("MONSTER_") > 0 && PrefixFloatingPnL("MONSTER_") <= monsterLimit)
     { CloseEnginePositions("MONSTER_"); Print("[BUDGET] MONSTER closed"); }
   if(CountEnginePositions("RANGE_") > 0 && PrefixFloatingPnL("RANGE_") <= rangeLimit)
     { CloseEnginePositions("RANGE_");   Print("[BUDGET] RANGE closed"); }
   if(CountEnginePositions("REVERSAL_") > 0 && PrefixFloatingPnL("REVERSAL_") <= revLimit)
     { CloseEnginePositions("REVERSAL_"); Print("[BUDGET] REVERSAL closed"); }
  }

//===================================================================
// SECTION 70 — STALE PENDING CLEANUP
//===================================================================
void CancelStalePendingOrders()
  {
   int limit = UseHourlyStraddleReset ? StaleOrderMinutesV2 : StaleOrderMinutes;
   if(limit <= 0) return;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol || ordInfo.Magic() != MagicNumber) continue;
      if(LegacyCampaign_IsComment(ordInfo.Comment())) continue;
      if(TimeCurrent() - ordInfo.TimeSetup() >= limit * 60)
        {
         MsgBudget_Count(1); // shared account-wide outbound request
         bool ok = trade.OrderDelete(ordInfo.Ticket());
         if(ok) MsgBudget_TickDelete();
        }
     }
  }

//===================================================================
// SECTION 71 — CLOSE ALL
//===================================================================
void CloseAllOurPositions()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      ClosePosition(posInfo.Ticket());
     }
   DeleteOrdersPrefix("");
  }

//===================================================================
// SECTION 71A — BTC LEGACY FAST CAMPAIGN + EXIT GOVERNOR
//===================================================================
int V1Risk_TrackIndex(ulong ticket)
  {
   if(ticket == 0) return -1;
   for(int i = 0; i < 64; i++)
      if(g_V1Risk_TrackTicket[i] == ticket) return i;
   return -1;
  }

int V1Risk_EnsureTracked(ulong ticket)
  {
   if(ticket == 0) return -1;
   int idx = V1Risk_TrackIndex(ticket);
   if(idx >= 0) return idx;

   for(int i = 0; i < 64; i++)
     {
      if(g_V1Risk_TrackTicket[i] != 0) continue;
      if(!PositionSelectByTicket(ticket)) return -1;

      double open = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl   = PositionGetDouble(POSITION_SL);
      if(open <= 0.0 || sl <= 0.0) return -1;

      g_V1Risk_TrackTicket[i]  = ticket;
      g_V1Risk_TrackRisk[i]    = MathAbs(open - sl);
      g_V1Risk_TrackOpen[i]    = (datetime)PositionGetInteger(POSITION_TIME);
      g_V1Risk_TrackPeakR[i]   = 0.0;
      g_V1Risk_TrackAdverse[i] = 0;
      return i;
     }
   return -1;
  }

void V1Risk_CleanupTracks()
  {
   for(int i = 0; i < 64; i++)
     {
      if(g_V1Risk_TrackTicket[i] == 0) continue;
      if(PositionSelectByTicket(g_V1Risk_TrackTicket[i])) continue;
      g_V1Risk_TrackTicket[i]  = 0;
      g_V1Risk_TrackRisk[i]    = 0.0;
      g_V1Risk_TrackOpen[i]    = 0;
      g_V1Risk_TrackPeakR[i]   = 0.0;
      g_V1Risk_TrackAdverse[i] = 0;
     }
  }

void V1Risk_RefreshCampaignState()
  {
   if(!V1RiskLayerEnabled) return;

   int positions = CountOurPositions();
   int pending   = CountPendingTotal();

   if(positions == 0 && pending == 0)
     {
      g_V1Risk_CampaignActive = false;
      g_V1Risk_CampaignDir    = 0;
      g_V1Risk_CampaignStart  = 0;
      g_V1Risk_MarketEntries  = 0;
      g_V1Risk_CampaignPeakR  = 0.0;
      V1Risk_CleanupTracks();
      return;
     }

   g_V1Risk_CampaignActive = true;
   if(g_V1Risk_CampaignStart == 0) g_V1Risk_CampaignStart = TimeCurrent();

   if(g_V1Risk_CampaignDir == 0)
     {
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         if(!posInfo.SelectByIndex(i)) continue;
         if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
         g_V1Risk_CampaignDir = (posInfo.PositionType() == POSITION_TYPE_BUY) ? 1 : -1;
         break;
        }
     }

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      V1Risk_EnsureTracked(posInfo.Ticket());
     }
   if(g_V1Risk_MarketEntries > V1MaxMarketEntries)
      g_V1Risk_MarketEntries = V1MaxMarketEntries;

   V1Risk_CleanupTracks();
  }

bool V1Risk_IsPendingHistoryOrder(ulong orderTicket)
  {
   if(orderTicket == 0) return false;
   if(!HistoryOrderSelect(orderTicket)) return false;
   ENUM_ORDER_TYPE type = (ENUM_ORDER_TYPE)HistoryOrderGetInteger(orderTicket, ORDER_TYPE);
   return (type == ORDER_TYPE_BUY_STOP || type == ORDER_TYPE_SELL_STOP ||
           type == ORDER_TYPE_BUY_LIMIT || type == ORDER_TYPE_SELL_LIMIT);
  }


bool V1Risk_OppositeFlow(int dir)
  {
   if(!V1CoreFlowReady()) return false;
   double fc = FlowComposite() * (double)dir;
   return (fc <= -V1ExitFlowScore &&
           gFlow.persistence >= V1ExitMinPersistence);
  }

bool V1Risk_OppositeStructure(int dir)
  {
   bool smcBreak = VNSMC_TrendBreak(-dir);
   bool thesisOpp = (UseM5ThesisLock && g_M5ThesisDir != 0 &&
                     g_M5ThesisDir == -dir &&
                     g_M5ThesisScore >= M5ThesisMinScore);
   return (smcBreak || thesisOpp);
  }

double V1Risk_CostBufferDistance()
  {
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   if(point<=0.0) point=_Point;
   double spreadPts=(double)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD);
   if(spreadPts<=0.0) spreadPts=CurrentSpreadPoints;
   double spreadSlip=(spreadPts*MathMax(1.0,SpreadMultiplier_Trail)+MathMax(0.0,ExitExpectedSlippagePoints))*point;
   double commissionDistance=0.0;
   double tickSize=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   double tickValue=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE_LOSS);
   if(tickValue<=0.0) tickValue=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
   if(ExitExpectedRoundTurnCostPerLot>0.0 && tickSize>0.0 && tickValue>0.0)
      commissionDistance=(ExitExpectedRoundTurnCostPerLot/tickValue)*tickSize;
   return MathMax(SafeTrailBuffer(),spreadSlip+commissionDistance);
  }

void V1Risk_SetProtection(ulong ticket, bool isBuy, double open,
                      double initialRisk, double lockR)
  {
   if(initialRisk<=0.0 || !PositionSelectByTicket(ticket)) return;
   double curSL=PositionGetDouble(POSITION_SL);
   double take=PositionGetDouble(POSITION_TP);
   double costBuffer=V1Risk_CostBufferDistance();
   double lockDistance=MathMax(initialRisk*MathMax(0.0,lockR),costBuffer);
   double desired=isBuy ? open+lockDistance : open-lockDistance;
   double quoteBuffer=SafeTrailBuffer();

   // If price has not moved far enough to place a valid cost-aware stop, wait.
   if(isBuy)
     {
      if(desired>=BidPrice()-quoteBuffer) return;
      if(curSL>0.0 && desired<=curSL+_Point) return; // never loosen
      bool ok=SafeModify(ticket,NormalizeDouble(desired,_Digits),take);
      if(!ok) PrintFormat("[V1 EXIT] BE/lock modify failed ticket=%I64u BUY desired=%.*f",ticket,_Digits,desired);
      else PrintFormat("[V1 EXIT] BE/lock confirmed ticket=%I64u BUY lockR=%.2f SL=%.*f",ticket,lockR,_Digits,desired);
     }
   else
     {
      if(desired<=AskPrice()+quoteBuffer) return;
      if(curSL>0.0 && desired>=curSL-_Point) return; // never loosen
      bool ok=SafeModify(ticket,NormalizeDouble(desired,_Digits),take);
      if(!ok) PrintFormat("[V1 EXIT] BE/lock modify failed ticket=%I64u SELL desired=%.*f",ticket,_Digits,desired);
      else PrintFormat("[V1 EXIT] BE/lock confirmed ticket=%I64u SELL lockR=%.2f SL=%.*f",ticket,lockR,_Digits,desired);
     }
  }


double V1_PositionCommissionAndFees(ulong positionIdentifier)
  {
   // Return only the share of entry-side commission/fees attributable to the still-open volume.
   // Exit-side charges on previously closed partial volume are realized costs, not current float.
   if(positionIdentifier==0) return 0.0;
   double currentVolume=0.0;
   if(posInfo.Identifier()==(long)positionIdentifier) currentVolume=posInfo.Volume();
   if(currentVolume<=0.0)
     {
      for(int p=PositionsTotal()-1;p>=0;p--)
        {
         ulong ticket=PositionGetTicket(p);
         if(ticket==0) continue;
         if((ulong)PositionGetInteger(POSITION_IDENTIFIER)==positionIdentifier)
           { currentVolume=PositionGetDouble(POSITION_VOLUME); break; }
        }
     }
   if(currentVolume<=0.0) return 0.0;

   static ulong cacheId[128];
   static double cacheValue[128];
   static double cacheVolume[128];
   static datetime cacheAt[128];
   int slot=-1, empty=-1, oldest=0;
   for(int i=0;i<128;i++)
     {
      if(cacheId[i]==positionIdentifier) { slot=i; break; }
      if(cacheId[i]==0 && empty<0) empty=i;
      if(cacheAt[i]<cacheAt[oldest]) oldest=i;
     }
   if(slot<0) slot=(empty>=0 ? empty : oldest);
   datetime now=TimeCurrent();
   if(cacheId[slot]==positionIdentifier && cacheAt[slot]==now &&
      MathAbs(cacheVolume[slot]-currentVolume)<1e-8) return cacheValue[slot];
   if(!HistorySelectByPosition((long)positionIdentifier))
      return (cacheId[slot]==positionIdentifier ? cacheValue[slot] : 0.0);

   double entryCosts=0.0, totalEntryVolume=0.0;
   for(int i=0;i<HistoryDealsTotal();i++)
     {
      ulong deal=HistoryDealGetTicket(i);
      if(deal==0) continue;
      ENUM_DEAL_ENTRY de=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal,DEAL_ENTRY);
      if(de!=DEAL_ENTRY_IN && de!=DEAL_ENTRY_INOUT) continue;
      double vol=HistoryDealGetDouble(deal,DEAL_VOLUME);
      if(vol<=0.0) continue;
      totalEntryVolume+=vol;
      entryCosts+=HistoryDealGetDouble(deal,DEAL_COMMISSION);
      entryCosts+=HistoryDealGetDouble(deal,DEAL_FEE);
     }
   double total=(totalEntryVolume>0.0 ? entryCosts*MathMin(1.0,currentVolume/totalEntryVolume) : 0.0);
   cacheId[slot]=positionIdentifier;
   cacheValue[slot]=total;
   cacheVolume[slot]=currentVolume;
   cacheAt[slot]=now;
   return total;
  }

bool V1PairBasket_CloseAll(string reason)
  {
   int requestedClose=0,requestedDelete=0;
   // Delete only this EA's pending orders for this chart symbol + magic.
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      ulong ticket=ordInfo.Ticket();
      MsgBudget_Count(1); // shared account-wide outbound request
      if(trade.OrderDelete(ticket)) { MsgBudget_TickDelete(); requestedDelete++; }
     }
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      if(ClosePosition(posInfo.Ticket())) requestedClose++;
     }
   int remainingPositions=CountOurPositions();
   PrintFormat("[PAIR BASKET EXIT] symbol=%s reason=%s closeRequests=%d pendingDeleted=%d remainingPositions=%d",_Symbol,reason,requestedClose,requestedDelete,remainingPositions);
   if(remainingPositions<=0)
     {
      g_V1PairBasketPeakProfit=0.0;
      g_V1PairBasketTrailArmed=false;
      g_V1PairBasketLastPositionCount=0;
     }
   else
     {
      g_V1PairBasketLastPositionCount=remainingPositions;
      PrintFormat("[PAIR BASKET EXIT RETRY] symbol=%s positions remain; peak profit watermark retained at %.2f",_Symbol,g_V1PairBasketPeakProfit);
     }
   return (requestedClose>0 || requestedDelete>0);
  }

bool V1PairBasket_Manage()
  {
   if(!V1PairBasketManagementEnabled || !V1RiskLayerEnabled) return false;
   int count=0;
   double pnl=0.0,totalLots=0.0,estimatedCosts=0.0;
   double spreadPrice=MathMax(0.0,AskPrice()-BidPrice());
   double slipPrice=MathMax(0.0,ExitExpectedSlippagePoints*_Point);
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      count++;
      double vol=posInfo.Volume(),open=posInfo.PriceOpen();
      bool isBuy=(posInfo.PositionType()==POSITION_TYPE_BUY);
      ENUM_ORDER_TYPE type=isBuy?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
      pnl+=posInfo.Profit()+posInfo.Swap()+V1_PositionCommissionAndFees((ulong)PositionGetInteger(POSITION_IDENTIFIER));
      totalLots+=vol;
      if(spreadPrice>0.0)
        estimatedCosts+=V1Risk_OrderRiskMoneyForSymbol(_Symbol,type,open,isBuy?open-spreadPrice:open+spreadPrice,vol);
      if(slipPrice>0.0)
        estimatedCosts+=V1Risk_OrderRiskMoneyForSymbol(_Symbol,type,open,isBuy?open-slipPrice:open+slipPrice,vol);
      estimatedCosts+=MathMax(0.0,ExitExpectedRoundTurnCostPerLot)*vol;
     }
   if(count<=0)
     {
      g_V1PairBasketPeakProfit=0.0;
      g_V1PairBasketTrailArmed=false;
      g_V1PairBasketLastPositionCount=0;
      return false;
     }
   if(g_V1PairBasketLastPositionCount<=0)
     {
      g_V1PairBasketPeakProfit=pnl;
      g_V1PairBasketTrailArmed=false;
     }
   g_V1PairBasketLastPositionCount=count;
   g_V1PairBasketPeakProfit=MathMax(g_V1PairBasketPeakProfit,pnl);

   double base=AccountInfoDouble(ACCOUNT_BALANCE);
   if(base<=0.0) base=AccountInfoDouble(ACCOUNT_EQUITY);
   if(base<=0.0) return false;
   double target=MathMax(V1_USDToAccountMoney(MathMax(0.0,V1PairBasketTakeProfitUSD)),
                         MathMax(base*MathMax(0.01,V1PairBasketTakeProfitPctBalance)/100.0,
                                 estimatedCosts*MathMax(1.0,V1PairBasketMinCostMultiple)));
   double trailArm=MathMax(V1_USDToAccountMoney(MathMax(0.0,V1PairBasketTrailArmUSD)),
                           MathMax(base*MathMax(0.01,V1PairBasketTrailArmPctBalance)/100.0,
                                   estimatedCosts*MathMax(1.5,V1PairBasketMinCostMultiple)));
   double giveback=MathMax(V1_USDToAccountMoney(MathMax(0.0,V1PairBasketGivebackUSD)),
                           MathMax(base*MathMax(0.01,V1PairBasketGivebackPctBalance)/100.0,
                                   estimatedCosts*1.25));
   double maxLoss=base*MathMax(0.01,V1PairBasketMaxLossPctBalance)/100.0;

   if(maxLoss>0.0 && pnl<=-maxLoss)
      return V1PairBasket_CloseAll(StringFormat("PAIR_BASKET_MAX_LOSS pnl=%.2f limit=%.2f",pnl,-maxLoss));
   if(target>0.0 && pnl>=target)
      return V1PairBasket_CloseAll(StringFormat("PAIR_BASKET_TARGET pnl=%.2f target=%.2f",pnl,target));
   if(g_V1PairBasketPeakProfit>=trailArm)
     {
      g_V1PairBasketTrailArmed=true;
      if(g_V1PairBasketPeakProfit-pnl>=giveback)
         return V1PairBasket_CloseAll(StringFormat("PAIR_BASKET_GIVEBACK peak=%.2f current=%.2f giveback=%.2f",g_V1PairBasketPeakProfit,pnl,g_V1PairBasketPeakProfit-pnl));
     }
   return false;
  }


double V1_USDToAccountMoney(double usd)
  {
   string cur=AccountInfoString(ACCOUNT_CURRENCY);
   StringToUpper(cur);
   if(cur=="USC" || cur=="USCENT" || cur=="US CENT") return usd*100.0;
   // The current profiles assume USD-denominated or USC cent-denominated accounts.
   // Other deposit currencies require an explicit conversion layer before live use.
   return usd;
  }

string V1PeakFlip_Key(ulong ticket, string suffix)
  {
   return StringFormat("BPF_%I64d_%I64d_%I64u_%s",
                       (long)AccountInfoInteger(ACCOUNT_LOGIN),
                       (long)MagicNumber, ticket, suffix);
  }

int V1_ClosedM1TriggerDirection()
  {
   // Use completed M1 bars only. Shift 0 is deliberately excluded because its EMA relation
   // can flip back and forth while the current candle is still forming.
   if(hGI_M1EMA5==INVALID_HANDLE || hGI_M1EMA13==INVALID_HANDLE) return 0;
   double fast=BufVal(hGI_M1EMA5,0,1);
   double slow=BufVal(hGI_M1EMA13,0,1);
   if(fast<=0.0 || slow<=0.0) return 0;
   if(fast>slow) return 1;
   if(fast<slow) return -1;
   return 0;
  }

void V1PeakFlip_DeleteTicketState(ulong ticket)
  {
   if(ticket==0) return;
   string suffixes[4]={"P","A","D","B"};
   for(int i=0;i<4;i++)
     {
      string key=V1PeakFlip_Key(ticket,suffixes[i]);
      if(GlobalVariableCheck(key)) GlobalVariableDel(key);
     }
  }

void V1PeakFlip_CleanupStaleState()
  {
   string prefix=StringFormat("BPF_%I64d_%I64d_",
                              (long)AccountInfoInteger(ACCOUNT_LOGIN),(long)MagicNumber);
   for(int i=GlobalVariablesTotal()-1;i>=0;i--)
     {
      string name=GlobalVariableName(i);
      if(StringFind(name,prefix)!=0) continue;
      string tail=StringSubstr(name,StringLen(prefix));
      int sep=StringFind(tail,"_");
      if(sep<=0) continue;
      ulong ticket=(ulong)StringToInteger(StringSubstr(tail,0,sep));
      if(ticket==0 || PositionSelectByTicket(ticket)) continue;
      V1PeakFlip_DeleteTicketState(ticket);
     }
  }

// Dynamic profit protection, activated only by an adverse direction change on a completed M1 bar.
// Peak P/L is stored per position ticket, survives chart/EA restarts, and never decreases.
// The broker SL is ratcheted to preserve V1PeakFlipRetainFraction of the peak net P/L.
// If the broker cannot place that SL or price gaps through it, the tick-level fallback closes at the floor.
bool V1_M1FlipPeakProtection_Manage()
  {
   if(!V1PeakFlipProtectionEnabled) return false;
   V1PeakFlip_CleanupStaleState();

   datetime closedBar=iTime(_Symbol,PERIOD_M1,1);
   if(closedBar<=0) return false;
   int closedDir=V1_ClosedM1TriggerDirection();
   double retain=Clamp(V1PeakFlipRetainFraction,0.10,0.90);
   double atr=CurrentATR1;
   if(atr<=0.0) atr=MathMax(CurrentATR5*0.25,_Point*10.0);

   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;

      ulong ticket=posInfo.Ticket();
      int idx=V1Risk_EnsureTracked(ticket);
      if(idx<0) continue;

      bool isBuy=(posInfo.PositionType()==POSITION_TYPE_BUY);
      int posDir=isBuy?1:-1;
      ENUM_ORDER_TYPE type=isBuy?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
      double volume=posInfo.Volume();
      double open=posInfo.PriceOpen();
      double swapNow=posInfo.Swap();
      double openCommission=V1_PositionCommissionAndFees(posInfo.Identifier());
      double pnl=posInfo.Profit()+swapNow+openCommission;
      double quote=isBuy?BidPrice():AskPrice();
      if(open<=0.0 || volume<=0.0 || quote<=0.0) continue;

      string peakKey=V1PeakFlip_Key(ticket,"P");
      string armedKey=V1PeakFlip_Key(ticket,"A");
      string dirKey=V1PeakFlip_Key(ticket,"D");
      string barKey=V1PeakFlip_Key(ticket,"B");

      double peakNet=GlobalVariableCheck(peakKey)?GlobalVariableGet(peakKey):0.0;
      peakNet=MathMax(peakNet,MathMax(0.0,pnl));
      GlobalVariableSet(peakKey,peakNet);
      // Cost estimate in deposit currency; the lock is armed only if peak can cover execution costs.
      double expectedCommission=MathMax(0.0,ExitExpectedCloseCostPerLot)*volume;
      double slipDistance=MathMax(0.0,ExitExpectedSlippagePoints*_Point);
      double slipMoney=0.0;
      if(slipDistance>0.0)
        {
         double slipProfit=0.0;
         double adverseQuote=isBuy?quote-slipDistance:quote+slipDistance;
         if(OrderCalcProfit(type,_Symbol,volume,quote,adverseQuote,slipProfit))
            slipMoney=MathAbs(slipProfit);
        }
      double estimatedExitCosts=expectedCommission+slipMoney;

      // Initialise the baseline signal without triggering immediately on EA startup or re-attach.
      if(!GlobalVariableCheck(dirKey) || !GlobalVariableCheck(barKey))
        {
         GlobalVariableSet(dirKey,(double)closedDir);
         GlobalVariableSet(barKey,(double)closedBar);
        }
      else
        {
         datetime lastBar=(datetime)GlobalVariableGet(barKey);
         int lastDir=(int)GlobalVariableGet(dirKey);
         if(closedBar>lastBar)
           {
            bool adverseClosedM1Flip=(lastDir==posDir && closedDir==-posDir);
            if(adverseClosedM1Flip && peakNet>estimatedExitCosts)
              {
               if(!GlobalVariableCheck(armedKey) || GlobalVariableGet(armedKey)<0.5)
                 {
                  GlobalVariableSet(armedKey,1.0);
                  PrintFormat("[M1 FLIP PEAK ARM] symbol=%s ticket=%I64u side=%s closedM1=%s->%s peakNet=%.2f retain=%.0f%%",
                              _Symbol,ticket,isBuy?"BUY":"SELL",DirStr(lastDir),DirStr(closedDir),
                              peakNet,retain*100.0);
                 }
              }
            if(closedDir!=0) GlobalVariableSet(dirKey,(double)closedDir);
            GlobalVariableSet(barKey,(double)closedBar);
           }
        }

      bool armed=(GlobalVariableCheck(armedKey) && GlobalVariableGet(armedKey)>0.5);
      if(!armed) continue;

      // Peak can continue to rise after activation. The retention floor therefore ratchets upward.
      double retainedNet=MathMax(0.0,peakNet*retain);
      double grossTarget=retainedNet-swapNow-openCommission+expectedCommission+slipMoney;
      double currentGross=0.0;
      bool canCalculate=OrderCalcProfit(type,_Symbol,volume,open,quote,currentGross);

      if(canCalculate && grossTarget>0.0 && currentGross>=grossTarget &&
         ((isBuy && quote>open) || (!isBuy && quote<open)))
        {
         double lo=0.0,hi=1.0;
         for(int n=0;n<48;n++)
           {
            double mid=(lo+hi)*0.5;
            double testPrice=open+(quote-open)*mid;
            double testProfit=0.0;
            if(!OrderCalcProfit(type,_Symbol,volume,open,testPrice,testProfit)) break;
            if(testProfit>=grossTarget) hi=mid; else lo=mid;
           }
         double desiredSL=open+(quote-open)*hi;
         double tickSize=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
         if(tickSize<=0.0) tickSize=_Point;
         if(isBuy) desiredSL=MathCeil(desiredSL/tickSize-1e-10)*tickSize;
         else      desiredSL=MathFloor(desiredSL/tickSize+1e-10)*tickSize;
         desiredSL=NormalizeDouble(desiredSL,_Digits);

         double freezeDist=(double)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_FREEZE_LEVEL)*_Point;
         double stopDist=MathMax(StopsLevelPrice(),freezeDist)+_Point;
         bool distanceOK=isBuy?(desiredSL<BidPrice()-stopDist && desiredSL>open)
                              :(desiredSL>AskPrice()+stopDist && desiredSL<open);
         double oldSL=posInfo.StopLoss();
         double minStep=MathMax(tickSize*2.0,atr*MathMax(0.01,V1PeakFlipStopStepATR));
         bool improves=isBuy?(oldSL<=0.0 || desiredSL>oldSL+minStep)
                            :(oldSL<=0.0 || desiredSL<oldSL-minStep);
         if(distanceOK && improves)
           {
            MsgBudget_Count(1);
            bool modified=trade.PositionModify(ticket,desiredSL,posInfo.TakeProfit());
            uint rc=trade.ResultRetcode();
            if(modified && (rc==TRADE_RETCODE_DONE || rc==TRADE_RETCODE_NO_CHANGES || rc==TRADE_RETCODE_PLACED))
               PrintFormat("[M1 FLIP PEAK SL] symbol=%s ticket=%I64u peakNet=%.2f retainedFloor=%.2f SL=%.*f pnl=%.2f",
                           _Symbol,ticket,peakNet,retainedNet,_Digits,desiredSL,pnl);
            else
               PrintFormat("[M1 FLIP PEAK SL RETRY] symbol=%s ticket=%I64u rc=%u %s peak=%.2f floor=%.2f pnl=%.2f",
                           _Symbol,ticket,rc,trade.ResultRetcodeDescription(),peakNet,retainedNet,pnl);
           }
         else if(!distanceOK)
           {
            V1_LogGateOnce(_Symbol+"|M1_FLIP_PEAK_DISTANCE_"+StringFormat("%I64u",ticket),
               StringFormat("[M1 FLIP PEAK WAIT] symbol=%s ticket=%I64u broker stop/freeze distance prevents the retained-profit SL; tick fallback remains active",
                            _Symbol,ticket),30);
           }
        }

      // A fast reversal/gap may cross the floor before a protective stop can be installed or filled.
      if(pnl<=retainedNet+estimatedExitCosts)
        {
         bool closed=ClosePosition(ticket);
         if(closed)
           {
            PrintFormat("[M1 FLIP PEAK EXIT] symbol=%s ticket=%I64u side=%s peakNet=%.2f floor=%.2f currentNet=%.2f retain=%.0f%% closedM1Flip=confirmed",
                        _Symbol,ticket,isBuy?"BUY":"SELL",peakNet,retainedNet,pnl,retain*100.0);
            V1PeakFlip_DeleteTicketState(ticket);
            return true;
           }
         PrintFormat("[M1 FLIP PEAK CLOSE RETRY] symbol=%s ticket=%I64u peak=%.2f floor=%.2f pnl=%.2f rc=%u %s",
                     _Symbol,ticket,peakNet,retainedNet,pnl,trade.ResultRetcode(),trade.ResultRetcodeDescription());
        }
     }
   return false;
  }


void V1_ManagePositionProtection()
  {
   if(!V1SingleExitControllerEnabled || !V1RiskLayerEnabled) return;
   V1Risk_RefreshCampaignState();
   if(V1_M1FlipPeakProtection_Manage()) return;
   if(V1PairBasket_Manage()) return;
   double campaignBestR=0.0;
   double atr1=CurrentATR1;
   if(atr1<=0.0) atr1=MathMax(CurrentATR5*0.25,_Point*10.0);
   double costBuffer=V1Risk_CostBufferDistance();

   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      // Single V1 exit owner: manage every V1 position for this symbol/magic.
      ulong ticket=posInfo.Ticket();
      int idx=V1Risk_EnsureTracked(ticket);
      if(idx<0) { PrintFormat("[V1 EXIT BLOCK] ticket=%I64u original SL/risk unavailable; position must retain broker SL",ticket); continue; }

      double open=posInfo.PriceOpen();
      double sl=posInfo.StopLoss();
      double tp=posInfo.TakeProfit();
      bool isBuy=(posInfo.PositionType()==POSITION_TYPE_BUY);
      double initialRisk=g_V1Risk_TrackRisk[idx];
      if(initialRisk<=0.0) continue;
      double executable=isBuy ? BidPrice() : AskPrice();
      double profitDist=isBuy ? executable-open : open-executable;
      double rr=profitDist/initialRisk;
      g_V1Risk_TrackPeakR[idx]=MathMax(g_V1Risk_TrackPeakR[idx],rr);
      double peakR=g_V1Risk_TrackPeakR[idx];
      campaignBestR=MathMax(campaignBestR,peakR);
      long ageSec=(long)(TimeCurrent()-g_V1Risk_TrackOpen[idx]);
      if(ageSec<0) ageSec=0;

      bool flowOpp=V1Risk_OppositeFlow(isBuy ? 1 : -1);
      bool structOpp=V1Risk_OppositeStructure(isBuy ? 1 : -1);
      int confirmations=(flowOpp ? 1 : 0)+(structOpp ? 1 : 0);
      if(confirmations>=V1AdverseConfirmations) g_V1Risk_TrackAdverse[idx]=MathMin(g_V1Risk_TrackAdverse[idx]+1,10);
      else if(g_V1Risk_TrackAdverse[idx]>0) g_V1Risk_TrackAdverse[idx]--;

      // Fast invalidation: only after noise-immunity and repeated adverse evidence.
      if(ageSec>=V1NoiseImmunitySec && g_V1Risk_TrackAdverse[idx]>=2 && rr<V1Protect_R)
        {
         PrintFormat("[V1 EXIT INVALIDATION] ticket=%I64u RR=%.2f flowOpp=%d structureOpp=%d",ticket,rr,(int)flowOpp,(int)structOpp);
         ClosePosition(ticket);
         continue;
        }

      // Peak harvest is handled only by V1_M1FlipPeakProtection_Manage after an adverse CLOSED-M1 trigger flip.
      // No direct peak-profit close is allowed on intrabar P/L flicker.

      // Adaptive break-even: favorable progress must clear both the initial-R and M1-noise thresholds.
      double beDistance=MathMax(initialRisk*V1BE_R,atr1*MathMax(V1BE_ATRMult,0.10));
      if(profitDist>=beDistance)
         V1Risk_SetProtection(ticket,isBuy,open,initialRisk,0.05);

      // Read back broker-confirmed SL after any modification request.
      if(!PositionSelectByTicket(ticket)) continue;
      sl=PositionGetDouble(POSITION_SL);
      tp=PositionGetDouble(POSITION_TP);
      bool beSecured=isBuy ? (sl>0.0 && sl>=open+costBuffer-_Point)
                           : (sl>0.0 && sl<=open-costBuffer+_Point);

      // Additional lock after the trade earns more room.
      if(rr>=V1Protect_R)
        {
         V1Risk_SetProtection(ticket,isBuy,open,initialRisk,V1ProtectLockR);
         if(!PositionSelectByTicket(ticket)) continue;
         sl=PositionGetDouble(POSITION_SL);
         beSecured=isBuy ? (sl>0.0 && sl>=open+costBuffer-_Point)
                         : (sl>0.0 && sl<=open-costBuffer+_Point);
        }

      // Discrete trailing only after cost-aware BE has been confirmed by the broker.
      double stepDistance=MathMax(atr1*MathMax(V1TrailStepATR,0.10),initialRisk*MathMax(V1TrailStepR,0.05));
      if(beSecured && profitDist>=MathMax(initialRisk*V1Trail_R,beDistance+stepDistance))
        {
         double trailDistance=MathMax(stepDistance,costBuffer);
         double desired=isBuy ? BidPrice()-trailDistance : AskPrice()+trailDistance;
         if(isBuy)
           {
            desired=MathMax(desired,open+costBuffer);
            if(desired<BidPrice()-SafeTrailBuffer() && desired>sl+stepDistance-_Point)
              {
               bool ok=SafeModify(ticket,NormalizeDouble(desired,_Digits),tp);
               if(!ok) PrintFormat("[V1 TRAIL] modify failed ticket=%I64u BUY RR=%.2f SL=%.*f",ticket,rr,_Digits,desired);
               else PrintFormat("[V1 TRAIL] confirmed ticket=%I64u BUY RR=%.2f SL=%.*f",ticket,rr,_Digits,desired);
              }
           }
         else
           {
            desired=MathMin(desired,open-costBuffer);
            if(desired>AskPrice()+SafeTrailBuffer() && (sl<=0.0 || desired<sl-stepDistance+_Point))
              {
               bool ok=SafeModify(ticket,NormalizeDouble(desired,_Digits),tp);
               if(!ok) PrintFormat("[V1 TRAIL] modify failed ticket=%I64u SELL RR=%.2f SL=%.*f",ticket,rr,_Digits,desired);
               else PrintFormat("[V1 TRAIL] confirmed ticket=%I64u SELL RR=%.2f SL=%.*f",ticket,rr,_Digits,desired);
              }
           }
        }
     }
   g_V1Risk_CampaignPeakR=MathMax(g_V1Risk_CampaignPeakR,campaignBestR);
  }

// V1 uses V1_ManagePositionProtection as the sole non-LegacyCampaign exit authority.

//===================================================================
// SECTION 72 — PER-POSITION MANAGEMENT [S4: spread-aware trailing]
//===================================================================
void ManagePositions()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;

      double open  = posInfo.PriceOpen();
      double stop  = posInfo.StopLoss();
      double take  = posInfo.TakeProfit();
      ulong  tkt   = posInfo.Ticket();
      bool   isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);

      if(stop <= 0.0) continue;
      double risk = MathAbs(open - stop);
      if(risk <= 0.0) continue;

      double profitDist = isBuy ? (BidPrice() - open) : (open - AskPrice());
      double rr = profitDist / risk;
      int engineIdx = EngineIndexFromComment(posInfo.Comment());

      // Require 2R for BE, 3R for trailing
      double beRR = 2.0;
      if(engineIdx == 2 || engineIdx == 3) beRR = 1.5;
      double trailRR = 3.0;
      if(engineIdx == 1) trailRR = 5.0;

      //--- [S4] spread-aware buffer
      double buf = SafeTrailBuffer();

      // --- WIDER BREAKEVEN ---
      if(beRR > 0.0 && rr >= beRR)
        {
         double ns;
         // Give it 1 ATR of room above entry, not just spread
         double beBuffer = MathMax(buf, CurrentATR1 * 1.0); 
         if(isBuy)
           {
            ns = NormalizeDouble(open + beBuffer, _Digits);
            if(ns > stop + _Point && ns < BidPrice() - beBuffer) SafeModify(tkt, ns, take);
           }
         else
           {
            ns = NormalizeDouble(open - beBuffer, _Digits);
            if(ns < stop - _Point && ns > AskPrice() + beBuffer) SafeModify(tkt, ns, take);
           }
        }

      //--- Trailing
      if(trailRR > 0.0 && rr >= trailRR)
        {
         double trailDist = risk * 0.5;
         double ns;
         if(isBuy)
           {
            ns = NormalizeDouble(BidPrice() - trailDist, _Digits);
            if(ns > stop + buf && ns < BidPrice() - buf)
               SafeModify(tkt, ns, take);
           }
         else
           {
            ns = NormalizeDouble(AskPrice() + trailDist, _Digits);
            if(ns < stop - buf && ns > AskPrice() + buf)
               SafeModify(tkt, ns, take);
           }
        }
     }
  }

//===================================================================
// SECTION 73 — TIGHT BE + TRAIL (TIER 2 — ATR-ADAPTIVE)
//===================================================================
void ManageTightExit(ulong ticket)
  {
   if(!UseTightBEV2 && !UseTightTrailV2) return;
   if(!PositionSelectByTicket(ticket)) return;

   double open  = PositionGetDouble(POSITION_PRICE_OPEN);
   double stop  = PositionGetDouble(POSITION_SL);
   double take  = PositionGetDouble(POSITION_TP);
   bool   isBuy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);

   if(open <= 0.0 || stop <= 0.0) return;
   double risk = MathAbs(open - stop);
   if(risk <= 0.0) return;

   double profitDist = isBuy ? (BidPrice() - open) : (open - AskPrice());
   double rr = profitDist / risk;

   //--- [S4] spread-aware buffer
   double buf = SafeTrailBuffer();

   //--- TIGHT BE (ATR-adaptive + spread floor)
   if(UseTightBEV2)
     {
      double beTrigPts = 0.0;
      double atrRef = CurrentATR1;
      if(atrRef > 0.0) beTrigPts = (atrRef * TightBE_ATR_Mult_V2) / _Point;
      beTrigPts = Clamp(beTrigPts, TightBE_MinPoints_V2, TightBE_MaxPoints_V2);

      //--- [S4] ensure BE trigger exceeds spread floor
      double spreadFloor = SpreadInPoints() * SpreadMultiplier_Trail;
      if(beTrigPts < spreadFloor) beTrigPts = spreadFloor;

      double beTrigPrice = beTrigPts * _Point;
      bool alreadyBE = isBuy ? (stop >= open) : (stop <= open);

      if(!alreadyBE && profitDist >= beTrigPrice)
        {
         double newSL = NormalizeDouble(open, _Digits);
         if(SafeModify(ticket, newSL, take))
            PrintFormat("[TIGHT-BE] %I64u BE at +%.1fpts",
                        ticket, profitDist / _Point);
         return;
        }
     }

   //--- TIGHT TRAIL (spread-aware)
   if(UseTightTrailV2 && rr >= TightTrail_StartR_V2)
     {
      double trailDist = risk * TightTrail_StepR_V2;
      if(trailDist < buf) trailDist = buf;   // [S4] spread floor

      double newSL;
      if(isBuy)
        {
         newSL = NormalizeDouble(BidPrice() - trailDist, _Digits);
         if(newSL > stop + TightTrail_MinImprovePts_V2 * _Point &&
            newSL < BidPrice() - buf)
            SafeModify(ticket, newSL, take);
        }
      else
        {
         newSL = NormalizeDouble(AskPrice() + trailDist, _Digits);
         if(newSL < stop - TightTrail_MinImprovePts_V2 * _Point &&
            newSL > AskPrice() + buf)
            SafeModify(ticket, newSL, take);
        }
     }
  }

void ManageAllTightExits()
  {
   if(!UseTightBEV2 && !UseTightTrailV2) return;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      ManageTightExit(posInfo.Ticket());
     }
  }

//===================================================================
// SECTION 74 — STALE POSITION EXIT
//===================================================================
void ManageStalePositions()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;

      datetime opened = (datetime)posInfo.Time();
      int ageMin = (int)((TimeCurrent() - opened) / 60);
      int engineIdx = EngineIndexFromComment(posInfo.Comment());
      int maxHold = (engineIdx == 1) ? Monster_HardMaxHoldMin : 90;

      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(stop <= 0.0) continue;
      double risk = MathAbs(open - stop);
      if(risk <= 0.0) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      double profitDist = isBuy ? (BidPrice() - open) : (open - AskPrice());
      double rr = profitDist / risk;

      bool stale = (ageMin >= 15 && rr < 0.20);
      bool hardExit = (ageMin >= maxHold);

      if(stale || hardExit)
         ClosePosition(posInfo.Ticket());
     }
  }

//===================================================================
// SECTION 75 — WICK ABORT
//===================================================================
void CheckWickAbort()
  {
   if(!UseWickAbort) return;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;

      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(stop <= 0.0) continue;

      double stopDist = MathAbs(open - stop);
      if(stopDist <= 0.0) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      double adverse = isBuy ? (open - BidPrice()) : (AskPrice() - open);

      if(adverse >= stopDist * WickAbortPct / 100.0)
         ClosePosition(posInfo.Ticket());
     }
  }

//===================================================================
// SECTION 76 — FLOW FLIP EXIT
//===================================================================
void CheckFlowFlipExit()
  {
   if(MQLInfoInteger(MQL_TESTER)) return;
   if(!UseBinanceFlow || !FlowFresh()) return;

   double fc = FlowComposite();
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      int dir = isBuy ? 1 : -1;
      int engineIdx = EngineIndexFromComment(posInfo.Comment());

      double profit = posInfo.Profit() + posInfo.Swap() + V1_PositionCommissionAndFees(posInfo.Identifier());
      if(profit <= 0.0) continue;

      if(fc * (double)dir <= -BinanceStrongFlowScore &&
         gFlow.persistence >= 0.50)
        {
         if(engineIdx == 1 && !VNSMC_TrendBreak(-dir)) continue;

         PrintFormat("[FLOW-FLIP] close %s pnl=%.2f fc=%.1f",
                     posInfo.Comment(), profit, fc);
         ClosePosition(posInfo.Ticket());
        }
     }
  }

//===================================================================
// SECTION 77 — WALL GUARD EXIT [A2: min profit + tighter wall]
//===================================================================
void WallGuardExit()
  {
   if(MQLInfoInteger(MQL_TESTER)) return;
   if(!gBinAux.valid) return;

   double mid = MidPrice();
   if(mid <= 0.0) return;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      int dir = isBuy ? 1 : -1;
      int engineIdx = EngineIndexFromComment(posInfo.Comment());

      double profit = posInfo.Profit() + posInfo.Swap() + V1_PositionCommissionAndFees(posInfo.Identifier());
      if(profit <= 0.0) continue;

      //--- [A2] minimum profit gate: 0.5R
      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(stop <= 0.0) continue;
      double riskUSD = MathAbs(open - stop) * posInfo.Volume()
                     / SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE)
                     * SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE_LOSS);
      if(riskUSD <= 0.0) continue;
      if(profit < riskUSD * 0.5) continue;

      if(engineIdx == 1 && !VNSMC_TrendBreak(-dir)) continue;

      //--- [A2] tighter wall distance: 50 pts (was 150)
      if(dir ==  1 && gBinAux.ask_wall_price > 0.0)
        {
         double d = (gBinAux.ask_wall_price - mid) / _Point;
         if(d > 0.0 && d < 50.0)
           {
            PrintFormat("[WALL-EXIT] BUY d=%.0f pnl=%.2f riskUSD=%.2f",
                        d, profit, riskUSD);
            ClosePosition(posInfo.Ticket());
           }
        }

      if(dir == -1 && gBinAux.bid_wall_price > 0.0)
        {
         double d = (mid - gBinAux.bid_wall_price) / _Point;
         if(d > 0.0 && d < 50.0)
           {
            PrintFormat("[WALL-EXIT] SELL d=%.0f pnl=%.2f riskUSD=%.2f",
                        d, profit, riskUSD);
            ClosePosition(posInfo.Ticket());
           }
        }
     }
  }

//===================================================================
// SECTION 78 — REVERSAL PARTIAL CLOSE (1.5R → 50% out)
//===================================================================
void ManageReversalPartial()
  {
   if(ReversalPartial) return;
   if(CountEnginePositions("REVERSAL_") <= 0) return;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), "REVERSAL_") < 0) continue;

      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(stop <= 0.0) continue;

      double risk = MathAbs(open - stop);
      if(risk <= 0.0) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      double prof = isBuy ? (BidPrice() - open) : (open - AskPrice());
      if(prof < risk * 1.50) continue;

      double vol = posInfo.Volume();
      double closeVol = NormalizeLots(vol * 0.50);
      if(closeVol <= 0.0 || closeVol >= vol) continue;
      if(closeVol < g_LotMin) continue;

      MsgBudget_Count(1); // shared account-wide outbound request
      if(trade.PositionClosePartial(posInfo.Ticket(), closeVol))
        {
         ReversalPartial = true;
         MsgBudget_TickModify();
         PrintFormat("[REVERSAL PARTIAL] closed %.4f of %.4f",
                     closeVol, vol);
        }
      return;
     }
  }

//===================================================================
// SECTION 79 — MONSTER THESIS EXIT [PATCHED: min-R gate]
//===================================================================
void CheckMonsterThesisExit()
  {
   if(g_MonsterPhase == MP_IDLE) return;
   if(g_MonsterDir == 0) return;
   if(CountEnginePositions("MONSTER_") <= 0) return;

   int mbi = EngineIndexFromName("MONSTER");
   double basketRisk = (mbi >= 0) ? BasketInitialRiskUSD[mbi] : 0.0;
   double pnl = PrefixFloatingPnL("MONSTER_");
   double monsterR = (basketRisk > 0.0) ? pnl / basketRisk : 0.0;

   bool oppositeBreak = VNSMC_TrendBreak(-g_MonsterDir);
   bool expansionLost = (g_R7 != R7_EXPANSION && !VNFlowTradeRateSurge());

   //--- PATCHED: only exit on thesis invalidation if we're still small profit
   // Below 1.5R: cut fast when thesis breaks (protect small gain)
   // Above 1.5R: let harvest/trail logic handle it (do NOT cut)
   if(oppositeBreak && expansionLost && monsterR > 0.0 && monsterR < 1.50)
     {
      PrintFormat("[MONSTER THESIS EXIT] R=%.2f opposite BOS/CHoCH", monsterR);
      CloseEnginePositions("MONSTER_");
      g_MonsterPhase = MP_IDLE;
      g_MonsterDir   = 0;
     }

   //--- PATCHED: log what would have exited but we held
   static datetime lastSkipLog = 0;
   if(oppositeBreak && expansionLost && monsterR >= 1.50 &&
      TimeCurrent() - lastSkipLog >= 60)
     {
      lastSkipLog = TimeCurrent();
      PrintFormat("[MONSTER HOLD] thesis broke but R=%.2f >= 1.50 — harvest/trail decides",
                  monsterR);
     }
  }

//===================================================================
// SECTION 80 — MONSTER / REVERSAL RESET HELPERS
//===================================================================
void ResetMonsterIfIdle()
  {
   if(g_MonsterPhase == MP_IDLE) return;
   if(CountEnginePositions("MONSTER_") > 0) return;
   if(CountEngineOrders("MONSTER_") > 0) return;
   g_MonsterPhase        = MP_IDLE;
   g_MonsterDir          = 0;
   g_MonsterPyramidCount = 0;
   g_MonsterPeakR        = 0.0;
   g_LastModelEngine     = "";
  }

void ResetRevIfStale()
  {
   if(g_RevState == REV_IDLE) return;
   if(g_RevState == REV_WATCH &&
      TimeCurrent() - g_RevWatchSince > Rev_WatchMaxMinutes * 60)
     {
      g_RevState = REV_IDLE;
      g_RevDir = 0;
      g_RevConfirmCount = 0;
     }
  }

//===================================================================
// SECTION 81 — HOURLY STRADDLE FLAG RESET
//===================================================================
void HourlyStraddleReset()
  {
   if(!UseHourlyStraddleReset) return;
   static datetime lastReset = 0;
   if(TimeCurrent() - lastReset < 3600) return;
   lastReset = TimeCurrent();
   g_StraddleActive = false;
   g_StraddleDir    = 0;
   g_GridLevelV2    = 0;
  }

//===================================================================
// SECTION 82 — HOURLY HARD RESET
//===================================================================
void HourlyHardReset()
  {
   static datetime lastHour = 0;
   if(TimeCurrent() - lastHour < 3600) return;
   lastHour = TimeCurrent();
   for(int i = 0; i < 4; i++)
     {
      g_EnginePnLToday[i]   = 0.0;
      g_EngineLossStreak[i] = 0;
     }
  }

//===================================================================
// SECTION 83 — DAILY RESET
//===================================================================
void DailyResetIfNeeded()
  {
   int today = (int)(TimeCurrent() / 86400);
   if(today == TodayStamp) return;
   TodayStamp = today;
   DayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
   DailyHalted = false;
   GlobalHalted = false;
   ConsecutiveLosses = 0;
   ConsecutiveWins = 0;
   g_GridLevelV2 = 0;
   Recovery_Reset();
   MsgBudget_DailyReset();
   for(int i = 0; i < 4; i++) g_EnginePnLToday[i] = 0.0;
   PrintFormat("[DAILY RESET] DayStartEquity=%.2f", DayStartEquity);
  }

//===================================================================
// SECTION 84 — SAFETY STACK
//===================================================================
void CheckSafety()
  {
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   if(equity > PeakEquity) PeakEquity = equity;

   if(UseDailyHalt && DayStartEquity > 0.0)
     {
      double dd = (DayStartEquity - equity) / DayStartEquity * 100.0;
      double dailyLimit = V1RiskLayerEnabled ? V1DailyLossPct : DailyLossLimitPct;
      if(dd >= dailyLimit && !DailyHalted)
        {
         DailyHalted = true;
         PauseUntil = TimeCurrent() + 3600;
         CloseAllOurPositions();
         PrintFormat("[SAFETY] Daily halt %.2f%%", dd);
        }
     }

   if(UseGlobalHalt && StartBalance > 0.0)
     {
      double dd = (StartBalance - equity) / StartBalance * 100.0;
      double globalLimit = V1RiskLayerEnabled ? V1GlobalLossPct : GlobalLossLimitPct;
      if(dd >= globalLimit && !GlobalHalted)
        {
         GlobalHalted = true;
         PauseUntil = TimeCurrent() + 6 * 3600;
         CloseAllOurPositions();
         PrintFormat("[SAFETY] Global halt %.2f%%", dd);
        }
     }

   if(UsePeakGiveback && PeakEquity > 0.0)
     {
      double gb = (PeakEquity - equity) / PeakEquity * 100.0;
      if(gb >= PeakGivebackPct && TimeCurrent() >= PauseUntil)
        {
         PauseUntil = TimeCurrent() + PeakGivebackPauseHrs * 3600;
         CloseAllOurPositions();
         PeakEquity = equity;
         PrintFormat("[PEAK-LOCK] giveback %.2f%%", gb);
        }
     }

   if(UseLossStreak && ConsecutiveLosses >= MaxConsecutiveLosses)
     {
      PauseUntil = MathMax(PauseUntil, TimeCurrent() + LossStreakPauseMin * 60);
      PrintFormat("[LOSS-STREAK] pause %d min", LossStreakPauseMin);
      ConsecutiveLosses = 0;
     }
  }
  
  //===================================================================
// SECTION 84A — TIER 5 FEATURES (V3.1 UPGRADE)
// 1) Generic Partial Exit
// 2) Discrete Growth Tiers
// 3) M5 Thesis Lock
//===================================================================

//--- Partial-close tracking (one per engine) ---------------------------
bool     g_PartialDone[4] = {false, false, false, false};

//--- M5 Thesis Lock state ----------------------------------------------
int      g_M5ThesisDir        = 0;
double   g_M5ThesisScore      = 0.0;
datetime g_M5ThesisBar        = 0;
string   g_M5ThesisReason     = "";


//-----------------------------------------------------------------------
// Message budget convenience helper (V3-compat shim)
//-----------------------------------------------------------------------
bool MsgBudget_Consume()
  {
   // Legacy helper used only by partial exits and pending-order cleanup.
   // Those management actions must remain possible after the NEW-entry cap.
   // Outbound operations are counted before submission by MsgBudget_Count; telemetry helpers do not add a second count.
   return true;
  }

//-----------------------------------------------------------------------
// 1) GENERIC PARTIAL EXIT
//-----------------------------------------------------------------------
double PartialRRForEngine(string engine)
  {
   if(engine == "MONSTER")  return PartialRR_Monster;
   if(engine == "SWING")    return PartialRR_Swing;
   if(engine == "RANGE")    return PartialRR_Range;
   if(engine == "REVERSAL") return PartialRR_Reversal;
   return PartialRR_Swing;
  }

double PartialPctForEngine(string engine)
  {
   if(engine == "MONSTER")  return PartialClosePct_Monster;
   if(engine == "SWING")    return PartialClosePct_Swing;
   if(engine == "RANGE")    return PartialClosePct_Range;
   if(engine == "REVERSAL") return PartialClosePct_Reversal;
   return PartialClosePct_Swing;
  }

void ManagePartialExitV3(string enginePrefix, int engIdx)
  {
   if(!UseGenericPartial) return;
   if(engIdx < 0 || engIdx > 3) return;
   if(g_PartialDone[engIdx]) return;
   if(CountEnginePositions(enginePrefix) <= 0) return;

   string bare = enginePrefix;
   StringReplace(bare, "_", "");

   double rrTrig = PartialRRForEngine(bare);
   double pctTrig = PartialPctForEngine(bare);

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), enginePrefix) < 0) continue;

      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(open <= 0.0 || stop <= 0.0) continue;
      double risk = MathAbs(open - stop);
      if(risk <= 0.0) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      double prof = isBuy ? (BidPrice() - open) : (open - AskPrice());
      double rrNow = prof / risk;
      if(rrNow < rrTrig) continue;

      double vol = posInfo.Volume();
      double closeVol = NormalizeLots(vol * pctTrig / 100.0);
      if(closeVol <= 0.0 || closeVol >= vol) continue;
      if(closeVol < g_LotMin) continue;

      if(!MsgBudget_Consume()) return;

      MsgBudget_Count(1); // shared account-wide outbound request
      if(trade.PositionClosePartial(posInfo.Ticket(), closeVol))
        {
         g_PartialDone[engIdx] = true;
         MsgBudget_TickModify();
         PrintFormat("[%s PARTIAL] closed %.4f/%.4f at %.2fR",
                     bare, closeVol, vol, rrNow);
        }
      return;
     }
  }

void ManageAllPartialsV3()
  {
   if(!UseGenericPartial) return;
   ManagePartialExitV3("SWING_",    0);
   ManagePartialExitV3("MONSTER_",  1);
   ManagePartialExitV3("RANGE_",    2);
   // REVERSAL intentionally omitted — handled by legacy ManageReversalPartial()
  }

void ResetPartialFlagsIfFlat()
  {
   if(CountEnginePositions("SWING_")    == 0) g_PartialDone[0] = false;
   if(CountEnginePositions("MONSTER_")  == 0) g_PartialDone[1] = false;
   if(CountEnginePositions("RANGE_")    == 0) g_PartialDone[2] = false;
   if(CountEnginePositions("REVERSAL_") == 0) g_PartialDone[3] = false;
  }

//-----------------------------------------------------------------------
// 2) M5 THESIS LOCK
//   Combines M5 direction + SMC bias + FastTrend + Flow into one score.
//   Direction is frozen once per new M5 bar so intra-bar flips are stopped.
//-----------------------------------------------------------------------
bool ComputeM5Thesis(int &outDir, double &outScore, string &outReason)
  {
   outDir = 0; outScore = 0.0; outReason = "";

   double atr = CurrentATR5;
   if(atr <= 0.0) atr = CurrentATR1;
   if(atr <= 0.0) { outReason = "NO_ATR"; return false; }

   double op = TfOpen(PERIOD_M5, 0);
   double px = MidPrice();
   if(op <= 0.0 || px <= 0.0) { outReason = "NO_PRICE"; return false; }

   double moveATR = (px - op) / atr;

   //--- M5 EMA alignment (cached handles)
   double e8  = BufVal(hEMA8_M5,  0, 0);
   double e21 = BufVal(hEMA21_M5, 0, 0);
   double e50 = BufVal(hEMA50_M5, 0, 0);
   double rsi = BufVal(hRSI_M5,   0, 0);
   double adx = BufVal(hADX_M5,   0, 0);
   double pdi = BufVal(hADX_M5,   1, 0);
   double mdi = BufVal(hADX_M5,   2, 0);
   double mom = BufVal(hMom14_M5, 0, 0);

   double bull = 0.0, bear = 0.0;

   // Move component (up to 22)
   if(moveATR >= 0.05) bull += Clamp(moveATR * 125.0, 0.0, 22.0);
   if(moveATR <= -0.05) bear += Clamp(-moveATR * 125.0, 0.0, 22.0);

   // EMA component (up to 22)
   if(e8 > 0.0 && e21 > 0.0)
     {
      if(e8 > e21) bull += 12.0; else bear += 12.0;
     }
   if(px > 0.0 && e50 > 0.0)
     {
      if(px > e50) bull += 10.0; else bear += 10.0;
     }

   // ADX component (up to 14)
   if(adx >= 18.0)
     {
      double add = Clamp(8.0 + (adx - 18.0) * 0.45, 8.0, 14.0);
      if(pdi > mdi) bull += add; else if(mdi > pdi) bear += add;
     }

   // RSI (7)
   if(rsi >= 53.0) bull += 7.0; else if(rsi <= 47.0) bear += 7.0;

   // Momentum (7)
   if(mom > 100.0) bull += 7.0; else if(mom > 0.0 && mom < 100.0) bear += 7.0;

   // SMC M5 bias / event (6)
   if(g_SMC.m5_bias == 1  || g_SMC.m5_event == 1)  bull += 6.0;
   if(g_SMC.m5_bias == -1 || g_SMC.m5_event == -1) bear += 6.0;

   // M15 context alignment (5)
   if(M15Direction == 1  && M5Direction == 1)  bull += 5.0;
   if(M15Direction == -1 && M5Direction == -1) bear += 5.0;

   // FastTrend direction alignment (8)
   if(UseFastTrendScore && g_FastTrendDir == 1) bull += 8.0;
   if(UseFastTrendScore && g_FastTrendDir == -1) bear += 8.0;

   // Bridge flow alignment (up to 10)
   if(BridgeReady())
     {
      double fc = FlowComposite();
      if(fc >  BinanceMinFlowScore) bull += Clamp(fc * 0.15, 0.0, 10.0);
      if(fc < -BinanceMinFlowScore) bear += Clamp(-fc * 0.15, 0.0, 10.0);
     }

   bull = Clamp(bull, 0.0, 100.0);
   bear = Clamp(bear, 0.0, 100.0);

   if(bull >= bear && bull >= M5ThesisMinScore)
     {
      outDir = 1; outScore = bull; outReason = "M5_BUY"; return true;
     }
   if(bear > bull && bear >= M5ThesisMinScore)
     {
      outDir = -1; outScore = bear; outReason = "M5_SELL"; return true;
     }

   outReason = "M5_BELOW_MIN";
   return false;
  }

void UpdateM5ThesisLock(bool force=false)
  {
   if(!UseM5ThesisLock) { g_M5ThesisDir = 0; return; }

   datetime bar = TfTime(PERIOD_M5, 0);
   if(bar == 0) return;
   if(!force && bar == g_M5ThesisBar) return;   // Already locked this bar

   g_M5ThesisBar = bar;
   int dir = 0; double score = 0.0; string reason = "";
   bool ok = ComputeM5Thesis(dir, score, reason);
   if(ok)
     {
      g_M5ThesisDir    = dir;
      g_M5ThesisScore  = score;
      g_M5ThesisReason = reason;
      PrintFormat("[M5 THESIS] %s score=%.1f", DirStr(dir), score);
     }
   else
     {
      g_M5ThesisDir    = 0;
      g_M5ThesisScore  = score;
      g_M5ThesisReason = reason;
     }
  }
  

//   Called by engines before placing orders.
//   Returns true if the requested dir is compatible with the frozen M5 thesis.
bool M5ThesisAllows(int dir, string engine)
  {
   if(!UseM5ThesisLock) return true;
   if(dir == 0) return false;

   // Range and Reversal are counter-trend by design — bypass lock.
   if(M5ThesisSkipRangeReversal &&
      (engine == "RANGE" || engine == "REVERSAL")) return true;

   if(g_M5ThesisDir == 0) return true;  // No lock yet — allow

   if(g_M5ThesisDir == dir) return true;

   // Opposite direction — block unless engine is MONSTER (needs to catch flips).
   if(M5ThesisBlockCounterTrend && engine != "MONSTER")
      return false;

   return true;
  }
  
 //-----------------------------------------------------------------------
 // FIB FACTOR BREAKOUT CONFIRMATION
 //   A breakout is only valid if price exceeds the swing level by at
 //   least FibBreakoutFactor * swing_leg_size.
 //   Prevents fake poke-above/poke-below traps.
 //-----------------------------------------------------------------------
double GetRecentSwingHigh(int bars)
  {
   double h = 0.0;
   for(int i = 1; i <= bars; i++)
      h = MathMax(h, TfHigh(PERIOD_M5, i));
   return h;
  }

double GetRecentSwingLow(int bars)
  {
   double l = DBL_MAX;
   for(int i = 1; i <= bars; i++)
     {
      double x = TfLow(PERIOD_M5, i);
      if(x > 0.0) l = MathMin(l, x);
     }
   return (l == DBL_MAX ? 0.0 : l);
  }

bool IsConfirmedBreakout(int dir, double swingHigh, double swingLow)
  {
   if(dir == 0) return false;
   if(swingHigh <= 0.0 || swingLow <= 0.0 || swingHigh <= swingLow) return false;

   double legSize   = swingHigh - swingLow;
   double threshold = legSize * FibBreakoutFactor;
   double price     = MidPrice();
   if(price <= 0.0) return false;

   if(dir == 1)
     {
      double required = swingHigh + threshold;
      if(price < required)
        {
         PrintFormat("[FIB BREAKOUT BLOCK] BUY requires %.2f, price=%.2f, short by %.2f",
                     required, price, required - price);
         return false;
        }
      return true;
     }

   if(dir == -1)
     {
      double required = swingLow - threshold;
      if(price > required)
        {
         PrintFormat("[FIB BREAKOUT BLOCK] SELL requires %.2f, price=%.2f, short by %.2f",
                     required, price, price - required);
         return false;
        }
      return true;
     }
   return false;
  }
  
  //-----------------------------------------------------------------------
  // M5 THESIS INVALIDATION
 //   If 2+ strong M1 bars close against the locked thesis with total
 //   movement >= 1.0 ATR, break the lock so the bot can react.
 //-----------------------------------------------------------------------
bool M5ThesisInvalidated(int thesisDir)
  {
   if(!UseM5ThesisLock) return false;
   if(thesisDir == 0) return false;

   double atr = CurrentATR1;
   if(atr <= 0.0) atr = NormalATR1;
   if(atr <= 0.0) return false;

   double reversalMove = 0.0;
   int    strongBars   = 0;

   for(int k = 1; k <= 3; k++)
     {
      double o = TfOpen(PERIOD_M1, k);
      double c = TfClose(PERIOD_M1, k);
      double h = TfHigh(PERIOD_M1, k);
      double l = TfLow(PERIOD_M1, k);
      if(o <= 0.0 || c <= 0.0) continue;

      double range = h - l;
      if(range <= 0.0) continue;
      double body = MathAbs(c - o) / range;

      bool againstThesis = ((thesisDir ==  1) && (c < o)) ||
                           ((thesisDir == -1) && (c > o));

      if(againstThesis && body >= 0.55)
        {
         strongBars++;
         reversalMove += MathAbs(c - o);
        }
     }

   if(strongBars >= 2 && reversalMove >= atr * 1.0)
      return true;

   return false;
  }

void CheckM5ThesisInvalidation()
  {
   if(!UseM5ThesisLock) return;
   if(g_M5ThesisDir == 0) return;

   if(M5ThesisInvalidated(g_M5ThesisDir))
     {
      PrintFormat("[M5 THESIS BREAK] dir=%s invalidated by strong reversal",
                  DirStr(g_M5ThesisDir));
      g_M5ThesisDir    = 0;
      g_M5ThesisScore  = 0.0;
      g_M5ThesisReason = "INVALIDATED";
      g_M5ThesisBar    = TfTime(PERIOD_M5, 0);  // Prevent re-lock this bar
     }
  }
  
//-----------------------------------------------------------------------
// 3) DISCRETE GROWTH TIERS
//-----------------------------------------------------------------------
double DiscreteGrowthMultiplier()
  {
   if(StartBalance <= 0.0) return 1.0;
   double growth = AccountInfoDouble(ACCOUNT_BALANCE) / StartBalance;
   if(growth <= 1.0) return 1.0;
   if(growth < DiscreteTier1_Growth) return 1.00;
   if(growth < DiscreteTier2_Growth) return DiscreteTier1_Mult;
   if(growth < DiscreteTier3_Growth) return DiscreteTier2_Mult;
   return DiscreteTier3_Mult;
  }

// V1.60: paired range entry implementation retired; independent range LIMITs are used.

//===================================================================
// SECTION 85 — BIASED STRADDLE PLAN BUILDER
//===================================================================
S_StraddlePlan BuildStraddlePlan(string engine, int direction,
                                 int moveState, bool isJerk, bool isExtreme,
                                 double atr5)
  {
   S_StraddlePlan p;
   p.buys = 0; p.sells = 0;
   p.buyMult = 1.0; p.sellMult = 1.0;
   p.isExtreme = isExtreme;
   p.isJerk    = isJerk;

   if(direction == 0) return p;

   // V2 topology: Monster owns the 7-order one-sided ladder.
   // Jerk context on non-Monster engines uses the broker/message-cap 5-order ladder.
   if(engine == "MONSTER")
     {
      int cnt = StraddleExtremeOrders;
      double mult = StraddleExtremeLotMult;
      if(direction == 1)
        { p.buys = cnt; p.sells = 0; p.buyMult = mult; }
      else
        { p.buys = 0; p.sells = cnt; p.sellMult = mult; }
     }
   else if(isJerk || isExtreme)
     {
      int cnt = isExtreme ? StraddleExtremeOrders : StraddleJerkOrders;
      double mult = isExtreme ? StraddleExtremeLotMult : StraddleJerkLotMult;
      if(direction == 1)
        { p.buys = cnt; p.sells = 0; p.buyMult = mult; }
      else
        { p.buys = 0; p.sells = cnt; p.sellMult = mult; }
     }
   else
     {
      if(direction == 1)
        {
         p.buys  = StraddleStrongOrders;
         p.sells = StraddleWeakOrders;
         p.buyMult  = StraddleStrongLotMult;
         p.sellMult = StraddleWeakLotMult;
        }
      else
        {
         p.buys  = StraddleWeakOrders;
         p.sells = StraddleStrongOrders;
         p.buyMult  = StraddleWeakLotMult;
         p.sellMult = StraddleStrongLotMult;
        }
     }

   double gapPrice = StraddleNormalGapPrice;
   if(engine == "MONSTER" || isJerk || isExtreme) gapPrice = StraddleImpulseGapPrice;
   p.gap = MathMax(gapPrice, CurrentSpreadPoints * _Point * 1.5);

   p.slPrice = ComputeSLDistance(engine);
   p.tpPrice = ComputeTPDistance(engine, p.slPrice);

   return p;
  }

//===================================================================
// LEGACY FAST BASELINE — PATH / FAIR CONTINUATION ENGINE
//===================================================================
double LegacyFast_M1VolumeRatio()
  {
   double sum = 0.0;
   int cnt = 0;
   for(int i = 2; i <= 21; i++)
     {
      long v = TfVolume(PERIOD_M1, i);
      if(v > 0)
        {
         sum += (double)v;
         cnt++;
        }
     }
   if(cnt <= 0) return 1.0;
   double cur = (double)TfVolume(PERIOD_M1, 1);
   return (sum > 0.0) ? cur / (sum / (double)cnt) : 1.0;
  }

bool LegacyFast_M1Path(int &dir, double &eff, double &netATR, double &dirPct,
                  double &netPts, double &travelPts)
  {
   dir = 0;
   eff = 0.0;
   netATR = 0.0;
   dirPct = 0.0;
   netPts = 0.0;
   travelPts = 0.0;

   int nBars = MathMax(5, LegacyFastPathLookbackBars);
   double oldest = TfClose(PERIOD_M1, nBars);
   double latest = TfClose(PERIOD_M1, 1);
   double atr = CurrentATR1;
   if(oldest <= 0.0 || latest <= 0.0 || atr <= 0.0) return false;

   double net = latest - oldest;
   double travel = 0.0;
   int dirBars = 0;

   for(int k = 1; k <= nBars; k++)
     {
      double o = TfOpen(PERIOD_M1, k);
      double c = TfClose(PERIOD_M1, k);
      if(c > o) dirBars++;
      else if(c < o) dirBars--;

      if(k < nBars)
        {
         double c1 = TfClose(PERIOD_M1, k);
         double c2 = TfClose(PERIOD_M1, k + 1);
         travel += MathAbs(c1 - c2);
        }
     }

   if(travel <= 0.0 || net == 0.0) return false;

   dir = net > 0.0 ? 1 : -1;
   eff = MathAbs(net) / travel;
   netATR = MathAbs(net) / atr;
   dirPct = MathAbs((double)dirBars) / (double)nBars;
   netPts = MathAbs(net) / _Point;
   travelPts = travel / _Point;

   return (eff >= LegacyFastPathMinEfficiency &&
           netATR >= LegacyFastPathMinNetATR &&
           dirPct >= LegacyFastPathMinDirectionalPct);
  }

bool LegacyFast_PathContextAllows(int dir)
  {
   if(dir == 0) return false;

   bool m5ctx = (M5Direction == dir || g_SMC.m5_bias == dir);
   bool trendctx = (UseFastTrendScore &&
                    g_FastTrendDir == dir &&
                    g_FastTrendScore >= (LegacyFastPathMinContextScore * 100.0));
   bool flowctx = (!BridgeReady() ||
                   Flow_Agrees(dir, false) ||
                   FlowComposite() * (double)dir >= 0.0);

   // A very efficient path may stand on its own; otherwise require M5/trend context.
   if(!m5ctx && !trendctx && g_LegacyFastPathEfficiency < 0.72) return false;
   if(!flowctx) return false;
   return true;
  }

bool LegacyFast_ExpansionOverrideForDir(int dir)
  {
   if(!UseLegacyFastBaseline || !LegacyFastExpansionOverride || dir == 0) return false;
   if(CurrentATR1 <= 0.0) return false;

   double atrRatio = (NormalATR1 > 0.0) ? CurrentATR1 / NormalATR1 : 1.0;
   double volRatio = LegacyFast_M1VolumeRatio();
   int pdir = 0;
   double eff = 0.0, netATR = 0.0, dirPct = 0.0, netPts = 0.0, travelPts = 0.0;
   bool path = LegacyFast_M1Path(pdir, eff, netATR, dirPct, netPts, travelPts);
   if(path && pdir == dir &&
      eff >= LegacyFastExpansionPathEfficiency &&
      (atrRatio >= LegacyFastExpansionATRRatio || volRatio >= LegacyFastExpansionVolumeRatio))
      return true;

   return false;
  }

bool LegacyFast_MonsterQualityPass(int dir)
  {
   if(!UseLegacyFastBaseline || !LegacyFastMonsterQualityGate) return true;
   if(dir == 0) return false;

   bool structure = (dir == 1)
                    ? (M1BullMSS() || M1BullDisplacement() || VNSMC_TrendBreak(dir))
                    : (M1BearMSS() || M1BearDisplacement() || VNSMC_TrendBreak(dir));
   bool sweep = (dir == 1) ? M1BullSweep() : M1BearSweep();
   bool fvg = (dir == 1) ? M1BullFVG() : M1BearFVG();
   double volRatio = LegacyFast_M1VolumeRatio();
   bool volume = (volRatio >= LegacyFastMonsterVolumeRatioMin);
   bool flow = false;
   if(BridgeReady())
      flow = (FlowComposite() * (double)dir >= LegacyFastMonsterStrongFlowMin &&
             gFlow.persistence >= BinanceMinPersistence);

   int pdir = 0;
   double eff = 0.0, netATR = 0.0, dirPct = 0.0, netPts = 0.0, travelPts = 0.0;
   bool pathValid = LegacyFast_M1Path(pdir, eff, netATR, dirPct, netPts, travelPts);
   bool path = (pathValid && pdir == dir && eff >= LegacyFastMonsterPathEfficiency);

   int evidence = 0;
   if(structure) evidence++;
   if(sweep)     evidence++;
   if(fvg)       evidence++;
   if(volume)    evidence++;
   if(flow)      evidence++;
   if(path)      evidence++;

   // A Monster signal must have structural/liquidity evidence and at least
   // the configured number of independent confirmations.
   if(!structure && !sweep && !fvg) return false;
   if(evidence < LegacyFastMonsterMinEvidence) return false;
   if(BridgeReady() && !flow && evidence <= LegacyFastMonsterMinEvidence)
      return false;

   return true;
  }

void LegacyFast_DeleteStaleContinuationPendings()
  {
   if(!UseLegacyFastBaseline || LegacyFastPendingLifetimeMin <= 0) return;
   if(TimeCurrent() - g_LegacyFastLastPendingCleanup < 5) return;
   g_LegacyFastLastPendingCleanup = TimeCurrent();

   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol || ordInfo.Magic() != MagicNumber) continue;
      string cmt = ordInfo.Comment();
      if(StringFind(cmt, "LEGACY FAST_") < 0) continue;
      datetime setup = (datetime)ordInfo.TimeSetup();
      if(setup <= 0) continue;
      if(TimeCurrent() - setup >= LegacyFastPendingLifetimeMin * 60)
        {
         MsgBudget_Count(1); // shared account-wide outbound request
         if(trade.OrderDelete(ordInfo.Ticket()))
            MsgBudget_TickDelete();
        }
     }
  }

bool LegacyFastPlaceDirectionalContinuation(string engine, int direction,
                                       bool isJerk, bool isExtreme,
                                       double totalLotsOverride,
                                       double slDistOverride,
                                       double tpDistOverride,
                                       string tag)
  {
   if(!UseLegacyFastBaseline || !UseLegacyFastFairContinuation) return false;
   if(direction == 0) return false;
   if(CountOurPositions() > 0 && engine != "MONSTER") return false;
   if(!MsgBudget_CanTrade()) return false;

   double atr1 = CurrentATR1;
   if(atr1 <= 0.0) atr1 = CurrentATR5;
   if(atr1 <= 0.0) return false;

   double slDist = (slDistOverride > 0.0) ? slDistOverride : ComputeSLDistance(engine);
   double tpDist = (tpDistOverride > 0.0) ? tpDistOverride : ComputeTPDistance(engine, slDist);
   if(slDist <= 0.0 || tpDist <= 0.0) return false;

   double totalLots = totalLotsOverride;
   if(totalLots <= 0.0)
      totalLots = CalcLots(engine, direction, slDist);
   if(totalLots <= 0.0) return false;

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return false;

   // One small starter + continuation slices. Every slice is capped by the
   // existing V1 campaign risk governor in SendMarketV2/SendStopV2.
   double starterLots = ValidateLot(totalLots * LegacyFastStarterRiskFraction);
   double remainingLots = MathMax(0.0, totalLots - starterLots);

   int placed = 0;
   string base = (tag == "" ? engine : tag) + "_LEGACY FAST_" + (direction > 0 ? "B" : "S");

   if(starterLots > 0.0)
     {
      double entry = (direction > 0) ? ask : bid;
      double sl = (direction > 0) ? entry - slDist : entry + slDist;
      double tp = (direction > 0) ? entry + tpDist : entry - tpDist;
      bool ok = SendMarketV2(direction > 0 ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
                             starterLots,
                             NormalizeDouble(sl, _Digits),
                             NormalizeDouble(tp, _Digits),
                             base + "_START");
      if(ok) placed++;
     }

   // After a successful starter, place directional STOPs in a close fair-gap
   // corridor. We never place the ladder at a remote swing extreme.
   int wanted = MathMax(0, MathMin(LegacyFastFairPendingCount, 4));
   if(remainingLots > 0.0 && wanted > 0)
     {
      double spreadPrice = CurrentSpreadPoints * _Point;
      double baseGap = MathMax(atr1 * LegacyFastFairGapBaseATR,
                               spreadPrice * LegacyFastFairMinGapSpreadMult);
      double maxDist = atr1 * LegacyFastFairMaxDistanceATR;
      double mults[4] = {1.0, LegacyFastFairGapStep2, LegacyFastFairGapStep3, LegacyFastFairGapStep4};
      int validSlots = 0;
      for(int j = 0; j < wanted; j++)
        {
         if(baseGap * mults[j] <= maxDist + 1e-9)
            validSlots++;
        }
      if(validSlots > 0)
        {
         double sliceLots = ValidateLot(remainingLots / (double)validSlots);
         if(sliceLots > 0.0)
           {
            for(int j = 0; j < wanted; j++)
              {
               double offset = baseGap * mults[j];
               if(offset > maxDist + 1e-9) continue;

               double price = (direction > 0) ? ask + offset : bid - offset;
               double sl = (direction > 0) ? price - slDist : price + slDist;
               double tp = (direction > 0) ? price + tpDist : price - tpDist;

               string cmt = base + "_P" + IntegerToString(j + 1);
               if(SendStopV2(direction > 0,
                             NormalizeDouble(price, _Digits),
                             sliceLots,
                             NormalizeDouble(sl, _Digits),
                             NormalizeDouble(tp, _Digits),
                             cmt))
                  placed++;
              }
           }
        }
     }

   if(placed > 0)
     {
      g_LastPlaceTime = TimeCurrent();
      g_LastEntryDir = direction;
      g_LastEntryTime = TimeCurrent();
      PrintFormat("[LEGACY FAST CONTINUATION] engine=%s dir=%s starter=%.4f pending=%d atr=%.2f baseGap=%.2f maxDist=%.2f jerk=%d extreme=%d",
                  engine, DirStr(direction), starterLots, MathMax(0, placed - (starterLots > 0.0 ? 1 : 0)),
                  atr1, (atr1 * LegacyFastFairGapBaseATR), (atr1 * LegacyFastFairMaxDistanceATR), (int)isJerk, (int)isExtreme);
      return true;
     }
   return false;
  }

bool LegacyFast_Path_Run()
  {
   if(!UseLegacyFastBaseline || !UseLegacyFastPathEngine) return false;
   if(CountOurPositions() > 0) return false;
   if(CountPendingTotal() > 0) return false;
   if(!EngineBudgetOK("SWING")) return false;
   if(!EngineCooldownOK("SWING")) return false;
   if(!Health_AllowsNewEntries()) return false;
   if(!SpreadOK()) return false;
   if(WickPauseActive()) return false;

   int dir = 0;
   double eff = 0.0, netATR = 0.0, dirPct = 0.0, netPts = 0.0, travelPts = 0.0;
   if(!LegacyFast_M1Path(dir, eff, netATR, dirPct, netPts, travelPts)) return false;

   g_LegacyFastPathDir = dir;
   g_LegacyFastPathEfficiency = eff;
   g_LegacyFastPathNetATR = netATR;
   g_LegacyFastPathDirectionalPct = dirPct;

   if(!LegacyFast_PathContextAllows(dir)) return false;

   bool m1Trigger = (dir > 0)
                    ? (M1BullDisplacement() || M1BullMSS() || M1BullFVG() || M1BullSweep())
                    : (M1BearDisplacement() || M1BearMSS() || M1BearFVG() || M1BearSweep());
   bool expansion = LegacyFast_ExpansionOverrideForDir(dir);
   if(!m1Trigger && !expansion) return false;

   if(!RegimeGateAllows(dir, "SWING") && !expansion) return false;
   if(!M15VetoAllows(dir) && !expansion) return false;
   if(!H1VetoAllows(dir) && !expansion) return false;
   if(!Flow_Agrees(dir, false)) return false;

   double slDist = ComputeSLDistance("SWING");
   double tpDist = ComputeTPDistance("SWING", slDist);
   double lots = CalcLots("SWING", dir, slDist);
   if(lots <= 0.0) return false;
   lots = ValidateLot(lots * LegacyFastPathRiskFraction);
   if(lots <= 0.0) return false;
   if(!EntryAllowed("SWING", lots, dir)) return false;

   datetime bar = TfTime(PERIOD_M1, 1);
   if(bar == g_LegacyFastLastPathBar) return false;
   g_LegacyFastLastPathBar = bar;

   bool ok = LegacyFastPlaceDirectionalContinuation("SWING", dir, false, expansion,
                                               lots, slDist, tpDist, "LEGACY FAST_PATH");
   if(ok)
      PrintFormat("[LEGACY FAST PATH] dir=%s eff=%.2f netATR=%.2f dirPct=%.2f expansion=%d",
                  DirStr(dir), eff, netATR, dirPct, (int)expansion);
   return ok;
  }

//===================================================================
// SECTION 86 — BIASED STRADDLE PLACER
//===================================================================
bool PlaceBiasedStraddle(string engine, int direction, bool isJerk, bool isExtreme)
  {
   // V2: Monster uses the engine-native 7-order ladder; LegacyFast fair-continuation
   // remains available through the dedicated LEGACY FAST PATH engine instead.
   if(!UseBiasedStraddle) return false;
   if(direction == 0) return false;
   if(!MsgBudget_CanTrade()) return false;

   double atr5 = CurrentATR5;
   if(atr5 <= 0.0) atr5 = CurrentATR1;
   if(atr5 <= 0.0) return false;

   S_StraddlePlan p = BuildStraddlePlan(engine, direction, CurrentMoveState,
                                        isJerk, isExtreme, atr5);
   if(p.buys + p.sells == 0) return false;

   double baseLotBuy  = CalcLots(engine,  1, p.slPrice);
   double baseLotSell = CalcLots(engine, -1, p.slPrice);
   if(baseLotBuy <= 0.0 && baseLotSell <= 0.0) return false;

   double lotBuy  = (baseLotBuy  > 0.0) ? ValidateLot(baseLotBuy  * p.buyMult)  : 0.0;
   double lotSell = (baseLotSell > 0.0) ? ValidateLot(baseLotSell * p.sellMult) : 0.0;

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return false;

   string prefix = engine + "_";
   int placed = 0;

   for(int i = 0; i < p.buys; i++)
     {
      if(lotBuy <= 0.0) break;
      double price = NormalizeDouble(ask + p.gap * (i + 1), _Digits);
      double sl    = NormalizeDouble(price - p.slPrice, _Digits);
      double tp    = NormalizeDouble(price + p.tpPrice, _Digits);
      if(SendStopV2(true, price, lotBuy, sl, tp,
                    prefix + "B" + IntegerToString(i))) placed++;
     }

   for(int i = 0; i < p.sells; i++)
     {
      if(lotSell <= 0.0) break;
      double price = NormalizeDouble(bid - p.gap * (i + 1), _Digits);
      double sl    = NormalizeDouble(price + p.slPrice, _Digits);
      double tp    = NormalizeDouble(price - p.tpPrice, _Digits);
      if(SendStopV2(false, price, lotSell, sl, tp,
                    prefix + "S" + IntegerToString(i))) placed++;
     }

   if(placed > 0)
     {
      g_LastPlaceTime = TimeCurrent();
      g_LastEntryDir  = direction;
      g_LastEntryTime = TimeCurrent();
      g_StraddleActive = true;
      g_StraddleDir    = direction;

      PrintFormat("[STRADDLE %s] dir=%s buys=%d sells=%d lotB=%.3f lotS=%.3f "
                  "gap=%.0fpts SL=%.0f TP=%.0f",
                  engine, DirStr(direction), p.buys, p.sells,
                  lotBuy, lotSell,
                  p.gap / _Point,
                  p.slPrice / _Point, p.tpPrice / _Point);
      return true;
     }

   return false;
  }

//===================================================================
// SECTION 87 — WIN-GATED GRID V2
//===================================================================
bool TryGridAddV2()
  {
   if(!UseWinGatedGrid) return false;
   if(g_GridLevelV2 >= GridMaxLevelsV2) return false;
   if(TimeCurrent() - g_LastGridAddV2 < GridCooldownSecV2) return false;
   if(!g_LastWasWin) return false;
   if(ConsecutiveWins < GridMinConsecutiveWins) return false;
   // V2: the win that unlocks a grid add must belong to the current
   // V1 campaign, preventing a stale previous win from authorising
   // new exposure in an unrelated campaign.
   if(V1RiskLayerEnabled && g_V1Risk_CampaignActive &&
      (LastWinTime <= 0 || LastWinTime < g_V1Risk_CampaignStart)) return false;
   if(!MsgBudget_CanTrade()) return false;

   if(GridRequireTrendRegime)
     {
      if(g_R7 != R7_STRONG_UP && g_R7 != R7_STRONG_DOWN &&
         g_R7 != R7_EXPANSION && g_R7 != R7_WEAK_UP && g_R7 != R7_WEAK_DOWN)
         return false;
     }

   string prefixes[4] = {"SWING_","MONSTER_","RANGE_","REVERSAL_"};
   string activeEngine = "";
   for(int i = 0; i < 4; i++)
     {
      if(CountEnginePositions(prefixes[i]) > 0 ||
         CountEngineOrders(prefixes[i]) > 0)
        { activeEngine = prefixes[i]; break; }
     }
   if(activeEngine == "") return false;

   int dir = 0;
   if(g_R7 == R7_STRONG_UP || g_R7 == R7_WEAK_UP || g_R7 == R7_EXPANSION) dir = 1;
   if(g_R7 == R7_STRONG_DOWN || g_R7 == R7_WEAK_DOWN) dir = -1;
   if(UseFastTrendScore && g_FastTrendDir != 0 && g_FastTrendScore >= FastTrend_PrimeThreshold)
      dir = g_FastTrendDir;
   if(dir == 0) return false;

   string engineShort = activeEngine;
   StringReplace(engineShort, "_", "");

   double atr5 = CurrentATR5;
   if(atr5 <= 0.0) return false;

   double slPrice = ComputeSLDistance(engineShort);
   double tpPrice = ComputeTPDistance(engineShort, slPrice);
   double gap     = atr5 * GridGapATRMult;

   double baseLot = BaseLotForEngine(engineShort);
   if(baseLot <= 0.0) baseLot = Range_Lot;

   double lotMult = MathPow(GridLotMultV2, (double)(ConsecutiveWins + g_GridLevelV2));
   double gridLot = ValidateLot(baseLot * lotMult);
   if(gridLot <= 0.0) return false;

   if(TotalOurLots() + gridLot > CapTotalLots() + 1e-12) return false;

   double bid = BidPrice(), ask = AskPrice();
   bool ok = false;
   string cmt = activeEngine + "G" + IntegerToString(g_GridLevelV2 + 1);

   if(dir == 1)
     {
      double price = NormalizeDouble(ask + gap, _Digits);
      double sl    = NormalizeDouble(price - slPrice, _Digits);
      double tp    = NormalizeDouble(price + tpPrice, _Digits);
      ok = SendStopV2(true, price, gridLot, sl, tp, cmt);
     }
   else
     {
      double price = NormalizeDouble(bid - gap, _Digits);
      double sl    = NormalizeDouble(price + slPrice, _Digits);
      double tp    = NormalizeDouble(price - tpPrice, _Digits);
      ok = SendStopV2(false, price, gridLot, sl, tp, cmt);
     }

   if(ok)
     {
      g_GridLevelV2++;
      g_LastGridAddV2 = TimeCurrent();
      PrintFormat("[GRID V2] level=%d engine=%s dir=%d lot=%.3f wins=%d",
                  g_GridLevelV2, engineShort, dir, gridLot, ConsecutiveWins);
     }
   return ok;
  }

//===================================================================
// SECTION 88 — VWAP CHOP STRADDLE [A6: log outcome]
//===================================================================
bool PlaceVWAPChopStraddle()
  {
   if(!UseVWAPChopStraddle) return false;
   if(!MsgBudget_CanTrade()) return false;
   if(g_R7 != R7_CHOP && g_R7 != R7_COMPRESSION) return false;
   if(UseFastTrendScore && g_FastTrendScore >= FastTrend_ChopThreshold) return false;

   if(CountEnginePositions("CHOP_") > 0) return false;
   if(CountEngineOrders("CHOP_") > 0) return false;

   int bias = GetVWAPBias();

   int buys  = VWAPChopBuyOrders;
   int sells = VWAPChopSellOrders;

   if(bias == 1)  { buys = 2; sells = 1; }
   if(bias == -1) { buys = 1; sells = 2; }

   double atr = CurrentATR1;
   if(atr <= 0.0) atr = CurrentATR5;
   if(atr <= 0.0) return false;

   double slDist = ComputeSLDistance("RANGE");
   double tpDist = ComputeTPDistance("RANGE", slDist);
   double gap    = MathMax(StraddleChopGapPrice, CurrentSpreadPoints * _Point * 1.5);

   double baseLot = Range_Lot * VWAPChopLotMult;
   double lot = CalcLots("RANGE", bias == -1 ? -1 : 1, slDist);
   if(lot <= 0.0) lot = ValidateLot(baseLot);
   if(lot <= 0.0) return false;

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return false;

   int placed = 0;

   for(int i = 0; i < sells; i++)
     {
      double price = NormalizeDouble(bid - gap * (i + 1), _Digits);
      double sl    = NormalizeDouble(price + slDist, _Digits);
      double tp    = NormalizeDouble(price - tpDist, _Digits);
      if(SendStopV2(false, price, lot, sl, tp,
                    "CHOP_S" + IntegerToString(i))) placed++;
     }

   for(int i = 0; i < buys; i++)
     {
      double price = NormalizeDouble(ask + gap * (i + 1), _Digits);
      double sl    = NormalizeDouble(price - slDist, _Digits);
      double tp    = NormalizeDouble(price + tpDist, _Digits);
      if(SendStopV2(true, price, lot, sl, tp,
                    "CHOP_B" + IntegerToString(i))) placed++;
     }

   if(placed > 0)
     {
      g_LastPlaceTime = TimeCurrent();
      //--- [A6] log CHOP order outcome with pending count
      PrintFormat("[VWAP CHOP] bias=%d buys=%d sells=%d lot=%.3f gap=%.0fpts "
                  "placed=%d pendingNow=%d",
                  bias, buys, sells, lot, gap / _Point,
                  placed, CountPendingTotal());
      return true;
     }
   return false;
  }

//===================================================================
// SECTION 89 — STRADDLE / CHOP HELPERS
//===================================================================
bool IsStraddleJerkContext()
  {
   if(Jerk_M15 != 0 && MSSFresh(Jerk_M15)) return true;
   if(Jerk_M5  != 0 && Jerk_M5 == M15Direction) return true;
   return false;
  }

bool IsStraddleExtremeContext()
  {
   if(!BridgeReady()) return false;
   if(!VNFlowTradeRateSurge()) return false;
   if(gFlow.persistence < 0.60) return false;
   if(MathAbs(FlowComposite()) < BinanceStrongFlowScore) return false;
   return true;
  }

void CleanupStraddleIfFilled()
  {
   if(!g_StraddleActive) return;
   int posCount = CountOurPositions();
   if(posCount > 0) return;
  }

//===================================================================
// SECTION 90 — REVERSAL 11-CHECK COUNTER
//===================================================================
bool Rev_Check_POCFail(int dir)
  {
   double price = MidPrice();
   if(price <= 0.0) return false;
   if(gBinAux.valid)
     {
      if(dir ==  1 && gBinAux.naked_below > 0.0 && price < gBinAux.naked_below) return true;
      if(dir == -1 && gBinAux.naked_above > 0.0 && price > gBinAux.naked_above) return true;
     }
   double h=-1e18, l=1e18;
   for(int i=1;i<=12;i++)
     {
      h = MathMax(h, TfHigh(PERIOD_M5, i));
      l = MathMin(l, TfLow (PERIOD_M5, i));
     }
   if(dir ==  1) return (price <= l + CurrentATR1 * 0.25);
   return (price >= h - CurrentATR1 * 0.25);
  }

bool Rev_Check_VWAPFail(int dir)
  {
   double vwap = GetVWAPValue();
   if(vwap <= 0.0) return false;
   double price = MidPrice();
   if(price <= 0.0 || CurrentATR1 <= 0.0) return false;
   if(dir ==  1) return (price < vwap - CurrentATR1 * 0.35);
   return (price > vwap + CurrentATR1 * 0.35);
  }

bool Rev_Check_CVDFlip(int dir)
  {
   if(MQLInfoInteger(MQL_TESTER)) return false;
   if(!FlowFresh()) return false;
   double fc = FlowComposite() * (double)dir;
   return (fc <= -BinanceStrongFlowScore);
  }

bool Rev_Check_StructureBreak(int dir)
  {
   if(CurrentATR1 <= 0.0) return false;
   if(dir ==  1) return M1BullMSS() || g_SMC.m1_event == 1;
   if(dir == -1) return M1BearMSS() || g_SMC.m1_event == -1;
   return false;
  }

bool Rev_Check_OrderbookFail(int dir)
  {
   if(!gBinAux.valid) return false;
   double price = MidPrice();
   if(price <= 0.0) return false;
   if(dir ==  1 && gBinAux.ask_wall_price > 0.0)
      return ((gBinAux.ask_wall_price - price) / _Point < 100.0);
   if(dir == -1 && gBinAux.bid_wall_price > 0.0)
      return ((price - gBinAux.bid_wall_price) / _Point < 100.0);
   return false;
  }

bool Rev_Check_PriceActionShift(int dir)
  {
   if(dir ==  1) return (M1BullSweep() || M1BullMSS() || M1BullFVG());
   if(dir == -1) return (M1BearSweep() || M1BearMSS() || M1BearFVG());
   return false;
  }

bool Rev_Check_SMCShift(int dir)
  {
   if(!UseSMCStructure) return false;
   return (dir ==  1) ? (g_SMC.m1_event == 1  || g_SMC.m5_event == 1)
                      : (g_SMC.m1_event == -1 || g_SMC.m5_event == -1);
  }

bool Rev_Check_EqualLiqSweep(int dir)
  {
   if(!UseEqualLiquidity) return false;
   return (dir ==  1 && g_SMC.bull_liq_sweep) || (dir == -1 && g_SMC.bear_liq_sweep);
  }

bool Rev_Check_LiqSessionSweep(int dir)
  {
   string source = "";
   int d = DetectLiquiditySweep(source);
   return (d == dir);
  }

bool Rev_Check_M1FVG(int dir)
  {
   return (dir ==  1 && M1BullFVG()) || (dir == -1 && M1BearFVG());
  }

bool Rev_Check_Displacement(int dir)
  {
   return (dir ==  1 && M1BullDisplacement()) || (dir == -1 && M1BearDisplacement());
  }

int Rev_CountConfirmations(int dir)
  {
   int n = 0;
   if(Rev_Check_POCFail(dir))           n++;
   if(Rev_Check_VWAPFail(dir))          n++;
   if(Rev_Check_CVDFlip(dir))           n++;
   if(Rev_Check_StructureBreak(dir))    n++;
   if(Rev_Check_OrderbookFail(dir))     n++;
   if(Rev_Check_PriceActionShift(dir))  n++;
   if(Rev_Check_SMCShift(dir))          n++;
   if(Rev_Check_EqualLiqSweep(dir))     n++;
   if(Rev_Check_LiqSessionSweep(dir))   n++;
   if(Rev_Check_M1FVG(dir))             n++;
   if(Rev_Check_Displacement(dir))      n++;
   return n;
  }

//===================================================================
// SECTION 91 — TIER 1 REVERSAL HARD GATES
//===================================================================
bool Rev_SessionSweepPresent(int dir)
  {
   if(!RevRequireSessionSweep) return true;
   string source = "";
   int d = DetectLiquiditySweep(source);
   if(d == dir && source != "") return true;
   if(dir ==  1 && g_SMC.bull_liq_sweep) return true;
   if(dir == -1 && g_SMC.bear_liq_sweep) return true;
   if(g_NVP.valid)
     {
      double price = MidPrice();
      if(dir ==  1 && price < g_NVP.val) return true;
      if(dir == -1 && price > g_NVP.vah) return true;
     }
   return false;
  }

bool Rev_CVDFlipHardGatePasses(int dir)
  {
   if(!RevRequireCVDFlipHardGate) return true;
   if(MQLInfoInteger(MQL_TESTER)) return true;
   if(!FlowFresh()) return true;
   double fc = FlowComposite() * (double)dir;
   if(fc <= -BinanceStrongFlowScore) return false;
   return true;
  }

bool Rev_FastTrendNotOpposed(int dir)
  {
   if(!RevBlockOnFastTrendOppose) return true;
   if(!UseFastTrendScore) return true;
   if(g_FastTrendScore >= FastTrend_PrimeThreshold)
     {
      if(g_FastTrendDir != 0 && g_FastTrendDir != dir) return false;
     }
   return true;
  }

bool Rev_HardGatesPass(int dir)
  {
   if(!Rev_SessionSweepPresent(dir))     { Print("[REV BLOCK] no session sweep");   return false; }
   if(!Rev_CVDFlipHardGatePasses(dir))   { Print("[REV BLOCK] CVD strongly opposes"); return false; }
   if(!Rev_FastTrendNotOpposed(dir))     { Print("[REV BLOCK] FastTrend opposes");   return false; }
   if(!RegimeGateAllows(dir, "REVERSAL"))
     { Print("[REV BLOCK] regime gate"); return false; }
   return true;
  }

//===================================================================
// SECTION 92 — REVERSAL CLOSE-ALL [A8: close confirmed, not just profitable]
//===================================================================
void ReversalCloseAllIfProfitable()
  {
   // V1 owns exits. Legacy reversal close-all is intelligence only.
   if(V1RiskLayerEnabled) return;
   int totalPos = CountOurPositions();
   if(totalPos <= 0)
     {
      DeleteOrdersPrefix("SWING_");
      DeleteOrdersPrefix("MONSTER_");
      DeleteOrdersPrefix("RANGE_");
      DeleteOrdersPrefix("CHOP_");
      return;
     }

   double totalPnL = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      totalPnL += posInfo.Profit() + posInfo.Swap() + V1_PositionCommissionAndFees(posInfo.Identifier());
     }

   //--- [A8] If profitable, close all. If losing and reversal is confirmed, still close all.
   // A confirmed reversal means the trend is going against us — holding losers is worse.
   bool hasStrongReversal = (g_RevConfirmCount >= 8);

   if(totalPnL < 0.0 && !hasStrongReversal)
     {
      PrintFormat("[REV CYCLE] floating %.2f < 0 and weak confirm — close-all skipped",
                  totalPnL);
      return;
     }

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      ClosePosition(posInfo.Ticket());
     }
   DeleteOrdersPrefix("SWING_");
   DeleteOrdersPrefix("MONSTER_");
   DeleteOrdersPrefix("RANGE_");
   DeleteOrdersPrefix("CHOP_");

   for(int i = 0; i < 4; i++)
     {
      g_EngineLossStreak[i] = 0;
      g_EngineWinStreak[i]  = 0;
     }
   g_GridLevelV2   = 0;
   g_StraddleActive = false;
   g_StraddleDir    = 0;

   PrintFormat("[REV CYCLE RESET] closed all, floating=%.2f confirm=%d",
               totalPnL, g_RevConfirmCount);
  }

//===================================================================
// SECTION 93 — REVERSAL EXECUTOR
//===================================================================
bool PlaceReversalSingle(int direction)
  {
   if(direction == 0) return false;
   if(!Health_AllowsNewEntries()) return false;
   if(!EngineBudgetOK("REVERSAL"))   return false;
   if(!EngineCooldownOK("REVERSAL")) return false;
   if(!MsgBudget_CanTrade()) return false;

   ReversalCloseAllIfProfitable();

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      int pdir = (posInfo.PositionType() == POSITION_TYPE_BUY) ? 1 : -1;
      if(pdir != direction)
        {
         // With V1 enabled, never close another position directly from
         // the reversal engine. Wait for the unified exit controller.
         if(V1RiskLayerEnabled) return false;
         ClosePosition(posInfo.Ticket());
        }
     }

   double atr5 = CurrentATR5;
   if(atr5 <= 0.0) atr5 = CurrentATR1;
   if(atr5 <= 0.0) return false;

   double slDist = ComputeSLDistance("REVERSAL");
   double tpDist = ComputeTPDistance("REVERSAL", slDist);

   double lots = CalcLots("REVERSAL", direction, slDist);
   if(lots <= 0.0)
     {
      double fallback = BaseLotForEngine("REVERSAL") * ContinuousGrowthMultiplier()
                        * SpreadThrottle();
      lots = ValidateLot(fallback);
     }
   if(lots <= 0.0) return false;

   if(!EntryAllowed("REVERSAL", lots, direction)) return false;

   double entry = (direction == 1) ? AskPrice() : BidPrice();
   if(entry <= 0.0) return false;
   double sl = (direction == 1) ? entry - slDist : entry + slDist;
   double tp = (direction == 1) ? entry + tpDist : entry - tpDist;

   string cmt = "REVERSAL_" + (direction == 1 ? "B" : "S");

   bool ok = SendMarketV2(
      (direction == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
      lots,
      NormalizeDouble(sl, _Digits),
      NormalizeDouble(tp, _Digits),
      cmt);

   if(ok)
     {
      g_LastPlaceTime = TimeCurrent();
      g_LastEntryDir  = direction;
      g_LastEntryTime = TimeCurrent();
      g_LastEngine    = ENG_REVERSAL;
      g_LastModelEngine = "REVERSAL";
      CancelOtherEnginePendingOrders("REVERSAL_");
      ReversalPartial = false;

      int ridx = EngineIndexFromName("REVERSAL");
      if(ridx >= 0)
         g_EngineCooldown[ridx] = TimeCurrent() + 30 * 60;

      PrintFormat("[REVERSAL] dir=%s lots=%.4f SL=%.0f TP=%.0f checks=%d",
                  DirStr(direction), lots, slDist / _Point, tpDist / _Point,
                  g_RevConfirmCount);
     }
   return ok;
  }

bool Rev_Tick()
  {
   int posCount = CountOurPositions();
   if(posCount > 0)
     {
      if(g_RevState != REV_IDLE)
        {
         g_RevState = REV_IDLE;
         g_RevDir   = 0;
         g_RevConfirmCount = 0;
        }
      return false;
     }

   if(!EngineBudgetOK("REVERSAL"))   return false;
   if(!EngineCooldownOK("REVERSAL")) return false;

   double range = TfHigh(PERIOD_M1, 1) - TfLow(PERIOD_M1, 1);
   bool wickPresent = (CurrentATR1 > 0.0 && range >= CurrentATR1 * 1.8);

   if(g_RevState == REV_IDLE)
     {
      if(wickPresent)
        {
         double o = TfOpen(PERIOD_M1, 1);
         double c = TfClose(PERIOD_M1, 1);
         g_RevDir = (c < o) ? 1 : -1;
         g_RevState = REV_WATCH;
         g_RevWatchSince = TimeCurrent();
         g_RevConfirmCount = 0;
         PrintFormat("[REV WATCH] candidate dir=%d range=%.0fpts",
                     g_RevDir, range / _Point);
        }
      return false;
     }

   if(g_RevState == REV_WATCH)
     {
      if(TimeCurrent() - g_RevWatchSince > Rev_WatchMaxMinutes * 60)
        {
         g_RevState = REV_IDLE;
         return false;
        }
      int n = Rev_CountConfirmations(g_RevDir);
      if(n >= 4)
        {
         g_RevState = REV_ALERT;
         g_RevConfirmCount = n;
         PrintFormat("[REV ALERT] dir=%d checks=%d", g_RevDir, n);
        }
      return false;
     }

   if(g_RevState == REV_ALERT)
     {
      int n = Rev_CountConfirmations(g_RevDir);
      g_RevConfirmCount = n;

      if(n >= 7)
        {
         if(!Rev_HardGatesPass(g_RevDir))
           {
            Print("[REV ABORT] hard gate");
            g_RevState = REV_IDLE;
            return false;
           }
         if(!M15VetoAllows(g_RevDir)) { Print("[REV ABORT] M15 veto"); g_RevState = REV_IDLE; return false; }
         if(!H1VetoAllows(g_RevDir))  { Print("[REV ABORT] H1 veto");  g_RevState = REV_IDLE; return false; }

         g_RevState = REV_CONFIRM;
         bool ok = PlaceReversalSingle(g_RevDir);
         g_RevState = REV_IDLE;
         return ok;
        }
      if(n < 4)
         g_RevState = REV_IDLE;
     }
   return false;
  }

//===================================================================
// SECTION 94 — CUSUM SHOCK [A3: bypass regime gate when fresh]
//===================================================================
bool CUSUMShockRun()
  {
   if(!UseCUSUM) return false;
   if(g_CUSUMDir == 0) return false;
   if(TimeCurrent() > g_CUSUMOverrideUntil) return false;

   // V2: a fresh shock must be able to supersede an older engine campaign.
   // Existing filled positions remain in the LegacyCampaign basket; competing pending
   // orders are canceled immediately by the activating Monster path.
   if(!V1LegacyCampaignEnabled && CountOurPositions() > 0) return false;
   if(!V1LegacyCampaignEnabled && CountPendingTotal() > 0) return false;
   if(!EngineCooldownOK("MONSTER")) return false;
   if(!EngineBudgetOK("MONSTER"))   return false;
   if(!MsgBudget_CanTrade()) return false;

   int dir = g_CUSUMDir;
   bool pa = (dir ==  1)
             ? (M1BullDisplacement() || M1BullMSS() || M1BullSweep())
             : (M1BearDisplacement() || M1BearMSS() || M1BearSweep());
   if(!pa) return false;
   if(!Flow_NotOpposed(dir)) return false;

   //--- [A3] Bypass regime gate if CUSUM is fresh (change-point is stronger signal)
   bool cusumFresh = (TimeCurrent() - g_CUSUMLastFire <= CUSUMFreshSeconds);
   if(!cusumFresh && !RegimeGateAllows(dir, "MONSTER"))
     {
      Print("[CUSUM BLOCK] regime gate");
      return false;
     }

   double slDist = ComputeSLDistance("MONSTER") * 0.80;
   slDist = MathMax(slDist, StopsLevelPrice() * 2.0);
   double tpDist = slDist * TP_RR_Monster;

   double lots = CalcLots("MONSTER", dir, slDist);
   if(lots <= 0.0) return false;
   if(!HardGatesPass("MONSTER", dir)) return false;

   // V2: free the pending-order path BEFORE the risk-entry cap is evaluated,
   // so a fresh Monster shock is never blocked by obsolete older-engine pendings.
   if(V1LegacyCampaignEnabled)
      LegacyCampaign_CancelCompetingPendings("MONSTER_");

   if(!EntryAllowed("MONSTER", lots, dir)) return false;

   if(UseBiasedStraddle && !IsStraddleExtremeContext())
     {
      if(PlaceBiasedStraddle("MONSTER", dir, true, false))
        {
         g_LastModelEngine = "MONSTER_SHOCK";
         g_LastEngine      = ENG_CUSUM;
         g_MonsterPhase    = MP_ACCELERATION;
         g_MonsterStart    = TimeCurrent();
         g_MonsterDir      = dir;
         g_MonsterPyramidCount = 0;
         g_MonsterPeakR    = 0.0;
         g_LastPyramidAt   = TimeCurrent();
         int mbi = EngineIndexFromName("MONSTER");
         if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
         CancelOtherEnginePendingOrders("MONSTER_");
         PrintFormat("[CUSUM SHOCK STRADDLE] dir=%s", DirStr(dir));
         return true;
        }
     }

   double entry = (dir == 1) ? AskPrice() : BidPrice();
   if(entry <= 0.0) return false;
   double stop = (dir == 1) ? entry - slDist : entry + slDist;
   double take = (dir == 1) ? entry + tpDist : entry - tpDist;

   string cmt = "MONSTER_SHOCK_" + (dir == 1 ? "B" : "S");
   bool ok = SendMarketV2(
      (dir == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
      lots,
      NormalizeDouble(stop, _Digits),
      NormalizeDouble(take, _Digits),
      cmt);

   if(ok)
     {
      g_MonsterPhase        = MP_ACCELERATION;
      g_MonsterStart        = TimeCurrent();
      g_MonsterDir          = dir;
      g_MonsterPyramidCount = 0;
      g_MonsterPeakR        = 0.0;
      g_LastPyramidAt       = TimeCurrent();
      g_LastPlaceTime       = TimeCurrent();
      g_LastEntryDir        = dir;
      g_LastEntryTime       = TimeCurrent();
      g_LastModelEngine     = "MONSTER_SHOCK";
      g_LastEngine          = ENG_CUSUM;
      int mbi = EngineIndexFromName("MONSTER");
      if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
      CancelOtherEnginePendingOrders("MONSTER_");
      PrintFormat("[CUSUM SHOCK] dir=%s lots=%.4f SL=%.0f TP=%.0f",
                  DirStr(dir), lots, slDist / _Point, tpDist / _Point);
     }
   return ok;
  }

//===================================================================
// SECTION 95 — KILLSHOT TRIGGER
//===================================================================
bool KillShotTrigger(int &outDir)
  {
   outDir = 0;
   if(!UseKillShot) return false;
   // V2: KillShot is a fast-path takeover, not a wait-for-flat signal.
   if(!V1LegacyCampaignEnabled && CountOurPositions() > 0) return false;
   if(!V1LegacyCampaignEnabled && CountPendingTotal()  > 0) return false;
   if(!EngineCooldownOK("MONSTER")) return false;
   if(!EngineBudgetOK("MONSTER"))   return false;

   int expDir = 0; double expStr = 0.0;
   if(!IsExplosiveBar(expDir, expStr)) return false;
   if(expStr < KillShotMinStrength)    return false;

   int c = 0;
   if(M5Direction  == expDir || M5Direction  == 0) c++;
   if(M15Direction == expDir || M15Direction == 0) c++;
   if(VNSMC_TrendBreak(expDir)) c++;

   double avgVol = 0.0; int vc = 0;
   for(int i = 3; i <= 22; i++)
     {
      long v = TfVolume(PERIOD_M1, i);
      if(v > 0) { avgVol += (double)v; vc++; }
     }
   if(vc > 0) avgVol /= (double)vc;
   long v1 = TfVolume(PERIOD_M1, 1);
   long v2 = TfVolume(PERIOD_M1, 2);
   if(avgVol > 0.0 && (double)v1 >= avgVol * 1.5 && (double)v2 >= avgVol * 1.5) c++;

   int sameDir = 0;
   for(int i = 2; i <= 4; i++)
     {
      double o = TfOpen(PERIOD_M1, i);
      double cc = TfClose(PERIOD_M1, i);
      if(o <= 0.0 || cc <= 0.0) continue;
      if(expDir ==  1 && cc > o) sameDir++;
      if(expDir == -1 && cc < o) sameDir++;
     }
   if(sameDir < 3) c++;

   double barRange = TfHigh(PERIOD_M1, 1) - TfLow(PERIOD_M1, 1);
   if(NormalATR1 > 0.0 && barRange >= NormalATR1 * 1.8) c++;

   int liveC = 0;
   if(BridgeReady())
     {
      if(CVDVelocityNormalized * expDir >= 0.20) liveC++;
      if(!WallInPath(expDir)) liveC++;
     }

   if(c < 5) return false;

   int s8 = GetSuper8();
   if(s8 != 0 && s8 != expDir) return false;

   if(!Flow_NotOpposed(expDir)) return false;
   if(!RegimeGateAllows(expDir, "MONSTER"))
     { Print("[KILLSHOT BLOCK] regime gate"); return false; }

   outDir = expDir;
   return true;
  }

bool KillShotFastPath()
  {
   int dir = 0;
   if(!KillShotTrigger(dir)) return false;
   if(!MsgBudget_CanTrade()) return false;

   double atr = CurrentATR5;
   if(atr <= 0.0) return false;

   double slDist = ComputeSLDistance("MONSTER") * KillShotSL_Shrink;
   slDist = MathMax(slDist, StopsLevelPrice() * 2.0);
   double tpDist = slDist * KillShotTP_RR;

   double sizeBoost = 1.0;
   if(UseKillShotPrimeBoost)
     {
      MqlDateTime dt;
      TimeToStruct(TimeGMT(), dt);
      if(dt.hour >= SessionPrimeStartUTC && dt.hour < SessionPrimeEndUTC)
         sizeBoost = KillShotPrimeSizeMult;
     }

   double lots = CalcLots("MONSTER", dir, slDist);
   if(lots <= 0.0) return false;
   lots = ValidateLot(lots * sizeBoost);
   if(lots <= 0.0) return false;

   if(!HardGatesPass("MONSTER", dir)) return false;

   // V2: free obsolete pending orders before the unified entry-cap check.
   if(V1LegacyCampaignEnabled)
      LegacyCampaign_CancelCompetingPendings("MONSTER_");

   if(!EntryAllowed("MONSTER", lots, dir)) return false;

   if(UseBiasedStraddle && IsStraddleExtremeContext())
     {
      if(PlaceBiasedStraddle("MONSTER", dir, false, true))
        {
         g_MonsterPhase = MP_ACCELERATION;
         g_MonsterStart = TimeCurrent();
         g_MonsterDir   = dir;
         g_MonsterPyramidCount = 0;
         g_MonsterPeakR = 0.0;
         g_LastPyramidAt = TimeCurrent();
         g_LastModelEngine = "MONSTER_KILLSHOT";
         g_LastEngine      = ENG_KILLSHOT;
         int mbi = EngineIndexFromName("MONSTER");
         if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
         CancelOtherEnginePendingOrders("MONSTER_");
         PrintFormat("[KILLSHOT STRADDLE] dir=%s", DirStr(dir));
         return true;
        }
     }

   double entry = (dir == 1) ? AskPrice() : BidPrice();
   if(entry <= 0.0) return false;
   double stop = (dir == 1) ? entry - slDist : entry + slDist;
   double take = (dir == 1) ? entry + tpDist : entry - tpDist;

   string cmt = "MONSTER_FAST_" + (dir == 1 ? "B" : "S");
   bool ok = SendMarketV2(
      (dir == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
      lots,
      NormalizeDouble(stop, _Digits),
      NormalizeDouble(take, _Digits),
      cmt);

   if(ok)
     {
      g_MonsterPhase        = MP_ACCELERATION;
      g_MonsterStart        = TimeCurrent();
      g_MonsterDir          = dir;
      g_MonsterPyramidCount = 0;
      g_MonsterPeakR        = 0.0;
      g_LastPyramidAt       = TimeCurrent();
      g_LastPlaceTime       = TimeCurrent();
      g_LastEntryDir        = dir;
      g_LastEntryTime       = TimeCurrent();
      g_LastModelEngine     = "MONSTER_KILLSHOT";
      g_LastEngine          = ENG_KILLSHOT;
      int mbi = EngineIndexFromName("MONSTER");
      if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
      CancelOtherEnginePendingOrders("MONSTER_");
      PrintFormat("[KILLSHOT] dir=%s lots=%.4f SL=%.0f TP=%.0f boost=%.2f",
                  DirStr(dir), lots, slDist / _Point, tpDist / _Point, sizeBoost);
     }
   return ok;
  }

//===================================================================
// SECTION 96 — MONSTER ENGINE
//===================================================================
bool Monster_IgnitionCheck(int &outDir)
  {
   outDir = 0;

   //--- [WHIPSAW GUARD] Block counter-trend Monster entries when M1 is
   //    moving sharply against the intended direction.
   double m1Trend3 = 0.0;
   for(int k = 1; k <= 3; k++)
      m1Trend3 += (TfClose(PERIOD_M1, k) - TfOpen(PERIOD_M1, k)) / _Point;
   bool sharpDown = (m1Trend3 < -400.0);
   bool sharpUp   = (m1Trend3 >  400.0);

   if(UseCUSUM && g_CUSUMDir != 0 &&
      TimeCurrent() <= g_CUSUMOverrideUntil &&
      VNShockEligible(g_CUSUMDir))
     {
      int d = g_CUSUMDir;
      double s = VNSMC_StructureScore(d, "MONSTER");
      double expStr = 0.0;
      int expDir = 0;
      bool explosive = IsExplosiveBar(expDir, expStr);
      if(s >= SMC_MinMonsterScore || (explosive && expDir == d))
        {
         if((d == 1 && sharpDown) || (d == -1 && sharpUp))
           {
            PrintFormat("[MONSTER BLOCK] sharp counter-move m1Trend3=%.0f", m1Trend3);
            return false;
           }
         outDir = d;
         g_LastModelEngine = "MONSTER_SHOCK";
         g_LastSignalConfidence = MathMax(g_LastSignalConfidence, 0.66);
         return true;
        }
     }

   int expDir = 0; double expStr = 0.0;
   bool explosive = IsExplosiveBar(expDir, expStr);
   double atrRatio = (NormalATR1 > 0.0) ? CurrentATR1 / NormalATR1 : 1.0;

   if((explosive || atrRatio >= 1.45) && expDir != 0)
     {
      bool pa = (expDir ==  1)
                ? (M1PA_BullDisp || M1PA_BullMSS || M1PA_BullSweep || M1PA_BullFVG)
                : (M1PA_BearDisp || M1PA_BearMSS || M1PA_BearSweep || M1PA_BearFVG);
      if(pa)
        {
         double smc = VNSMC_StructureScore(expDir, "MONSTER");
         bool catalyst = VNSMC_TrendBreak(expDir) ||
                         VNFlowCascade(expDir) || VNFlowTradeRateSurge() ||
                         VNFlowCVDAccelerationStrong(expDir) ||
                         smc >= SMC_MinMonsterScore || atrRatio >= 1.80;
           if(catalyst)
            {
              if(!LegacyFast_MonsterQualityPass(expDir))
               {
                PrintFormat("[MONSTER BLOCK] LegacyFast quality evidence insufficient dir=%d", expDir);
                return false;
               }
              if((expDir == 1 && sharpDown) || (expDir == -1 && sharpUp))
              {
               PrintFormat("[MONSTER BLOCK] sharp counter-move m1Trend3=%.0f", m1Trend3);
               return false;
              }
            outDir = expDir;
            g_LastSignalConfidence = MathMax(g_LastSignalConfidence,
                                             Clamp(0.50 + MathMin(0.35, expStr / 180.0), 0.50, 0.90));
            g_LastModelEngine = (atrRatio >= 1.80 ? "MONSTER_EXPANSION" : "MONSTER_KILLSHOT");
            return true;
           }
        }
     }

   int trendDir = 0;
   if(M15Direction != 0 && M5Direction == M15Direction) trendDir = M15Direction;
   else if(g_SMC.m15_bias != 0 && g_SMC.m5_bias == g_SMC.m15_bias) trendDir = g_SMC.m15_bias;
   else if(g_MTF_confidence >= 0.55 && g_LastModelDir != 0) trendDir = g_LastModelDir;
   if(trendDir == 0) return false;

   bool trigger = (trendDir ==  1)
                  ? (M1BullDisplacement() || M1BullMSS() || M1BullFVG() || g_SMC.m1_event ==  1)
                  : (M1BearDisplacement() || M1BearMSS() || M1BearFVG() || g_SMC.m1_event == -1);
   if(!trigger) return false;

   double smcScore = VNSMC_StructureScore(trendDir, "MONSTER");
   if(smcScore < SMC_MinMonsterScore && g_MTF_confidence < 0.55) return false;
   if(!Flow_NotOpposed(trendDir)) return false;
   if(!LegacyFast_MonsterQualityPass(trendDir)) return false;

      if((trendDir == 1 && sharpDown) || (trendDir == -1 && sharpUp))
     {
      PrintFormat("[MONSTER BLOCK] sharp counter-move m1Trend3=%.0f", m1Trend3);
      return false;
     }

   outDir = trendDir;
   g_LastModelEngine = "MONSTER_TREND";
   g_LastSignalConfidence = MathMax(g_LastSignalConfidence,
                                    Clamp(0.50 + 0.45 * smcScore, 0.50, 0.92));
   return true;
  }

void Monster_Ignite(int dir)
  {
   double atr = CurrentATR5;
   if(atr <= 0.0) return;

   double slDist = ComputeSLDistance("MONSTER");
   if(g_LastModelEngine == "MONSTER_SHOCK") slDist *= 0.80;
   slDist = MathMax(slDist, StopsLevelPrice() * 2.0);
   double tpDist = slDist * TP_RR_Monster;

   double lots = CalcLots("MONSTER", dir, slDist);
   if(lots <= 0.0) return;
   if(!EntryAllowed("MONSTER", lots, dir)) return;

   if(UseBiasedStraddle)
     {
      bool jerk    = IsStraddleJerkContext();
      bool extreme = IsStraddleExtremeContext();
      if(PlaceBiasedStraddle("MONSTER", dir, jerk, extreme))
        {
         g_MonsterPhase        = MP_ACCELERATION;
         g_MonsterStart        = TimeCurrent();
         g_MonsterDir          = dir;
         g_MonsterPyramidCount = 0;
         g_MonsterPeakR        = 0.0;
         g_LastPyramidAt       = TimeCurrent();
         g_LastPlaceTime       = TimeCurrent();
         g_LastEntryDir        = dir;
         g_LastEntryTime       = TimeCurrent();
         g_LastEngine          = ENG_MONSTER;
         int mbi = EngineIndexFromName("MONSTER");
         if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
         CancelOtherEnginePendingOrders("MONSTER_");
         PrintFormat("[MONSTER IGN STRADDLE] %s dir=%s",
                     g_LastModelEngine, DirStr(dir));
         return;
        }
     }

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return;
   double entry = (dir == 1) ? ask : bid;
   double stop  = (dir == 1) ? entry - slDist : entry + slDist;
   double take  = (dir == 1) ? entry + tpDist : entry - tpDist;

   string mode = (g_LastModelEngine == "" ? "MONSTER" : g_LastModelEngine);
   string cmt = "MONSTER_IGN_" + (dir == 1 ? "B" : "S");

   bool ok = SendMarketV2(
      (dir == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
      lots,
      NormalizeDouble(stop, _Digits),
      NormalizeDouble(take, _Digits),
      cmt);

   if(ok)
     {
      g_MonsterPhase        = MP_ACCELERATION;
      g_MonsterStart        = TimeCurrent();
      g_MonsterDir          = dir;
      g_MonsterPyramidCount = 0;
      g_MonsterPeakR        = 0.0;
      g_LastPyramidAt       = TimeCurrent();
      g_LastPlaceTime       = TimeCurrent();
      g_LastEntryDir        = dir;
      g_LastEntryTime       = TimeCurrent();
      g_LastEngine          = ENG_MONSTER;
      int mbi = EngineIndexFromName("MONSTER");
      if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
      CancelOtherEnginePendingOrders("MONSTER_");
      PrintFormat("[MONSTER IGN] %s dir=%s lots=%.4f SL=%.0f TP=%.0f",
                  mode, DirStr(dir), lots, slDist / _Point, tpDist / _Point);
     }
  }

bool Monster_Pyramid()
  {
   if(g_MonsterDir == 0) return false;
   if(g_MonsterPyramidCount >= Monster_MaxPyramid) return false;
   if(g_LastSignalConfidence < 0.55) return false;
   if(!MsgBudget_CanTrade()) return false;

   double atr = CurrentATR5;
   if(atr <= 0.0) return false;
   double slDist = ComputeSLDistance("MONSTER");
   double tpDist = slDist * TP_RR_Monster;

   double lots = ValidateLot(CalcLots("MONSTER", g_MonsterDir, slDist) * 0.65);
   if(lots <= 0.0) return false;
   if(TotalOurLots() + lots > CapTotalLots() + 1e-12) return false;

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return false;
   double entry = (g_MonsterDir == 1) ? ask : bid;
   double stop  = (g_MonsterDir == 1) ? entry - slDist : entry + slDist;
   double take  = (g_MonsterDir == 1) ? entry + tpDist : entry - tpDist;

   string cmt = "MONSTER_PYR" + IntegerToString(g_MonsterPyramidCount + 1);
   bool ok = SendMarketV2(
      (g_MonsterDir == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
      lots,
      NormalizeDouble(stop, _Digits),
      NormalizeDouble(take, _Digits),
      cmt);

   if(ok)
     {
      g_LastPlaceTime = TimeCurrent();
      PrintFormat("[MONSTER PYR] level=%d dir=%d lots=%.4f",
                  g_MonsterPyramidCount + 1, g_MonsterDir, lots);
     }
   return ok;
  }

void Monster_HarvestStart()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), "MONSTER_") < 0) continue;
      double vol = posInfo.Volume();
      double cv = NormalizeLots(vol * (double)Monster_HarvestClosePct / 100.0);
      if(cv <= 0.0 || cv >= vol || cv < g_LotMin) continue;
      MsgBudget_Count(1); // shared account-wide outbound request
      if(trade.PositionClosePartial(posInfo.Ticket(), cv))
         MsgBudget_TickModify();
     }
   PrintFormat("[MONSTER HARVEST] partial %d%% peak=%.2fR",
               Monster_HarvestClosePct, g_MonsterPeakR);
  }

void Monster_Manage()
  {
   if(g_MonsterPhase == MP_IDLE) return;
   int posCount = CountEnginePositions("MONSTER_");
   int ordCount = CountEngineOrders("MONSTER_");
   if(posCount == 0 && ordCount == 0)
     {
      PrintFormat("[MONSTER] cycle end phase=%d peak=%.2fR",
                  (int)g_MonsterPhase, g_MonsterPeakR);
      g_MonsterPhase = MP_IDLE;
      g_MonsterDir = 0;
      g_MonsterPyramidCount = 0;
      g_MonsterPeakR = 0.0;
      g_LastModelEngine = "";
      return;
     }

   int mbi = EngineIndexFromName("MONSTER");
   double basketRisk = (mbi >= 0) ? BasketInitialRiskUSD[mbi] : 0.0;
   double pnl = PrefixFloatingPnL("MONSTER_");
   double monsterR = (basketRisk > 0.0) ? pnl / basketRisk : 0.0;
   if(monsterR > g_MonsterPeakR) g_MonsterPeakR = monsterR;

   if(!V1RiskLayerEnabled &&
      g_MonsterDir != 0 && VNSMC_TrendBreak(-g_MonsterDir) &&
      g_R7 != R7_EXPANSION && !VNFlowTradeRateSurge() && monsterR > 0.0)
     {
      PrintFormat("[MONSTER THESIS EXIT] R=%.2f", monsterR);
      CloseEnginePositions("MONSTER_");
      g_MonsterPhase = MP_IDLE;
      return;
     }

   if(g_MonsterPhase == MP_ACCELERATION)
     {
      if(g_MonsterPyramidCount < Monster_MaxPyramid &&
         TimeCurrent() - g_LastPyramidAt >= Monster_PyramidCooldownS &&
         monsterR >= Monster_PyramidMinR)
        {
         bool momentum = (g_R7 == R7_EXPANSION ||
                          g_R7 == (g_MonsterDir == 1 ? R7_STRONG_UP : R7_STRONG_DOWN) ||
                          VNFlowCVDAccelerationStrong(g_MonsterDir) ||
                          VNFlowTradeRateSurge());
         if(momentum && Monster_Pyramid())
           {
            g_MonsterPyramidCount++;
            g_LastPyramidAt = TimeCurrent();
           }
        }

      if(monsterR >= Monster_HarvestMinR)
        {
         g_MonsterPhase = MP_HARVEST;
         if(!V1RiskLayerEnabled) Monster_HarvestStart();
        }
     }

   if(!V1RiskLayerEnabled && g_MonsterPhase == MP_HARVEST)
     {
      double giveback = g_MonsterPeakR - monsterR;
      if(monsterR > 0.0 && giveback >= Monster_TrailGivebackR)
        {
         PrintFormat("[MONSTER TRAIL] peak=%.2fR now=%.2fR", g_MonsterPeakR, monsterR);
         CloseEnginePositions("MONSTER_");
         g_MonsterPhase = MP_IDLE;
        }
     }
  }

bool Monster_Run()
  {
   if(!Regime_AllowsEngine("MONSTER") &&
      !(g_R7 == R7_WEAK_UP || g_R7 == R7_WEAK_DOWN))
     {
      int probeDir = (g_LegacyFastPathDir != 0 ? g_LegacyFastPathDir : CurrentDirection);
      if(probeDir == 0)
        {
         int pd = 0;
         double pe = 0.0, pn = 0.0, pp = 0.0, pnp = 0.0, ptp = 0.0;
         LegacyFast_M1Path(pd, pe, pn, pp, pnp, ptp);
         probeDir = pd;
        }
      if(!LegacyFast_ExpansionOverrideForDir(probeDir)) return false;
     }
   if(!EngineBudgetOK("MONSTER"))   return false;
   if(!EngineCooldownOK("MONSTER")) return false;

   if(g_MonsterPhase == MP_IDLE &&
      CountEnginePositions("MONSTER_") == 0 &&
      CountEngineOrders("MONSTER_") == 0)
     {
      int dir = 0;
      if(Monster_IgnitionCheck(dir))
        {
         if(!RegimeGateAllows(dir, "MONSTER"))
           {
            Print("[MONSTER BLOCK] regime gate");
            return false;
           }

         double est = ComputeSLDistance("MONSTER");
         double estLots = CalcLots("MONSTER", dir, est);
         if(estLots > 0.0 && HardGatesPass("MONSTER", dir) &&
            EntryAllowed("MONSTER", estLots, dir))
           {
            Monster_Ignite(dir);
            Monster_Manage();
            return CountEnginePositions("MONSTER_") > 0 ||
                   CountEngineOrders("MONSTER_") > 0;
           }
        }
     }
   Monster_Manage();
   return false;
  }

//===================================================================
// SECTION 97 — SWING ENGINE
//===================================================================
bool Swing_ComputeStructureTarget(int dir, double &outTP)
  {
   outTP = 0.0;
   double price = MidPrice();
   if(price <= 0.0) return false;
   double best = 0.0;

   if(BridgeReady() && gBinAux.naked_above > 0.0 && gBinAux.naked_below > 0.0)
     {
      if(dir ==  1 && gBinAux.naked_above > price) best = gBinAux.naked_above;
      if(dir == -1 && gBinAux.naked_below > 0.0 && gBinAux.naked_below < price)
         best = gBinAux.naked_below;
     }

   if(best == 0.0)
     {
      if(dir == 1)
        {
         for(int i = 0; i < BearOBCount; i++)
           {
            if(BearOBs[i].mitigated) continue;
            if(BearOBs[i].low > price)
               if(best == 0.0 || BearOBs[i].low < best) best = BearOBs[i].low;
           }
        }
      else
        {
         for(int i = 0; i < BullOBCount; i++)
           {
            if(BullOBs[i].mitigated) continue;
            if(BullOBs[i].high < price)
               if(best == 0.0 || BullOBs[i].high > best) best = BullOBs[i].high;
           }
        }
     }

   if(best == 0.0) return false;
   outTP = MathAbs(best - price);
   return (outTP > CurrentATR5 * 0.5);
  }
     
   bool Swing_Run()
  {
   if(g_R7 == R7_CHOP || g_R7 == R7_COMPRESSION) return false;
   if(!Regime_AllowsEngine("SWING")) return false;
   if(!EngineBudgetOK("SWING"))      return false;
   if(!EngineCooldownOK("SWING"))    return false;
   if(CountEnginePositions("SWING_") > 0) return false;
   if(CountEngineOrders("SWING_") > 0)    return false;

   int dir = 0;
   if(M15Direction != 0 && M5Direction == M15Direction) dir = M15Direction;
   else if(g_SMC.m15_bias != 0 && g_SMC.m5_bias == g_SMC.m15_bias) dir = g_SMC.m15_bias;
   else if(Jerk_M5 != 0 && Jerk_M5 == M15Direction) dir = Jerk_M5;
   if(dir == 0) return false;

   //--- [WHIPSAW GUARD] Block counter-trend entries in weak conditions
   double m1Trend = 0.0;
   for(int k = 1; k <= 5; k++)
      m1Trend += (TfClose(PERIOD_M1, k) - TfOpen(PERIOD_M1, k)) / _Point;
   bool priceFalling = (m1Trend < -200.0);
   bool priceRising  = (m1Trend >  200.0);
   bool fastTrendWeak = (!UseFastTrendScore || g_FastTrendScore < 25.0);

   if(dir ==  1 && priceFalling && fastTrendWeak)
     {
      Print("[SWING BLOCK] counter-trend buy in falling market");
      return false;
     }
   if(dir == -1 && priceRising && fastTrendWeak)
     {
      Print("[SWING BLOCK] counter-trend sell in rising market");
      return false;
     }

   if(!RegimeGateAllows(dir, "SWING"))
     {
      Print("[SWING BLOCK] regime gate");
      return false;
     }

   bool disp = (dir ==  1) ? M1BullDisplacement() : M1BearDisplacement();
   bool mss  = (dir ==  1) ? M1BullMSS()          : M1BearMSS();
   bool fvg  = (dir ==  1) ? M1BullFVG()          : M1BearFVG();
   bool structural = VNSMC_TrendBreak(dir) ||
                     (VNSMC_StructureScore(dir, "SWING") >= SMC_MinSwingScore);
   if(!disp && !mss && !fvg && !structural) return false;

   if(!HardGatesPass("SWING", dir)) return false;
   if(!M15VetoAllows(dir)) return false;
   if(!H1VetoAllows(dir))  return false;
   if(!Flow_Agrees(dir, false)) return false;

   double atr = CurrentATR5;
   if(atr <= 0.0) return false;
   double slDist = ComputeSLDistance("SWING");
   double tpDist = 0.0;
   bool structTarget = Swing_ComputeStructureTarget(dir, tpDist);
   if(!structTarget) tpDist = ComputeTPDistance("SWING", slDist);
   if(tpDist < slDist * 1.5) tpDist = slDist * 1.5;

   double lots = CalcLots("SWING", dir, slDist);
   if(lots <= 0.0) return false;
   if(!EntryAllowed("SWING", lots, dir)) return false;
 

   if(UseBiasedStraddle)
     {
      bool jerk    = IsStraddleJerkContext();
      bool extreme = IsStraddleExtremeContext();
      if(PlaceBiasedStraddle("SWING", dir, jerk, extreme))
        {
         g_LastEngine = ENG_TREND;
         CancelOtherEnginePendingOrders("SWING_");
         return true;
        }
     }

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return false;

   double breakDist = atr * 0.15;
   double entry, stop, take;
   if(dir == 1)
     {
      // Buy the dip (Limit below current price)
      entry = NormalizeDouble(bid - breakDist, _Digits);
      stop  = NormalizeDouble(entry - slDist, _Digits);
      take  = NormalizeDouble(entry + tpDist, _Digits);
     }
   else
     {
      // Sell the rally (Limit above current price)
      entry = NormalizeDouble(ask + breakDist, _Digits);
      stop  = NormalizeDouble(entry + slDist, _Digits);
      take  = NormalizeDouble(entry - tpDist, _Digits);
     }

   string cmt = "SWING_" + (dir == 1 ? "B" : "S");
   bool ok = (dir == 1)
             ? SendLimitV2(true, entry, lots, stop, take, cmt)
             : SendLimitV2(false, entry, lots, stop, take, cmt);

   if(ok)
     {
      g_LastPlaceTime = TimeCurrent();
      g_LastEntryDir  = dir;
      g_LastEntryTime = TimeCurrent();
      g_LastEngine    = ENG_TREND;
      CancelOtherEnginePendingOrders("SWING_");
      PrintFormat("[SWING] %s lots=%.4f SL=%.0f TP=%.0f struct=%s",
                  DirStr(dir), lots, slDist / _Point, tpDist / _Point,
                  (structTarget ? "yes" : "fallback"));
     }
   return ok;
  }

//===================================================================
// SECTION 98 — RANGE ENGINE
//===================================================================
bool VNRangeExpansionInvalidated()
  {
   if(!ORangeAbortOnExpansion) return false;
   if(g_R7 == R7_EXPANSION || g_R7 == R7_COMPRESSION) return true;
   if(g_CUSUMDir != 0 && TimeCurrent() <= g_CUSUMOverrideUntil) return true;
   if(VNFlowTradeRateSurge()) return true;
   if(MathAbs(CVDAccelerationNormalized) >= 0.25 * 1.25) return true;
   return false;
  }

void VNCancelRangeOnBreak()
  {
   if(VNRangeExpansionInvalidated())
     {
      if(CountEngineOrders("RANGE_") > 0)
        {
         DeleteOrdersPrefix("RANGE_");
         Print("[RANGE -> MONSTER] mean-reversion invalidated; pending orders cancelled");
        }
     }
  }

bool Range_Run()
  {
   VNCancelRangeOnBreak();

   if(g_R7 != R7_CHOP && g_R7 != R7_WEAK_UP && g_R7 != R7_WEAK_DOWN)
      return false;
   if(!EngineBudgetOK("RANGE"))   return false;
   if(!EngineCooldownOK("RANGE")) return false;
   if(CountEnginePositions("RANGE_") > 0) return false;
   if(CountEngineOrders("RANGE_") > 0)    return false;
   if(CountOurPositions() > 0) return false;

   if(g_LastRangePlace > 0 &&
      TimeCurrent() - g_LastRangePlace < Range_PendingLifetimeMin * 60) return false;

   double rHigh = -1e18, rLow = 1e18;
   for(int i = 1; i <= Range_WindowBars; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      if(h > rHigh) rHigh = h;
      if(l < rLow)  rLow  = l;
     }
   if(rHigh <= 0.0 || rLow <= 0.0 || rHigh <= rLow) return false;

   double atr = CurrentATR1;
   if(atr <= 0.0) return false;
   double width = rHigh - rLow;
   if(width < atr * Range_MinWidthATR) return false;
   if(width > atr * Range_MaxWidthATR) return false;

   if(!VNComputeOU()) return false;
   double z = g_OU.z;
   int dir = 0;
   if(z <= -OUMinAbsZ) dir = 1;
   else if(z >= OUMinAbsZ) dir = -1;
   else return false;

   if(!VNOUAllowsRange(dir)) return false;

   if(UseSMCStructure)
     {
      double oppScore = VNSMC_StructureScore(-dir, "RANGE");
      if(oppScore >= 0.72 && VNSMC_TrendBreak(-dir)) return false;
     }

   bool revTrigger = (dir ==  1)
                     ? (M1BullMSS() || M1BullSweep() || M1BullFVG())
                     : (M1BearMSS() || M1BearSweep() || M1BearFVG());
   if(!revTrigger) return false;

   if(g_MTF_confidence > MTFMaxRangeTrendConf) return false;
   if(g_OU.reversion_prob < OURangeMinProbability) return false;

   double slDist = MathMax(width * 0.90, MathMax(atr * 1.10, StopsLevelPrice() * 2.0));
   if(dir ==  1) slDist = MathMax(slDist, MidPrice() - rLow  + atr * 0.10);
   else          slDist = MathMax(slDist, rHigh - MidPrice() + atr * 0.10);

   double price = (dir == 1) ? AskPrice() : BidPrice();
   if(price <= 0.0) return false;

   double tpDist = MathAbs(g_OU.mu - price) * ORangeTargetFraction;
   double minTp = MathMax(StopsLevelPrice() * 2.0, atr * 0.60);
   if(tpDist < minTp) tpDist = minTp;

   if(!HardGatesPass("RANGE", dir)) return false;
   if(!M15VetoAllows(dir)) return false;
   if(!H1VetoAllows(dir))  return false;

   double lots = CalcLots("RANGE", dir, slDist);
   if(lots <= 0.0) return false;
   if(!EntryAllowed("RANGE", lots, dir)) return false;

      // V1.61: paired entry routes are removed. Genesis owns independent range routing.
   if(UseGenesisIntelligence && GenesisIntelBlockLegacy) return false;

   double stop = (dir == 1) ? price - slDist : price + slDist;
   double take = (dir == 1) ? price + tpDist : price - tpDist;

   string cmt = "RANGE_" + (dir == 1 ? "B" : "S");
   bool ok = SendMarketV2((dir == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
                          lots,
                          NormalizeDouble(stop, _Digits),
                          NormalizeDouble(take, _Digits),
                          cmt);

   if(ok)
     {
      g_LastRangePlace = TimeCurrent();
      g_LastPlaceTime  = TimeCurrent();
      g_LastEntryDir   = dir;
      g_LastEntryTime  = TimeCurrent();
      g_LastEngine     = ENG_RANGE;
      PrintFormat("[RANGE OU] %s lots=%.4f z=%.2f theta=%.4f prob=%.2f",
                  DirStr(dir), lots, z, g_OU.theta, g_OU.reversion_prob);
     }
   return ok;
  }

//===================================================================
// SECTION 99 — FACTOR B — HELPERS
//===================================================================
void FB_BuildVolumeProfile()
  {
   g_FB_VP.valid = false;
   int bins = MathMin(VP_Bins, 40);
   if(Bars(_Symbol, PERIOD_M1) < VP_LookbackBars + 10) return;

   double high = -1e18, low = 1e18;
   for(int i=0; i<VP_LookbackBars; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      if(h<=0 || l<=0) continue;
      if(h>high) high = h;
      if(l<low)  low  = l;
     }
   if(high<=low) return;

   g_FB_VP.minP = low;
   g_FB_VP.maxP = high;
   g_FB_VP.binSize = (high-low)/bins;
   for(int i=0; i<bins; i++) g_FB_VP.bins[i] = 0;
   g_FB_VP.totalVol = 0;

   for(int i=0; i<VP_LookbackBars; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      double v = (double)TfVolume(PERIOD_M1, i);
      if(h<=l || v<=0) continue;
      double barRange = h-l;
      for(int b=0; b<bins; b++)
        {
         double binLo = g_FB_VP.minP + b*g_FB_VP.binSize;
         double binHi = binLo + g_FB_VP.binSize;
         double ovl = MathMin(h,binHi) - MathMax(l,binLo);
         if(ovl > 0) g_FB_VP.bins[b] += v * (ovl/barRange);
        }
     }

   double maxVol = 0; int pocIdx = 0;
   for(int i=0; i<bins; i++)
     {
      g_FB_VP.totalVol += g_FB_VP.bins[i];
      if(g_FB_VP.bins[i] > maxVol){ maxVol = g_FB_VP.bins[i]; pocIdx = i; }
     }
   if(g_FB_VP.totalVol <= 0) return;
   g_FB_VP.poc = g_FB_VP.minP + (pocIdx+0.5)*g_FB_VP.binSize;

   double target = g_FB_VP.totalVol * VP_ValueAreaPct / 100.0;
   int left = pocIdx, right = pocIdx;
   double cum = g_FB_VP.bins[pocIdx];
   while(cum < target && (left>0 || right<bins-1))
     {
      double lv = (left>0)       ? g_FB_VP.bins[left-1]  : -1;
      double rv = (right<bins-1) ? g_FB_VP.bins[right+1] : -1;
      if(rv >= lv && right<bins-1){ right++; cum += g_FB_VP.bins[right]; }
      else if(left>0)             { left--;  cum += g_FB_VP.bins[left]; }
      else break;
     }
   g_FB_VP.val = g_FB_VP.minP + left*g_FB_VP.binSize;
   g_FB_VP.vah = g_FB_VP.minP + (right+1)*g_FB_VP.binSize;
   if(g_FB_VP.poc > 0) g_FB_VP.vaWidthPct = (g_FB_VP.vah - g_FB_VP.val) / g_FB_VP.poc * 100.0;
   else g_FB_VP.vaWidthPct = 100.0;
   g_FB_VP.valid = true;
  }

bool FB_PriceInVA()
  {
   if(!g_FB_VP.valid) return false;
   double m = MidPrice();
   return (m >= g_FB_VP.val && m <= g_FB_VP.vah);
  }

bool FB_VACompressed()
  {
   if(!g_FB_VP.valid) return false;
   return (g_FB_VP.vaWidthPct < VP_CompressMaxPct);
  }

void FB_UpdateVROC()
  {
   double avgVol = 0; int c = 0;
   for(int i=2; i<22; i++)
     {
      double v = (double)TfVolume(PERIOD_M1, i);
      if(v>0){ avgVol += v; c++; }
     }
   if(c>0) avgVol /= c;
   double curVol = (double)TfVolume(PERIOD_M1, 0) + (double)TfVolume(PERIOD_M1, 1);
   g_FB_VROC = (avgVol > 0) ? curVol / (avgVol * 2.0) : 0;

   double rng = TfHigh(PERIOD_M1, 0) - TfLow(PERIOD_M1, 0);
   double atr = CurrentATR1;
   g_FB_RangeExp = (atr > 0) ? rng/atr : 0;
  }

void FB_UpdateSessionVWAP()
  {
   MqlDateTime dt; TimeToStruct(TimeCurrent(), dt);
   int mins = dt.hour*60 + dt.min;
   if(mins < 5) return;
   int lookback = MathMin(mins, 1440);
   double pv=0, vol=0;
   for(int i=0; i<lookback; i++)
     {
      double h=TfHigh(PERIOD_M1,i), l=TfLow(PERIOD_M1,i), cl=TfClose(PERIOD_M1,i);
      double v=(double)TfVolume(PERIOD_M1,i);
      if(h<=0||l<=0||cl<=0||v<=0) continue;
      pv += ((h+l+cl)/3.0) * v;
      vol += v;
     }
   if(vol<=0) return;
   double vwap = pv/vol;

   double pv10=0, vol10=0;
   for(int i=10; i<lookback+10 && i<1440; i++)
     {
      double h=TfHigh(PERIOD_M1,i), l=TfLow(PERIOD_M1,i), cl=TfClose(PERIOD_M1,i);
      double v=(double)TfVolume(PERIOD_M1,i);
      if(h<=0||l<=0||cl<=0||v<=0) continue;
      pv10 += ((h+l+cl)/3.0) * v;
      vol10 += v;
     }
   double vwapOld = (vol10>0) ? pv10/vol10 : vwap;
   g_FB_VWAP = vwap;
   g_FB_VWAPSlope = (vwap - vwapOld) / (10.0 * _Point);
  }

int FB_DetectMSS_Event()
  {
   int bars = Bars(_Symbol, PERIOD_M15);
   if(bars < FB_MSS_LeftBars + FB_MSS_RightBars + 5) return 0;

   int searchDepth = MathMin(100, bars - FB_MSS_LeftBars - FB_MSS_RightBars - 1);
   double pivH=0, pivL=0;
   datetime pivHt=0, pivLt=0;

   for(int i = FB_MSS_RightBars; i < searchDepth; i++)
     {
      double h = TfHigh(PERIOD_M15, i);
      if(h > 0 && pivH == 0)
        {
         bool ok = true;
         for(int j=1; j<=FB_MSS_LeftBars; j++)
            if(TfHigh(PERIOD_M15,i+j) >= h){ ok=false; break; }
         if(ok) for(int j=1; j<=FB_MSS_RightBars; j++)
            if(TfHigh(PERIOD_M15,i-j) >= h){ ok=false; break; }
         if(ok){ pivH = h; pivHt = TfTime(PERIOD_M15,i); }
        }
      double l = TfLow(PERIOD_M15, i);
      if(l > 0 && pivL == 0)
        {
         bool ok = true;
         for(int j=1; j<=FB_MSS_LeftBars; j++)
            if(TfLow(PERIOD_M15,i+j) <= l){ ok=false; break; }
         if(ok) for(int j=1; j<=FB_MSS_RightBars; j++)
            if(TfLow(PERIOD_M15,i-j) <= l){ ok=false; break; }
         if(ok){ pivL = l; pivLt = TfTime(PERIOD_M15,i); }
        }
      if(pivH > 0 && pivL > 0) break;
     }

   if(pivH > 0 && pivHt > g_FB_MSS_LastHighTime) { g_FB_MSS_LastHigh = pivH; g_FB_MSS_LastHighTime = pivHt; }
   if(pivL > 0 && pivLt > g_FB_MSS_LastLowTime)  { g_FB_MSS_LastLow  = pivL; g_FB_MSS_LastLowTime  = pivLt; }

   double close = TfClose(PERIOD_M15, 1);
   if(close <= 0) return 0;

   int dir = 0;
   if(g_FB_MSS_LastHigh>0 && close>g_FB_MSS_LastHigh && g_FB_MSS_LastDir!=1)  dir = 1;
   else if(g_FB_MSS_LastLow>0 && close<g_FB_MSS_LastLow && g_FB_MSS_LastDir!=-1) dir = -1;

   if(dir != 0)
     {
      g_FB_MSS_LastDir = dir;
      g_FB_MSS_LastEventDir = dir;
      g_FB_MSS_LastEventTime = TimeCurrent();
     }
   return dir;
  }

bool FB_MSSFresh(int dir)
  {
   if(g_FB_MSS_LastEventDir != dir || g_FB_MSS_LastEventTime == 0) return false;
   return (TimeCurrent() - g_FB_MSS_LastEventTime <= FB_MSS_ConfirmWindowMin*60);
  }

void FB_StoreBullOB(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FB_OB_MaxStored, 8);
   if(g_FB_BullOBCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) g_FB_BullOB[i]=g_FB_BullOB[i-1]; g_FB_BullOBCount=maxKeep-1; }
   else
     { for(int i=g_FB_BullOBCount;i>0;i--) g_FB_BullOB[i]=g_FB_BullOB[i-1]; }
   g_FB_BullOB[0].high=high; g_FB_BullOB[0].low=low;
   g_FB_BullOB[0].avg=(high+low)/2.0;
   g_FB_BullOB[0].dir=1; g_FB_BullOB[0].t=t; g_FB_BullOB[0].mitigated=false;
   g_FB_BullOBCount++;
  }

void FB_StoreBearOB(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FB_OB_MaxStored, 8);
   if(g_FB_BearOBCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) g_FB_BearOB[i]=g_FB_BearOB[i-1]; g_FB_BearOBCount=maxKeep-1; }
   else
     { for(int i=g_FB_BearOBCount;i>0;i--) g_FB_BearOB[i]=g_FB_BearOB[i-1]; }
   g_FB_BearOB[0].high=high; g_FB_BearOB[0].low=low;
   g_FB_BearOB[0].avg=(high+low)/2.0;
   g_FB_BearOB[0].dir=-1; g_FB_BearOB[0].t=t; g_FB_BearOB[0].mitigated=false;
   g_FB_BearOBCount++;
  }

void FB_ScanOB()
  {
   if(Bars(_Symbol, PERIOD_M15) < 20) return;
   int shift = 1;
   double obO = TfOpen(PERIOD_M15,shift);
   double obC = TfClose(PERIOD_M15,shift);
   double obH = TfHigh(PERIOD_M15,shift);
   double obL = TfLow(PERIOD_M15,shift);
   datetime obT = TfTime(PERIOD_M15,shift);
   if(obO<=0||obC<=0||obH<=0||obL<=0||obT==0) return;

   int up=0, dn=0;
   for(int i=2; i<=6; i++)
     {
      double o=TfOpen(PERIOD_M15,i), c=TfClose(PERIOD_M15,i);
      if(c>o) up++; else if(c<o) dn++;
     }
   if(obC<obO && up==5)
     {
      bool exists=false;
      for(int i=0;i<g_FB_BullOBCount;i++) if(g_FB_BullOB[i].t==obT){ exists=true; break; }
      if(!exists) FB_StoreBullOB(obO, obL, obT);
     }
   if(obC>obO && dn==5)
     {
      bool exists=false;
      for(int i=0;i<g_FB_BearOBCount;i++) if(g_FB_BearOB[i].t==obT){ exists=true; break; }
      if(!exists) FB_StoreBearOB(obH, obO, obT);
     }

   double current = TfClose(PERIOD_M15, 0);
   for(int i=0;i<g_FB_BullOBCount;i++)
      if(!g_FB_BullOB[i].mitigated && current<g_FB_BullOB[i].low) g_FB_BullOB[i].mitigated=true;
   for(int i=0;i<g_FB_BearOBCount;i++)
      if(!g_FB_BearOB[i].mitigated && current>g_FB_BearOB[i].high) g_FB_BearOB[i].mitigated=true;
  }

void FB_StoreBullFVG(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FB_FVG_MaxStored, 8);
   if(g_FB_BullFVGCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) g_FB_BullFVG[i]=g_FB_BullFVG[i-1]; g_FB_BullFVGCount=maxKeep-1; }
   else
     { for(int i=g_FB_BullFVGCount;i>0;i--) g_FB_BullFVG[i]=g_FB_BullFVG[i-1]; }
   g_FB_BullFVG[0].high=high; g_FB_BullFVG[0].low=low;
   g_FB_BullFVG[0].mid=(high+low)/2.0;
   g_FB_BullFVG[0].dir=1; g_FB_BullFVG[0].t=t; g_FB_BullFVG[0].mitigated=false;
   g_FB_BullFVGCount++;
  }

void FB_StoreBearFVG(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FB_FVG_MaxStored, 8);
   if(g_FB_BearFVGCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) g_FB_BearFVG[i]=g_FB_BearFVG[i-1]; g_FB_BearFVGCount=maxKeep-1; }
   else
     { for(int i=g_FB_BearFVGCount;i>0;i--) g_FB_BearFVG[i]=g_FB_BearFVG[i-1]; }
   g_FB_BearFVG[0].high=high; g_FB_BearFVG[0].low=low;
   g_FB_BearFVG[0].mid=(high+low)/2.0;
   g_FB_BearFVG[0].dir=-1; g_FB_BearFVG[0].t=t; g_FB_BearFVG[0].mitigated=false;
   g_FB_BearFVGCount++;
  }

void FB_ScanFVG()
  {
   if(Bars(_Symbol, PERIOD_M5) < 20) return;
   double h1 = TfHigh(PERIOD_M5,1);
   double l1 = TfLow(PERIOD_M5,1);
   double h3 = TfHigh(PERIOD_M5,3);
   double l3 = TfLow(PERIOD_M5,3);
   double c2 = TfClose(PERIOD_M5,2);
   datetime t1 = TfTime(PERIOD_M5,1);
   if(h1<=0||l1<=0||h3<=0||l3<=0||c2<=0) return;

   if(l1 > h3 && c2 > h3 && ((l1-h3)/_Point) >= FB_FVG_MinSizePts)
     {
      bool exists=false;
      for(int i=0;i<g_FB_BullFVGCount;i++) if(g_FB_BullFVG[i].t==t1){ exists=true; break; }
      if(!exists) FB_StoreBullFVG(l1, h3, t1);
     }
   if(h1 < l3 && c2 < l3 && ((l3-h1)/_Point) >= FB_FVG_MinSizePts)
     {
      bool exists=false;
      for(int i=0;i<g_FB_BearFVGCount;i++) if(g_FB_BearFVG[i].t==t1){ exists=true; break; }
      if(!exists) FB_StoreBearFVG(l3, h1, t1);
     }

   double current = TfClose(PERIOD_M5, 0);
   for(int i=0;i<g_FB_BullFVGCount;i++)
      if(!g_FB_BullFVG[i].mitigated && current<g_FB_BullFVG[i].low) g_FB_BullFVG[i].mitigated=true;
   for(int i=0;i<g_FB_BearFVGCount;i++)
      if(!g_FB_BearFVG[i].mitigated && current>g_FB_BearFVG[i].high) g_FB_BearFVG[i].mitigated=true;
  }

bool FB_NearStoredZone(int dir, double distATR)
  {
   double price = MidPrice();
   if(price<=0 || CurrentATR1<=0) return false;

   if(dir > 0)
     {
      for(int i=0;i<g_FB_BullOBCount;i++)
        {
         if(g_FB_BullOB[i].mitigated) continue;
         double d = 0;
         if(price<g_FB_BullOB[i].low)       d = g_FB_BullOB[i].low - price;
         else if(price>g_FB_BullOB[i].high) d = price - g_FB_BullOB[i].high;
         if(d <= CurrentATR1*distATR) return true;
        }
      for(int i=0;i<g_FB_BullFVGCount;i++)
        {
         if(g_FB_BullFVG[i].mitigated) continue;
         double d = 0;
         if(price<g_FB_BullFVG[i].low)       d = g_FB_BullFVG[i].low - price;
         else if(price>g_FB_BullFVG[i].high) d = price - g_FB_BullFVG[i].high;
         if(d <= CurrentATR1*distATR) return true;
        }
     }
   else if(dir < 0)
     {
      for(int i=0;i<g_FB_BearOBCount;i++)
        {
         if(g_FB_BearOB[i].mitigated) continue;
         double d = 0;
         if(price<g_FB_BearOB[i].low)       d = g_FB_BearOB[i].low - price;
         else if(price>g_FB_BearOB[i].high) d = price - g_FB_BearOB[i].high;
         if(d <= CurrentATR1*distATR) return true;
        }
      for(int i=0;i<g_FB_BearFVGCount;i++)
        {
         if(g_FB_BearFVG[i].mitigated) continue;
         double d = 0;
         if(price<g_FB_BearFVG[i].low)       d = g_FB_BearFVG[i].low - price;
         else if(price>g_FB_BearFVG[i].high) d = price - g_FB_BearFVG[i].high;
         if(d <= CurrentATR1*distATR) return true;
        }
     }
   return false;
  }

int FB_FastDirection()
  {
   int dirV = 0;
   if(g_FB_VROC >= FB_VROC_TrendMin)
     {
      double o = TfOpen(PERIOD_M1, 0);
      double c = TfClose(PERIOD_M1, 0);
      if(o > 0 && c > 0)
        {
         if(c > o + 5*_Point) dirV = 1;
         if(c < o - 5*_Point) dirV = -1;
        }
     }
   int dirC = 0;
   if(FlowFresh())
     {
      if(CVDAccelerationNormalized > CVDAccelMin && CVDVelocityNormalized > 0) dirC = 1;
      if(CVDAccelerationNormalized < -CVDAccelMin && CVDVelocityNormalized < 0) dirC = -1;
     }
   int dirW = 0;
   if(g_FB_VWAPSlope >  FB_VWAP_SlopeMin) dirW = 1;
   if(g_FB_VWAPSlope < -FB_VWAP_SlopeMin) dirW = -1;

   if(MQLInfoInteger(MQL_TESTER))
     {
      if(dirV == 1  && dirW >= 0) return 1;
      if(dirV == -1 && dirW <= 0) return -1;
      return 0;
     }
   int votes = dirV + dirC + dirW;
   if(dirV == 1  && votes >= 1)  return 1;
   if(dirV == -1 && votes <= -1) return -1;
   return 0;
  }

double FB_NormalizeLots(double lots)
  {
   double mn=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double st=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   double mx=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   if(mn<=0) mn=0.01; if(st<=0) st=0.01; if(mx<=0) mx=100;
   if(mx>CapTotalLots_Max) mx = CapTotalLots_Max;
   int s = (int)MathFloor(lots/st + 1e-9);
   lots = NormalizeDouble(s*st, 2);
   if(lots<mn) return 0;
   if(lots>mx) lots = mx;
   return lots;
  }

//===================================================================
// SECTION 100 — FACTOR B — MODE + ENGINES
//===================================================================
int FB_DetectMode()
  {
   bool bSweep = M1BullSweep(), sSweep = M1BearSweep();
   bool bMSS   = M1BullMSS(),   sMSS   = M1BearMSS();
   bool bDisp  = M1BullDisplacement(), sDisp = M1BearDisplacement();

   if(bSweep && bMSS && bDisp) return 3;
   if(sSweep && sMSS && sDisp) return 3;

   if(g_FB_VROC >= FB_VROC_MonsterMin && g_FB_RangeExp >= FB_RE_MonsterMin) return 2;
   if(g_FB_VROC >= FB_VROC_TrendMin   && g_FB_RangeExp >= FB_RE_TrendMin)   return 1;

   if(g_FB_VP.valid && FB_PriceInVA()) return 0;

   if(!g_FB_VP.valid) return 1;
   return 1;
  }

void FB_ChopEngine()
  {
   // One active range campaign at a time: includes pending orders, not only filled positions.
   if(CountEnginePositions("FB_CHOP_") > 0) return;
   if(CountEngineOrders("FB_CHOP_") > 0) return;
   if(CountPendingTotal() > 0) return;
   if(TimeCurrent() - g_FB_LastClose[0] < 60) return;
   if(!g_FB_VP.valid) return;
   if(!FB_VACompressed()) return;

   double vaRange = g_FB_VP.vah - g_FB_VP.val;
   if(vaRange <= 0) return;
   double mid = MidPrice();
   double posInVA = (mid - g_FB_VP.val) / vaRange;
   bool nearLow  = (posInVA < 0.25);
   bool nearHigh = (posInVA > 0.75);
   if(!nearLow && !nearHigh) return;

   double slDist = FB_Chop_SL_Pts * _Point;
   double tpDist = FB_Chop_TP_Pts * _Point;
   //--- [S1] apply spread floor
   slDist = SafeSLDistance(slDist);
   tpDist = SafeTPDistance(tpDist, slDist);

   double buffer = CurrentSpreadPoints * 2 * _Point;
   double buyPrice  = NormalizeDouble(g_FB_VP.val + buffer, _Digits);
   double sellPrice = NormalizeDouble(g_FB_VP.vah - buffer, _Digits);

   if(buyPrice  >= AskPrice()) buyPrice  = NormalizeDouble(AskPrice()  - 20*_Point, _Digits);
   if(sellPrice <= BidPrice()) sellPrice = NormalizeDouble(BidPrice()  + 20*_Point, _Digits);

   double lot = FB_NormalizeLots(FB_Chop_Lot * SpreadThrottle());
   if(lot<=0) return;

   int placed = 0;
   double sl = NormalizeDouble(buyPrice - slDist, _Digits);
   double tp = NormalizeDouble(buyPrice + tpDist, _Digits);
   if(SendLimitV2(true, buyPrice, lot, sl, tp, "FB_CHOP_BL")) placed++;

   sl = NormalizeDouble(sellPrice + slDist, _Digits);
   tp = NormalizeDouble(sellPrice - tpDist, _Digits);
   if(SendLimitV2(false, sellPrice, lot, sl, tp, "FB_CHOP_SL")) placed++;

   if(placed > 0)
      PrintFormat("[FB CHOP] pos=%.2f width=%.3f placed=%d",
                  posInVA, g_FB_VP.vaWidthPct, placed);
  }

void FB_TrendEngine()
  {
   if(CountEnginePositions("FB_TREND_") > 0) return;
   if(TimeCurrent() - g_FB_LastClose[1] < 60) return;

   int dir = 0;
   if(g_FB_JerkM15 != 0) dir = g_FB_JerkM15;
   else if((dir = FB_FastDirection()) != 0) { }
   else if(g_FB_VWAPSlope >  FB_VWAP_SlopeMin) dir = 1;
   else if(g_FB_VWAPSlope < -FB_VWAP_SlopeMin) dir = -1;
   else return;

   if(dir ==  1 && g_FB_VWAPSlope < 0) return;
   if(dir == -1 && g_FB_VWAPSlope > 0) return;

   double slDist = FB_Trend_SL_Pts * _Point;
   double tpDist = FB_Trend_TP_Pts * _Point;
   slDist = SafeSLDistance(slDist);
   tpDist = SafeTPDistance(tpDist, slDist);
   double gapP = FB_Trend_Gap_Pts * _Point;

   double lot = FB_NormalizeLots(FB_Trend_Lot * SpreadThrottle());
   if(lot<=0) return;

   double bid = BidPrice(), ask = AskPrice();
   int placed = 0;
   int depth = MathMax(1, FB_TrendLadderDepth);

   if(dir == 1)
     {
      for(int i=0; i<depth; i++)
        {
         double p = NormalizeDouble(ask + gapP*(i+1), _Digits);
         double sl = NormalizeDouble(p - slDist, _Digits);
         double tp = NormalizeDouble(p + tpDist, _Digits);
         if(SendStopV2(true, p, lot, sl, tp, "FB_TREND_B"+IntegerToString(i))) placed++;
        }
     }
   else
     {
      for(int i=0; i<depth; i++)
        {
         double p = NormalizeDouble(bid - gapP*(i+1), _Digits);
         double sl = NormalizeDouble(p + slDist, _Digits);
         double tp = NormalizeDouble(p - tpDist, _Digits);
         if(SendStopV2(false, p, lot, sl, tp, "FB_TREND_S"+IntegerToString(i))) placed++;
        }
     }

   if(placed > 0)
      PrintFormat("[FB TREND] dir=%d placed=%d VROC=%.2f RE=%.2f",
                  dir, placed, g_FB_VROC, g_FB_RangeExp);
  }

void FB_MonsterEngine()
  {
   if(CountEnginePositions("FB_MON_") > 0) return;
   if(TimeCurrent() - g_FB_LastClose[2] < 120) return;

   int dir = FB_FastDirection();
   if(dir == 0 && g_FB_JerkM15 != 0) dir = g_FB_JerkM15;
   if(dir == 0) return;

   double slDist = FB_Monster_SL_Pts * _Point;
   double tpDist = FB_Monster_TP_Pts * _Point;
   slDist = SafeSLDistance(slDist);
   tpDist = SafeTPDistance(tpDist, slDist);
   double gapP = FB_Monster_Gap_Pts * _Point;

   double lot = FB_NormalizeLots(FB_Monster_Lot * SpreadThrottle());
   if(lot<=0) return;

   double bid = BidPrice(), ask = AskPrice();
   int placed = 0;
   int depth = MathMax(1, FB_MonsterLadderDepth);

   if(dir == 1)
     {
      for(int i=0; i<depth; i++)
        {
         double p = NormalizeDouble(ask + gapP*(i+1), _Digits);
         double sl = NormalizeDouble(p - slDist, _Digits);
         double tp = NormalizeDouble(p + tpDist, _Digits);
         if(SendStopV2(true, p, lot, sl, tp, "FB_MON_B"+IntegerToString(i))) placed++;
        }
     }
   else
     {
      for(int i=0; i<depth; i++)
        {
         double p = NormalizeDouble(bid - gapP*(i+1), _Digits);
         double sl = NormalizeDouble(p + slDist, _Digits);
         double tp = NormalizeDouble(p - tpDist, _Digits);
         if(SendStopV2(false, p, lot, sl, tp, "FB_MON_S"+IntegerToString(i))) placed++;
        }
     }

   if(placed > 0)
      PrintFormat("[FB MONSTER] dir=%d placed=%d VROC=%.2f", dir, placed, g_FB_VROC);
  }

void FB_ReversalEngine()
  {
   if(CountEnginePositions("FB_REV_") > 0) return;
   if(TimeCurrent() - g_FB_LastClose[3] < 180) return;

   bool bSweep = M1BullSweep(), sSweep = M1BearSweep();
   bool bMSS   = M1BullMSS(),   sMSS   = M1BearMSS();
   bool bDisp  = M1BullDisplacement(), sDisp = M1BearDisplacement();

   int dir = 0;
   if(bSweep && bMSS && bDisp) dir = 1;
   else if(sSweep && sMSS && sDisp) dir = -1;
   else return;

   if(FB_ReqM1Sweep       && !(dir== 1?bSweep:sSweep)) return;
   if(FB_ReqM1MSS         && !(dir== 1?bMSS:sMSS))     return;
   if(FB_ReqM1Displ       && !(dir== 1?bDisp:sDisp))   return;
   if(FB_ReqZoneProximity && !FB_NearStoredZone(dir, 1.50)) return;

   double slDist = FB_Reversal_SL_Pts * _Point;
   double tpDist = FB_Reversal_TP_Pts * _Point;
   slDist = SafeSLDistance(slDist);
   tpDist = SafeTPDistance(tpDist, slDist);

   double lot = FB_NormalizeLots(FB_Reversal_Lot * SpreadThrottle());
   if(lot<=0) return;

   double entry = (dir == 1) ? AskPrice() : BidPrice();
   double sl = (dir ==  1) ? entry - slDist : entry + slDist;
   double tp = (dir ==  1) ? entry + tpDist : entry - tpDist;
   sl = NormalizeDouble(sl, _Digits);
   tp = NormalizeDouble(tp, _Digits);

   bool ok = (dir == 1)
             ? SendMarketV2(ORDER_TYPE_BUY,  lot, sl, tp, "FB_REV_B")
             : SendMarketV2(ORDER_TYPE_SELL, lot, sl, tp, "FB_REV_S");

   if(ok)
      PrintFormat("[FB REVERSAL] dir=%d lots=%.2f SL=%.0f TP=%.0f",
                  dir, lot, slDist/_Point, tpDist/_Point);
  }

//===================================================================
// SECTION 101 — FACTOR B — BASKET MANAGEMENT
//===================================================================
double FB_BasketBE()
  {
   double base = (StartBalance > 0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   double pctTarget = base * FB_BasketBE_Pct / 100.0;
   //--- spread floor
   int posCount = MathMax(1, CountOurPositions());
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double spreadUSD = SpreadInPoints() * posCount * TotalOurLots() * tickValue;
   return MathMax(pctTarget, spreadUSD * SpreadMultiplier_Basket);
  }
double FB_BasketTrailUSD()
  {
   double base = (StartBalance > 0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   double pctTarget = base * FB_BasketTrail_Pct / 100.0;
   double be = FB_BasketBE();
   if(pctTarget < be * 1.5) pctTarget = be * 1.5;
   return pctTarget;
  }
double FB_BasketStepUSD()
  {
   double base = (StartBalance > 0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   double pctTarget = base * FB_BasketStep_Pct / 100.0;
   int posCount = MathMax(1, CountOurPositions());
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double spreadUSD = SpreadInPoints() * posCount * TotalOurLots() * tickValue;
   double spreadFloor = spreadUSD * SpreadMultiplier_Basket * 0.75;
   return MathMax(pctTarget, spreadFloor);
  }
double FB_BasketSL_USD()
  {
   double base = (StartBalance > 0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   return -base * MathAbs(FB_BasketSL_Pct) / 100.0;
  }

void FB_BasketManage(string pfx, int idx, datetime &lastClose)
  {
   if(CountEnginePositions(pfx) <= 0)
     {
      g_FB_BE[idx] = false;
      g_FB_Trail[idx] = false;
      return;
     }
   double pnl = PrefixFloatingPnL(pfx);

   if(pnl <= FB_BasketSL_USD())
     {
      DeleteOrdersPrefix(pfx);
      CloseEnginePositions(pfx);
      lastClose = TimeCurrent();
      g_FB_BE[idx] = false;
      g_FB_Trail[idx] = false;
      PrintFormat("[FB BASKET SL] %s pnl=%.2f", pfx, pnl);
      return;
     }
   if(!g_FB_BE[idx] && pnl >= FB_BasketBE())
     {
      MovePrefixToBE(pfx);
      g_FB_BE[idx] = true;
      PrintFormat("[FB BASKET BE] %s pnl=%.2f", pfx, pnl);
     }
   if(!g_FB_Trail[idx] && pnl >= FB_BasketTrailUSD())
     {
      g_FB_Trail[idx] = true;
      g_FB_TrailHigh[idx] = pnl;
      g_FB_TrailSL[idx] = pnl - FB_BasketStepUSD();
     }
   if(g_FB_Trail[idx])
     {
      if(pnl > g_FB_TrailHigh[idx])
        {
         g_FB_TrailHigh[idx] = pnl;
         g_FB_TrailSL[idx] = pnl - FB_BasketStepUSD();
        }
      if(pnl <= g_FB_TrailSL[idx] && pnl > 0)
        {
         DeleteOrdersPrefix(pfx);
         CloseEnginePositions(pfx);
         lastClose = TimeCurrent();
         g_FB_Trail[idx] = false;
         PrintFormat("[FB BASKET TRAIL] %s pnl=%.2f", pfx, pnl);
        }
     }
  }

//===================================================================
// SECTION 102 — FACTOR B — LEGACY CAMPAIGN DISPATCHER
//===================================================================
void RunFactorB()
  {
   //--- V2: Factor B does not wait for Factor-A positions when LegacyCampaign is on.
   //    Existing filled positions remain in the unified campaign; only
   //    competing pending inventory is replaced by the active fallback engine.
   if(!V1LegacyCampaignEnabled)
     {
      if(CountEnginePositions("SWING_")    > 0) return;
      if(CountEnginePositions("MONSTER_")  > 0) return;
      if(CountEnginePositions("RANGE_")    > 0) return;
      if(CountEnginePositions("REVERSAL_") > 0) return;
      if(CountEnginePositions("CHOP_")     > 0) return;
     }

   if(CountOurPositions() >= (V1LegacyCampaignEnabled ? LegacyCampaignMaxOpenPositions : 2)) return;
   if(!MsgBudget_CanTrade()) return;

   //--- Per-bar refresh
   datetime cm15 = TfTime(PERIOD_M15, 0);
   if(cm15 > 0 && cm15 != g_FB_LastM15Time)
     {
      g_FB_LastM15Time = cm15;
      g_FB_JerkM15 = DetectM15Jerk();
      FB_DetectMSS_Event();
      FB_ScanOB();
     }
   datetime cm5 = TfTime(PERIOD_M5, 0);
   if(cm5 > 0 && cm5 != g_FB_LastM5Time)
     {
      g_FB_LastM5Time = cm5;
      FB_UpdateSessionVWAP();
      FB_ScanFVG();
      FB_BuildVolumeProfile();
     }
   datetime cm1 = TfTime(PERIOD_M1, 0);
   if(cm1 > 0 && cm1 != g_FB_LastM1Time)
     {
      g_FB_LastM1Time = cm1;
      FB_UpdateVROC();

      int newMode = FB_DetectMode();
      if(newMode != g_FB_Mode)
        {
         PrintFormat("[FB MODE] %d -> %d VROC=%.2f RE=%.2f VA=%.3f",
                     g_FB_Mode, newMode, g_FB_VROC, g_FB_RangeExp,
                     g_FB_VP.valid ? g_FB_VP.vaWidthPct : 0.0);
         g_FB_Mode = newMode;
        }
     }

   //--- V2: fallback engine handoff owns pending inventory, but never closes
   //    already-filled positions from another engine.
   if(V1LegacyCampaignEnabled)
     {
      if(g_FB_Mode == 0) LegacyCampaign_CancelCompetingPendings("FB_CHOP_");
      else if(g_FB_Mode == 1) LegacyCampaign_CancelCompetingPendings("FB_TREND_");
      else if(g_FB_Mode == 2) LegacyCampaign_CancelCompetingPendings("FB_MON_");
      else if(g_FB_Mode == 3) LegacyCampaign_CancelCompetingPendings("FB_REV_");
     }

   //--- Basket management runs every tick when LegacyCampaign is NOT the exit owner.
   if(!V1LegacyCampaignEnabled)
     {
      FB_BasketManage("FB_CHOP_",  0, g_FB_LastClose[0]);
      FB_BasketManage("FB_TREND_", 1, g_FB_LastClose[1]);
      FB_BasketManage("FB_MON_",   2, g_FB_LastClose[2]);
      FB_BasketManage("FB_REV_",   3, g_FB_LastClose[3]);
     }

   //--- One entry per M1 bar
   static datetime lastExec = 0;
   if(cm1 == 0 || cm1 == lastExec) return;
   lastExec = cm1;

   if(g_FB_Mode == 0)      FB_ChopEngine();
   else if(g_FB_Mode == 1) FB_TrendEngine();
   else if(g_FB_Mode == 2) FB_MonsterEngine();
   else if(g_FB_Mode == 3) FB_ReversalEngine();
  }

//===================================================================
// SECTION 102A-INTEL — GENESIS BABA ELITE INTELLIGENCE CORE
// Forward declarations keep the intelligence brain independent of the
// campaign implementation that follows later in the source.
//===================================================================
bool   LegacyCampaign_IsActive();
double LegacyCampaign_FloatingPnL();
int    LegacyCampaign_CountPending();
int    LegacyCampaign_CountPositions();
double Genesis_CampaignR(double pnl);
string GenesisIntelligencePhaseName(int phase)
  {
   switch(phase)
     {
      case GI_PHASE_CHOP:         return "CHOP";
      case GI_PHASE_COMPRESSION:  return "COMPRESSION";
      case GI_PHASE_TRANSITION:   return "TRANSITION";
      case GI_PHASE_IGNITION:     return "IGNITION";
      case GI_PHASE_ACCELERATION: return "ACCELERATION";
      case GI_PHASE_EXPANSION:    return "EXPANSION";
      case GI_PHASE_CLIMAX:       return "CLIMAX";
      case GI_PHASE_EXHAUSTION:   return "EXHAUSTION";
      case GI_PHASE_TREND:        return "TREND";
     }
   return "UNKNOWN";
  }

string GenesisIntelligenceActionName(int action)
  {
   switch(action)
     {
      case GI_ATTACK:       return "ATTACK";
      case GI_REVERSAL:     return "REVERSAL";
      case GI_CONTINUATION: return "CONTINUATION";
      case GI_RANGE:        return "RANGE";
      case GI_WAIT:         return "WAIT";
     }
   return "WAIT";
  }

double GI_AverageM1Volume(int startShift,int endShift)
  {
   double sum=0.0; int n=0;
   if(startShift<0) startShift=0;
   if(endShift<startShift) endShift=startShift;
   for(int i=startShift;i<=endShift;i++)
     {
      long v=TfVolume(PERIOD_M1,i);
      if(v>0) { sum+=(double)v; n++; }
     }
   return (n>0)?sum/(double)n:0.0;
  }

double GI_M1VolumeRatio()
  {
   double avg=GI_AverageM1Volume(2,21);
   if(avg<=0.0) return 1.0;
   return (double)TfVolume(PERIOD_M1,0)/avg;
  }

double GI_M5VolumeRatio()
  {
   double sum=0.0; int n=0;
   for(int i=2;i<=21;i++)
     {
      long v=TfVolume(PERIOD_M5,i);
      if(v>0){sum+=(double)v;n++;}
     }
   double avg=(n>0)?sum/(double)n:0.0;
   if(avg<=0.0) return 1.0;
   return (double)TfVolume(PERIOD_M5,1)/avg;
  }

double GI_TradeRateRatio()
  {
   if(!FlowFresh()) return 1.0;
   if(FlowRateCount<10 || gFlow.trade_rate<=0.0) return 1.0;
   double avg=AverageFlowTradeRate();
   return (avg>0.0)?gFlow.trade_rate/avg:1.0;
  }

double GI_PriceEfficiency(int bars)
  {
   if(bars<3) bars=3;
   double first=TfClose(PERIOD_M1,bars+1);
   double last =TfClose(PERIOD_M1,1);
   if(first<=0.0 || last<=0.0) return 0.0;
   double net=MathAbs(last-first), path=0.0;
   for(int i=1;i<=bars;i++)
     {
      double c0=TfClose(PERIOD_M1,i), c1=TfClose(PERIOD_M1,i+1);
      if(c0>0.0 && c1>0.0) path+=MathAbs(c0-c1);
     }
   if(path<=0.0) return 0.0;
   return Clamp(net/path,0.0,1.0);
  }

double GI_DirectionStrengthFromComponents(int dir)
  {
   if(dir==0) return 0.0;
   double score=0.0;
   // M15 strategic control
   double e10=BufVal(hEMA10_M15,0,1), e20=BufVal(hEMA20_M15,0,1), e50=BufVal(hEMA50_M15,0,1);
   double p15=TfClose(PERIOD_M15,1);
   double adx15=BufVal(hADX_M15,0,1), pdi15=BufVal(hADX_M15,1,1), mdi15=BufVal(hADX_M15,2,1);
   double mac15=BufVal(hMACD_M15,0,1), sig15=BufVal(hMACD_M15,1,1);
   if(dir==1 && e10>e20) score+=8.0;
   if(dir==-1 && e10<e20) score+=8.0;
   if(dir==1 && p15>e50) score+=7.0;
   if(dir==-1 && p15<e50) score+=7.0;
   if(adx15>=18.0 && ((dir==1 && pdi15>mdi15)||(dir==-1 && mdi15>pdi15))) score+=5.0;
   if((dir==1 && mac15>sig15)||(dir==-1 && mac15<sig15)) score+=3.0;
   if(KAMA_M15_Slope*dir>0.0) score+=2.0;
   if(g_SMC.m15_bias==dir) score+=5.0;
   if(g_SMC.m15_event==dir) score+=3.0;

   // M5 tactical control
   double e8=BufVal(hEMA8_M5,0,1), e21=BufVal(hEMA21_M5,0,1), e50m5=BufVal(hEMA50_M5,0,1);
   double p5=TfClose(PERIOD_M5,1);
   double rsi5=BufVal(hRSI_M5,0,1), adx5=BufVal(hADX_M5,0,1);
   double pdi5=BufVal(hADX_M5,1,1), mdi5=BufVal(hADX_M5,2,1);
   double mac5=BufVal(hMACD_M5,0,1), sig5=BufVal(hMACD_M5,1,1), mom5=BufVal(hMom14_M5,0,1);
   if(dir==1 && e8>e21) score+=8.0;
   if(dir==-1 && e8<e21) score+=8.0;
   if(dir==1 && p5>e50m5) score+=7.0;
   if(dir==-1 && p5<e50m5) score+=7.0;
   if(adx5>=16.0 && ((dir==1 && pdi5>mdi5)||(dir==-1 && mdi5>pdi5))) score+=4.0;
   if((dir==1 && rsi5>=50.0)||(dir==-1 && rsi5<=50.0)) score+=3.0;
   if((dir==1 && mom5>100.0)||(dir==-1 && mom5<100.0)) score+=2.0;
   if((dir==1 && mac5>sig5)||(dir==-1 && mac5<sig5)) score+=2.0;
   if(g_SMC.m5_bias==dir) score+=5.0;
   if(g_SMC.m5_event==dir) score+=3.0;
   if(g_M5ThesisDir==dir) score+=4.0;
   if(g_GI.m1LeadDir==dir) score+=MathMin(10.0,g_GI.m1LeadScore*0.10);
   if((dir==1 && g_GI.m1LeadCrossUp)||(dir==-1 && g_GI.m1LeadCrossDown)) score+=6.0;

   return Clamp(score,0.0,100.0);
  }

double GI_M1Control(int dir)
  {
   if(dir==0) return 0.0;
   double score=0.0;
   if(dir==1 && M1PA_BullSweep) score+=18.0;
   if(dir==-1 && M1PA_BearSweep) score+=18.0;
   if(dir==1 && M1PA_BullMSS) score+=22.0;
   if(dir==-1 && M1PA_BearMSS) score+=22.0;
   if(dir==1 && M1PA_BullDisp) score+=22.0;
   if(dir==-1 && M1PA_BearDisp) score+=22.0;
   if(dir==1 && M1PA_BullFVG) score+=8.0;
   if(dir==-1 && M1PA_BearFVG) score+=8.0;
   if(M1PA_Dir==dir) score+=MathMin(15.0,M1PA_Score*0.15);

   double o=TfOpen(PERIOD_M1,0), c=TfClose(PERIOD_M1,0), h=TfHigh(PERIOD_M1,0), l=TfLow(PERIOD_M1,0);
   double atr=CurrentATR1;
   if(o>0.0 && c>0.0 && h>0.0 && l>0.0 && atr>0.0)
     {
      double r=h-l;
      if(r>0.0)
        {
         double br=MathAbs(c-o)/r;
         double ext=r/atr;
         double cp=(c-l)/r;
         if(ext>=0.75) score+=5.0;
         if(br>=0.55) score+=5.0;
         if((dir==1 && cp>=0.65)||(dir==-1 && cp<=0.35)) score+=5.0;
      }
     }
   return Clamp(score,0.0,100.0);
  }

double GI_FlowPressure(int dir)
  {
   if(dir==0) return 0.0;
   if(!BridgeReady() || !GenesisIntelUseFlowOnBridge)
     {
      // Factor-B/native fallback: use volume, VWAP slope, and native volume
      // state. This is supportive, not a competing trader.
      double score=20.0;
      if(FB_FastDirection()==dir) score+=20.0;
      if(g_FB_VROC>FB_VROC_TrendMin) score+=15.0;
      if((dir==1 && g_FB_VWAPSlope>0.0)||(dir==-1 && g_FB_VWAPSlope<0.0)) score+=15.0;
      if((dir==1 && VolSurgeBull_sig)||(dir==-1 && VolSurgeBear_sig)) score+=20.0;
      return Clamp(score,0.0,100.0);
     }

   double fc=FlowComposite()*(double)dir;
   double score=Clamp(50.0 + fc*0.50,0.0,100.0);
   if(fc>=GenesisIntelStrongFlowBridge) score+=6.0;
   if(VNFlowCVDAccelerationStrong(dir)) score+=12.0;
   if(VNFlowTradeRateSurge()) score+=8.0;
   if(VNFlowCascade(dir)) score+=8.0;
   if((gFlow.ofi*(double)dir)>0.15) score+=6.0;
   if((gFlow.depth*(double)dir)>0.15) score+=4.0;
   if((gFlow.book*(double)dir)>0.15) score+=4.0;
   if(gBinAux.valid && gBinAux.liquidation_imbalance*(double)dir>0.20) score+=5.0;
   if(gBinAux.valid && gBinAux.oi_delta_1m*(double)dir>0.0) score+=3.0;
   if(gFlow.persistence>=0.50 && fc>0.0) score+=4.0;
   return Clamp(score,0.0,100.0);
  }

//===================================================================
// BGBI BUYER/SELLER PROFILE — rolling price-volume map + confirmed pivots
//===================================================================
double BPI_Clip(double x)
  {
   return MathMax(0.0,MathMin(1.0,x));
  }

bool BPI_RebuildProfile()
  {
   g_BPIValid=false;
   int rows=(int)MathMax(24,MathMin(BGBIProfileRows,100));
   int available=Bars(_Symbol,BGBIProfileTF);
   if(available<100) return false;
   int lookback=(int)MathMax(80,MathMin(BGBIProfileLookback,available-2));
   if(lookback<80) return false;

   double lo=DBL_MAX, hi=-DBL_MAX;
   for(int sh=1;sh<=lookback;sh++)
     {
      double bh=iHigh(_Symbol,BGBIProfileTF,sh);
      double bl=iLow(_Symbol,BGBIProfileTF,sh);
      if(bh<=0.0 || bl<=0.0 || bh<bl) continue;
      if(bl<lo) lo=bl;
      if(bh>hi) hi=bh;
     }
   if(lo==DBL_MAX || hi<=lo) return false;

   double span=MathMax(hi-lo,SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE)*(double)rows);
   double step=span/(double)rows;
   if(step<=0.0) return false;
   ArrayInitialize(g_BPIBinTotal,0.0);
   ArrayInitialize(g_BPIBinBuy,0.0);
   g_BPIBinRows=rows;
   g_BPILow=lo;
   g_BPIHigh=hi;
   g_BPIBinStep=step;
   g_BPITotalVolume=0.0;

   for(int sh=1;sh<=lookback;sh++)
     {
      double bl=iLow(_Symbol,BGBIProfileTF,sh);
      double bh=iHigh(_Symbol,BGBIProfileTF,sh);
      double bc=iClose(_Symbol,BGBIProfileTF,sh);
      if(bl<=0.0 || bh<=0.0 || bh<bl || bc<=0.0) continue;
      double vol=(double)iVolume(_Symbol,BGBIProfileTF,sh);
      if(vol<=0.0) continue;
      double barRange=bh-bl;
      double buyFraction=(barRange>0.0)?BPI_Clip((bc-bl)/barRange):0.50;
      int r0=(int)MathFloor((bl-lo)/step);
      int r1=(int)MathFloor((bh-lo)/step);
      r0=(int)MathMax(0,MathMin(rows-1,r0));
      r1=(int)MathMax(0,MathMin(rows-1,r1));
      if(barRange<=0.0) r1=r0;
      for(int r=r0;r<=r1;r++)
        {
         double rl=lo+(double)r*step;
         double overlap=(barRange>0.0)?MathMax(0.0,MathMin(bh,rl+step)-MathMax(bl,rl)):step;
         double frac=(barRange>0.0)?overlap/barRange:1.0;
         if(frac<=0.0) continue;
         double part=vol*frac;
         g_BPIBinTotal[r]+=part;
         g_BPIBinBuy[r]+=part*buyFraction;
        }
     }

   double total=0.0,buy=0.0,maxBin=0.0;
   int pocIndex=0;
   for(int r=0;r<rows;r++)
     {
      total+=g_BPIBinTotal[r];
      buy+=g_BPIBinBuy[r];
      if(g_BPIBinTotal[r]>maxBin) { maxBin=g_BPIBinTotal[r]; pocIndex=r; }
     }
   if(total<=0.0 || maxBin<=0.0) return false;
   g_BPITotalVolume=total;
   g_BPIPOC=lo+((double)pocIndex+0.5)*step;
   g_BPIBuyShare=BPI_Clip(buy/total);
   g_BPIValid=true;
   return true;
  }

bool BPI_ProfileNode(double raw,bool support,double atrPrice,
                     double &nodePrice,double &evidence,double &nodeStrength)
  {
   nodePrice=raw; evidence=0.0; nodeStrength=0.0;
   if(!g_BPIValid || g_BPIBinRows<2 || g_BPIBinStep<=0.0) return false;
   double mx=0.0000001;
   for(int r=0;r<g_BPIBinRows;r++) mx=MathMax(mx,g_BPIBinTotal[r]);
   double radius=MathMax(atrPrice*BGBIProfileSearchATR,g_BPIBinStep*2.0);
   double best=-1.0;
   for(int r=0;r<g_BPIBinRows;r++)
     {
      double p=g_BPILow+((double)r+0.5)*g_BPIBinStep;
      double d=MathAbs(p-raw);
      if(d>radius) continue;
      double v=g_BPIBinTotal[r];
      if(v<=0.0) continue;
      double strength=v/mx;
      double left=(r>0)?g_BPIBinTotal[r-1]:v;
      double right=(r<g_BPIBinRows-1)?g_BPIBinTotal[r+1]:v;
      double neighbour=MathMax((left+right)*0.5,mx*0.01);
      double peak=BPI_Clip((v/neighbour-0.85)/0.65);
      double bshare=BPI_Clip(g_BPIBinBuy[r]/v);
      double sideShare=support?bshare:(1.0-bshare);
      double proximity=1.0-d/radius;
      double ev=0.50*strength+0.20*peak+0.20*sideShare+0.10*proximity;
      if(ev>best)
        {
         best=ev;
         nodePrice=p;
         evidence=ev;
         nodeStrength=strength;
        }
     }
   return (best>=0.0);
  }

void BPI_StoreLevel(double price,double raw,double score,double evidence,bool support,datetime born,double atrPrice)
  {
   double merge=MathMax(atrPrice*BGBIProfileMergeATR,_Point*5.0);
   int same=-1,freeSlot=-1,weakest=0;
   double weakestScore=DBL_MAX;
   for(int i=0;i<ArraySize(g_BPILevels);i++)
     {
      if(!g_BPILevels[i].active) { if(freeSlot<0) freeSlot=i; continue; }
      if(g_BPILevels[i].score<weakestScore) { weakestScore=g_BPILevels[i].score; weakest=i; }
      if(g_BPILevels[i].support==support && MathAbs(g_BPILevels[i].price-price)<=merge)
        { same=i; break; }
     }
   S_BGBIProfileLevel fresh;
   fresh.price=price; fresh.rawPrice=raw; fresh.score=score; fresh.evidence=evidence;
   fresh.support=support; fresh.active=true; fresh.born=born;
   if(same>=0)
     {
      if(score>g_BPILevels[same].score) g_BPILevels[same]=fresh;
      return;
     }
   int target=freeSlot;
   if(target<0)
     {
      if(score<=weakestScore) return;
      target=weakest;
     }
   g_BPILevels[target]=fresh;
  }

void BPI_EvaluatePivot(bool support,int pivotShift)
  {
   double raw=support?iLow(_Symbol,BGBIProfileTF,pivotShift):iHigh(_Symbol,BGBIProfileTF,pivotShift);
   if(raw<=0.0 || !g_BPIValid) return;
   double atrPrice=CurrentATR1;
   if(BGBIProfileTF==PERIOD_M5) atrPrice=CurrentATR5;
   else if(BGBIProfileTF==PERIOD_M15) atrPrice=CurrentATR15;
   if(atrPrice<=0.0) atrPrice=BufVal(hATR_M1,0,pivotShift);
   if(atrPrice<=0.0) atrPrice=MathMax(g_BPIBinStep*2.0,_Point*10.0);

   double node=raw,evid=0.0,nodeStrength=0.0;
   if(!BPI_ProfileNode(raw,support,atrPrice,node,evid,nodeStrength)) return;
   if(nodeStrength<BGBIProfileNodeMin || evid<BGBIProfileEvidenceMin) return;

   int avgCount=40;
   double volSum=0.0; int vCount=0;
   for(int sh=pivotShift;sh<pivotShift+avgCount;sh++)
     {
      long vv=iVolume(_Symbol,BGBIProfileTF,sh);
      if(vv>0) { volSum+=(double)vv; vCount++; }
     }
   double avgVol=(vCount>0)?volSum/(double)vCount:0.0;
   double pivotVol=(double)iVolume(_Symbol,BGBIProfileTF,pivotShift);
   double vr=(avgVol>0.0)?pivotVol/avgVol:1.0;
   double vScore=BPI_Clip((vr-0.80)/(2.20-0.80));
   double op=iOpen(_Symbol,BGBIProfileTF,pivotShift);
   double cl=iClose(_Symbol,BGBIProfileTF,pivotShift);
   double hi=iHigh(_Symbol,BGBIProfileTF,pivotShift);
   double lo=iLow(_Symbol,BGBIProfileTF,pivotShift);
   double candleRange=MathMax(hi-lo,_Point);
   double wick=support?(MathMin(op,cl)-lo):(hi-MathMax(op,cl));
   double wickScore=BPI_Clip((wick/candleRange)/0.50);

   double absorption=0.0;
   int absRad=(int)MathMin(3,MathMax(1,BGBIProfileSwingLen));
   for(int off=-absRad;off<=absRad;off++)
     {
      int sh=pivotShift+off;
      if(sh<1) continue;
      double bh=iHigh(_Symbol,BGBIProfileTF,sh), bl=iLow(_Symbol,BGBIProfileTF,sh);
      double bo=iOpen(_Symbol,BGBIProfileTF,sh), bc=iClose(_Symbol,BGBIProfileTF,sh);
      double rng=MathMax(bh-bl,_Point);
      double v=(double)iVolume(_Symbol,BGBIProfileTF,sh);
      double vs=0.0; int vc=0;
      for(int k=sh;k<sh+avgCount;k++)
        {
         long vv=iVolume(_Symbol,BGBIProfileTF,k);
         if(vv>0) { vs+=(double)vv; vc++; }
        }
      double base=(vc>0)?vs/(double)vc:0.0;
      double vRatio=(base>0.0)?v/base:1.0;
      double bodyRatio=MathAbs(bc-bo)/rng;
      double small=BPI_Clip((0.40-bodyRatio)/0.40);
      double activeVol=BPI_Clip((vRatio-1.0)/(1.50-1.0));
      absorption=MathMax(absorption,MathSqrt(small*activeVol));
     }

   double score=100.0*(0.50*evid+0.20*absorption+0.15*vScore+0.15*wickScore);
   if(score<BGBIProfileScoreMin) return;
   double pull=BGBIProfilePullMax*BPI_Clip(evid/0.65);
   double finalPrice=raw+(node-raw)*pull;
   datetime born=iTime(_Symbol,BGBIProfileTF,pivotShift);
   BPI_StoreLevel(finalPrice,raw,score,evid,support,born,atrPrice);
  }

void BPI_InvalidateLevels(double closedPrice,double atrPrice)
  {
   if(closedPrice<=0.0) return;
   double buffer=MathMax(atrPrice*BGBIProfileBreakATR,0.0);
   for(int i=0;i<ArraySize(g_BPILevels);i++)
     {
      if(!g_BPILevels[i].active) continue;
      if((g_BPILevels[i].support && closedPrice<g_BPILevels[i].price-buffer) ||
         (!g_BPILevels[i].support && closedPrice>g_BPILevels[i].price+buffer))
         g_BPILevels[i].active=false;
     }
  }

void BPI_Update()
  {
   if(!UseBGBIProfileIntel) { g_BPIValid=false; return; }
   datetime closedBar=iTime(_Symbol,BGBIProfileTF,1);
   if(closedBar<=0 || closedBar==g_BPILastBar) return;
   if(Bars(_Symbol,BGBIProfileTF)<100) return;
   g_BPILastBar=closedBar;
   if(!BPI_RebuildProfile()) return;

   double atr=(BGBIProfileTF==PERIOD_M5)?CurrentATR5:((BGBIProfileTF==PERIOD_M15)?CurrentATR15:CurrentATR1);
   if(atr<=0.0) atr=MathMax(g_BPIBinStep*2.0,_Point*10.0);
   BPI_InvalidateLevels(iClose(_Symbol,BGBIProfileTF,1),atr);

   int len=(int)MathMax(2,MathMin(BGBIProfileSwingLen,25));
   int pivotShift=len+1; // all right-side confirming candles are closed before this test
   if(Bars(_Symbol,BGBIProfileTF)>pivotShift+len+45)
     {
      double candidateLow=iLow(_Symbol,BGBIProfileTF,pivotShift);
      double candidateHigh=iHigh(_Symbol,BGBIProfileTF,pivotShift);
      bool isLow=(candidateLow>0.0), isHigh=(candidateHigh>0.0);
      for(int k=1;k<=len;k++)
        {
         if(candidateLow>=iLow(_Symbol,BGBIProfileTF,pivotShift-k) || candidateLow>=iLow(_Symbol,BGBIProfileTF,pivotShift+k)) isLow=false;
         if(candidateHigh<=iHigh(_Symbol,BGBIProfileTF,pivotShift-k) || candidateHigh<=iHigh(_Symbol,BGBIProfileTF,pivotShift+k)) isHigh=false;
        }
      if(isLow) BPI_EvaluatePivot(true,pivotShift);
      if(isHigh) BPI_EvaluatePivot(false,pivotShift);
     }
  }

void BPI_NearestLevels(double price,double &supportPrice,double &supportScore,
                       double &resistancePrice,double &resistanceScore)
  {
   supportPrice=0.0; supportScore=0.0; resistancePrice=0.0; resistanceScore=0.0;
   double sd=DBL_MAX,rd=DBL_MAX;
   for(int i=0;i<ArraySize(g_BPILevels);i++)
     {
      if(!g_BPILevels[i].active) continue;
      double d=MathAbs(g_BPILevels[i].price-price);
      if(g_BPILevels[i].support && d<sd)
        { sd=d; supportPrice=g_BPILevels[i].price; supportScore=g_BPILevels[i].score; }
      if(!g_BPILevels[i].support && d<rd)
        { rd=d; resistancePrice=g_BPILevels[i].price; resistanceScore=g_BPILevels[i].score; }
     }
  }

double BPI_LocationScore(int dir)
  {
   if(!UseBGBIProfileIntel || !g_BPIValid || dir==0) return 50.0;
   // Estimated pressure is a weak directional prior, never a stand-alone signal.
   double score=50.0+(double)dir*(g_BPIBuyShare-0.50)*70.0;
   double price=MidPrice();
   double atr=MathMax(CurrentATR5,CurrentATR1);
   if(atr<=0.0) atr=MathMax(g_BPIBinStep*2.0,_Point*10.0);
   double zone=MathMax(atr*0.45,g_BPIBinStep*2.0);
   double sp=0.0,ss=0.0,rp=0.0,rs=0.0;
   BPI_NearestLevels(price,sp,ss,rp,rs);
   if(sp>0.0)
     {
      double f=BPI_Clip(1.0-MathAbs(price-sp)/zone)*(0.50+0.005*ss);
      if(dir==1) score+=12.0*f; else score-=9.0*f;
     }
   if(rp>0.0)
     {
      double f=BPI_Clip(1.0-MathAbs(price-rp)/zone)*(0.50+0.005*rs);
      if(dir==-1) score+=12.0*f; else score-=9.0*f;
     }
   // POC is acceptance/value context, not inherently bullish or bearish.
   if(g_BPIPOC>0.0 && MathAbs(price-g_BPIPOC)<=zone*0.50)
      score+=(double)dir*(g_BPIBuyShare-0.50)*8.0;
   return MathMax(0.0,MathMin(100.0,score));
  }

double GI_LocationScore(int dir)
  {
   if(dir==0) return 0.0;
   double score=35.0;
   if((dir==1 && g_SMC.bull_zone_near)||(dir==-1 && g_SMC.bear_zone_near)) score+=20.0;
   if((dir==1 && g_SMC.bull_liq_sweep)||(dir==-1 && g_SMC.bear_liq_sweep)) score+=15.0;
   if(dir==1 && g_SMC.pd_location<=-0.15) score+=12.0;
   if(dir==-1 && g_SMC.pd_location>=0.15) score+=12.0;

   double p=MidPrice();
   if(g_NVP.valid && p>0.0)
     {
      if(dir==1 && p<=g_NVP.val + MathMax(CurrentATR5*0.35,_Point*10.0)) score+=10.0;
      if(dir==-1 && p>=g_NVP.vah - MathMax(CurrentATR5*0.35,_Point*10.0)) score+=10.0;
      if(dir==1 && p>g_NVP.vah) score-=5.0;
      if(dir==-1 && p<g_NVP.val) score-=5.0;
     }

   double z=MathAbs(GetVWAPZ());
   if(z>2.0) score-=8.0;
   else if(z>1.25) score-=3.0;

   score=Clamp(score,0.0,100.0);
   if(UseBGBIProfileIntel && g_BPIValid)
     {
      double w=BPI_Clip(BGBIProfileInfluence);
      w=MathMin(w,0.45); // keep the existing SMC/VWAP location stack dominant
      double profileScore=BPI_LocationScore(dir);
      score=score*(1.0-w)+profileScore*w;
     }
   return Clamp(score,0.0,100.0);
  }

double GI_MTFCoherence(int dir)
  {
   if(dir==0) return 0.0;
   double score=20.0;
   int aligned=0, opposed=0;
   if(M15Direction==dir) {score+=18.0;aligned++;}
   else if(M15Direction==-dir){score-=8.0;opposed++;}
   if(M5Direction==dir) {score+=18.0;aligned++;}
   else if(M5Direction==-dir){score-=8.0;opposed++;}
   if(g_SMC.m15_bias==dir) {score+=7.0;aligned++;}
   else if(g_SMC.m15_bias==-dir){score-=3.0;opposed++;}
   if(g_SMC.m5_bias==dir) {score+=7.0;aligned++;}
   else if(g_SMC.m5_bias==-dir){score-=3.0;opposed++;}
   if(M1PA_Dir==dir) {score+=10.0;aligned++;}
   else if(M1PA_Dir==-dir){score-=4.0;opposed++;}
   if(g_GI.m1LeadDir==dir) {score+=8.0;aligned++;}
   else if(g_GI.m1LeadDir==-dir){score-=5.0;opposed++;}
   if(g_GI.m1LeadConfirmed && g_GI.m1LeadDir==dir) {score+=5.0;aligned++;}
   if(g_M5ThesisDir==dir) {score+=6.0;aligned++;}
   else if(g_M5ThesisDir==-dir){score-=4.0;opposed++;}
   if(g_FastTrendDir==dir && g_FastTrendScore>=50.0) score+=8.0;
   if(g_FastTrendDir==-dir && g_FastTrendScore>=60.0) score-=8.0;
   if(aligned>=4) score+=8.0;
   if(opposed>=3) score-=8.0;
   return Clamp(score,0.0,100.0);
  }

double GI_ExhaustionScore(int dir)
  {
   if(dir==0) return 0.0;
   double score=0.0;
   double h=TfHigh(PERIOD_M1,0), l=TfLow(PERIOD_M1,0), o=TfOpen(PERIOD_M1,0), c=TfClose(PERIOD_M1,0);
   double atr=CurrentATR1;
   if(h>0.0 && l>0.0 && o>0.0 && c>0.0 && atr>0.0)
     {
      double r=h-l;
      if(r>0.0)
        {
         double ext=r/atr;
         double body=MathAbs(c-o)/r;
         double uw=(h-MathMax(o,c))/r;
         double lw=(MathMin(o,c)-l)/r;
         if(ext>=1.20) score+=12.0;
         if(ext>=1.60) score+=13.0;
         if(ext>=2.00) score+=10.0;
         if(body<0.45) score+=8.0;
         if(dir==1 && uw>=0.35) score+=10.0;
         if(dir==-1 && lw>=0.35) score+=10.0;
         if(dir==1 && c<o && uw>=0.25) score+=6.0;
         if(dir==-1 && c>o && lw>=0.25) score+=6.0;
        }
     }

   double vr=GI_M1VolumeRatio();
   if(vr>=1.40) score+=6.0;
   if(vr>=1.80) score+=8.0;
   if(vr>=2.50) score+=6.0;

   double z=MathAbs(GetVWAPZ());
   if(z>=1.25) score+=5.0;
   if(z>=1.80) score+=7.0;
   if(z>=2.30) score+=6.0;

   double rsi5=BufVal(hRSI_M5,0,1);
   if(dir==1 && rsi5>=70.0) score+=8.0;
   if(dir==-1 && rsi5<=30.0) score+=8.0;

   // A move is more likely exhausted if participation decelerates while
   // price continues extending in the same direction.
   if(BridgeReady())
     {
      double fc=FlowComposite()*(double)dir;
      if(fc<10.0) score+=7.0;
      if(fc<0.0) score+=10.0;
      if(CVDAccelerationNormalized*(double)dir < -0.05) score+=9.0;
      if(gFlow.persistence<0.25) score+=4.0;
      if(gBinAux.valid && gBinAux.oi_delta_1m*(double)dir<0.0) score+=5.0;
     }

   // Price entering the opposite structural zone is a classic late-stage condition.
   if(dir==1 && g_SMC.bear_zone_near) score+=10.0;
   if(dir==-1 && g_SMC.bull_zone_near) score+=10.0;

   // High sweep against the current directional thesis increases exhaustion.
   if(dir==1 && (M1PA_BearSweep || g_SMC.bear_liq_sweep)) score+=10.0;
   if(dir==-1 && (M1PA_BullSweep || g_SMC.bull_liq_sweep)) score+=10.0;

   // V1 transition intelligence: Lux phase maturity + spectral regime change.
   if(dir==1 && g_GI.luxBullExhaustion>=9) score+=8.0;
   if(dir==-1 && g_GI.luxBearExhaustion>=9) score+=8.0;
   if(g_GI.spectralState==GI_SPEC_NOISY) score+=6.0;
   if(g_GI.spectralTransition>=45.0) score+=8.0;
   return Clamp(score,0.0,100.0);
  }

double GI_ReversalProbability(int dir, double exhaustion)
  {
   if(dir==0) return 0.0;
   int opp=-dir;
   double score=0.25*exhaustion;
   if((opp==1 && (M1PA_BullSweep || M1PA_BullMSS)) ||
      (opp==-1 && (M1PA_BearSweep || M1PA_BearMSS))) score+=18.0;
   if((opp==1 && M1PA_BullDisp)||(opp==-1 && M1PA_BearDisp)) score+=12.0;
   if(M1PA_Dir==opp) score+=8.0;
   if(BridgeReady())
     {
      double fc=FlowComposite()*(double)opp;
      if(fc>=BinanceMinFlowScore) score+=10.0;
      if(fc>=BinanceStrongFlowScore) score+=8.0;
      if(VNFlowCVDAccelerationStrong(opp)) score+=8.0;
      if(VNFlowCascade(opp)) score+=6.0;
     }
   if((opp==1 && g_SMC.m5_event==1)||(opp==-1 && g_SMC.m5_event==-1)) score+=8.0;
   if((opp==1 && g_SMC.bull_zone_near)||(opp==-1 && g_SMC.bear_zone_near)) score+=8.0;
   if((opp==1 && VolSurgeBull_sig)||(opp==-1 && VolSurgeBear_sig)) score+=4.0;

   // Transition evidence is reversal evidence only when it points to the opposite side.
   if((opp==1 && g_GI.luxBullFlip)||(opp==-1 && g_GI.luxBearFlip)) score+=10.0;
   if((opp==1 && g_GI.luxBullExhaustion>=9)||(opp==-1 && g_GI.luxBearExhaustion>=9)) score+=10.0;
   if(g_GI.spectralDirection==opp && g_GI.spectralTransition>=35.0) score+=8.0;
   return Clamp(score,0.0,100.0);
  }

//===================================================================
// GENESIS V1 — CAUSAL LUX-STYLE MOMENTUM / EXHAUSTION STATE MACHINE
// Based on the user-supplied LuxAlgo Reversal Signals phase concepts.
// No plots/alerts are ported; only causal phase evidence is retained.
//===================================================================
void GI_UpdateLuxPhase()
  {
   g_GI.luxBullMomentum=0; g_GI.luxBearMomentum=0;
   g_GI.luxBullExhaustion=0; g_GI.luxBearExhaustion=0;
   g_GI.luxBullComplete=false; g_GI.luxBearComplete=false;
   g_GI.luxBullCompleteAge=9999; g_GI.luxBearCompleteAge=9999;
   g_GI.luxBullFlip=false; g_GI.luxBearFlip=false;
   g_GI.luxState=GI_LUX_NONE; g_GI.luxTransitionScore=0.0;
   if(!GenesisIntelUseLuxPhase) return;

   ENUM_TIMEFRAMES tf=GenesisIntelLuxTF;
   int lb=MathMax(40,GenesisIntelLuxLookback);
   if(Bars(_Symbol,tf)<lb+8) return;

   int bullSC=0,bearSC=0,bullCC=0,bearCC=0;
   bool bullExh=false,bearExh=false;
   double bullC8=0.0,bearC8=0.0;
   bool prevPbS=false,prevPsS=false;
   int prevBullSC=0,prevBearSC=0;
   int bullCompAge=-1,bearCompAge=-1;

   for(int s=lb;s>=0;--s)
     {
      double c=TfClose(tf,s),c4=TfClose(tf,s+4);
      double h=TfHigh(tf,s),l=TfLow(tf,s);
      double h1=TfHigh(tf,s+1),l1=TfLow(tf,s+1);
      double h2=TfHigh(tf,s+2),l2=TfLow(tf,s+2);
      double h3=TfHigh(tf,s+3),l3=TfLow(tf,s+3);
      if(c<=0.0 || c4<=0.0 || h<=0.0 || l<=0.0) continue;

      if(c<c4) { bullSC=(bullSC==9)?1:bullSC+1; bearSC=0; }
      else     { bearSC=(bearSC==9)?1:bearSC+1; bullSC=0; }

      bool pbS=((l<=l3 && l<=l2) || (l1<=l3 && l1<=l2));
      bool psS=((h>=h3 && h>=h2) || (h1>=h3 && h1>=h2));
      bool bC8=(prevBullSC==8 && bearSC==1);
      bool sC8=(prevBearSC==8 && bullSC==1);

      // Count bars since the most recent momentum completion.
      if(bullCompAge>=0) bullCompAge++;
      if(bearCompAge>=0) bearCompAge++;
      if(bullSC==9 || bC8) { bullCompAge=0; bullC8=c; }
      if(bearSC==9 || sC8) { bearCompAge=0; bearC8=c; }

      if(bullSC==9 && bullCC==0 && (pbS || prevPbS)) bullExh=true;
      else if(bearSC==9 || bullCC>=13 || (bullC8>0.0 && c>bullC8)) bullExh=false;
      if(bearSC==9 && bearCC==0 && (psS || prevPsS)) bearExh=true;
      else if(bullSC==9 || bearCC>=13 || (bearC8>0.0 && c<bearC8)) bearExh=false;

      bool bCC=(c<=l2),sCC=(c>=h2);
      if(bullExh)
        {
         if(bullSC==9) bullCC=bCC?1:0;
         else if(bCC) bullCC++;
         if(bullCC==13 && bullC8>0.0 && l>=bullC8) bullCC=12;
        }
      else bullCC=0;

      if(bearExh)
        {
         if(bearSC==9) bearCC=sCC?1:0;
         else if(sCC) bearCC++;
         if(bearCC==13 && bearC8>0.0 && h<=bearC8) bearCC=12;
        }
      else bearCC=0;

      prevPbS=pbS; prevPsS=psS;
      prevBullSC=bullSC; prevBearSC=bearSC;
     }

   g_GI.luxBullMomentum=bullSC;
   g_GI.luxBearMomentum=bearSC;
   g_GI.luxBullExhaustion=MathMin(13,bullCC);
   g_GI.luxBearExhaustion=MathMin(13,bearCC);

   // Only a recent momentum completion is actionable as a transition marker.
   const int recentBars=5;
   g_GI.luxBullComplete=(bullCompAge>=0 && bullCompAge<=recentBars);
   g_GI.luxBearComplete=(bearCompAge>=0 && bearCompAge<=recentBars);
   g_GI.luxBullCompleteAge=(bullCompAge>=0?bullCompAge:9999);
   g_GI.luxBearCompleteAge=(bearCompAge>=0?bearCompAge:9999);

   double c0=TfClose(tf,0),c4x=TfClose(tf,4),c1=TfClose(tf,1),c5=TfClose(tf,5);
   if(c0>0.0 && c4x>0.0 && c1>0.0 && c5>0.0)
     {
      // Price-flip tests are intrabar/current-bar aware, matching the M1 timing philosophy.
      g_GI.luxBullFlip=(c0>c4x && c1<c5);
      g_GI.luxBearFlip=(c0<c4x && c1>c5);
     }

   double tr=0.0;
   if(g_GI.luxBullComplete) tr+=14.0;
   if(g_GI.luxBearComplete) tr+=14.0;
   if(g_GI.luxBullExhaustion>=9) tr+=16.0;
   if(g_GI.luxBearExhaustion>=9) tr+=16.0;
   if(g_GI.luxBullExhaustion>=13) tr+=18.0;
   if(g_GI.luxBearExhaustion>=13) tr+=18.0;
   if(g_GI.luxBullFlip) tr+=GenesisIntelLuxFlipBoost;
   if(g_GI.luxBearFlip) tr+=GenesisIntelLuxFlipBoost;
   g_GI.luxTransitionScore=Clamp(tr,0.0,100.0);

   if(g_GI.luxBullExhaustion>=GenesisIntelLuxExhaustionWarn || g_GI.luxBullComplete)
      g_GI.luxState=GI_LUX_BULL_EXHAUSTION;
   if(g_GI.luxBearExhaustion>=GenesisIntelLuxExhaustionWarn || g_GI.luxBearComplete)
      g_GI.luxState=GI_LUX_BEAR_EXHAUSTION;
   if(g_GI.luxBullFlip) g_GI.luxState=GI_LUX_BULL_FLIP;
   if(g_GI.luxBearFlip) g_GI.luxState=GI_LUX_BEAR_FLIP;

   if(g_GI.luxBullExhaustion>=GenesisIntelLuxExhaustionHigh && g_GI.luxBullFlip)
     {
      g_GI_LuxTransitionDir=1;
      g_GI_LuxTransitionTime=TimeCurrent();
     }
   else if(g_GI.luxBearExhaustion>=GenesisIntelLuxExhaustionHigh && g_GI.luxBearFlip)
     {
      g_GI_LuxTransitionDir=-1;
      g_GI_LuxTransitionTime=TimeCurrent();
     }
  }

//===================================================================
// GENESIS V1 — CAUSAL SPECTRAL REGIME SENSOR
// Inspired by the user-supplied Loxx RFFTP. Completed bars only.
//===================================================================
void GI_UpdateSpectral()
  {
   g_GI.spectralSlopeATR=0.0; g_GI.spectralLowFrac=0.0; g_GI.spectralHighFrac=0.0;
   g_GI.spectralConcentration=0.0; g_GI.spectralTransition=0.0;
   g_GI.spectralDirection=0; g_GI.spectralState=GI_SPEC_UNKNOWN;
   if(!GenesisIntelUseSpectral) return;
   ENUM_TIMEFRAMES tf=GenesisIntelSpectralTF;
   int requested=GenesisIntelSpectralWindow,N=16;
   if(requested>=32) N=32; if(requested>=64) N=64; if(requested>=128) N=128; if(requested>=256) N=256;
   if(Bars(_Symbol,tf)<N+10) return;
   double sx=0,sy=0,sxx=0,sxy=0;
   for(int k=0;k<N;k++){ double p=TfClose(tf,N-k),x=(double)k; sx+=x; sy+=p; sxx+=x*x; sxy+=x*p; }
   double den=(double)N*sxx-sx*sx; if(MathAbs(den)<1e-12) return;
   double slope=((double)N*sxy-sx*sy)/den,intercept=(sy-slope*sx)/(double)N;
   double atr=CurrentATR5; if(tf==PERIOD_M1) atr=CurrentATR1; else if(tf==PERIOD_M15) atr=CurrentATR15; if(atr<=0) atr=1.0;
   double r[256]; for(int k=0;k<N;k++) r[k]=TfClose(tf,N-k)-(intercept+slope*(double)k);
   double total=0,low=0,high=0,dom=0;
   for(int f=1;f<=N/2-1;f++)
     {
      double re=0,im=0;
      for(int k=0;k<N;k++){ double a=6.283185307179586*(double)f*(double)k/(double)N; re+=r[k]*MathCos(a); im-=r[k]*MathSin(a); }
      double e=re*re+im*im; total+=e; if(e>dom) dom=e; if(f<=MathMax(1,N/8)) low+=e; if(f>=MathMax(2,N/4)) high+=e;
     }
   if(total<=0) return;
   g_GI.spectralLowFrac=Clamp(low/total,0,1); g_GI.spectralHighFrac=Clamp(high/total,0,1);
   g_GI.spectralConcentration=Clamp(dom/total,0,1); g_GI.spectralSlopeATR=Clamp((slope*(double)N)/atr,-5,5);
   g_GI.spectralDirection=(g_GI.spectralSlopeATR>=GenesisIntelSpectralSlopeMinATR)?1:(g_GI.spectralSlopeATR<=-GenesisIntelSpectralSlopeMinATR?-1:0);
   if(g_GI.spectralHighFrac>=GenesisIntelSpectralNoiseHigh && MathAbs(g_GI.spectralSlopeATR)<GenesisIntelSpectralSlopeMinATR*1.5) g_GI.spectralState=GI_SPEC_NOISY;
   else if(g_GI.spectralLowFrac>=GenesisIntelSpectralLowFracMin && g_GI.spectralHighFrac<=GenesisIntelSpectralHighFracMax && MathAbs(g_GI.spectralSlopeATR)>=GenesisIntelSpectralSlopeMinATR) g_GI.spectralState=GI_SPEC_DIRECTIONAL;
   else if(g_GI.spectralHighFrac>g_GI.spectralLowFrac) g_GI.spectralState=GI_SPEC_CYCLIC;
   else g_GI.spectralState=GI_SPEC_TRANSITION;
   double tr=0;
   if(g_GI_PrevSpectralDir!=0 && g_GI.spectralDirection!=0 && g_GI.spectralDirection!=g_GI_PrevSpectralDir) tr+=45;
   if(MathAbs(g_GI.spectralLowFrac-g_GI_PrevSpectralLowFrac)>=GenesisIntelSpectralFlipGap) tr+=20;
   if(MathAbs(g_GI.spectralHighFrac-g_GI_PrevSpectralHighFrac)>=GenesisIntelSpectralFlipGap) tr+=15;
   if(g_GI.spectralState==GI_SPEC_NOISY) tr+=10; if(g_GI.spectralState==GI_SPEC_TRANSITION) tr+=12;
   g_GI.spectralTransition=Clamp(tr,0,100);
   g_GI_PrevSpectralSlopeATR=g_GI.spectralSlopeATR; g_GI_PrevSpectralLowFrac=g_GI.spectralLowFrac;
   g_GI_PrevSpectralHighFrac=g_GI.spectralHighFrac; g_GI_PrevSpectralConc=g_GI.spectralConcentration;
   g_GI_PrevSpectralDir=g_GI.spectralDirection; g_GI_SpectralUpdateTime=TimeCurrent();
  }

double GI_LuxDirectionalEvidence(int dir)
  {
   if(dir==0 || !GenesisIntelUseLuxPhase) return 0.0;
   double s=0.0;

   // Momentum phase is directional evidence. Exhaustion is deliberately NOT
   // rewarded here; it is handled separately by the exhaustion/reversal brain.
   if(dir==1)
     {
      if(g_GI.luxBullMomentum>=5) s+=8.0;
      if(g_GI.luxBullMomentum>=8) s+=8.0;
      if(g_GI.luxBullComplete) s+=10.0;
      if(g_GI.luxBullFlip) s+=25.0;
     }
   else
     {
      if(g_GI.luxBearMomentum>=5) s+=8.0;
      if(g_GI.luxBearMomentum>=8) s+=8.0;
      if(g_GI.luxBearComplete) s+=10.0;
      if(g_GI.luxBearFlip) s+=25.0;
     }

   return Clamp(s,0.0,51.0);
  }

double GI_SpectralDirectionalEvidence(int dir)
  {
   if(dir==0 || !GenesisIntelUseSpectral) return 0.0; double s=0.0;
   if(g_GI.spectralDirection==dir) s+=25; if(g_GI.spectralState==GI_SPEC_DIRECTIONAL) s+=18;
   if(g_GI.spectralState==GI_SPEC_CYCLIC) s-=10; if(g_GI.spectralState==GI_SPEC_NOISY) s-=18;
   return Clamp(s,0,43);
  }

double GI_EliteStateTransition(int dominantDir,double baseTransition)
  {
   double s=baseTransition;
   if(GenesisIntelUseLuxPhase) s+=g_GI.luxTransitionScore*0.30;
   if(GenesisIntelUseSpectral) s+=g_GI.spectralTransition*0.25;
   if(g_GI.luxBullFlip || g_GI.luxBearFlip) s+=10;
   if(g_GI.spectralState==GI_SPEC_NOISY) s+=6;
   if(dominantDir!=0 && g_GI.spectralDirection!=0 && g_GI.spectralDirection!=dominantDir) s+=10;
   if(g_GI_LuxTransitionDir!=0 && dominantDir!=0 && g_GI_LuxTransitionDir!=dominantDir && TimeCurrent()-g_GI_LuxTransitionTime<=30) s+=12;
   return Clamp(s,0,100);
  }

int GenesisIntel_MaxPositionsAllowed()
  {
   int cap=MathMax(1,GenesisIntelNormalMaxPositions);
   if(g_GI.action==GI_REVERSAL) cap=MathMax(cap,GenesisIntelReversalMaxPositions);
   else if(g_GI.phase==GI_PHASE_ACCELERATION || g_GI.phase==GI_PHASE_EXPANSION) cap=MathMax(cap,GenesisIntelExpansionMaxPositions);
   if((g_GI.phase==GI_PHASE_ACCELERATION || g_GI.phase==GI_PHASE_EXPANSION) && g_GI.finalConfidence>=GenesisIntelMonsterConf && g_GI.exhaustionScore<55) cap=MathMax(cap,GenesisIntelMonsterMaxPositions);
   if(g_GI.phase==GI_PHASE_CLIMAX || g_GI.phase==GI_PHASE_EXHAUSTION) cap=MathMin(cap,GenesisIntelNormalMaxPositions);
   return MathMin(cap,MathMin(GenesisIntelMaxPositions,V1Risk_EffectivePairMaxPositions()));
  }

int GenesisIntel_MaxEntriesAllowed()
  {
   int cap=MathMax(1,GenesisIntelNormalMaxEntries);
   if(g_GI.action==GI_REVERSAL) cap=MathMax(cap,GenesisIntelReversalMaxEntries);
   else if(g_GI.phase==GI_PHASE_ACCELERATION || g_GI.phase==GI_PHASE_EXPANSION) cap=MathMax(cap,GenesisIntelExpansionMaxEntries);
   if((g_GI.phase==GI_PHASE_ACCELERATION || g_GI.phase==GI_PHASE_EXPANSION) && g_GI.finalConfidence>=GenesisIntelMonsterConf && g_GI.exhaustionScore<55) cap=MathMax(cap,GenesisIntelMonsterMaxEntries);
   if(g_GI.phase==GI_PHASE_CLIMAX || g_GI.phase==GI_PHASE_EXHAUSTION) cap=MathMin(cap,GenesisIntelNormalMaxEntries);
   return MathMin(cap,GenesisIntelMaxEntriesCampaign);
  }

double GI_TransitionProbability()
  {
   double score=20.0;
   if(g_R7Pending!=g_R7) score+=18.0;
   if(g_CUSUMDir!=0 && TimeCurrent()<=g_CUSUMOverrideUntil) score+=20.0;
   if(NormalATR5>0.0 && CurrentATR5/NormalATR5>1.15) score+=10.0;
   if(GI_M5VolumeRatio()>1.25) score+=8.0;
   if(GI_TradeRateRatio()>1.25) score+=8.0;
   if(MathAbs(CVDAccelerationNormalized)>=0.08) score+=8.0;
   if(MathAbs(M1PA_Score)>=M1PA_BoostScore) score+=5.0;
   if(M5Direction!=0 && M1PA_Dir!=0 && M1PA_Dir!=M5Direction) score+=10.0;
   return Clamp(score,0.0,100.0);
  }

double GI_IgnitionScore(int dir,double flowPressure,double transitionProbability)
  {
   if(dir==0) return 0.0;
   double score=0.0;
   double o=TfOpen(PERIOD_M1,0), c=TfClose(PERIOD_M1,0), h=TfHigh(PERIOD_M1,0), l=TfLow(PERIOD_M1,0);
   double atr=CurrentATR1;
   double vr=GI_M1VolumeRatio();
   double rr=(atr>0.0 && h>0.0 && l>0.0)?(h-l)/atr:0.0;
   double br=(h>l && o>0.0 && c>0.0)?MathAbs(c-o)/(h-l):0.0;
   if(rr>=0.85) score+=12.0;
   if(rr>=1.20) score+=15.0;
   if(br>=0.55) score+=10.0;
   if(vr>=1.20) score+=10.0;
   if(vr>=1.60) score+=8.0;
   if(flowPressure>=55.0) score+=15.0;
   if(flowPressure>=70.0) score+=8.0;
   if(transitionProbability>=55.0) score+=8.0;
   if(M1PA_Dir==dir && M1PA_Score>=M1PA_BoostScore) score+=10.0;
   if(g_CUSUMDir==dir && TimeCurrent()<=g_CUSUMOverrideUntil) score+=8.0;
   if(VNFlowTradeRateSurge() && BridgeReady()) score+=7.0;
   return Clamp(score,0.0,100.0);
  }

double GI_SignalFreshness()
  {
   datetime bar=TfTime(PERIOD_M1,0);
   if(bar<=0) return 0.0;
   int age=(int)(TimeCurrent()-bar);
   if(age<0) age=0;
   if(age>60) age=60;
   return Clamp(100.0-(double)age*1.60,0.0,100.0);
  }

double GI_ChaseRisk()
  {
   double atr=CurrentATR1;
   double risk=10.0;
   if(atr>0.0)
     {
      double h=TfHigh(PERIOD_M1,0), l=TfLow(PERIOD_M1,0);
      if(h>0.0 && l>0.0)
        {
         double ext=(h-l)/atr;
         if(ext>=0.80) risk+=15.0;
         if(ext>=1.20) risk+=20.0;
         if(ext>=1.60) risk+=25.0;
         if(ext>=2.00) risk+=20.0;
        }
      risk+=MathMax(0.0,MathAbs(GetVWAPZ())-0.80)*12.0;
     }
   return Clamp(risk,0.0,100.0);
  }

void GI_UpdateM1FastLead()
  {
   g_GI.m1LeadDir=0; g_GI.m1LeadScore=50.0; g_GI.m1LeadSpreadATR=0.0;
   g_GI.m1LeadSlopeATR=0.0; g_GI.m1LeadCrossUp=false; g_GI.m1LeadCrossDown=false;
   g_GI.m1LeadConfirmed=false; g_GI.m1LeadFreshness=0.0;
   g_GI.m1StructureProof=false; g_GI.m1DisplacementProof=false;
   g_GI.marketProof=false; g_GI.stopProof=false;
   if(!GenesisV3UseM1EMALead) return;
   if(hGI_M1EMA5==INVALID_HANDLE || hGI_M1EMA13==INVALID_HANDLE) return;

   double fast0=BufVal(hGI_M1EMA5,0,0), slow0=BufVal(hGI_M1EMA13,0,0);
   double fast1=BufVal(hGI_M1EMA5,0,1), slow1=BufVal(hGI_M1EMA13,0,1);
   double fast2=BufVal(hGI_M1EMA5,0,2), slow2=BufVal(hGI_M1EMA13,0,2);
   if(fast0<=0.0 || slow0<=0.0 || fast1<=0.0 || slow1<=0.0) return;

   g_GI.m1LeadDir=(fast0>slow0)?1:(fast0<slow0?-1:0);
   g_GI.m1LeadCrossUp=(fast0>slow0 && fast1<=slow1);
   g_GI.m1LeadCrossDown=(fast0<slow0 && fast1>=slow1);
   g_GI.m1LeadSpreadATR=(CurrentATR1>0.0)?MathAbs(fast0-slow0)/CurrentATR1:0.0;
   g_GI.m1LeadSlopeATR=(CurrentATR1>0.0)?(fast0-fast1)/CurrentATR1:0.0;

   double score=50.0;
   if(g_GI.m1LeadDir!=0) score+=16.0;
   if(g_GI.m1LeadSpreadATR>=GenesisV3M1LeadSpreadATR) score+=10.0;
   if(g_GI.m1LeadSpreadATR>=GenesisV3M1LeadSpreadATR*2.0) score+=6.0;
   if(g_GI.m1LeadDir==1 && g_GI.m1LeadSlopeATR>=GenesisV3M1LeadSlopeATR) score+=8.0;
   if(g_GI.m1LeadDir==-1 && g_GI.m1LeadSlopeATR<=-GenesisV3M1LeadSlopeATR) score+=8.0;
   if(g_GI.m1LeadCrossUp || g_GI.m1LeadCrossDown) score+=18.0;

   double o=TfOpen(PERIOD_M1,0), c=TfClose(PERIOD_M1,0);
   if(o>0.0 && c>0.0)
     {
      if(g_GI.m1LeadDir==1 && c>o) score+=4.0;
      if(g_GI.m1LeadDir==-1 && c<o) score+=4.0;
     }

   bool bullConfirmed=(fast1>slow1 && fast2<=slow2);
   bool bearConfirmed=(fast1<slow1 && fast2>=slow2);
   g_GI.m1LeadConfirmed=(bullConfirmed || bearConfirmed);
   if(GenesisV3M1EMAConfirmCandle)
     {
      double oc=TfOpen(PERIOD_M1,1), cc=TfClose(PERIOD_M1,1);
      if(g_GI.m1LeadDir==1) g_GI.m1LeadConfirmed=(g_GI.m1LeadConfirmed && cc>oc);
      if(g_GI.m1LeadDir==-1) g_GI.m1LeadConfirmed=(g_GI.m1LeadConfirmed && cc<oc);
     }
   if(g_GI.m1LeadConfirmed) score+=8.0;

   if(g_GI.m1LeadCrossUp || g_GI.m1LeadCrossDown)
     {
      g_GI_M1LeadCrossDir=g_GI.m1LeadDir;
      g_GI_M1LeadCrossTime=TimeCurrent();
     }
   int age=(g_GI_M1LeadCrossTime>0)?(int)(TimeCurrent()-g_GI_M1LeadCrossTime):9999;
   if(age<0) age=0;
   g_GI.m1LeadFreshness=(age<=60)?Clamp(100.0-(double)age*1.60,0.0,100.0):0.0;
   if(g_GI.m1LeadFreshness>=60.0) score+=5.0;

   g_GI.m1StructureProof=(g_GI.m1LeadDir==1)?M1PA_BullMSS:((g_GI.m1LeadDir==-1)?M1PA_BearMSS:false);
   g_GI.m1DisplacementProof=(g_GI.m1LeadDir==1)?M1PA_BullDisp:((g_GI.m1LeadDir==-1)?M1PA_BearDisp:false);
   if(g_GI.m1StructureProof) score+=8.0;
   if(g_GI.m1DisplacementProof) score+=8.0;
   g_GI.m1LeadScore=Clamp(score,0.0,100.0);
  }

double GI_M1LeadEvidence(int dir)
  {
   if(dir==0 || !GenesisV3UseM1EMALead || g_GI.m1LeadDir!=dir) return 0.0;
   return g_GI.m1LeadScore;
  }

bool GI_MarketEntryProof(int dir)
  {
   if(dir==0 || !GenesisV3UseM1EMALead || g_GI.m1LeadDir!=dir) return false;
   if(g_GI.m1LeadScore<GenesisV3M1LeadMinForMarket) return false;
   if(!g_GI.m1StructureProof || !g_GI.m1DisplacementProof) return false;
   if(g_GI.exhaustionScore>=GenesisV3MarketMaxExhaustion) return false;
   if(g_GI.chaseRisk>GenesisV3MarketMaxChase) return false;

   double flow=GI_FlowPressure(dir), oppFlow=GI_FlowPressure(-dir);
   if(flow<GenesisV3MarketMinFlow) return false;
   if(BridgeReady() && GenesisIntelUseFlowOnBridge && flow-oppFlow<GenesisV3MarketFlowGap) return false;

   if(g_GI.transitionProbability>=GenesisIntelFlipGuardTransition &&
      g_GI.m1LeadDir!=g_GI.direction && g_GI.reversalProbability>=GenesisIntelFlipGuardReversal)
      return false;
   return true;
  }

bool GI_ProofStopFor(int dir)
  {
   if(dir==0 || !GenesisV3UseM1EMALead || g_GI.m1LeadDir!=dir) return false;
   if(g_GI.m1LeadScore<GenesisV3M1LeadMinForStop) return false;
   bool structure=g_GI.m1StructureProof || g_GI.m1DisplacementProof;
   bool freshCross=(g_GI.m1LeadFreshness>=55.0 && (g_GI.m1LeadCrossUp || g_GI.m1LeadCrossDown));
   if(!structure && !freshCross) return false;
   if(g_GI.exhaustionScore>=75.0) return false;
   if(g_GI.ignitionScore<GenesisV3ProofStopMinIgnition &&
      g_GI.transitionProbability<GenesisV3ProofStopMinTransition) return false;

   double flow=GI_FlowPressure(dir), oppFlow=GI_FlowPressure(-dir);
   if(BridgeReady() && GenesisIntelUseFlowOnBridge)
     {
      if(flow<GenesisIntelMinFlowBridge) return false;
      if(flow-oppFlow<GenesisIntelFastTransitionFlowGap && g_GI.transitionProbability<70.0) return false;
     }
   g_GI.stopProof=true;
   return true;
  }

bool GI_HasProofPending()
  {
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      if(StringFind(ordInfo.Comment(),"GENESIS_INTEL_PROOF_")>=0) return true;
     }
   return false;
  }

bool GenesisIntel_ArmProofStop()
  {
   if(!UseGenesisIntelligence || !GenesisV3UseM1EMALead) return false;
   if(CountOurPositions()>0) return false;
   if(GenesisV3OneProofStopPerCampaign && GI_HasProofPending()) return false;
   if(g_GI_EntriesCampaign>=GenesisIntel_MaxEntriesAllowed()) return false;
   if(TimeCurrent()<PauseUntil || DailyHalted || GlobalHalted) return false;
   if(g_GI_LastEntry>0 && TimeCurrent()-g_GI_LastEntry<GenesisIntelEntryCooldownSec) return false;
   if(!Health_AllowsNewEntries() || !SpreadOK() || !SessionAllowed() || !HourFilterOK() || WickPauseActive()) return false;

   int dir=g_GI.m1LeadDir;
   if(dir==0 || !GI_ProofStopFor(dir)) return false;
   if(LegacyCampaign_CountPending()>0) return false;

   double atr=CurrentATR1; if(atr<=0.0) atr=CurrentATR5;
   if(atr<=0.0) return false;
   double bid=BidPrice(), ask=AskPrice(); if(bid<=0.0 || ask<=0.0) return false;
   double minDist=MathMax(StopsLevelPrice()*1.10,_Point*2.0);
   double maxDist=MathMax(atr*GenesisV3ProofStopMaxDistanceATR,minDist*2.0);
   double buffer=MathMax(atr*GenesisV3ProofStopBufferATR,StopsLevelPrice()*0.25);
   double ref=0.0,entry=0.0;
   if(dir==1)
     {
      ref=M1RecentSwingHigh(ref);
      entry=(ref>ask+minDist)?ref+buffer:ask+MathMax(minDist,atr*0.18);
      entry=MathMin(entry,ask+maxDist);
     }
   else
     {
      ref=M1RecentSwingLow(ref);
      entry=(ref<bid-minDist)?ref-buffer:bid-MathMax(minDist,atr*0.18);
      entry=MathMax(entry,bid-maxDist);
     }
   if(entry<=0.0) return false;

   double lot=ValidateLot(MathMin(GenesisIntel_Lot(),GenesisIntelBaseLot));
   if(lot<=0.0) return false;
   double slDist=GenesisIntel_SLDistance(), tpDist=GenesisIntel_TPDistance(slDist);
   double sl=(dir==1)?entry-slDist:entry+slDist;
   double tp=(dir==1)?entry+tpDist:entry-tpDist;
   string cmt="GENESIS_INTEL_PROOF_"+(dir==1?"B":"S");
   bool ok=(dir==1)?SendBuyStop(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt):
                      SendSellStop(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt);
   if(ok)
     {
      g_GI_EntriesCampaign++;
      g_GI_LastEntry=TimeCurrent();
      g_GI_LastActionDir=dir;
      g_GI_LastAction=GI_ATTACK;
      PrintFormat("[GENESIS V3 PROOF STOP] dir=%s trigger=%.*f lot=%.3f lead=%.1f mss=%d disp=%d flow=%.1f tr=%.1f ign=%.1f",
                  DirStr(dir),_Digits,entry,lot,g_GI.m1LeadScore,(int)g_GI.m1StructureProof,
                  (int)g_GI.m1DisplacementProof,GI_FlowPressure(dir),g_GI.transitionProbability,g_GI.ignitionScore);
     }
   return ok;
  }

void GI_UpdateM5EMAThesis()
  {
   g_GI.m5ThesisDir=0;
   g_GI.m5ThesisScore=50.0;
   g_GI.m5ThesisSpreadATR=0.0;
   g_GI.m5ThesisCrossUp=false;
   g_GI.m5ThesisCrossDown=false;
   if(!GenesisIntelUseM5EMAThesis) return;
   if(hGI_M5EMA5==INVALID_HANDLE || hGI_M5EMA13==INVALID_HANDLE) return;

   double fast1=BufVal(hGI_M5EMA5,0,1);
   double slow1=BufVal(hGI_M5EMA13,0,1);
   double fast2=BufVal(hGI_M5EMA5,0,2);
   double slow2=BufVal(hGI_M5EMA13,0,2);
   if(fast1<=0.0 || slow1<=0.0 || fast2<=0.0 || slow2<=0.0) return;

   g_GI.m5ThesisCrossUp=(fast1>slow1 && fast2<=slow2);
   g_GI.m5ThesisCrossDown=(fast1<slow1 && fast2>=slow2);
   g_GI.m5ThesisDir=(fast1>slow1)?1:(fast1<slow1?-1:0);

   double atr=CurrentATR5;
   if(atr<=0.0) atr=CurrentATR1;
   g_GI.m5ThesisSpreadATR=(atr>0.0)?MathAbs(fast1-slow1)/atr:0.0;
   double score=50.0;
   if(g_GI.m5ThesisDir!=0) score+=22.0;
   if(g_GI.m5ThesisSpreadATR>=GenesisIntelM5EMASpreadBoostATR) score+=12.0;
   if(g_GI.m5ThesisSpreadATR>=GenesisIntelM5EMASpreadBoostATR*2.0) score+=6.0;
   double fastSlope=(atr>0.0)?(fast1-fast2)/atr:0.0;
   if(g_GI.m5ThesisDir==1 && fastSlope>0.02) score+=5.0;
   if(g_GI.m5ThesisDir==-1 && fastSlope<-0.02) score+=5.0;
   if(GenesisIntelM5EMAConfirmCandle)
     {
      double o=TfOpen(PERIOD_M5,1), c=TfClose(PERIOD_M5,1);
      if(o>0.0 && c>0.0)
        {
         if(g_GI.m5ThesisDir==1 && c>o) score+=5.0;
         if(g_GI.m5ThesisDir==-1 && c<o) score+=5.0;
        }
     }
   if(g_GI.m5ThesisCrossUp || g_GI.m5ThesisCrossDown) score+=GenesisIntelM5EMAFlipBoost;
   g_GI.m5ThesisScore=Clamp(score,0.0,100.0);
  }

int GI_ExistingPositionDirection()
  {
   int found=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      int d=(posInfo.PositionType()==POSITION_TYPE_BUY)?1:-1;
      if(found==0) found=d;
      else if(found!=d) return 0;
     }
   return found;
  }

bool GI_HasTransitionPending(int dir)
  {
   if(dir==0) return false;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      string c=ordInfo.Comment();
      if(StringFind(c,"GENESIS_INTEL_TRANSITION_")<0) continue;
      ENUM_ORDER_TYPE t=ordInfo.OrderType();
      int odir=(t==ORDER_TYPE_BUY_STOP || t==ORDER_TYPE_BUY_LIMIT || t==ORDER_TYPE_BUY_STOP_LIMIT)?1:-1;
      if(odir==dir) return true;
     }
   return false;
  }

bool GI_IsFastTransitionFor(int newDir,int oldDir)
  {
   if(newDir==0 || oldDir==0 || newDir!=-oldDir) return false;
   if(!GenesisV3UseOppositeTransitionStops || !GenesisIntelUseTransitionStops) return false;
   if(g_GI.transitionProbability<GenesisIntelFastTransitionMin) return false;
   bool mss=(newDir==1)?M1PA_BullMSS:M1PA_BearMSS;
   bool disp=(newDir==1)?M1PA_BullDisp:M1PA_BearDisp;
   bool structureProof=(mss && disp);
   bool leadProof=(g_GI.m1LeadDir==newDir && g_GI.m1LeadScore>=GenesisV3M1LeadMinForStop &&
                   (g_GI.m1LeadCrossUp || g_GI.m1LeadCrossDown || g_GI.m1LeadFreshness>=55.0));
   if(!structureProof && !leadProof) return false;
   double newFlow=GI_FlowPressure(newDir), oldFlow=GI_FlowPressure(oldDir);
   if(newFlow<GenesisIntelFastTransitionFlow) return false;
   if(newFlow-oldFlow<GenesisIntelFastTransitionFlowGap && !structureProof) return false;
   bool sensor=((newDir==1 && g_GI.luxBullFlip) || (newDir==-1 && g_GI.luxBearFlip) ||
                g_GI.spectralTransition>=35.0 || g_GI.exhaustionScore>=GenesisIntelFastTransitionExhaust ||
                g_GI.m1LeadScore>=GenesisV3M1LeadStrong);
   if(!sensor) return false;
   bool m5Flip=(newDir==1 && g_GI.m5ThesisDir==1 && g_GI.m5ThesisCrossUp) ||
               (newDir==-1 && g_GI.m5ThesisDir==-1 && g_GI.m5ThesisCrossDown);
   bool fastProof=(structureProof && leadProof && newFlow>=GenesisV3MarketMinFlow);
   if(g_GI.reversalProbability<GenesisIntelFastTransitionReversal && !m5Flip && !fastProof) return false;
   return true;
  }


// Forward declarations used by the V4 execution governor.
bool Genesis_M5TrueReversal();
bool GenesisIntel_SafetyGate(int dir);

//===================================================================
// SECTION 102A-V4 — DUAL DIRECTION + POST-FILL DEFENSE
// Genesis remains the core. V4 changes only how direction becomes an
// executable order and how a fresh fill is defended against reversal.
//===================================================================
int V4_M5PrimaryDir()
  {
   if(!GenesisV4Enable || !GenesisV4M5OwnsDirectionalThesis) return 0;
   if(g_GI.m5ThesisDir==0 || g_GI.m5ThesisScore<GenesisV4M5ThesisMinScore) return 0;
   return g_GI.m5ThesisDir;
  }

int V4_M1TacticalDir()
  {
   if(!GenesisV4Enable) return 0;
   if(M1PA_Dir==0 || M1PA_Score<GenesisV4M1TacticalMinScore) return 0;
   bool mss=(M1PA_Dir==1)?M1PA_BullMSS:M1PA_BearMSS;
   bool disp=(M1PA_Dir==1)?M1PA_BullDisp:M1PA_BearDisp;
   bool sweep=(M1PA_Dir==1)?M1PA_BullSweep:M1PA_BearSweep;
   if(!(mss || disp || sweep)) return 0;
   return M1PA_Dir;
  }

bool V4_M5ThesisValidFor(int dir)
  {
   if(!GenesisV4Enable || dir==0) return false;
   int m5=V4_M5PrimaryDir();
   if(!GenesisV4RequireM5ForContinuation) return (m5==0 || m5==dir);
   return (m5==dir);
  }

double V4_CycleExtensionATR(int dir)
  {
   if(dir==0) return 0.0;
   double atr=CurrentATR1;
   if(atr<=0.0) atr=CurrentATR5;
   if(atr<=0.0) return 0.0;
   double now=(dir==1)?AskPrice():BidPrice();
   double ref=TfClose(PERIOD_M1,7);
   if(now<=0.0 || ref<=0.0) return 0.0;
   double favorable=(dir==1)?(now-ref):(ref-now);
   return favorable/atr;
  }

bool V4_FreshEventFor(int dir)
  {
   if(dir==0) return false;
   bool m1pa=(V4_M1TacticalDir()==dir);
   bool structure=(dir==1)?(M1PA_BullMSS||M1PA_BullDisp||M1PA_BullSweep)
                          :(M1PA_BearMSS||M1PA_BearDisp||M1PA_BearSweep);
   if(!m1pa && !structure) return false;
   bool recentLead=(g_GI_M1LeadCrossTime>0 && TimeCurrent()-g_GI_M1LeadCrossTime<=GenesisV4SignalFreshnessSec);
   if(g_GI.m1LeadFreshness<55.0 && !structure && !recentLead) return false;
   if(V4_CycleExtensionATR(dir)>GenesisV4MaxCycleExtensionATR) return false;
   return true;
  }


// V2 fallback confirmation uses only the last CLOSED M1 candle (shift 1).
// It may substitute for the tactical classifier returning neutral, but never for
// M5 thesis alignment, spread, risk, freshness, or account safety gates.
bool V2_ClosedM1ConfirmsDirection(int dir)
  {
   if(dir==0 || Bars(_Symbol,PERIOD_M1)<3) return false;
   double o=TfOpen(PERIOD_M1,1), c=TfClose(PERIOD_M1,1);
   double h=TfHigh(PERIOD_M1,1), l=TfLow(PERIOD_M1,1);
   if(o<=0.0 || c<=0.0 || h<=l) return false;
   double atr=BufVal(hATR_M1,0,1);
   if(atr<=0.0) atr=CurrentATR1;
   if(atr<=0.0) return false;
   double range=h-l, body=MathAbs(c-o);
   if(body<MathMax(_Point*2.0,atr*0.12) || range<atr*0.18) return false;
   double closeLocation=(c-l)/range;
   if(dir==1) return (c>o && closeLocation>=0.60);
   return (c<o && closeLocation<=0.40);
  }

void V1Route_LogDecision(string state,string reason);

double V1Route_M5VolumeRatio()
  {
   int lookback=(int)MathMax(5,MathMin(V1M5VolumeLookback,60));
   double sum=0.0;
   int n=0;
   for(int i=2;i<=lookback+1;i++)
     {
      long v=TfVolume(PERIOD_M5,i);
      if(v>0) { sum+=(double)v; n++; }
     }
   long last=TfVolume(PERIOD_M5,1);
   if(n<=0 || sum<=0.0 || last<=0) return -1.0; // missing volume is not counted as confirmation
   return (double)last/(sum/(double)n);
  }

double V1Route_M5ClosedSetupScore(int dir)
  {
   if(dir==0) return 0.0;
   double o=TfOpen(PERIOD_M5,1), h=TfHigh(PERIOD_M5,1);
   double l=TfLow(PERIOD_M5,1), c=TfClose(PERIOD_M5,1);
   double atr=CurrentATR5;
   if(o<=0.0 || h<=l || l<=0.0 || c<=0.0 || atr<=0.0) return 0.0;

   double range=h-l;
   double body=MathAbs(c-o);
   double bodyRatio=body/range;
   double rangeATR=range/atr;
   double closeLoc=(c-l)/range;
   double volRatio=V1Route_M5VolumeRatio();
   bool candleAligned=(dir==1)?(c>o):(c<o);
   bool closeNearEdge=(dir==1)?(closeLoc>=0.65):(closeLoc<=0.35);
   double score=0.0;

   if(g_V4_M15Bias==dir) score+=20.0;
   else if(g_V4_M15Bias==0) score+=8.0;

   if(V4_M5PrimaryDir()==dir) score+=25.0;
   else if(g_GI.m5ThesisDir==0) score+=5.0;

   if(candleAligned) score+=15.0;
   if(bodyRatio>=V1M5MinBodyRatio) score+=10.0;
   else if(V1M5MinBodyRatio>0.0) score+=5.0*Clamp(bodyRatio/V1M5MinBodyRatio,0.0,1.0);

   if(closeNearEdge) score+=10.0;
   else score+=4.0;

   if(rangeATR>=V1M5MinRangeATR) score+=5.0;
   else if(V1M5MinRangeATR>0.0) score+=5.0*Clamp(rangeATR/V1M5MinRangeATR,0.0,1.0);

   if(volRatio>=V1M5VolumeMin) score+=10.0;
   else if(volRatio>=0.0 && V1M5VolumeMin>0.0) score+=4.0*Clamp(volRatio/V1M5VolumeMin,0.0,1.0);

   if(FlowFresh())
     {
      double flow=GI_FlowPressure(dir);
      if(flow>=GenesisIntelMinFlowBridge) score+=10.0;
      else if(flow>=30.0) score+=5.0;
     }
   else score+=3.0; // stale flow is neutral/low evidence, not a fabricated flow confirmation

   // BGBI profile is a soft location bonus, never a standalone trigger.
   if(g_GI.locationScore>=65.0) score+=5.0;
   else if(g_GI.locationScore>=50.0) score+=2.0;
   return Clamp(score,0.0,100.0);
  }

bool V1Route_StrongShockEntryBypass(int dir)
  {
   if(!V1AllowStrongShockBypass || dir==0) return false;
   if(g_GI.phase!=GI_PHASE_IGNITION) return false;
   if(g_GI.ignitionScore<V1ShockBypassMinIgnition ||
      g_GI.volatilityScore<V1ShockBypassMinVolatility) return false;
   if(!g_GI.m1StructureProof || !g_GI.m1DisplacementProof) return false;
   if(g_GI.chaseRisk>=30.0 || g_GI.exhaustionScore>=55.0) return false;
   if(V4_CycleExtensionATR(dir)>GenesisV4MarketMaxExtensionATR) return false;
   return true;
  }

bool V1Route_StrongDirectionalContext(int &dir);

bool V1Route_MTFEntryAllows(int dir,bool reversal,string &reason,bool allowStrongM5Fallback=false)
  {
   reason="";
   if(!V1UseMTFCandleGate || !GenesisV4Enable) return true;
   if(dir==0) { reason="MTF_ZERO_DIRECTION"; return false; }
   if(V1Route_StrongShockEntryBypass(dir)) { reason="MTF_STRONG_SHOCK_BYPASS"; return true; }

   double setupScore=V1Route_M5ClosedSetupScore(dir);
   double o=TfOpen(PERIOD_M5,1),c=TfClose(PERIOD_M5,1);
   bool m5CandleAligned=(dir==1)?(c>o):(c<o);
   int strongCtxDir=0;
   bool strongDirectionalFallback=(allowStrongM5Fallback &&
                                   V1Route_StrongDirectionalContext(strongCtxDir) && strongCtxDir==dir);
   if(V1RequireDirectionalM5Candle && !m5CandleAligned && !strongDirectionalFallback)
     { reason="MTF_M5_CLOSED_CANDLE_OPPOSES_ENTRY"; return false; }

   if(reversal)
     {
      bool newM5Thesis=(g_GI.m5ThesisDir==dir &&
                        g_GI.m5ThesisScore>=MathMax(GenesisV4M5ThesisMinScore,70.0));
      bool reversalEvidence=(g_GI.reversalProbability>=70.0 && g_GI.transitionProbability>=60.0);
      if(!newM5Thesis || !reversalEvidence)
        { reason="MTF_REVERSAL_NEEDS_NEW_M5_THESIS_AND_TRANSITION"; return false; }
      int m1=V4_M1TacticalDir();
      if(m1!=dir && g_GI.reversalProbability<90.0)
        { reason="MTF_REVERSAL_NEEDS_M1_TRIGGER"; return false; }
      return true;
     }

   if(V4_M5PrimaryDir()!=dir)
     { reason="MTF_M5_THESIS_MISMATCH"; return false; }
   double minSetupScore=strongDirectionalFallback ? MathMax(52.0,V1M5SetupMinScore-14.0) : V1M5SetupMinScore;
   if(setupScore<minSetupScore)
     { reason=StringFormat("MTF_M5_SETUP_SCORE_%.1f_LT_%.1f",setupScore,minSetupScore); return false; }

   int m1=V4_M1TacticalDir();
   bool m1Confirmed=(m1==dir && M1PA_Score>=V1M1MinTriggerScore && V4_FreshEventFor(dir));
   if(!m1Confirmed && !allowStrongM5Fallback)
     { reason="MTF_M1_TRIGGER_NOT_CONFIRMED"; return false; }

   if(g_V4_M15Bias!=0 && g_V4_M15Bias!=dir)
     {
      bool transitionOverride=(g_V4_M15Phase==V4_M15_PHASE_EXHAUSTION &&
                               g_GI.transitionProbability>=70.0 && g_GI.reversalProbability>=70.0);
      if(!transitionOverride)
        { reason="MTF_M15_COUNTER_DIRECTION_NOT_PROVEN"; return false; }
     }
   return true;
  }

bool V1Route_StrongDirectionalContext(int &dir)
  {
   dir=0;
   if(!GenesisV4Enable || !V1UseM5DirectionalPrearm) return false;
   int m5=V4_M5PrimaryDir();
   if(m5==0 || g_GI.m5ThesisScore<V1DirectionalStrongM5Score) return false;
   if(g_GI.direction!=0 && g_GI.direction!=m5) return false;
   bool m15Aligned=(g_V4_M15Bias==0 || g_V4_M15Bias==m5);
   // A higher-timeframe exhaustion is not an automatic veto when a genuine
   // turn has already developed on M1/M5. Require M1 direction + structure and
   // fresh directional flow; this is not a blind counter-trend entry.
   bool counterM15Transition=false;
   if(g_V4_M15Bias!=0 && g_V4_M15Bias!=m5 &&
      g_V4_M15Phase==V4_M15_PHASE_EXHAUSTION && g_GI.transitionProbability>=60.0)
     {
      int m1turn=V4_M1TacticalDir();
      bool m1Aligned=(m1turn==m5 && M1PA_Score>=V1DirectionalM1MinScore);
      bool m1OppStruct=(m5==1)?(M1PA_BearMSS || M1PA_BearDisp):(M1PA_BullMSS || M1PA_BullDisp);
      bool flowSupports=(PairFlow_CryptoFastSupports(m5) ||
                         (PairFlow_NativeFresh() && PairFlow_NativeScore()*(double)m5>=PairFlowStrongConfirmScore &&
                          gPairFlowPersistence>=MathMax(1,PairFlowMinPersistenceSamples)) ||
                         (FlowFresh() && FlowComposite()*(double)m5>=BinanceStrongFlowScore));
      counterM15Transition=(m1Aligned && !m1OppStruct && flowSupports);
     }
   if(!m15Aligned && !counterM15Transition) return false;
   if(g_V4_M15Bias==0 && g_GI.mtfCoherence<72.0) return false;
   if(g_GI.exhaustionScore>=MathMax(55.0,GenesisIntelMaxExhaustionChase)) return false;
   if(g_GI.chaseRisk>=40.0) return false;
   if(V4_CycleExtensionATR(m5)>MathMin(GenesisV4MaxCycleExtensionATR,0.90)) return false;

   double o=TfOpen(PERIOD_M5,1),h=TfHigh(PERIOD_M5,1),l=TfLow(PERIOD_M5,1),c=TfClose(PERIOD_M5,1);
   double atr=CurrentATR5;
   if(atr<=0.0) atr=BufVal(hATR_M5,0,1);
   if(o<=0.0 || h<=l || l<=0.0 || c<=0.0 || atr<=0.0) return false;
   double body=MathAbs(c-o), range=h-l, closeLoc=(c-l)/range;
   // A compact pause is acceptable before a breakout; a strong candle against the thesis is not.
   if(m5==1 && c<o && body>=atr*0.55 && closeLoc<=0.30) return false;
   if(m5==-1 && c>o && body>=atr*0.55 && closeLoc>=0.70) return false;
   if(V1Route_M5ClosedSetupScore(m5)<MathMax(52.0,V1M5SetupMinScore-14.0)) return false;
   if(FlowFresh() && FlowVetoes(m5) && !PairFlow_AbsorptionSupportsDirection(m5)) return false;
   dir=m5;
   return true;
  }

bool V4_ContinuationEligible(int dir)
  {
   if(!GenesisV4Enable || dir==0) return false;
   int m5=V4_M5PrimaryDir();
   int m1=V4_M1TacticalDir();
   int strongDir=0;
   bool strongM5=V1Route_StrongDirectionalContext(strongDir) && strongDir==dir;
   bool opposingM1Structure=(dir==1)?(M1PA_BearMSS || M1PA_BearDisp):(M1PA_BullMSS || M1PA_BullDisp);
   if(GenesisV4RequireM5ForContinuation && m5!=dir) return false;
   if(m1!=0 && m1!=dir && (!strongM5 || opposingM1Structure)) return false;
   if(g_GI.transitionProbability>=GenesisIntelFlipGuardTransition &&
      g_GI.reversalProbability>=GenesisIntelFlipGuardReversal && m1==-dir && !strongM5) return false;
   if(g_GI.exhaustionScore>=GenesisIntelMaxExhaustionChase) return false;
   if(g_GI.chaseRisk>=55.0) return false;
   if(!V4_FreshEventFor(dir) && !strongM5) return false;
   if(!Flow_NotOpposed(dir) && !(strongM5 && PairFlow_AbsorptionSupportsDirection(dir))) return false;
   return true;
  }

bool V4_ExceptionalMarketAllowed(int dir,double extension)
  {
   if(!GenesisV4Enable || !GenesisV4StopFirstExecution) return true;
   if(extension>GenesisV4MarketMaxExtensionATR) return false;
   if(g_GI.volatilityScore<GenesisV4MarketShockMinVolatility) return false;
   if(g_GI.ignitionScore<GenesisV4MarketShockMinIgnition) return false;
   if(g_GI.flowPressure<GenesisV4MarketShockMinFlow) return false;
   if(g_GI.exhaustionScore>=55.0 || g_GI.chaseRisk>=30.0) return false;
   if(!g_GI.m1StructureProof || !g_GI.m1DisplacementProof) return false;
   if(!V4_M5ThesisValidFor(dir) && g_GI.phase!=GI_PHASE_IGNITION) return false;
   return true;
  }

bool V4_PositionDirectional(int &dir)
  {
   dir=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      int d=(posInfo.PositionType()==POSITION_TYPE_BUY)?1:-1;
      if(dir==0) dir=d;
      else if(dir!=d) return false;
     }
   return (dir!=0);
  }

int V4_NetExposureDirection()
  {
   double buyLots=0.0,sellLots=0.0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      if(posInfo.PositionType()==POSITION_TYPE_BUY) buyLots+=posInfo.Volume();
      else sellLots+=posInfo.Volume();
     }
   if(buyLots>sellLots+1e-9) return 1;
   if(sellLots>buyLots+1e-9) return -1;
   return 0;
  }

bool V4_DeletePendingDirection(int dir)
  {
   bool any=false;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      string c=ordInfo.Comment();
      if(StringFind(c,"GENESIS_INTEL_")<0) continue;
      ENUM_ORDER_TYPE t=ordInfo.OrderType();
      int od=(t==ORDER_TYPE_BUY_STOP || t==ORDER_TYPE_BUY_LIMIT || t==ORDER_TYPE_BUY_STOP_LIMIT)?1:
             ((t==ORDER_TYPE_SELL_STOP || t==ORDER_TYPE_SELL_LIMIT || t==ORDER_TYPE_SELL_STOP_LIMIT)?-1:0);
      if(dir!=0 && od!=dir) continue;
      ulong tk=ordInfo.Ticket();
      MsgBudget_Count(1); // shared account-wide outbound request
      if(trade.OrderDelete(tk))
        { MsgBudget_TickDelete(); any=true; }
     }
   return any;
  }

bool V4_SendDirectionalStop(int dir,double lot,double slDist,double tpDist,string cmt,double bufferATR,double maxDistATR)
  {
   if(dir==0 || lot<=0.0) return false;
   double atr=CurrentATR1; if(atr<=0.0) atr=CurrentATR5; if(atr<=0.0) return false;
   double bid=BidPrice(),ask=AskPrice(); if(bid<=0.0 || ask<=0.0) return false;
   double minDist=MathMax(StopsLevelPrice()*1.10,_Point*2.0);
   double buffer=MathMax(atr*bufferATR,StopsLevelPrice()*0.25);
   double maxDist=MathMax(atr*maxDistATR,minDist*2.0);
   double ref=0.0,entry=0.0;
   if(dir==1)
     {
      bool hasSwing=M1RecentSwingHigh(ref);
      entry=(hasSwing && ref>ask+minDist)?ref+buffer:ask+MathMax(minDist,atr*0.18);
      entry=MathMin(entry,ask+maxDist);
     }
   else
     {
      bool hasSwing=M1RecentSwingLow(ref);
      entry=(hasSwing && ref<bid-minDist)?ref-buffer:bid-MathMax(minDist,atr*0.18);
      entry=MathMax(entry,bid-maxDist);
     }
   if(entry<=0.0) return false;
   if(V4_CycleExtensionATR(dir)>GenesisV4MaxCycleExtensionATR) return false;
   if(dir==1 && entry<=ask+minDist) return false;
   if(dir==-1 && entry>=bid-minDist) return false;
   lot=ValidateLot(lot); if(lot<=0.0) return false;
   double sl=(dir==1)?entry-slDist:entry+slDist;
   double tp=(dir==1)?entry+tpDist:entry-tpDist;
   bool ok=(dir==1)?SendBuyStop(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt):
                     SendSellStop(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt);
   if(ok)
     {
      g_V4_LastPendingDir=dir; g_V4_LastPendingTime=TimeCurrent();
      if(GenesisV4LogDecisions)
         PrintFormat("[GENESIS V4 STOP] dir=%s trigger=%.*f lot=%.3f ext=%.2fATR m5=%s/%.1f m1=%s/%.1f flow=%.1f",
                     DirStr(dir),_Digits,entry,lot,V4_CycleExtensionATR(dir),DirStr(V4_M5PrimaryDir()),g_GI.m5ThesisScore,
                     DirStr(V4_M1TacticalDir()),M1PA_Score,g_GI.flowPressure);
     }
   return ok;
  }

string V4_M15PhaseText()
  {
   switch(g_V4_M15Phase)
     {
      case V4_M15_PHASE_BEGINNING:  return "BEGINNING";
      case V4_M15_PHASE_EXPANSION:  return "EXPANSION";
      case V4_M15_PHASE_EXHAUSTION: return "EXHAUSTION";
      case V4_M15_PHASE_COMPRESSION:return "COMPRESSION";
      case V4_M15_PHASE_NEUTRAL:    return "NEUTRAL";
      default:                      return "UNKNOWN";
     }
  }

void V4_UpdateM15Context()
  {
   if(!GenesisV4Enable) return;
   datetime currentM15=TfTime(PERIOD_M15,0);
   if(currentM15<=0 || (g_V4_M15PhaseBar>0 && currentM15==g_V4_M15PhaseBar)) return;
   if(Bars(_Symbol,PERIOD_M15)<12) return;

   bool hadPrevious=(g_V4_M15PhaseBar>0);
   int oldBias=g_V4_M15Bias;
   int bias=M15Direction; // M15Direction is derived from closed-bar indicators.
   double o=TfOpen(PERIOD_M15,1), c=TfClose(PERIOD_M15,1);
   double h=TfHigh(PERIOD_M15,1), l=TfLow(PERIOD_M15,1);
   double atr=CurrentATR15;
   if(atr<=0.0) atr=BufVal(hATR_M15,0,1);
   if(o<=0.0 || c<=0.0 || h<=0.0 || l<=0.0 || atr<=0.0 || h<=l)
     {
      g_V4_M15PreviousBias=oldBias;
      g_V4_M15Bias=bias;
      g_V4_M15Phase=V4_M15_PHASE_UNKNOWN;
      g_V4_M15PhaseBar=currentM15;
      return;
     }

   double range=h-l;
   double body=MathAbs(c-o);
   double bodyRatio=body/range;
   double closePos=(c-l)/range;
   double upperWick=h-MathMax(o,c);
   double lowerWick=MathMin(o,c)-l;
   double rangeATR=range/atr;
   bool up=(c>o), down=(c<o);
   bool breakout=false;
   if(bias==1)
     {
      int hs=iHighest(_Symbol,PERIOD_M15,MODE_HIGH,5,2);
      if(hs>=0 && c>TfHigh(PERIOD_M15,hs)) breakout=true;
     }
   else if(bias==-1)
     {
      int ls=iLowest(_Symbol,PERIOD_M15,MODE_LOW,5,2);
      if(ls>=0 && c<TfLow(PERIOD_M15,ls)) breakout=true;
     }

   ENUM_V4_M15_PHASE phase=V4_M15_PHASE_NEUTRAL;
   if(bias==0)
     {
      phase=(rangeATR<=0.52)?V4_M15_PHASE_COMPRESSION:V4_M15_PHASE_NEUTRAL;
     }
   else
     {
      bool oppositeBody=((bias==1 && down)||(bias==-1 && up)) && bodyRatio>=0.42;
      bool wickRejection=(bias==1 && upperWick/range>=0.42 && closePos<0.68) ||
                         (bias==-1 && lowerWick/range>=0.42 && closePos>0.32);
      bool exhaustion=(rangeATR>=0.80 && (oppositeBody || wickRejection));
      bool changed=(hadPrevious && bias!=oldBias);
      bool directionalBody=(bias==1 && up && closePos>=0.68) ||
                           (bias==-1 && down && closePos<=0.32);
      if(exhaustion)
         phase=V4_M15_PHASE_EXHAUSTION;
      else if(changed || (breakout && bodyRatio>=0.48 && rangeATR>=0.60))
         phase=V4_M15_PHASE_BEGINNING;
      else if(directionalBody && bodyRatio>=0.45 && rangeATR>=0.58)
         phase=V4_M15_PHASE_EXPANSION;
      else if(rangeATR<=0.52)
         phase=V4_M15_PHASE_COMPRESSION;
      else
         phase=V4_M15_PHASE_NEUTRAL;
     }

   g_V4_M15PreviousBias=oldBias;
   g_V4_M15Bias=bias;
   g_V4_M15Phase=phase;
   g_V4_M15PhaseBar=currentM15;
   if(GenesisV4LogDecisions)
      PrintFormat("[GENESIS V4 M15 CONTEXT] bias=%s phase=%s rangeATR=%.2f body=%.2f closePos=%.2f",
                  DirStr(bias),V4_M15PhaseText(),rangeATR,bodyRatio,closePos);
  }













bool V4_StraddlePendingStillValid(int orderDir)
  {
   if(g_V4_M15Bias==0 || orderDir==0) return false;
   if(g_V4_StraddleBiasAtArm!=0 && g_V4_M15Bias!=g_V4_StraddleBiasAtArm) return false;
   int counter=-g_V4_M15Bias;
   if(orderDir!=g_V4_M15Bias && orderDir!=counter) return false;
   if(V4_M5PrimaryDir()!=counter) return false;
   int m1=V4_M1TacticalDir();
   if(m1!=0 && m1!=counter) return false;
   return true;
  }

bool V1Route_IsRangeContext()
  {
   // A strong aligned M15/M5 directional thesis outranks an M1-only CHOP label.
   // It routes to a one-sided STOP pre-arm; it does NOT arm a blind paired straddle.
   int strongDir=0;
   if(V1Route_StrongDirectionalContext(strongDir)) return false;
   if(g_R7==R7_EXPANSION) return false;
   if(g_GI.fastTransition && g_GI.transitionProbability>=V1TransitionRangeExitThreshold)
      return false;
   bool regimeRange=(g_R7==R7_CHOP || g_R7==R7_COMPRESSION);
   bool phaseRange=(g_V4_M15Phase==V4_M15_PHASE_COMPRESSION);
   bool neutralWait=(g_V4_M15Phase==V4_M15_PHASE_NEUTRAL &&
                     g_GI.action==GI_WAIT && g_GI.finalConfidence<68.0);
   return (regimeRange || phaseRange || neutralWait);
  }

void V1Route_LogDecision(string state,string reason)
  {
   datetime now=TimeCurrent();
   bool sameDecision=(state==g_V1Route_State && reason==g_V1Route_LastDecision);
   if(sameDecision && now-g_V1Route_LastDecisionLog<MathMax(5,V1RouterLogCooldownSec)) return;
   if(!sameDecision && g_V1Route_LastDecisionLog>0 && now-g_V1Route_LastDecisionLog<2) return;
   g_V1Route_State=state;
   PrintFormat("[BGBI V1 ROUTER] state=%s reason=%s M15=%s/%s M5=%s/%.1f M1=%s/%.1f regime=%s flow=%s health=%d pend=%d pos=%d",
               state,reason,DirStr(g_V4_M15Bias),V4_M15PhaseText(),DirStr(V4_M5PrimaryDir()),g_GI.m5ThesisScore,
               DirStr(V4_M1TacticalDir()),M1PA_Score,Regime7Name(g_R7),FlowStateStr(),(int)g_HealthState,
               LegacyCampaign_CountPending(),CountOurPositions());
   g_V1Route_LastDecision=reason;
   g_V1Route_LastDecisionLog=now;
  }


string V2_OrderModeName()
  {
   if(OrderMode==OMODE_STOP) return "STOP";
   if(OrderMode==OMODE_LIMIT) return "LIMIT";
   return "DYNAMIC";
  }

string V2_SpreadBlockReason()
  {
   if(CurrentSpreadPoints>=HardMaxSpreadPoints)
      return StringFormat("SPREAD_HARD_POINTS_%.0f_GE_%.0f",CurrentSpreadPoints,HardMaxSpreadPoints);
   if(!V1UseATRNormalizedSpreadGuard) return "SPREAD_BLOCKED_OTHER_GATE";
   double atr=CurrentATR5;
   if(atr<=0.0) atr=BufVal(hATR_M5,0,1);
   if(atr<=0.0) return StringFormat("SPREAD_BLOCKED_ATR_UNAVAILABLE pts=%.0f",CurrentSpreadPoints);
   double spreadPrice=MathMax(0.0,CurrentSpreadPoints*_Point);
   double ratio=spreadPrice/atr;
   double maxRatio=MathMax(0.01,V1_Profile_MaxSpreadATR());
   return StringFormat("SPREAD_ATR_RATIO_%.3f_GT_%.3f price=%.5f ATR5=%.5f pts=%.0f",
                       ratio,maxRatio,spreadPrice,atr,CurrentSpreadPoints);
  }

bool V1Route_CommonEntryGate(string &reason)
  {
   reason="";
   int v1CooldownRemaining=0;
   if(V1_StopCooldownActive(v1CooldownRemaining))
     { reason=StringFormat("POST_STOP_COOLDOWN_%ds",v1CooldownRemaining); return false; }
   if(!UseGenesisIntelligence || !GenesisIntelBlockLegacy || !GenesisV4Enable)
      { reason="GENESIS_ROUTER_OFF"; return false; }
   if(TimeCurrent()<PauseUntil) { reason="PAUSE"; return false; }
   if(DailyHalted) { reason="DAILY_HALT"; return false; }
   if(GlobalHalted) { reason="GLOBAL_HALT"; return false; }
   if(!MsgBudget_CanTrade()) { reason="MESSAGE_BUDGET"; return false; }
   if(!Health_AllowsNewEntries()) { reason="HEALTH_GATE"; return false; }
   if(!SpreadOK()) { reason=V2_SpreadBlockReason(); return false; }
   if(!SessionAllowed()) { reason="SESSION"; return false; }
   if(!HourFilterOK()) { reason="HOUR_FILTER"; return false; }
   if(WickPauseActive()) { reason="WICK_PAUSE"; return false; }
   if(CountOurPositions()>0) { reason="POSITION_ACTIVE"; return false; }
   if(LegacyCampaign_CountPending()>0) { reason="PENDING_ALREADY_ARMED"; return false; }
   if(g_GI_EntriesCampaign>=GenesisIntel_MaxEntriesAllowed() || GenesisIntelMaxEntriesCampaign<=0)
      { reason="CAMPAIGN_ENTRY_CAP"; return false; }
   return true;
  }

bool V1Route_GetM5Range(int lookback,double &rangeHigh,double &rangeLow,double &rangeATR)
  {
   rangeHigh=-DBL_MAX;
   rangeLow=DBL_MAX;
   rangeATR=0.0;
   lookback=(int)MathMax(4,MathMin(lookback,30));
   if(Bars(_Symbol,PERIOD_M5)<lookback+3) return false;
   for(int i=1;i<=lookback;i++)
     {
      double h=TfHigh(PERIOD_M5,i), l=TfLow(PERIOD_M5,i);
      if(h<=0.0 || l<=0.0 || h<=l) return false;
      if(h>rangeHigh) rangeHigh=h;
      if(l<rangeLow) rangeLow=l;
     }
   double atr=CurrentATR5;
   if(atr<=0.0) atr=BufVal(hATR_M5,0,1);
   if(atr<=0.0 || rangeHigh<=rangeLow) return false;
   rangeATR=(rangeHigh-rangeLow)/atr;
   return true;
  }

bool V1Route_RangePendingStillValid(int dir)
  {
   if(dir==0 || CountOurPositions()>0) return false;
   // Pending age is validated from the broker order's ORDER_TIME_SETUP inside
   // V4_CleanOwnPendings(). Do not use process-local timestamps here: they reset
   // when MT5 restarts or the EA is reattached, which can force a cancel/re-arm loop.
   return true;
  }

bool V1Route_DirectionalPendingStillValid(int dir)
  {
   if(dir==0 || CountOurPositions()>0) return false;
   // Expiration is owned by V4_CleanOwnPendings() using the persisted broker
   // order setup timestamp; this function only validates live direction/extension.
   int m5=V4_M5PrimaryDir();
   if(m5!=0 && m5!=dir) return false;
   int m1=V4_M1TacticalDir();
   int strongDir=0;
   bool strongM5=V1Route_StrongDirectionalContext(strongDir) && strongDir==dir;
   bool opposingM1Structure=(dir==1)?(M1PA_BearMSS || M1PA_BearDisp):(M1PA_BullMSS || M1PA_BullDisp);
   if(m1!=0 && m1!=dir && (!strongM5 || opposingM1Structure)) return false;
   if(V4_CycleExtensionATR(dir)>GenesisV4MaxCycleExtensionATR) return false;
   return true;
  }



// Returns 0 when not applicable, 1 when one or two LIMITs were armed, -1 when
// BTC CHOP was applicable but no safe range order could be armed. This prevents
// fallback into a blind two-sided STOP/STOP pair while BTC is still in CHOP.

int V1RangeLimit_CountOwnPendings()
  {
   int count=0;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      if(StringFind(ordInfo.Comment(),"BGBI_EDGE_LIMIT_")!=0) continue;
      ENUM_ORDER_TYPE ot=ordInfo.OrderType();
      if(ot==ORDER_TYPE_BUY_LIMIT || ot==ORDER_TYPE_SELL_LIMIT) count++;
     }
   return count;
  }

void V1RangeLimit_DeleteOwnPendings(string reason)
  {
   int deleted=0;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      if(StringFind(ordInfo.Comment(),"BGBI_EDGE_LIMIT_")!=0) continue;
      ulong ticket=ordInfo.Ticket();
      MsgBudget_Count(1); // shared account-wide outbound request
      if(trade.OrderDelete(ticket)) { MsgBudget_TickDelete(); deleted++; }
     }
   if(deleted>0) PrintFormat("[PAIR RANGE LIMIT CLEANUP] symbol=%s deleted=%d reason=%s",_Symbol,deleted,reason);
  }

// Each range-edge LIMIT is an independent order; fills do not cancel other edge LIMITs.
// A fill does not cancel the opposite edge. Orders expire individually and
// are removed when the regime leaves CHOP/COMPRESSION.
int V1UniversalChopLimits_Arm()
  {
   if(!V1Route_IsRangeContext()) return 0;
   if(V1_ActiveAssetClass()==V1_ASSET_CRYPTO && V1_IsBitcoinSymbol(_Symbol) && V1BTCChopABCEnabled) return 0;
   if(V1RangeLimit_CountOwnPendings()>0) return 1;
   if(CountOurPositions()>0 || CountPendingTotal()>0) return -1;

   string gateReason="";
   if(!V1Route_CommonEntryGate(gateReason))
     { V1Route_LogDecision("WAIT",gateReason); return -1; }

   double hi=0.0,lo=0.0,rangeATR=0.0;
   if(!V1Route_GetM5Range(V1_Profile_RangeLookbackM5(),hi,lo,rangeATR)) return -1;
   double width=hi-lo;
   if(width<=0.0 || rangeATR<V1_Profile_RangeMinWidthATR() || rangeATR>V1_Profile_RangeMaxWidthATR()) return -1;
   double atr=CurrentATR5;
   if(atr<=0.0) atr=BufVal(hATR_M5,0,1);
   double bid=BidPrice(),ask=AskPrice();
   if(atr<=0.0 || bid<=0.0 || ask<=bid) return -1;

   double spreadPrice=MathMax(0.0,ask-bid);
   double edge=Clamp(V1_Profile_RangeLimitRetracePct(),0.08,0.30);
   double buffer=MathMax(atr*MathMax(0.05,V1_Profile_RangeStopBufferATR()),
                         MathMax(spreadPrice*2.0,StopsLevelPrice()*1.5));
   double minDist=MathMax(StopsLevelPrice()*1.15,MathMax(_Point*2.0,spreadPrice*1.5));
   double mid=NormalizeDouble((hi+lo)*0.5,_Digits);
   double buyEntry=NormalizeDouble(lo+width*edge,_Digits);
   double sellEntry=NormalizeDouble(hi-width*edge,_Digits);
   double slDist=MathMax(atr*MathMax(0.10,V1_Profile_RangeLimitSL_ATR()),buffer);
   double buySL=NormalizeDouble(MathMin(lo-buffer,buyEntry-slDist),_Digits);
   double sellSL=NormalizeDouble(MathMax(hi+buffer,sellEntry+slDist),_Digits);
   double buyTP=mid,sellTP=mid;

   bool buyOK=(buyEntry<bid-minDist && buySL<buyEntry && buyTP>buyEntry);
   bool sellOK=(sellEntry>ask+minDist && sellSL>sellEntry && sellTP<sellEntry);
   // A resting range LIMIT may fade the immediate trend, but must not fade overwhelming pressure.
   if(buyOK && !PairFlow_AllowsDirection(1,2)) buyOK=false;
   if(sellOK && !PairFlow_AllowsDirection(-1,2)) sellOK=false;
   double buyRisk=MathAbs(buyEntry-buySL),buyReward=MathAbs(buyTP-buyEntry);
   double sellRisk=MathAbs(sellSL-sellEntry),sellReward=MathAbs(sellEntry-sellTP);
   double minRR=MathMax(1.0,V1RangeLimitMinRR);
   if(buyOK && (buyReward<buyRisk*minRR || buyReward<spreadPrice*3.0)) buyOK=false;
   if(sellOK && (sellReward<sellRisk*minRR || sellReward<spreadPrice*3.0)) sellOK=false;
   if(!buyOK && !sellOK) return -1;

   double requested=V1_EquityScaledLot(Range_Lot);
   if(requested<=0.0) return -1;
   int placed=0;
   if(buyOK && SendLimitV2(true,buyEntry,requested,buySL,buyTP,"BGBI_EDGE_LIMIT_B")) placed++;
   if(sellOK && SendLimitV2(false,sellEntry,requested,sellSL,sellTP,"BGBI_EDGE_LIMIT_S")) placed++;
   if(placed>0)
     {
      g_GI_EntriesCampaign++;
      g_GI_LastEntry=TimeCurrent();
      PrintFormat("[PAIR CHOP LIMIT] symbol=%s widthATR=%.2f range=[%.*f,%.*f] edge=%.2f lotsReq=%.3f placed=%d; independent LIMITs",
                  _Symbol,rangeATR,_Digits,lo,_Digits,hi,edge,requested,placed);
      return 1;
     }
   return -1;
  }

void V1RangeLimit_Maintenance()
  {
   if(CountOurPositions()>0)
     { V1RangeLimit_DeleteOwnPendings("RANGE_POSITION_OPEN_CANCEL_REMAINING_LIMITS"); return; }
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      if(StringFind(ordInfo.Comment(),"BGBI_EDGE_LIMIT_")!=0) continue;
      datetime setup=(datetime)OrderGetInteger(ORDER_TIME_SETUP);
      int life=(V1BTCChopABCEnabled && V1_IsBitcoinSymbol(_Symbol)) ? V1BTCChopPendingLifetimeMin : V1RangeLimitPendingLifetimeMin;
      bool stale=(setup<=0 || TimeCurrent()-setup>=MathMax(1,life)*60);
      if(stale || !V1Route_IsRangeContext())
        {
         ulong ticket=ordInfo.Ticket();
         MsgBudget_Count(1); // shared account-wide outbound request
         if(trade.OrderDelete(ticket))
           { MsgBudget_TickDelete(); PrintFormat("[PAIR RANGE LIMIT CLEANUP] symbol=%s ticket=%I64u reason=%s",_Symbol,ticket,(stale?"EXPIRED":"REGIME_CHANGED")); }
        }
     }
  }
int V1BTCChopABC_Arm()
  {
   if(!V1BTCChopABCEnabled || V1_ActiveAssetClass()!=V1_ASSET_CRYPTO || !V1_IsBitcoinSymbol(_Symbol)) return 0;
   if(g_R7!=R7_CHOP && g_R7!=R7_COMPRESSION) return 0;
   if(CountOurPositions()>0) return -1;
   if(V1RangeLimit_CountOwnPendings()>0) return 1; // keep independent edge LIMITs; no sibling cancellation
   if(LegacyCampaign_CountPending()>0) return -1;

   double hi=0.0,lo=0.0,rangeATR=0.0;
   if(!V1Route_GetM5Range(V1BTCChopLookbackM5,hi,lo,rangeATR))
     { V1_LogGateOnce(_Symbol+"|BTC_CHOP_DATA", "[BTC CHOP ABC] WAIT: closed M5 range/ATR unavailable"); return -1; }
   double width=hi-lo;
   if(width<=0.0) return -1;

   int tier=0;
   double preferredAtRef=0.0;
   if(width<V1BTCChopA_MaxRangeUSD)
     { tier=1; preferredAtRef=V1BTCChopA_LotAtReferenceEquity; }
   else if(width<V1BTCChopB_MaxRangeUSD)
     { tier=2; preferredAtRef=V1BTCChopB_LotAtReferenceEquity; }
   else if(width<=V1BTCChopC_MaxRangeUSD)
     { tier=3; preferredAtRef=V1BTCChopC_LotAtReferenceEquity; }
   else
     {
      V1_LogGateOnce(_Symbol+"|BTC_CHOP_OUTSIDE_TIERS",
         StringFormat("[BTC CHOP ABC] range=%.2f USD exceeds tier C max=%.2f; evaluate transition path instead",width,V1BTCChopC_MaxRangeUSD));
      return -1;
     }

   if(rangeATR<V1_Profile_RangeMinWidthATR() || rangeATR>V1_Profile_RangeMaxWidthATR())
     {
      V1_LogGateOnce(_Symbol+"|BTC_CHOP_ATR_OUTSIDE",
         StringFormat("[BTC CHOP ABC] tier=%s range=%.2f USD widthATR=%.2f outside profile limits",(tier==1?"A":(tier==2?"B":"C")),width,rangeATR));
      return -1;
     }

   double atr=CurrentATR5;
   if(atr<=0.0) atr=BufVal(hATR_M5,0,1);
   double bid=BidPrice(),ask=AskPrice();
   if(atr<=0.0 || bid<=0.0 || ask<=bid) return -1;

   double spreadPrice=MathMax(0.0,CurrentSpreadPoints*_Point);
   double edgeFraction=Clamp(V1BTCChopEdgeFraction,0.05,0.25);
   double buffer=MathMax(atr*MathMax(0.05,V1BTCChopStopBufferATR),
                         MathMax(spreadPrice*2.0,width*0.025));
   double minDist=MathMax(StopsLevelPrice()*1.15,MathMax(_Point*2.0,spreadPrice*1.50));

   // Edge LIMITs are placed against the closed-M5 range. SL is beyond the edge;
   // TP is the range midline. A limit too close to current price is omitted.
   double buyEntry=NormalizeDouble(lo+width*edgeFraction,_Digits);
   double sellEntry=NormalizeDouble(hi-width*edgeFraction,_Digits);
   double mid=NormalizeDouble((hi+lo)*0.5,_Digits);
   double buySL=NormalizeDouble(lo-buffer,_Digits);
   double sellSL=NormalizeDouble(hi+buffer,_Digits);
   double buyTP=mid;
   double sellTP=mid;

   bool buyValid=(buyEntry<bid-minDist && buyTP>buyEntry && buySL<buyEntry);
   bool sellValid=(sellEntry>ask+minDist && sellTP<sellEntry && sellSL>sellEntry);
   double buyRisk=MathAbs(buyEntry-buySL), buyReward=MathAbs(buyTP-buyEntry);
   double sellRisk=MathAbs(sellSL-sellEntry), sellReward=MathAbs(sellEntry-sellTP);
   if(buyValid && (buyReward<buyRisk*MathMax(1.0,V1BTCChopMinRR) || buyReward<spreadPrice*3.0)) buyValid=false;
   if(sellValid && (sellReward<sellRisk*MathMax(1.0,V1BTCChopMinRR) || sellReward<spreadPrice*3.0)) sellValid=false;
   if(!buyValid && !sellValid)
     {
      V1_LogGateOnce(_Symbol+"|BTC_CHOP_EDGE_INVALID",
         StringFormat("[BTC CHOP ABC] tier=%s range=%.2f no edge has sufficient entry distance/net RR",(tier==1?"A":(tier==2?"B":"C")),width));
      return -1;
     }

   // These are preference sizes at the reference equity, scaled to account size.
   // SendLimitV2's money-risk governor can reduce or reject the volume; minimum
   // broker lots never override the cash-risk budget.
   double requested=V1_EquityScaledLot(preferredAtRef);
   if(requested<=0.0) return -1;
   string tierName=(tier==1?"A":(tier==2?"B":"C"));
   int placed=0;
   if(buyValid && SendLimitV2(true,buyEntry,requested,buySL,buyTP,"BGBI_EDGE_LIMIT_B")) placed++;
   if(sellValid && SendLimitV2(false,sellEntry,requested,sellSL,sellTP,"BGBI_EDGE_LIMIT_S")) placed++;
   if(placed<=0)
     {
      V1_LogGateOnce(_Symbol+"|BTC_CHOP_RISK_REJECT",
         StringFormat("[BTC CHOP ABC] tier=%s preferredLots=%.3f; edge LIMITs rejected by broker/cash-risk checks",tierName,requested));
      return -1;
     }

   g_V4_LastStraddleTime=TimeCurrent();
   g_V4_LastPendingTime=TimeCurrent();
   g_V4_LastPendingDir=(g_V4_M15Bias!=0?g_V4_M15Bias:V4_M5PrimaryDir());
   g_GI_EntriesCampaign++;
   g_GI_LastEntry=TimeCurrent();
   V1Route_LogDecision("ARMED",StringFormat("BTC_CHOP_TIER_%s edgeLimits=%d widthUSD=%.2f widthATR=%.2f preferredLots=%.3f no paired STOP; transition handled by directional route",tierName,placed,width,rangeATR,requested));
   PrintFormat("[BTC CHOP ABC] tier=%s range=%.2f USD rangeATR=%.2f edgeFraction=%.2f preferredAtRef=%.3f scaledRequested=%.3f placed=%d; independent edge LIMITs",
               tierName,width,rangeATR,edgeFraction,preferredAtRef,requested,placed);
   return 1;
  }



bool V1Route_SendM5BoundaryStop(int dir,double requestedLot,double slDist,double tpDist,
                             string comment,double bufferATR,double maxDistanceATR)
  {
   if(dir==0 || requestedLot<=0.0 || slDist<=0.0 || tpDist<=0.0) return false;
   double hi=0.0,lo=0.0,rAtr=0.0;
   if(!V1Route_GetM5Range(5,hi,lo,rAtr)) return false;
   double atr=CurrentATR5;
   if(atr<=0.0) return false;
   double bid=BidPrice(),ask=AskPrice();
   if(bid<=0.0 || ask<=0.0) return false;
   double minDist=MathMax(StopsLevelPrice()*1.10,_Point*2.0);
   double buffer=MathMax(atr*bufferATR,StopsLevelPrice()*0.25);
   double entry=(dir==1)?hi+buffer:lo-buffer;
   entry=NormalizeDouble(entry,_Digits);
   double current=(dir==1)?ask:bid;
   if(dir==1 && entry<=ask+minDist) return false; // boundary already broken: don't chase
   if(dir==-1 && entry>=bid-minDist) return false;
   if(MathAbs(entry-current)/atr>maxDistanceATR) return false;
   double sl=(dir==1)?entry-slDist:entry+slDist;
   double tp=(dir==1)?entry+tpDist:entry-tpDist;
   bool ok=(dir==1)?SendBuyStop(entry,requestedLot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),comment):
                     SendSellStop(entry,requestedLot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),comment);
   if(ok)
     {
      g_V4_LastPendingDir=dir;
      g_V4_LastPendingTime=TimeCurrent();
      g_GI_EntriesCampaign++;
      g_GI_LastEntry=TimeCurrent();
      V1Route_LogDecision("ARMED",StringFormat("M5_DIRECTIONAL_STOP dir=%s trigger=%.2f lot=%.3f",DirStr(dir),entry,requestedLot));
     }
   return ok;
  }

bool V1Route_ArmM5DirectionalPrearm(bool allowRangeContext=false)
  {
   if(!V1UseM5DirectionalPrearm || !GenesisV4Enable) return false;
   if(V1Route_IsRangeContext() && !allowRangeContext) return false;
   if(CountOurPositions()>0 || LegacyCampaign_CountPending()>0) return false;
   string gateReason="";
   if(!V1Route_CommonEntryGate(gateReason))
     { V1Route_LogDecision("WAIT",gateReason); return false; }

   // Anti-loop guard: if a pre-armed direction was just invalidated/cancelled,
   // do not re-arm on the very next tick as M1 conditions fluctuate.
   if(g_V4_LastPendingTime>0 && TimeCurrent()-g_V4_LastPendingTime<GenesisIntelEntryCooldownSec)
     { V1Route_LogDecision("WAIT","DIRECTIONAL_REARM_COOLDOWN"); return false; }

   int m5=V4_M5PrimaryDir();
   if(m5==0 || g_GI.m5ThesisScore<V1DirectionalM5MinScore)
     { V1Route_LogDecision("WAIT","M5_THESIS_NOT_STRONG_ENOUGH"); return false; }
   if(g_GI.direction!=0 && g_GI.direction!=m5)
     { V1Route_LogDecision("WAIT","GENESIS_M5_DIRECTION_CONFLICT"); return false; }
   int m1=V4_M1TacticalDir();
   int strongDir=0;
   bool strongDirectional=V1Route_StrongDirectionalContext(strongDir) && strongDir==m5;
   bool opposingM1Structure=(m5==1)?(M1PA_BearMSS || M1PA_BearDisp):(M1PA_BullMSS || M1PA_BullDisp);
   if(m1!=0 && m1!=m5 && (!strongDirectional || opposingM1Structure))
     { V1Route_LogDecision("WAIT",opposingM1Structure?"M1_OPPOSING_STRUCTURE_BLOCKS_PREARM":"M1_M5_CONFLICT_COUNTER_REQUIRES_PROOF"); return false; }
   bool closedM1Fallback=(m1==0 && g_GI.m5ThesisScore>=V1DirectionalStrongM5Score &&
                          V2_ClosedM1ConfirmsDirection(m5) &&
                          (g_GI.volatilityScore>=55.0 || g_GI.ignitionScore>=60.0));
   bool legacyStrongM5Fallback=(m1==0 && g_GI.m5ThesisScore>=V1DirectionalStrongM5Score &&
                          (g_GI.volatilityScore>=65.0 || g_GI.ignitionScore>=65.0) &&
                          (g_GI.m5ThesisCrossUp || g_GI.m5ThesisCrossDown || g_GI.spectralTransition>=35.0));
   bool strongM5Fallback=(strongDirectional || legacyStrongM5Fallback || closedM1Fallback);
   bool m1Proof=(m1==m5 && M1PA_Score>=V1DirectionalM1MinScore && V4_FreshEventFor(m5));
   if(!m1Proof && !strongM5Fallback)
     { V1Route_LogDecision("WAIT","FRESH_M1_EVENT_OR_STRONG_M15_M5_CONTEXT_REQUIRED"); return false; }

   if(g_V4_M15Bias!=0 && m5!=g_V4_M15Bias &&
      g_V4_M15Phase!=V4_M15_PHASE_EXHAUSTION &&
      g_GI.transitionProbability<65.0 && g_GI.reversalProbability<70.0)
     { V1Route_LogDecision("WAIT","COUNTER_M15_NEEDS_TRANSITION_PROOF"); return false; }
   if(V4_CycleExtensionATR(m5)>GenesisV4MaxCycleExtensionATR)
     { V1Route_LogDecision("WAIT","ANTI_CHASE_EXTENSION"); return false; }
   bool absorptionSupport=(strongDirectional && PairFlow_AbsorptionSupportsDirection(m5));
   if(FlowFresh() && FlowVetoes(m5) && !absorptionSupport)
     { V1Route_LogDecision("WAIT","FRESH_FLOW_OPPOSES_SETUP_NO_ABSORPTION_SUPPORT"); return false; }
   if(!PairFlow_AllowsDirection(m5,0) && !absorptionSupport)
     { V1Route_LogDecision("WAIT","PAIR_FLOW_NOT_CONFIRMED_FOR_M5_PREARM"); return false; }
   string mtfReason="";
   if(!V1Route_MTFEntryAllows(m5,false,mtfReason,strongM5Fallback))
     { V1Route_LogDecision("WAIT",mtfReason); return false; }

   double lot=GenesisIntel_Lot()*V1DirectionalLotFraction;
   if(!FlowFresh()) lot*=0.70;
   lot=ValidateLot(lot);
   if(lot<=0.0) { V1Route_LogDecision("WAIT","LOT_BELOW_BROKER_MINIMUM"); return false; }
   double slDist=MathMax(GenesisIntel_SLDistance(),CurrentATR5*1.0);
   double tpDist=slDist*MathMax(1.50,GenesisIntelTP_RR_Normal);
   string cmt="GENESIS_INTEL_V4_STR_V1Risk_"+(m5==1?"B":"S");
   bool armed=V1Route_SendM5BoundaryStop(m5,lot,slDist,tpDist,cmt,
                                  V1DirectionalStopBufferATR,
                                  V1DirectionalMaxDistanceATR);
   if(armed && strongDirectional)
      V1Route_LogDecision("ARMED","STRONG_M15_M5_DIRECTIONAL_EARLY_PREARM_SINGLE_SIDE");
   return armed;
  }

bool V4_ArmContinuationStop()
  {
   if(!GenesisV4Enable || LegacyCampaign_IsActive()) return false;
   if(g_GI_EntriesCampaign>=GenesisIntel_MaxEntriesAllowed()) return false;
   if(LegacyCampaign_CountPending()>0) return false;
   if(TimeCurrent()-g_V4_LastPendingTime<GenesisIntelEntryCooldownSec) return false;
   if(g_V4_ContinuationArmCount>=GenesisV4MaxContinuationStops) return false;
   int dir=g_GI.direction;
   if(dir==0 || g_GI.action==GI_WAIT || g_GI.action==GI_REVERSAL) return false;
   if(!V4_ContinuationEligible(dir)) return false;
   string mtfReason="";
   if(!V1Route_MTFEntryAllows(dir,false,mtfReason))
     { V1Route_LogDecision("WAIT",mtfReason); return false; }
   if(!GenesisIntel_SafetyGate(dir)) return false;
   double lot=ValidateLot(GenesisIntel_Lot()); if(lot<=0.0) return false;
   double slDist=GenesisIntel_SLDistance(),tpDist=GenesisIntel_TPDistance(slDist);
   string cmt="GENESIS_INTEL_V4_CONT_"+(dir==1?"B":"S");
   if(V4_SendDirectionalStop(dir,lot,slDist,tpDist,cmt,GenesisV4StopBufferATR,GenesisV4StopMaxDistanceATR))
     { g_V4_ContinuationArmCount++; g_GI_EntriesCampaign++; g_GI_LastEntry=TimeCurrent(); return true; }
   return false;
  }

bool V4_IsStrongOpposite(int existingDir,int &oppDir)
  {
   oppDir=-existingDir;
   if(existingDir==0) return false;
   int m1=V4_M1TacticalDir();
   double oppFlow=GI_FlowPressure(oppDir), curFlow=GI_FlowPressure(existingDir);
   bool m1Opp=(m1==oppDir && M1PA_Score>=GenesisV4PostFillM1OppScore);
   bool structure=(oppDir==1)?(M1PA_BullMSS||M1PA_BullDisp):(M1PA_BearMSS||M1PA_BearDisp);
   bool flowOpp=(oppFlow>=GenesisV4PostFillFlowScore && oppFlow-curFlow>=GenesisV4PostFillFlowGap);
   bool reversalScore=(g_GI.reversalProbability>=GenesisV4PostFillReversalScore);
   bool m5Rev=(g_GI.m5ThesisDir==oppDir && g_GI.m5ThesisScore>=GenesisV4PostFillM5ReversalScore);
   bool trueRev=Genesis_M5TrueReversal();
   return ((m1Opp && structure && flowOpp && reversalScore) || (trueRev && flowOpp) || (m1Opp && m5Rev && flowOpp));
  }

bool V4_ArmOppositeTransitionStop()
  {
   if(!GenesisV4Enable || !GenesisV4PostFillDefenseEnable || !GenesisV4ArmOppositeAfterDefense) return false;
   int existing=V4_NetExposureDirection(),opp=0;
   if(existing==0) return false;
   if(!V4_IsStrongOpposite(existing,opp)) return false;
   if(g_GI.transitionProbability<GenesisIntelFlipGuardTransition) return false;
   if(LegacyCampaign_CountPending()>0) return false;
   if(CountOurPositions()>=GenesisIntel_MaxPositionsAllowed()) return false;
   double lot=ValidateLot(MathMin(GenesisIntel_Lot(),GenesisIntelTrendLot)); if(lot<=0.0) return false;
   double slDist=GenesisIntel_SLDistance(),tpDist=GenesisIntel_TPDistance(slDist);
   string cmt="GENESIS_INTEL_V4_DEFENSE_"+(opp==1?"B":"S");
   return V4_SendDirectionalStop(opp,lot,slDist,tpDist,cmt,GenesisV4OppositeStopBufferATR,GenesisV4OppositeStopMaxDistanceATR);
  }

bool V4_UpdatePostFillDefense()
  {
   if(!GenesisV4Enable || !GenesisV4PostFillDefenseEnable) return false;
   int pos=CountOurPositions();
   if(pos>g_V4_LastPosCount)
     {
      g_V4_LastFillTime=TimeCurrent(); g_V4_DefenseUntil=TimeCurrent()+GenesisV4PostFillWatchSec;
      g_V4_DefenseDir=V4_NetExposureDirection(); g_V4_DefenseEvents++;
      if(GenesisV4LogDecisions) PrintFormat("[GENESIS V4 POST-FILL] positions=%d defense=%s",pos,DirStr(g_V4_DefenseDir));
     }
   g_V4_LastPosCount=pos;
   if(pos<=0) { g_V4_DefenseDir=0; g_V4_DefenseUntil=0; return false; }
   if(TimeCurrent()>g_V4_DefenseUntil) return false;
   int existing=V4_NetExposureDirection(),opp=0;
   if(existing==0) return false;
   if(!V4_IsStrongOpposite(existing,opp)) return false;
   if(GenesisV4CancelSameSidePendings) V4_DeletePendingDirection(existing);
   bool hardThesis=(Genesis_M5TrueReversal() ||
                    (g_GI.m5ThesisDir==opp && g_GI.m5ThesisScore>=GenesisV4PostFillM5ReversalScore));
   if(hardThesis)
     {
      double pnl=LegacyCampaign_FloatingPnL();
      if(pnl>0.0) LegacyCampaign_MoveAllToBE();
      else if(g_GI.reversalProbability>=88.0 && g_GI.flowPressure>=GenesisV4PostFillFlowScore)
        { LegacyCampaign_CloseCampaign("GENESIS_V4_POSTFILL_HARD_REVERSAL"); return true; }
     }
   return false;
  }

void V4_CleanOwnPendings()
  {
   if(!GenesisV4Enable) return;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      string c=ordInfo.Comment(); if(StringFind(c,"GENESIS_INTEL_V4_")<0) continue;
      long setup=OrderGetInteger(ORDER_TIME_SETUP); bool cancel=false;
      // Per-pair, per-order-family lifetime. Range and fast breakout orders must
      // have enough time to catch the move; short tactical pre-arms retain their
      // shorter lifespan. ORDER_TIME_SETUP survives terminal/EA restarts.
      int familyLifetimeSec=GenesisV4PendingLifetimeSec;
      if(StringFind(c,"_DR_RANGE_")>=0)
         familyLifetimeSec=MathMax(familyLifetimeSec,V1RangeLimitPendingLifetimeMin*60);
      if(StringFind(c,"_DR_FAST_")>=0)
         familyLifetimeSec=MathMax(familyLifetimeSec,GenesisIntelPendingLifetimeMin*60);
      // Fail closed when the broker setup timestamp is unavailable.
      if(setup<=0 || TimeCurrent()-(datetime)setup>=familyLifetimeSec) cancel=true;
      ENUM_ORDER_TYPE t=ordInfo.OrderType();
      int d=(t==ORDER_TYPE_BUY_STOP || t==ORDER_TYPE_BUY_LIMIT || t==ORDER_TYPE_BUY_STOP_LIMIT)?1:
            ((t==ORDER_TYPE_SELL_STOP || t==ORDER_TYPE_SELL_LIMIT || t==ORDER_TYPE_SELL_STOP_LIMIT)?-1:0);
      if(d==0) cancel=true;
      if(StringFind(c,"_CONT_")>=0)
        {
         if(!V4_ContinuationEligible(d)) cancel=true;
         int m5=V4_M5PrimaryDir();
         if(GenesisV4CancelOnM5Conflict && m5!=0 && m5!=d) cancel=true;
         if(V4_CycleExtensionATR(d)>GenesisV4MaxCycleExtensionATR) cancel=true;
        }
      if(StringFind(c,"_DEFENSE_")>=0)
        {
         int existing=V4_NetExposureDirection(),opp=0;
         if(existing==0) cancel=true;
         else { opp=-existing; if(d!=opp || !V4_IsStrongOpposite(existing,opp)) cancel=true; }
        }
      // Classify each order family exactly once. V1 straddle comments
      // contain BOTH "_DR_" and "_STR_". Do not fall through to the older V4
      // straddle validator after a V1 order passes its own validator;
      // that old validator can reject a valid range leg, causing an arm/cancel
      // loop on every tick and flooding the broker with order requests.
      if(StringFind(c,"_DR_")>=0)
        {
         if(!V1Route_RangePendingStillValid(d)) cancel=true;
        }
      else if(StringFind(c,"_V1Risk_")>=0)
        {
         if(!V1Route_DirectionalPendingStillValid(d)) cancel=true;
        }
      else if(StringFind(c,"_STR_")>=0)
        {
         if(!V4_StraddlePendingStillValid(d)) cancel=true;
        }
      if(cancel)
        {
         ulong tk=ordInfo.Ticket();
         MsgBudget_Count(1); // shared account-wide outbound request
         if(trade.OrderDelete(tk)) { MsgBudget_TickDelete(); if(GenesisV4LogDecisions) PrintFormat("[GENESIS V4 CANCEL] ticket=%I64u",tk); }
        }
     }
  }

void V4_ApplyDirectionalGovernor()
  {
   if(!GenesisV4Enable) return;
   int m5=V4_M5PrimaryDir(),m1=V4_M1TacticalDir();
   g_GI.v4M5PrimaryDir=m5; g_GI.v4M1TacticalDir=m1;
   g_GI.v4M5PrimaryScore=g_GI.m5ThesisScore; g_GI.v4M1TacticalScore=M1PA_Score;
   g_GI.v4DualAligned=(m5!=0 && m1==m5);
   if(m5!=0 && g_GI.action!=GI_REVERSAL)
     {
      // Never silently overwrite a live candidate direction with the M5 thesis.
      // A conflicting thesis waits for a separately validated reversal/transition;
      // when direction is unresolved, M5 may seed it and side-specific evidence is recomputed.
      if(g_GI.direction==0)
        {
         g_GI.direction=m5;
         g_GI.flowPressure=GI_FlowPressure(m5);
         g_GI.locationScore=GI_LocationScore(m5);
         g_GI.mtfCoherence=GI_MTFCoherence(m5);
        }
      else if(g_GI.direction!=m5)
        { g_GI.action=GI_WAIT; g_GI.reason="V4 M5 THESIS CONFLICT - WAIT FOR VALIDATED REVERSAL"; }
     }
   if(m5!=0 && g_GI.action!=GI_REVERSAL && m1!=0 && m1!=m5)
     {
      if(g_GI.transitionProbability<GenesisIntelFlipGuardTransition || g_GI.reversalProbability<GenesisIntelFlipGuardReversal)
        { g_GI.action=GI_WAIT; g_GI.reason="V4 M1 COUNTERTREND NOISE"; }
     }
   g_GI.v4TransitionArmed=g_GI.fastTransition;
   g_GI.v4PostFillDefense=(TimeCurrent()<=g_V4_DefenseUntil && g_V4_DefenseDir!=0);
   g_GI.v4DefenseDir=g_V4_DefenseDir;
  }

bool GenesisIntel_TransitionGate(int dir)
  {
   if(!UseGenesisIntelligence || !GenesisIntelUseTransitionStops || dir==0) return false;
   if(TimeCurrent()<PauseUntil || DailyHalted || GlobalHalted) return false;
   if(!Health_AllowsNewEntries()) return false;
   if(!SpreadOK() || !SessionAllowed() || !HourFilterOK() || WickPauseActive()) return false;
   // A transition stop is a controlled opposite-side contingency. It may add one
   // conditional position beyond the current phase cap, but remains bounded by
   // the master Genesis cap and the global V1 cap.
   int transitionPosCap=MathMin(GenesisIntelMaxPositions,V1Risk_EffectivePairMaxPositions());
   if(CountOurPositions()>=transitionPosCap) return false;
   if(GenesisV3LockOldDirectionOnTransition && GI_ExistingPositionDirection()==dir) return false;
   if(GenesisIntelMaxEntriesCampaign<=0 || g_GI_EntriesCampaign>=GenesisIntel_MaxEntriesAllowed()) return false;
   if(LegacyCampaign_CountPending()>0 && !GI_HasTransitionPending(dir)) return false;
   if(!g_GI.fastTransition && g_GI.finalConfidence<GenesisIntelTransitionStopMinConf &&
      g_GI.reversalProbability<GenesisIntelFastTransitionReversal) return false;
   return true;
  }

bool GenesisIntel_ArmTransitionStop()
  {
   if(!UseGenesisIntelligence || !GenesisIntelUseTransitionStops) return false;
   int oldDir=GI_ExistingPositionDirection();
   if(oldDir==0) return false;
   int newDir=-oldDir;
   if(!GI_IsFastTransitionFor(newDir,oldDir)) return false;
   if(GI_HasTransitionPending(newDir))
     {
      g_GI_TransitionArmedDir=newDir;
      g_GI.transitionArmed=true;
      g_GI.transitionDirection=newDir;
      return false;
     }
   if(!GenesisIntel_TransitionGate(newDir)) return false;

   double atr=CurrentATR1;
   if(atr<=0.0) atr=CurrentATR5;
   if(atr<=0.0) return false;
   double bid=BidPrice(), ask=AskPrice();
   if(bid<=0.0 || ask<=0.0) return false;

   double ref=0.0;
   if(newDir==1) ref=M1RecentSwingHigh(ref); else ref=M1RecentSwingLow(ref);
   double buffer=atr*GenesisIntelTransitionStopBufferATR;
   double minDist=MathMax(StopsLevelPrice()*1.10,_Point*2.0);
   double maxDist=MathMax(atr*GenesisIntelTransitionStopMaxDistATR,minDist*2.0);
   double entry=0.0;
   if(newDir==1)
     {
      entry=(ref>ask+minDist)?ref+buffer:ask+MathMax(minDist,atr*0.25);
      entry=MathMin(entry,ask+maxDist);
     }
   else
     {
      entry=(ref<bid-minDist)?ref-buffer:bid-MathMax(minDist,atr*0.25);
      entry=MathMax(entry,bid-maxDist);
     }
   if(entry<=0.0) return false;

   double slDist=GenesisIntel_SLDistance();
   double tpDist=GenesisIntel_TPDistance(slDist);
   double sl=(newDir==1)?entry-slDist:entry+slDist;
   double tp=(newDir==1)?entry+tpDist:entry-tpDist;
   double lot=ValidateLot(MathMin(GenesisIntel_Lot(),GenesisIntelBaseLot));
   if(lot<=0.0) return false;

   string cmt="GENESIS_INTEL_TRANSITION_"+(newDir==1?"B":"S");
   bool ok=(newDir==1)?SendBuyStop(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt):
                         SendSellStop(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt);
   if(ok)
     {
      g_GI_TransitionArmedDir=newDir;
      g_GI_TransitionArmedTime=TimeCurrent();
      g_GI_TransitionTrigger=entry;
      g_GI.transitionDirection=newDir;
      g_GI.transitionArmed=true;
      g_GI_TransitionPendingTicket=0;
      for(int j=OrdersTotal()-1;j>=0;j--)
        {
         if(!ordInfo.SelectByIndex(j)) continue;
         if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
         if(StringFind(ordInfo.Comment(),"GENESIS_INTEL_TRANSITION_")<0) continue;
         ENUM_ORDER_TYPE ot=ordInfo.OrderType();
         if((newDir==1 && ot==ORDER_TYPE_BUY_STOP)||(newDir==-1 && ot==ORDER_TYPE_SELL_STOP))
           { g_GI_TransitionPendingTicket=ordInfo.Ticket(); break; }
        }
      g_GI_EntriesCampaign++;
      PrintFormat("[GENESIS V3 TRANSITION STOP] old=%s new=%s trigger=%.*f lot=%.3f tr=%.1f exh=%.1f rev=%.1f flow=%.1f",
                  DirStr(oldDir),DirStr(newDir),_Digits,entry,lot,g_GI.transitionProbability,
                  g_GI.exhaustionScore,g_GI.reversalProbability,GI_FlowPressure(newDir));
     }
   return ok;
  }

void GenesisIntelligence_Update()
  {
   if(!UseGenesisIntelligence) return;
   static datetime lastUpdate=0;
   datetime now=TimeCurrent();
   if(lastUpdate>0 && now-lastUpdate<MathMax(1,GenesisIntelUpdateSeconds)) return;
   lastUpdate=now;

   // Keep all higher-timeframe context on CLOSED candles. Only M1 trigger data
   // is allowed to use the live candle.
   RefreshLegacyContext();
   UpdateM1PA();
   VNSMC_Update();
   ComputeAdaptiveRegimeMetrics();
   VNAdvancedMarketUpdate();
   if(UseFastTrendScore) ComputeFastTrendScore();
   VNUpdateCUSUM();

   // Keep Factor-B context alive for failover, but never let its engines place
   // a second competing trade while Genesis Intelligence is enabled.
   if(g_ActiveFactor==FACTOR_B_FALLBACK)
     {
      datetime cm15=TfTime(PERIOD_M15,0), cm5=TfTime(PERIOD_M5,0), cm1=TfTime(PERIOD_M1,0);
      if(cm15>0 && cm15!=g_FB_LastM15Time){g_FB_LastM15Time=cm15;g_FB_JerkM15=DetectM15Jerk();FB_DetectMSS_Event();FB_ScanOB();}
      if(cm5>0 && cm5!=g_FB_LastM5Time){g_FB_LastM5Time=cm5;FB_UpdateSessionVWAP();FB_ScanFVG();FB_BuildVolumeProfile();}
      if(cm1>0 && cm1!=g_FB_LastM1Time){g_FB_LastM1Time=cm1;FB_UpdateVROC();g_FB_Mode=FB_DetectMode();}
     }

   g_GI.valid=true;
   g_GI.updated=now;
   GI_UpdateLuxPhase();
   GI_UpdateSpectral();
   GI_UpdateM5EMAThesis();
   GI_UpdateM1FastLead();
   g_GI.signalFreshness=GI_SignalFreshness();
   g_GI.priceEfficiency=GI_PriceEfficiency(8);
   double transition=GI_TransitionProbability();
   g_GI.transitionProbability=transition;

   double bullDir=GI_DirectionStrengthFromComponents(1);
   double bearDir=GI_DirectionStrengthFromComponents(-1);
   double bullM1=GI_M1Control(1), bearM1=GI_M1Control(-1);
   double bullFlow=GI_FlowPressure(1), bearFlow=GI_FlowPressure(-1);
   double bullMTF=GI_MTFCoherence(1), bearMTF=GI_MTFCoherence(-1);
   double bullLoc=GI_LocationScore(1), bearLoc=GI_LocationScore(-1);
   double bullLux=GI_LuxDirectionalEvidence(1), bearLux=GI_LuxDirectionalEvidence(-1);
   double bullSpec=GI_SpectralDirectionalEvidence(1), bearSpec=GI_SpectralDirectionalEvidence(-1);
   double bullLead=GI_M1LeadEvidence(1), bearLead=GI_M1LeadEvidence(-1);

   // Unified control: higher TF thesis + tactical structure + M1 trigger + live flow.
   double bullM5Thesis=(g_GI.m5ThesisDir==1)?g_GI.m5ThesisScore:MathMax(0.0,100.0-g_GI.m5ThesisScore);
   double bearM5Thesis=(g_GI.m5ThesisDir==-1)?g_GI.m5ThesisScore:MathMax(0.0,100.0-g_GI.m5ThesisScore);
   double bullControl = bullDir*0.23 + bullM1*0.18 + bullLead*0.10 + bullFlow*0.19 + bullMTF*0.08 + bullLoc*0.07 + bullLux*0.05 + bullSpec*0.05 + bullM5Thesis*0.05;
   double bearControl = bearDir*0.23 + bearM1*0.18 + bearLead*0.10 + bearFlow*0.19 + bearMTF*0.08 + bearLoc*0.07 + bearLux*0.05 + bearSpec*0.05 + bearM5Thesis*0.05;
   // USD bridge influence is soft, limited, and only active when fresh. It never replaces M5/M15/M1 evidence.
   double usdPairBias=USDHybrid_DirectionBias();
   if(MathAbs(usdPairBias)>0.01)
     {
      double usdAdj=Clamp(usdPairBias,-100.0,100.0)*Clamp(USDHybridDirectionWeight,0.0,0.12);
      if(usdAdj>0.0) bullControl+=usdAdj;
      else bearControl+=MathAbs(usdAdj);
     }
   bullControl=Clamp(bullControl,0.0,100.0);
   bearControl=Clamp(bearControl,0.0,100.0);
   g_GI.bullControl=bullControl;
   g_GI.bearControl=bearControl;

   int dir=(bullControl>bearControl)?1:-1;
   double dominant=MathMax(bullControl,bearControl);
   double weaker=MathMin(bullControl,bearControl);
   double separation=dominant-weaker;
   g_GI.direction= (dominant>=45.0 && separation>=GenesisIntelTransitionGap) ? dir : 0;
   if(g_GI.direction==0)
      {
       if(transition>=60.0 && g_GI.m1LeadDir!=0 && g_GI.m1LeadScore>=GenesisV3M1LeadMinForStop) g_GI.direction=g_GI.m1LeadDir;
       else if(transition>=70.0 && M1PA_Dir!=0) g_GI.direction=M1PA_Dir;
       else if(M5Direction!=0) g_GI.direction=M5Direction;
       else if(M15Direction!=0) g_GI.direction=M15Direction;
      }
   // Critical invariant: score flow/location/MTF/transition for the resolved candidate side,
   // not the earlier weighted-score side when a transition fallback changed direction.
   if(g_GI.direction!=0)
     {
      dir=g_GI.direction;
      dominant=(dir==1)?bullControl:bearControl;
      weaker=(dir==1)?bearControl:bullControl;
      separation=dominant-weaker;
     }
   g_GI.directionConfidence=Clamp(50.0 + separation*0.85,0.0,100.0);
   g_GI.transitionProbability=GI_EliteStateTransition(dir,g_GI.transitionProbability);
   transition=g_GI.transitionProbability;
   g_GI.stateTransitionScore=g_GI.transitionProbability;

   g_GI.flowPressure=(dir==1)?bullFlow:bearFlow;
   g_GI.locationScore=(dir==1)?bullLoc:bearLoc;
   g_GI.mtfCoherence=(dir==1)?bullMTF:bearMTF;

   double volatility=20.0;
   double ar1=(NormalATR1>0.0)?CurrentATR1/NormalATR1:1.0;
   double ar5=(NormalATR5>0.0)?CurrentATR5/NormalATR5:1.0;
   double mr=GI_M5VolumeRatio(), tr=GI_TradeRateRatio();
   if(ar1>=GenesisIntelTrendATR) volatility+=15.0;
   if(ar1>=GenesisIntelShockATR) volatility+=15.0;
   if(ar5>=1.10) volatility+=12.0;
   if(mr>=1.20) volatility+=12.0;
   if(mr>=1.60) volatility+=10.0;
   if(mr>=GenesisIntelShockVolume) volatility+=6.0;
   if(tr>=1.20) volatility+=10.0;
   if(g_GI.priceEfficiency>=0.60) volatility+=8.0;
   g_GI.volatilityScore=Clamp(volatility,0.0,100.0);

   g_GI.exhaustionScore=GI_ExhaustionScore(dir);
   g_GI.reversalProbability=GI_ReversalProbability(dir,g_GI.exhaustionScore);
   g_GI.ignitionScore=GI_IgnitionScore(dir,g_GI.flowPressure,g_GI.transitionProbability);
   g_GI.chaseRisk=GI_ChaseRisk();

   int phase=GI_PHASE_CHOP;
   if(g_GI.exhaustionScore>=78.0 && g_GI.reversalProbability>=68.0) phase=GI_PHASE_EXHAUSTION;
   else if(g_GI.volatilityScore<38.0 && ar1<=GenesisIntelCompressionATR) phase=GI_PHASE_COMPRESSION;
   else if(transition>=68.0 && g_GI.ignitionScore>=55.0) phase=GI_PHASE_TRANSITION;
   else if(g_GI.ignitionScore>=76.0 && g_GI.volatilityScore>=65.0) phase=GI_PHASE_IGNITION;
   else if(g_GI.volatilityScore>=78.0 && g_GI.priceEfficiency>=0.65) phase=GI_PHASE_ACCELERATION;
   else if(g_GI.volatilityScore>=65.0) phase=GI_PHASE_EXPANSION;
   else if(g_GI.directionConfidence>=76.0 && g_GI.priceEfficiency>=0.58) phase=GI_PHASE_TREND;
   else if(g_GI.exhaustionScore>=62.0) phase=GI_PHASE_CLIMAX;
   else phase=GI_PHASE_CHOP;

   if(g_GI.transitionProbability>=72.0 &&
      (g_GI.luxBullFlip || g_GI.luxBearFlip) &&
      (g_GI.spectralTransition>=35.0 || g_GI.exhaustionScore>=55.0))
      phase=GI_PHASE_TRANSITION;
   if(g_GI.luxBullExhaustion>=13 || g_GI.luxBearExhaustion>=13)
      phase=(g_GI.reversalProbability>=68.0)?GI_PHASE_EXHAUSTION:GI_PHASE_CLIMAX;
   g_GI.phase=phase;

   double nonExh=100.0-g_GI.exhaustionScore;
   double nonChase=100.0-g_GI.chaseRisk;
   double confidence=g_GI.directionConfidence*0.20 + g_GI.flowPressure*0.17 +
                     g_GI.mtfCoherence*0.15 + g_GI.locationScore*0.09 +
                     g_GI.ignitionScore*0.13 + nonExh*0.09 + nonChase*0.04 +
                     g_GI.priceEfficiency*100.0*0.03 + MathMax(bullLead,bearLead)*0.10;
   g_GI.finalConfidence=Clamp(confidence,0.0,100.0);
   g_GI.marketProof=GI_MarketEntryProof(g_GI.direction);
   g_GI.stopProof=GI_ProofStopFor(g_GI.direction);

   int action=GI_WAIT;
   string reason="NO EDGE";
   bool hardTransition=(g_GI.transitionProbability>=72.0 && g_GI.directionConfidence<62.0 &&
                         (g_GI.spectralTransition>=35.0 || g_GI.luxTransitionScore>=55.0));
   int activeDir=GI_ExistingPositionDirection();
   g_GI.fastTransition=false;
   g_GI.transitionDirection=0;
   if(activeDir!=0 && GI_IsFastTransitionFor(-activeDir,activeDir))
     { g_GI.fastTransition=true; g_GI.transitionDirection=-activeDir; }
   bool flipAgainstDir=(g_GI.direction!=0 &&
                        ((g_GI.direction==1 && g_GI.luxBearFlip) ||
                         (g_GI.direction==-1 && g_GI.luxBullFlip)));

   // Reversal is allowed to challenge MTF only when the reversal evidence is
   // substantially stronger than the old directional thesis.
   if(GenesisIntelAllowCounterTrendReversal &&
      ((g_GI.exhaustionScore>=GenesisIntelReversalExhaustion &&
        g_GI.reversalProbability>=GenesisIntelReversalTrigger &&
        g_GI.finalConfidence>=GenesisIntelReversalMinConf) ||
       (g_GI.fastTransition &&
        g_GI.transitionProbability>=GenesisIntelFastTransitionMin &&
        g_GI.reversalProbability>=GenesisIntelFastTransitionReversal)))
     {
      action=GI_REVERSAL;
      reason="EXHAUSTION+REVERSAL";
      g_GI.direction=-dir;
      g_GI.flowPressure=GI_FlowPressure(g_GI.direction);
      g_GI.locationScore=GI_LocationScore(g_GI.direction);
      g_GI.mtfCoherence=GI_MTFCoherence(g_GI.direction);
      g_GI.finalConfidence=Clamp(g_GI.reversalProbability*0.35 +
                                  g_GI.flowPressure*0.20 +
                                  g_GI.locationScore*0.15 +
                                  g_GI.mtfCoherence*0.10 +
                                  g_GI.exhaustionScore*0.10 +
                                  (100.0-g_GI.chaseRisk)*0.10,0.0,100.0);
     }
   else if(GenesisIntelUseM5ThesisAsHardGate && g_GI.direction!=0 &&
           g_GI.action!=GI_REVERSAL && g_GI.m5ThesisDir!=0 &&
           g_GI.m5ThesisDir!=g_GI.direction)
     {
      action=GI_WAIT;
      reason="M5 EMA THESIS CONFLICT";
     }
   else if(g_GI.direction!=0 &&
           dominant>=GenesisIntelMinDirection &&
           g_GI.finalConfidence>=GenesisIntelContinuationConf &&
           g_GI.ignitionScore>=GenesisIntelIgnitionMin &&
           g_GI.exhaustionScore<GenesisIntelMaxExhaustionChase &&
           g_GI.flowPressure>=GenesisIntelMinFlowBridge &&
           g_GI.chaseRisk<GenesisIntelMaxExhaustionChase &&
           !hardTransition && !flipAgainstDir &&
           (g_GI.marketProof || g_GI.stopProof))
     {
      action=(g_GI.phase==GI_PHASE_TREND || g_GI.phase==GI_PHASE_ACCELERATION ||
              g_GI.phase==GI_PHASE_EXPANSION) ? GI_CONTINUATION : GI_ATTACK;
      reason="DIRECTION+FLOW+IGNITION";
     }
   else if(g_GI.direction!=0 &&
           g_GI.finalConfidence>=GenesisIntelAttackMinConf &&
           g_GI.ignitionScore>=GenesisIntelIgnitionMin-8.0 &&
           g_GI.flowPressure>=30.0 &&
           g_GI.exhaustionScore<60.0 && g_GI.chaseRisk<55.0 &&
           !hardTransition && !flipAgainstDir &&
           (g_GI.marketProof || g_GI.stopProof))
     {
      action=GI_ATTACK;
      reason="BALANCED EDGE";
     }
   else if(GenesisIntelAllowRangeTrade &&
           g_R7==R7_CHOP && g_GI.locationScore>=72.0 &&
           g_GI.finalConfidence>=GenesisIntelRangeMinConf &&
           g_GI.exhaustionScore<55.0 && g_GI.chaseRisk<45.0)
     {
      action=GI_RANGE;
      reason="CHOP+LOCATION";
     }

   g_GI.action=action;
   g_GI.actionText=GenesisIntelligenceActionName(action);
   g_GI.phaseText=GenesisIntelligencePhaseName(phase);
   g_GI.reason=reason;
   g_GI_LastAction=action;
   g_GI_LastActionDir=g_GI.direction;
   g_GI_LastConfidence=g_GI.finalConfidence;
   g_GI_LastReversal=g_GI.reversalProbability;
   g_GI_LastExhaustion=g_GI.exhaustionScore;

  }

bool GenesisIntel_SafetyGate(int dir)
  {
   if(dir==0) return false;
   if(GenesisV4Enable)
     {
      bool isRev=(g_GI.action==GI_REVERSAL);
      if(!isRev && GenesisV4RequireM5ForContinuation && !V4_M5ThesisValidFor(dir)) return false;
      int m1=V4_M1TacticalDir();
      if(!isRev && m1!=0 && m1!=dir) return false;
      if(!isRev && V4_CycleExtensionATR(dir)>GenesisV4MaxCycleExtensionATR) return false;
      if(isRev && m1!=0 && m1!=dir && g_GI.reversalProbability<GenesisV4PostFillReversalScore) return false;
     }
   if(!UseGenesisIntelligence) return true;
   if(TimeCurrent()<PauseUntil || DailyHalted || GlobalHalted) return false;
   if(!Health_AllowsNewEntries()) return false;
   if(!SpreadOK() || !SessionAllowed() || !HourFilterOK() || WickPauseActive()) return false;
   if(CountOurPositions()>=GenesisIntel_MaxPositionsAllowed()) return false;
   if(GenesisIntelMaxEntriesCampaign<=0 || g_GI_EntriesCampaign>=GenesisIntel_MaxEntriesAllowed()) return false;
   if(g_GI_LastEntry>0 && TimeCurrent()-g_GI_LastEntry<GenesisIntelEntryCooldownSec) return false;
   if(LegacyCampaign_CountPending()>0 && !GI_HasTransitionPending(dir)) return false;
   if(g_GI.phase==GI_PHASE_EXHAUSTION || g_GI.phase==GI_PHASE_CLIMAX)
     { if(g_GI.action!=GI_REVERSAL && !g_GI.stopProof) return false; }
   if(UseGenesisIntelligence && g_GI.direction==0) return false;

   int pairFlowSetup=(g_GI.action==GI_REVERSAL)?1:((g_GI.action==GI_RANGE)?2:0);
   if(!PairFlow_AllowsDirection(dir,pairFlowSetup))
     { V1Route_LogDecision("WAIT","PAIR_FLOW_NOT_CONFIRMED_OR_STALE"); return false; }
   if(UseCryptoFastReaction && UseBinanceFlow && !MQLInfoInteger(MQL_TESTER) && PairFlow_IsCryptoChart() &&
      gCryptoFastValid && gCryptoFastDir!=0 && gCryptoFastDir!=dir &&
      !(g_GI.action==GI_REVERSAL && g_GI.reversalProbability>=GenesisIntelReversalTrigger))
     { V1Route_LogDecision("WAIT","FRESH_FAST_FLOW_OPPOSES_SETUP"); return false; }

   if(BridgeReady() && GenesisIntelUseFlowOnBridge && !GenesisIntelFlowCanConfirmOnly &&
      g_GI.flowPressure<GenesisIntelMinFlowBridge)
     {
      if(g_GI.action!=GI_REVERSAL || g_GI.reversalProbability<GenesisIntelReversalTrigger) return false;
     }
   if(GenesisIntelRequireMTFOnAttack && (g_GI.action==GI_ATTACK || g_GI.action==GI_CONTINUATION) &&
      g_GI.mtfCoherence<52.0) return false;

   if(GenesisIntelUseDirectionFlipGuard)
     {
      bool opposingFlip=(dir==1)?g_GI.luxBearFlip:g_GI.luxBullFlip;
      bool spectralOpp=(g_GI.spectralDirection!=0 && g_GI.spectralDirection!=dir);
      if(opposingFlip && g_GI.transitionProbability>=GenesisIntelFlipGuardTransition &&
         g_GI.directionConfidence<=50.0+GenesisIntelFlipGuardDirectionGap &&
         g_GI.reversalProbability>=GenesisIntelFlipGuardReversal) return false;
      if(spectralOpp && g_GI.spectralTransition>=60.0 && g_GI.reversalProbability>=65.0) return false;
     }
   return true;
  }

double GenesisIntel_Lot()
  {
   double lot=GenesisIntelBaseLot;
   if(g_GI.action==GI_CONTINUATION)
     {
      if(g_GI.finalConfidence>=GenesisIntelMonsterConf && g_GI.phase==GI_PHASE_ACCELERATION)
         lot=GenesisIntelMonsterLot;
      else lot=GenesisIntelTrendLot;
     }
   else if(g_GI.action==GI_REVERSAL)
      lot=GenesisIntelTrendLot;
   else if(g_GI.action==GI_RANGE)
      lot=GenesisIntelBaseLot;

   if(g_GI.finalConfidence>=88.0 && g_GI.phase==GI_PHASE_ACCELERATION)
      lot=MathMax(lot,GenesisIntelTrendLot);
   lot=V1_EquityScaledLot(lot);
   lot=MathMin(lot,GenesisIntelMaxLot);
   return ValidateLot(lot);
  }

double GenesisIntel_SLDistance()
  {
   double atr=CurrentATR1;
   if(atr<=0.0) atr=CurrentATR5;
   if(atr<=0.0) atr=CurrentATR15;
   if(atr<=0.0) return MathMax(StopsLevelPrice()*2.0,_Point*500.0);
   double m=GenesisIntelSL_ATR_Normal;
   if(g_GI.action==GI_REVERSAL) m=GenesisIntelSL_ATR_Reversal;
   else if(g_GI.action==GI_CONTINUATION)
     {
      m=(g_GI.phase==GI_PHASE_ACCELERATION || g_GI.phase==GI_PHASE_EXPANSION) ? GenesisIntelSL_ATR_Monster : GenesisIntelSL_ATR_Trend;
     }
   else if(g_GI.action==GI_ATTACK && g_GI.finalConfidence>=GenesisIntelMonsterConf) m=GenesisIntelSL_ATR_Trend;
   double d=atr*m;
   d*=MathMax(0.50,V1_Profile_GenesisSLScale());
   d=MathMax(d,SafeTrailBuffer()*1.50);
   d=MathMax(d,StopsLevelPrice()*2.0);
   return d;
  }

double GenesisIntel_TPDistance(double slDist)
  {
   double rr=GenesisIntelTP_RR_Normal;
   if(g_GI.action==GI_REVERSAL) rr=GenesisIntelTP_RR_Reversal;
   else if(g_GI.action==GI_CONTINUATION)
      rr=(g_GI.phase==GI_PHASE_ACCELERATION || g_GI.finalConfidence>=GenesisIntelMonsterConf) ? GenesisIntelTP_RR_Monster : GenesisIntelTP_RR_Trend;
   double target=MathMax(slDist*rr,SafeTrailBuffer()*2.0);
   target*=MathMax(0.50,V1_Profile_GenesisTPScale());
   return MathMax(target,SafeTrailBuffer()*2.0);
  }

bool GenesisIntel_SendEntry()
  {
   g_V2_LastEntryRequestFailed=false;
   if(!UseGenesisIntelligence) return false;
   int signalDir=g_GI.direction;
   if(signalDir==0 || g_GI.action==GI_WAIT) return false;
   // Run the shared router gate first so a spread, health, cooldown, budget or
   // session rejection is reported with its actual reason rather than a silent false.
   if(GenesisV4Enable)
     {
      string commonGateReason="";
      if(!V1Route_CommonEntryGate(commonGateReason))
        { V1Route_LogDecision("WAIT",commonGateReason); return false; }
     }
   if(!GenesisIntel_SafetyGate(signalDir))
     {
      if(!SpreadOK()) V1Route_LogDecision("WAIT",V2_SpreadBlockReason());
      else if(!Health_AllowsNewEntries()) V1Route_LogDecision("WAIT","HEALTH_GATE");
      else V1Route_LogDecision("WAIT","GENESIS_SAFETY_GATE");
      return false;
     }
   bool v2ClosedM1Fallback=(GenesisV4Enable && V4_M5PrimaryDir()==signalDir &&
                            g_GI.m5ThesisScore>=V1DirectionalStrongM5Score &&
                            V2_ClosedM1ConfirmsDirection(signalDir) &&
                            (g_GI.volatilityScore>=55.0 || g_GI.ignitionScore>=60.0));
   if(g_GI.action==GI_ATTACK || g_GI.action==GI_CONTINUATION || g_GI.action==GI_REVERSAL)
     {
      string mtfReason="";
      bool isReversal=(g_GI.action==GI_REVERSAL);
      if(!V1Route_MTFEntryAllows(signalDir,isReversal,mtfReason,v2ClosedM1Fallback))
        { V1Route_LogDecision("WAIT",mtfReason); return false; }
     }

   int dir=signalDir;
   double conf=g_GI.finalConfidence;
   double lot=GenesisIntel_Lot();
   if(lot<=0.0) return false;
   double slDist=GenesisIntel_SLDistance();
   double tpDist=GenesisIntel_TPDistance(slDist);
   double ask=AskPrice(),bid=BidPrice();
   if(ask<=0.0 || bid<=0.0) return false;
   double cur=(dir==1)?ask:bid;
   string suffix=(dir==1)?"B":"S";
   string cmt="GENESIS_INTEL_"+g_GI.actionText+"_"+suffix;
   bool ok=false;
   string routeSelected="NONE";
   double atr=CurrentATR1; if(atr<=0.0) atr=CurrentATR5;
   double curRange=TfHigh(PERIOD_M1,0)-TfLow(PERIOD_M1,0);
   double sl=0.0,tp=0.0,entry=0.0;
   bool marketShotAvailable=(!GenesisIntelOneMarketShotCampaign || g_GI_MarketShotCount==0);
   bool marketProof=GI_MarketEntryProof(dir);
   bool stopProof=GI_ProofStopFor(dir);
   bool dynamicMode=(OrderMode==OMODE_DYNAMIC && GenesisIntelUseDynamicRouter);
   bool limitMode=(OrderMode==OMODE_LIMIT);
   bool stopMode=(OrderMode==OMODE_STOP || (OrderMode==OMODE_DYNAMIC && !GenesisIntelUseDynamicRouter));
   double barRangeATR=(atr>0.0)?MathMax(0.0,curRange/atr):0.0;
   double cycleExtensionATR=GenesisV4Enable?V4_CycleExtensionATR(dir):0.0;
   bool isReversal=(g_GI.action==GI_REVERSAL);
   int m5Dir=GenesisV4Enable?V4_M5PrimaryDir():g_GI.m5ThesisDir;
   int m1Dir=GenesisV4Enable?V4_M1TacticalDir():g_GI.m1LeadDir;
   bool closedM1Fallback=(v2ClosedM1Fallback && m5Dir==dir);
   bool alignedM1=(m1Dir==dir || closedM1Fallback);
   bool alignedM5=(m5Dir==dir || (g_GI.phase==GI_PHASE_IGNITION && !GenesisV4RequireM5ForContinuation));

   if(GenesisV4Enable)
     {
      if(isReversal)
        stopProof=stopProof && (V4_FreshEventFor(dir) ||
                                g_GI.reversalProbability>=GenesisV4PostFillReversalScore);
      else
        {
         bool continuationProof=V4_ContinuationEligible(dir) || PairFlow_CryptoFastSupports(dir);
         // A strongly aligned CLOSED M5 thesis plus a directional CLOSED M1 candle
         // may substitute for a tactical classifier that returned neutral, but not
         // for the closed-M5 setup, spread, account-risk or flow checks.
         if(!continuationProof && closedM1Fallback && V4_M5ThesisValidFor(dir) &&
            g_GI.exhaustionScore<GenesisIntelMaxExhaustionChase && g_GI.chaseRisk<55.0 &&
            Flow_NotOpposed(dir) && cycleExtensionATR<=GenesisV4MaxCycleExtensionATR)
            continuationProof=true;
         stopProof=(stopProof || PairFlow_CryptoFastSupports(dir)) && continuationProof;
        }
     }

   bool marketContext=isReversal || g_GI.phase==GI_PHASE_IGNITION;
   if(!marketContext && (g_GI.action==GI_ATTACK || g_GI.action==GI_CONTINUATION))
      marketContext=(g_GI.finalConfidence>=MathMax(76.0,GenesisIntelContinuationConf) &&
                     g_GI.ignitionScore>=GenesisIntelIgnitionMin &&
                     g_GI.flowPressure>=MathMax(GenesisV3MarketMinFlow,GenesisIntelMinFlowBridge) &&
                     g_GI.chaseRisk<=GenesisV3MarketMaxChase &&
                     g_GI.exhaustionScore<GenesisV3MarketMaxExhaustion &&
                     alignedM5 && alignedM1 && !g_GI.fastTransition);

   bool marketAllowed=marketShotAvailable && marketProof && marketContext && alignedM5 && alignedM1 &&
                      cycleExtensionATR<=GenesisIntelMarketMaxExtensionATR && barRangeATR<=1.25;
   if(GenesisV4Enable && GenesisV4StopFirstExecution)
      marketAllowed=(marketAllowed && V4_ExceptionalMarketAllowed(dir,cycleExtensionATR));

   // Dynamic limits are for a validated trend pullback / location, not an arbitrary
   // opposite-side order. A pullback is only considered after a modest favorable move.
   bool limitCandidate=(g_GI.action==GI_ATTACK || g_GI.action==GI_CONTINUATION) && stopProof &&
                       g_GI.locationScore>=66.0 && g_GI.chaseRisk<65.0 && alignedM5 && alignedM1 &&
                       cycleExtensionATR>=0.05 && cycleExtensionATR<=GenesisV4MaxCycleExtensionATR;

   if(!limitMode && !stopMode && dynamicMode && marketAllowed)
     {
      entry=cur; sl=(dir==1)?entry-slDist:entry+slDist; tp=(dir==1)?entry+tpDist:entry-tpDist;
      routeSelected="MARKET";
      ok=SendMarketV2((dir==1)?ORDER_TYPE_BUY:ORDER_TYPE_SELL,lot,
                      NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt);
      if(ok) g_GI_MarketShotCount++;
      else
        { g_V2_LastEntryRequestFailed=true; V1Route_LogDecision("WAIT",StringFormat("DYNAMIC_MARKET_REJECTED retcode_check_logs dir=%s conf=%.1f cycleExt=%.2f barATR=%.2f",DirStr(dir),conf,cycleExtensionATR,barRangeATR)); return false; }
     }

   if(!ok && !stopMode && limitCandidate && (dynamicMode || limitMode))
     {
      double pull=MathMax(atr*GenesisIntelLimitPullbackATR,StopsLevelPrice()*2.0);
      entry=(dir==1)?bid-pull:ask+pull;
      sl=(dir==1)?entry-slDist:entry+slDist;
      tp=(dir==1)?entry+tpDist:entry-tpDist;
      bool loc=(dir==1)?(entry<bid && entry<ask):(entry>ask && entry>bid);
      if(loc)
        {
         routeSelected="LIMIT";
         ok=(dir==1)?SendBuyLimit(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt):
                      SendSellLimit(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt);
         if(!ok)
           { g_V2_LastEntryRequestFailed=true; V1Route_LogDecision("WAIT",StringFormat("ORDER_MODE_%s_LIMIT_REJECTED retcode_check_logs dir=%s loc=%.1f cycleExt=%.2f",V2_OrderModeName(),DirStr(dir),g_GI.locationScore,cycleExtensionATR)); return false; }
        }
     }

   // STOP mode is explicit. DYNAMIC uses STOP only after market and LIMIT candidates
   // have been ruled out by their evidence/location/extension criteria.
   if(!ok && !limitMode && stopProof && (dynamicMode || stopMode || OrderMode==OMODE_STOP))
     {
      double minDist=MathMax(StopsLevelPrice()*1.10,_Point*2.0);
      double maxDist=MathMax(atr*GenesisV3ProofStopMaxDistanceATR,minDist*2.0);
      double buffer=MathMax(atr*GenesisV3ProofStopBufferATR,StopsLevelPrice()*0.25);
      double ref=0.0;
      if(dir==1)
        { ref=M1RecentSwingHigh(ref); entry=(ref>ask+minDist)?ref+buffer:ask+MathMax(minDist,atr*0.18); entry=MathMin(entry,ask+maxDist); }
      else
        { ref=M1RecentSwingLow(ref); entry=(ref<bid-minDist)?ref-buffer:bid-MathMax(minDist,atr*0.18); entry=MathMax(entry,bid-maxDist); }
      sl=(dir==1)?entry-slDist:entry+slDist; tp=(dir==1)?entry+tpDist:entry-tpDist;
      string scmt="GENESIS_INTEL_PROOF_"+suffix;
      routeSelected="STOP";
      ok=(dir==1)?SendBuyStop(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),scmt):
                  SendSellStop(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),scmt);
      if(!ok)
        { g_V2_LastEntryRequestFailed=true; V1Route_LogDecision("WAIT",StringFormat("ORDER_MODE_%s_STOP_REJECTED retcode_check_logs dir=%s stopProof=%d",V2_OrderModeName(),DirStr(dir),(int)stopProof)); return false; }
     }

   if(!ok)
     {
      V1Route_LogDecision("WAIT",StringFormat("ORDER_MODE_%s_NO_QUALIFIED_ROUTE action=%s marketProof=%d stopProof=%d conf=%.1f loc=%.1f chase=%.1f cycleExt=%.2f barATR=%.2f",
                            V2_OrderModeName(),g_GI.actionText,(int)marketProof,(int)stopProof,conf,g_GI.locationScore,g_GI.chaseRisk,cycleExtensionATR,barRangeATR));
      return false;
     }

   if(ok)
     {
      bool isProof=(StringFind((g_GI.actionText+"_"+suffix),"PROOF_")>=0);
      if(!isProof) { g_GI_EntriesCampaign++; g_GI_LastEntry=TimeCurrent(); g_GI_LastActionDir=dir; g_GI_LastConfidence=conf; }
      g_LastModelEngine="GENESIS_INTELLIGENCE";
      g_LastEngine=(g_GI.action==GI_REVERSAL)?ENG_REVERSAL:((g_GI.action==GI_CONTINUATION)?ENG_MONSTER:ENG_TREND);
      PrintFormat("[GENESIS V2 ENTRY] route=%s mode=%s action=%s dir=%s conf=%.1f phase=%s lead=%.1f mss=%d disp=%d marketProof=%d stopProof=%d flow=%.1f ign=%.1f exh=%.1f loc=%.1f mtf=%.1f cycleExtATR=%.2f barRangeATR=%.2f m5ema=%s/%.1f lot=%.3f",
                  routeSelected,V2_OrderModeName(),g_GI.actionText,DirStr(dir),g_GI.finalConfidence,g_GI.phaseText,g_GI.m1LeadScore,
                  (int)g_GI.m1StructureProof,(int)g_GI.m1DisplacementProof,(int)marketProof,(int)stopProof,
                  g_GI.flowPressure,g_GI.ignitionScore,g_GI.exhaustionScore,g_GI.locationScore,g_GI.mtfCoherence,
                  cycleExtensionATR,barRangeATR,DirStr(g_GI.m5ThesisDir),g_GI.m5ThesisScore,lot);
     }
   return ok;
  }

bool GenesisIntel_Reinforce()
  {
   if(!UseGenesisIntelligence || !LegacyCampaign_IsActive()) return false;
   if(GenesisV4Enable && GenesisV4UseAlphaPyramidDiscipline)
     {
      if(!V4_M5ThesisValidFor(g_GI.direction)) return false;
      if(V4_M1TacticalDir()!=0 && V4_M1TacticalDir()!=g_GI.direction) return false;
      if(V4_CycleExtensionATR(g_GI.direction)>GenesisV4MaxCycleExtensionATR) return false;
      if(Genesis_CampaignR(LegacyCampaign_FloatingPnL())<GenesisV4ReinforceMinCampaignR) return false;
      if(g_GI.finalConfidence<GenesisV4ReinforceMinConfidence) return false;
      if(TimeCurrent()-g_GI_LastEntry<GenesisV4ReinforceCooldownSec) return false;
     }
   if(g_GI_EntriesCampaign>=GenesisIntel_MaxEntriesAllowed()) return false;
   if(CountOurPositions()<=0) return false;
   if(TimeCurrent()-g_GI_LastEntry<GenesisIntelEntryCooldownSec) return false;
   if(g_GI.action==GI_WAIT || g_GI.direction==0) return false;
   int existingDir=GI_ExistingPositionDirection();
   if(existingDir==0 || existingDir!=g_GI.direction) return false;
   if(g_GI_TransitionArmedDir!=0 && existingDir!=g_GI_TransitionArmedDir) return false;
   if(GenesisV3LockOldDirectionOnTransition && g_GI.transitionProbability>=GenesisIntelFlipGuardTransition && g_GI.transitionDirection==-existingDir) return false;
   if(g_GI.fastTransition && g_GI.transitionDirection==-existingDir) return false;
   if(!GI_ProofStopFor(existingDir)) return false;
   if(g_GI.finalConfidence<82.0 || g_GI.ignitionScore<70.0) return false;
   if(g_GI.exhaustionScore>=55.0 || g_GI.chaseRisk>=60.0) return false;
   if(g_GI.phase==GI_PHASE_CLIMAX || g_GI.phase==GI_PHASE_EXHAUSTION || g_GI.transitionProbability>=75.0) return false;
   if(g_GI.flowPressure<50.0) return false;
   if(Genesis_CampaignR(LegacyCampaign_FloatingPnL())<0.25) return false;

   double lot=ValidateLot(MathMin(GenesisIntel_Lot(),GenesisIntelTrendLot));
   if(lot<=0.0) return false;
   double slDist=GenesisIntel_SLDistance(),tpDist=GenesisIntel_TPDistance(slDist);
   double bid=BidPrice(),ask=AskPrice();
   if(bid<=0.0 || ask<=0.0) return false;
   double atr=CurrentATR1; if(atr<=0.0) atr=CurrentATR5; if(atr<=0.0) return false;
   double ref=0.0,minDist=MathMax(StopsLevelPrice()*1.10,_Point*2.0),buffer=atr*GenesisIntelStopBufferATR;
   double maxDist=MathMax(atr*GenesisIntelStopMaxDistanceATR,minDist*2.0),entry=0.0;
   if(existingDir==1)
     {
      ref=M1RecentSwingHigh(ref); if(ref>ask+minDist) entry=ref+buffer; else entry=ask+MathMax(minDist,atr*0.20); entry=MathMin(entry,ask+maxDist);
     }
   else
     {
      ref=M1RecentSwingLow(ref); if(ref<bid-minDist) entry=ref-buffer; else entry=bid-MathMax(minDist,atr*0.20); entry=MathMax(entry,bid-maxDist);
     }
   if(entry<=0.0) return false;
   double sl=(existingDir==1)?entry-slDist:entry+slDist, tp=(existingDir==1)?entry+tpDist:entry-tpDist;
   string cmt="GENESIS_INTEL_REINFORCE_STOP_"+(existingDir==1?"B":"S");
   bool ok=(existingDir==1)?SendBuyStop(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt):
                             SendSellStop(NormalizeDouble(entry,_Digits),lot,NormalizeDouble(sl,_Digits),NormalizeDouble(tp,_Digits),cmt);
   if(ok){ g_GI_EntriesCampaign++; g_GI_LastEntry=TimeCurrent(); g_TM_Reinforcements++;
      PrintFormat("[GENESIS V3 REINFORCE STOP] dir=%s trigger=%.*f lot=%.3f conf=%.1f flow=%.1f ign=%.1f",DirStr(existingDir),_Digits,entry,lot,g_GI.finalConfidence,g_GI.flowPressure,g_GI.ignitionScore); }
   return ok;
  }

void GenesisIntel_CleanPending()
  {
   if(!UseGenesisIntelligence) return;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      string cmt=ordInfo.Comment(); if(StringFind(cmt,"GENESIS_INTEL_")<0) continue;
      ENUM_ORDER_TYPE t=ordInfo.OrderType();
      int odir=(t==ORDER_TYPE_BUY_STOP || t==ORDER_TYPE_BUY_LIMIT || t==ORDER_TYPE_BUY_STOP_LIMIT)?1:
               ((t==ORDER_TYPE_SELL_STOP || t==ORDER_TYPE_SELL_LIMIT || t==ORDER_TYPE_SELL_STOP_LIMIT)?-1:0);
      bool transitionPending=(StringFind(cmt,"GENESIS_INTEL_TRANSITION_")>=0);
      bool proofPending=(StringFind(cmt,"GENESIS_INTEL_PROOF_")>=0);
      bool cancel=false; long setup=OrderGetInteger(ORDER_TIME_SETUP);
      int lifeMin=transitionPending?GenesisIntelTransitionPendingMin:(proofPending?GenesisV3ProofPendingLifetimeMin:GenesisIntelPendingLifetimeMin);
      if(setup>0 && TimeCurrent()-(datetime)setup>=lifeMin*60) cancel=true;
      if(transitionPending)
        {
         bool keep=(g_GI_TransitionArmedDir!=0 && odir==g_GI_TransitionArmedDir && GI_IsFastTransitionFor(odir,-odir));
         if(!keep) cancel=true;
        }
      else if(proofPending)
        {
         if(odir==0 || !GI_ProofStopFor(odir)) cancel=true;
         if(GenesisV3OneProofStopPerCampaign && CountOurPositions()>0) cancel=true;
        }
      else
        {
         if(g_GI.action==GI_WAIT || g_GI.direction==0) cancel=true;
         if(odir!=0 && odir!=g_GI.direction) cancel=true;
        }
      if(cancel)
        {
         ulong ticket=ordInfo.Ticket();
         MsgBudget_Count(1); // shared account-wide outbound request
         if(trade.OrderDelete(ticket))
           {
            MsgBudget_TickDelete();
            if(transitionPending)
              {
               g_GI_TransitionArmedDir=0;
               g_GI_TransitionArmedTime=0;
               g_GI_TransitionPendingTicket=0;
               g_GI_TransitionTrigger=0.0;
               g_GI.transitionArmed=false;
               g_GI.transitionDirection=0;
              }
            PrintFormat("[GENESIS INTEL CANCEL] ticket=%I64u transition=%d reason=stale_or_invalid",ticket,(int)transitionPending);
           }
        }
     }
  }

void GenesisIntelligence_ResetCampaignCounter()
  {
   if(CountOurPositions()==0 && LegacyCampaign_CountPending()==0)
     {
      g_GI_EntriesCampaign=0;
      g_GI_MarketShotCount=0;
      g_GI_TransitionArmedDir=0;
      g_GI_TransitionArmedTime=0;
      g_GI_TransitionPendingTicket=0;
      g_GI_TransitionTrigger=0.0;
      g_GI.transitionArmed=false;
      g_GI.transitionDirection=0;
      g_GI_LastAction=GI_WAIT;
      g_GI_LastActionDir=0;
      g_V4_LastPosCount=0;
      g_V4_LastFillTime=0;
      g_V4_DefenseUntil=0;
      g_V4_DefenseDir=0;
      g_V4_ContinuationArmCount=0;
      g_V4_LastPendingDir=0;
      g_V4_LastPendingTime=0;
      g_V4_LastStraddleTime=0;
      g_V4_StraddleBiasAtArm=0;
      g_V4_StraddleCounterAtArm=0;
     }
  }


//===================================================================
// GENESIS OCO ENGINE — paired breakout orders with strict OCO cleanup
//===================================================================
void V1OCO_CancelAll(string reason)
  {
   int removed=0;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      if(StringFind(ordInfo.Comment(),"GENESIS_INTEL_OCO_")<0) continue;
      ulong ticket=ordInfo.Ticket();
      MsgBudget_Count(1); // shared account-wide outbound request
      if(trade.OrderDelete(ticket)) { MsgBudget_TickDelete(); removed++; }
      else PrintFormat("[OCO CANCEL FAIL] symbol=%s ticket=%I64u reason=%s rc=%u %s",_Symbol,ticket,reason,trade.ResultRetcode(),trade.ResultRetcodeDescription());
     }
   if(removed>0)
      PrintFormat("[OCO CANCEL] symbol=%s reason=%s deleted=%d",_Symbol,reason,removed);
  }

void V1OCO_Maintenance()
  {
   if(!V1OCOEngineEnabled) return;
   int count=0;
   bool stale=false;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      if(StringFind(ordInfo.Comment(),"GENESIS_INTEL_OCO_")<0) continue;
      count++;
      datetime setup=(datetime)OrderGetInteger(ORDER_TIME_SETUP);
      if(setup<=0 || TimeCurrent()-setup>=MathMax(1,V1OCOPendingLifetimeMin)*60) stale=true;
     }
   if(count<=0) return;
   if(CountOurPositions()>0) { V1OCO_CancelAll("POSITION_FILLED_CANCEL_SIBLING"); return; }
   if(!V1Route_IsRangeContext()) { V1OCO_CancelAll("RANGE_CONTEXT_ENDED"); return; }
   if(count!=2) { V1OCO_CancelAll("INCOMPLETE_OCO_PAIR"); return; }
   if(stale) { V1OCO_CancelAll("PENDING_EXPIRED"); return; }
  }

// Calculate one broker-valid lot for the complete OCO pair BEFORE submitting either leg.
// This avoids sequential sizing where the first pending consumes risk budget and makes
// the second leg smaller/rejected. Pair risk counts both legs because terminal-managed
// OCO cancellation is not atomic and both legs can fill during a race/gap.
double V1OCO_PreflightPairLot(double requestedLots,
                              double buyEntry,double buySL,
                              double sellEntry,double sellSL)
  {
   double candidate=USDHybrid_ScaleRequestedLots(requestedLots);
   if(candidate<=0.0)
     { PrintFormat("[OCO RISK PLAN BLOCK] symbol=%s reason=USD-scaled requested lot is zero",_Symbol); return 0.0; }
   candidate=ValidateLot(candidate);
   if(candidate<=0.0)
     { PrintFormat("[OCO RISK PLAN BLOCK] symbol=%s reason=broker lot normalization returned zero",_Symbol); return 0.0; }

   if(!V1RiskLayerEnabled)
     { PrintFormat("[OCO RISK PLAN] symbol=%s riskLayer=OFF pairLot=%.4f",_Symbol,candidate); return candidate; }

   int pairPendingCap=V1Risk_EffectivePairMaxPendingOrders();
   if(pairPendingCap<2)
     { PrintFormat("[OCO RISK PLAN BLOCK] symbol=%s reason=pending_cap_below_two cap=%d",_Symbol,pairPendingCap); return 0.0; }

   double buyRiskPerLot=V1Risk_OrderRiskMoney(ORDER_TYPE_BUY_STOP,buyEntry,buySL,1.0);
   double sellRiskPerLot=V1Risk_OrderRiskMoney(ORDER_TYPE_SELL_STOP,sellEntry,sellSL,1.0);
   if(buyRiskPerLot<=0.0 || sellRiskPerLot<=0.0)
     { PrintFormat("[OCO RISK PLAN BLOCK] symbol=%s reason=risk-estimate-unavailable buyRiskPerLot=%.4f sellRiskPerLot=%.4f",_Symbol,buyRiskPerLot,sellRiskPerLot); return 0.0; }

   double campaignBudget=V1Risk_CampaignBudgetMoney();
   double reserved=V1Risk_ReservedRiskMoney();
   double allowedCombined=MathMax(0.0,campaignBudget-reserved);
   if(V1Risk_IsCryptoSymbol(_Symbol))
     {
      double cryptoBudget=V1Risk_AccountRiskMoney(V1CryptoBasketRiskPct);
      double cryptoReserved=V1Risk_CryptoReservedRiskMoney();
      allowedCombined=MathMin(allowedCombined,MathMax(0.0,cryptoBudget-cryptoReserved));
     }

   double enginePct=MathMin(V1Risk_EngineRiskPctFromComment("GENESIS_INTEL_OCO_TREND"),V1PerEntryRiskPct);
   double perEntryBudget=V1Risk_AccountRiskMoney(enginePct);
   if(allowedCombined<=0.0 || perEntryBudget<=0.0)
     { PrintFormat("[OCO RISK PLAN BLOCK] symbol=%s reason=no-risk-capacity reserved=%.2f campaign=%.2f entryBudget=%.2f",_Symbol,reserved,campaignBudget,perEntryBudget); return 0.0; }

   // Each leg stays within the normal per-entry limit; the sum of both possible
   // fills stays within remaining account/crypto campaign risk.
   double maxByOneLeg=perEntryBudget/MathMax(buyRiskPerLot,sellRiskPerLot);
   double maxByPair=allowedCombined/(buyRiskPerLot+sellRiskPerLot);
   double allowedLots=MathMin(candidate,MathMin(maxByOneLeg,maxByPair));
   double lot=ValidateLot(allowedLots);
   if(lot<=0.0)
     { PrintFormat("[OCO RISK PLAN BLOCK] symbol=%s reason=allowed-lot-zero requested=%.4f allowed=%.4f",_Symbol,candidate,allowedLots); return 0.0; }

   double buyRisk=V1Risk_OrderRiskMoney(ORDER_TYPE_BUY_STOP,buyEntry,buySL,lot);
   double sellRisk=V1Risk_OrderRiskMoney(ORDER_TYPE_SELL_STOP,sellEntry,sellSL,lot);
   double tolerance=MathMax(0.01,allowedCombined*0.001);
   if(buyRisk<=0.0 || sellRisk<=0.0 ||
      buyRisk>perEntryBudget+tolerance || sellRisk>perEntryBudget+tolerance ||
      buyRisk+sellRisk>allowedCombined+tolerance)
     {
      PrintFormat("[OCO RISK PLAN BLOCK] symbol=%s reason=normalized-min-lot-exceeds-pair-budget lot=%.4f buyRisk=%.2f sellRisk=%.2f combined=%.2f allowedCombined=%.2f perEntry=%.2f",
                  _Symbol,lot,buyRisk,sellRisk,buyRisk+sellRisk,allowedCombined,perEntryBudget);
      return 0.0;
     }

   PrintFormat("[OCO RISK PLAN] symbol=%s lot=%.4f requested=%.4f buyRisk=%.2f sellRisk=%.2f worstCasePair=%.2f pairBudget=%.2f perEntryBudget=%.2f reserved=%.2f/%0.2f",
               _Symbol,lot,candidate,buyRisk,sellRisk,buyRisk+sellRisk,allowedCombined,perEntryBudget,reserved,campaignBudget);
   return lot;
  }

int V1OCO_ArmRange()
  {
   if(!V1OCOEngineEnabled) return 0;
   if(!V1Route_IsRangeContext()) return 0;
   if(CountOurPositions()>0) return -1;
   int existingOcoCount=0;
   for(int ei=OrdersTotal()-1;ei>=0;ei--)
     {
      if(!ordInfo.SelectByIndex(ei)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      if(StringFind(ordInfo.Comment(),"GENESIS_INTEL_OCO_")>=0) existingOcoCount++;
     }
   if(existingOcoCount==2) return 1;
   if(existingOcoCount>0) { V1OCO_CancelAll("INCOMPLETE_PAIR_BEFORE_REARM"); return -1; }
   if(CountPendingTotal()>0) return -1;
   int effectivePendingCap=V1RiskLayerEnabled?V1Risk_EffectivePairMaxPendingOrders():MaxPendingTotal;
   if(effectivePendingCap<2)
     { PrintFormat("[OCO ARM BLOCK] symbol=%s reason=pending_cap_below_two cap=%d",_Symbol,effectivePendingCap); return -1; }
   if(g_V4_LastPendingTime>0 && TimeCurrent()-g_V4_LastPendingTime<GenesisIntelEntryCooldownSec)
      return -1;

   double hi=0.0,lo=0.0,rangeATR=0.0;
   if(!V1Route_GetM5Range(V1OCOBoxLookbackM5,hi,lo,rangeATR)) return -1;
   if(rangeATR<MathMax(V1OCOMinRangeATR,V1_Profile_RangeMinWidthATR()) || rangeATR>MathMin(V1OCOMaxRangeATR,V1_Profile_RangeMaxWidthATR())) return -1;
   double atr=CurrentATR5;
   if(atr<=0.0) atr=BufVal(hATR_M5,0,1);
   double bid=BidPrice(),ask=AskPrice();
   if(atr<=0.0 || bid<=0.0 || ask<=bid) return -1;

   double spreadPrice=MathMax(0.0,ask-bid);
   double buffer=MathMax(atr*MathMax(0.05,V1OCOStopBufferATR),
                         MathMax(spreadPrice*2.0,StopsLevelPrice()*1.5));
   double minDist=MathMax(StopsLevelPrice()*1.15,MathMax(_Point*2.0,spreadPrice*1.5));
   double buyEntry=NormalizeDouble(hi+buffer,_Digits);
   double sellEntry=NormalizeDouble(lo-buffer,_Digits);
   // Require BOTH arms to be valid. Never quietly turn an OCO pair into a naked one-sided order.
   if(buyEntry<=ask+minDist || sellEntry>=bid-minDist) return -1;

   double slDist=MathMax(atr*MathMax(0.20,V1OCOSL_ATR),buffer*1.5);
   double tpDist=slDist*MathMax(1.0,V1OCOTP_RR);
   double buySL=NormalizeDouble(buyEntry-slDist,_Digits);
   double buyTP=NormalizeDouble(buyEntry+tpDist,_Digits);
   double sellSL=NormalizeDouble(sellEntry+slDist,_Digits);
   double sellTP=NormalizeDouble(sellEntry-tpDist,_Digits);
   double requested=V1_EquityScaledLot(GenesisIntelTrendLot);
   requested=MathMin(requested,GenesisIntelMaxLot);
   if(requested<=0.0)
     { PrintFormat("[OCO ARM BLOCK] symbol=%s reason=requested-lot-zero",_Symbol); return -1; }

   // Preflight one identical lot using combined risk for the pair. Do not let the
   // second leg re-size itself after the first leg has reserved its share.
   double pairLot=V1OCO_PreflightPairLot(requested,buyEntry,buySL,sellEntry,sellSL);
   if(pairLot<=0.0) return -1;

   bool buyOK=false, sellOK=false;
   g_V1OCO_PairLotPrevalidatedSubmit=true;
   buyOK=SendBuyStop(buyEntry,pairLot,buySL,buyTP,"GENESIS_INTEL_OCO_TREND_BUY");
   if(buyOK)
      sellOK=SendSellStop(sellEntry,pairLot,sellSL,sellTP,"GENESIS_INTEL_OCO_TREND_SELL");
   g_V1OCO_PairLotPrevalidatedSubmit=false;
   PrintFormat("[OCO PAIR RESULT] symbol=%s buyOK=%d sellOK=%d preflightLot=%.4f buyEntry=%.*f sellEntry=%.*f",
               _Symbol,(int)buyOK,(int)sellOK,pairLot,_Digits,buyEntry,_Digits,sellEntry);

   // Verify the broker-visible pair after volume normalization and risk checks.
   int ocoCount=0, ocoBuyCount=0, ocoSellCount=0;
   double ocoBuyLots=0.0, ocoSellLots=0.0;
   for(int oi=OrdersTotal()-1;oi>=0;oi--)
     {
      if(!ordInfo.SelectByIndex(oi)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      if(StringFind(ordInfo.Comment(),"GENESIS_INTEL_OCO_")<0) continue;
      ocoCount++;
      ENUM_ORDER_TYPE ot=ordInfo.OrderType();
      double ov=OrderGetDouble(ORDER_VOLUME_CURRENT);
      if(ot==ORDER_TYPE_BUY_STOP) { ocoBuyCount++; ocoBuyLots=ov; }
      else if(ot==ORDER_TYPE_SELL_STOP) { ocoSellCount++; ocoSellLots=ov; }
     }
   double volStep=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   if(volStep<=0.0) volStep=0.01;
   bool pairVerified=(ocoCount==2 && ocoBuyCount==1 && ocoSellCount==1 &&
                      MathAbs(ocoBuyLots-ocoSellLots)<=volStep*0.5+1e-9);
   if(!buyOK || !sellOK || !pairVerified)
     {
      V1OCO_CancelAll("PAIR_ARM_FAILED_OR_MISMATCHED_CLEANUP");
      g_V4_LastPendingTime=TimeCurrent();
      PrintFormat("[OCO NOT ARMED] symbol=%s buySend=%d sellSend=%d pairVerified=%d count=%d buyLots=%.3f sellLots=%.3f requested=%.3f; OCO pendings cancelled",
                  _Symbol,(int)buyOK,(int)sellOK,(int)pairVerified,ocoCount,ocoBuyLots,ocoSellLots,requested);
      return -1;
     }

   g_V4_LastPendingDir=0;
   g_V4_LastPendingTime=TimeCurrent();
   g_GI_EntriesCampaign++;
   g_GI_LastEntry=TimeCurrent();
   PrintFormat("[OCO ARMED] symbol=%s box=[%.*f,%.*f] widthATR=%.2f buyStop=%.*f sellStop=%.*f requested=%.3f SL_ATR=%.2f TP_RR=%.2f",
               _Symbol,_Digits,lo,_Digits,hi,rangeATR,_Digits,buyEntry,_Digits,sellEntry,
               requested,V1OCOSL_ATR,V1OCOTP_RR);
   return 1;
  }

void GenesisIntelligence_Dispatch()
  {
   if(!UseGenesisIntelligence || !GenesisIntelBlockLegacy) return;
   GenesisIntelligence_Update();
   V1OCO_Maintenance();
   V1RangeLimit_Maintenance();
   GenesisIntelligence_ResetCampaignCounter();

   int v1CooldownRemaining=0;
   if(CountOurPositions()<=0 && V1_StopCooldownActive(v1CooldownRemaining))
     {
      V1OCO_CancelAll("POST_STOP_COOLDOWN");
      DeleteOrdersPrefix("");
      V1Route_LogDecision("WAIT",StringFormat("POST_STOP_COOLDOWN_%ds",v1CooldownRemaining));
      return;
     }

   if(GenesisV4Enable)
     {
      V4_UpdateM15Context();
      V4_ApplyDirectionalGovernor();
      if(V4_UpdatePostFillDefense()) return;
      V4_CleanOwnPendings();
      // Existing positions remain under Genesis post-fill defense/reinforcement.
      if(CountOurPositions()>0)
        {
         int v1OpenCooldownRemaining=0;
         bool v1OpenCooling=V1_StopCooldownActive(v1OpenCooldownRemaining);
         if(!v1OpenCooling) V4_ArmOppositeTransitionStop();
         else DeleteOrdersPrefix("");
         V4_CleanOwnPendings();
         if(!v1OpenCooling) GenesisIntel_Reinforce();
         return;
        }

      // V1.61 universal CHOP route: independent LIMIT orders only. No paired entries
      // and no market-entry fallback while CHOP.
      V1RangeLimit_Maintenance();
      if(V1Route_IsRangeContext())
        {
         string rangeGate="";
         if(!V1Route_CommonEntryGate(rangeGate))
           { V1Route_LogDecision("WAIT",rangeGate); return; }

         int rangeResult=0;
         bool trueChop=(g_R7==R7_CHOP ||
                        (g_V4_M15Phase==V4_M15_PHASE_NEUTRAL && g_GI.action==GI_WAIT && g_GI.finalConfidence<68.0));
         string rangeRoute="INDEPENDENT_CHOP_EDGE_LIMITS";
         if(OrderMode==OMODE_LIMIT)
           {
            if(V1BTCChopABCEnabled && V1_IsBitcoinSymbol(_Symbol) && V1_ActiveAssetClass()==V1_ASSET_CRYPTO)
               rangeResult=V1BTCChopABC_Arm();
            else
               rangeResult=V1UniversalChopLimits_Arm();
            rangeRoute="LIMIT_MODE_RANGE_EDGES";
           }
         else if(OrderMode==OMODE_STOP)
           {
            if(V1OCOEngineEnabled)
              { rangeResult=V1OCO_ArmRange(); rangeRoute="STOP_MODE_OCO_PAIR"; }
            else
              { rangeResult=-1; rangeRoute="STOP_MODE_NO_VALID_RANGE_STOP_ENGINE"; }
           }
         else if(trueChop)
           {
            // In true CHOP, work the validated range edges with LIMITs. The paired
            // OCO stops are reserved for compression where a breakout is the thesis.
            if(V1BTCChopABCEnabled && V1_IsBitcoinSymbol(_Symbol) && V1_ActiveAssetClass()==V1_ASSET_CRYPTO)
               rangeResult=V1BTCChopABC_Arm();
            else
               rangeResult=V1UniversalChopLimits_Arm();
            rangeRoute="DYNAMIC_CHOP_LIMITS";
           }
         else if(V1OCOEngineEnabled)
           {
            rangeResult=V1OCO_ArmRange();
            rangeRoute="DYNAMIC_COMPRESSION_OCO_STOPS";
            // If compression is too narrow/unsafe for a stop pair, a separately
            // validated limit-edge setup may still be used; risk gates remain active.
            if(rangeResult<=0)
              {
               int limitResult=V1UniversalChopLimits_Arm();
               if(limitResult>0) { rangeResult=limitResult; rangeRoute="DYNAMIC_COMPRESSION_LIMIT_FALLBACK"; }
              }
           }
         else
           {
            rangeResult=V1UniversalChopLimits_Arm();
            rangeRoute="DYNAMIC_RANGE_LIMITS_NO_OCO_ENGINE";
           }

         if(rangeResult>0)
           { V1Route_LogDecision("ARMED",rangeRoute); return; }
         V1Route_LogDecision("WAIT",StringFormat("%s_NOT_SAFE_OR_NOT_ARMED mode=%s",rangeRoute,V2_OrderModeName()));
         return;
        }

      // V2: try the selected OrderMode through Genesis first. In DYNAMIC mode this
      // means market proof -> valid pullback LIMIT -> validated continuation STOP.
      // The pre-arm remains a fallback for strong M5 + closed-M1 structural evidence,
      // not the first execution path on every directional tick.
      if(LegacyCampaign_CountPending()==0 && g_GI.action!=GI_WAIT)
        {
         bool genesisSent=GenesisIntel_SendEntry();
         V4_CleanOwnPendings();
         if(genesisSent || LegacyCampaign_CountPending()>0) return;
         if(g_V2_LastEntryRequestFailed)
           { V1Route_LogDecision("WAIT","ENTRY_REQUEST_REJECTED_NO_SECOND_ROUTE_THIS_TICK"); return; }
        }

      // LIMIT is explicit: never silently fall through to a STOP when no valid
      // pullback exists. Wait with a diagnostic instead.
      if(OrderMode==OMODE_LIMIT)
        {
         string limitGateReason="";
         if(!V1Route_CommonEntryGate(limitGateReason))
            V1Route_LogDecision("WAIT",limitGateReason);
         else
            V1Route_LogDecision("WAIT","ORDER_MODE_LIMIT_NO_VALID_PULLBACK_OR_ENTRY");
         return;
        }

      // STOP or DYNAMIC fallback: strong M5 + M1 evidence may pre-arm a boundary stop.
      if(LegacyCampaign_CountPending()==0)
        {
         bool earlyArmed=V1Route_ArmM5DirectionalPrearm();
         V4_CleanOwnPendings();
         if(earlyArmed || LegacyCampaign_CountPending()>0) return;
        }

      if(LegacyCampaign_CountPending()>0) return;
      bool armed=V4_ArmContinuationStop();
      V4_CleanOwnPendings();
      if(armed || LegacyCampaign_CountPending()>0) return;
      V1Route_LogDecision("WAIT",StringFormat("ORDER_MODE_%s_NO_QUALIFIED_ROUTE action=%s marketProof=%d stopProof=%d conf=%.1f loc=%.1f chase=%.1f",V2_OrderModeName(),g_GI.actionText,(int)g_GI.marketProof,(int)g_GI.stopProof,g_GI.finalConfidence,g_GI.locationScore,g_GI.chaseRisk));
      return;
     }

   GenesisIntel_ArmTransitionStop();
   GenesisIntel_ArmProofStop();
   GenesisIntel_CleanPending();
   if(LegacyCampaign_IsActive())
     {
      GenesisIntel_Reinforce();
      return;
     }
   GenesisIntel_SendEntry();
  }

//===================================================================
// SECTION 102A — BTC LEGACY FAST LEGACY CAMPAIGN CAMPAIGN
// Engine-native entries + unified campaign tracking + MT4-style basket control.
//===================================================================
bool LegacyCampaign_IsComment(string cmt)
  {
   // Only actual legacy campaign comments are classified as such. Normal V1
   // Genesis/Super Hybrid positions must not be hidden from the V1 exit controller.
   return (StringFind(cmt, "TM_") == 0 || StringFind(cmt, "LEGACY_CAMPAIGN_") == 0);
  }

int LegacyCampaign_CountPositions()
  {
   return CountOurPositions();
  }

int LegacyCampaign_CountPending()
  {
   return CountPendingTotal();
  }

int LegacyCampaign_CountAllExposure()
  {
   return LegacyCampaign_CountPositions() + LegacyCampaign_CountPending();
  }

double LegacyCampaign_TotalLots()
  {
   double lots = 0.0;
   for(int i = PositionsTotal()-1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(!LegacyCampaign_IsComment(posInfo.Comment())) continue;
      lots += posInfo.Volume();
     }
   return lots;
  }

double LegacyCampaign_FloatingPnL()
  {
   double pnl = 0.0;
   for(int i = PositionsTotal()-1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      pnl += posInfo.Profit() + posInfo.Swap() + V1_PositionCommissionAndFees(posInfo.Identifier());
     }
   return pnl;
  }

double LegacyCampaign_SpreadCostUSD()
  {
   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return 0.0;

   double cost = 0.0;
   for(int i = PositionsTotal()-1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(!LegacyCampaign_IsComment(posInfo.Comment())) continue;

      double vol = posInfo.Volume();
      if(vol <= 0.0) continue;

      double probe = 0.0;
      ENUM_ORDER_TYPE type = (posInfo.PositionType() == POSITION_TYPE_BUY)
                             ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
      double from = (type == ORDER_TYPE_BUY) ? ask : bid;
      double to   = (type == ORDER_TYPE_BUY) ? bid : ask;
      if(OrderCalcProfit(type, _Symbol, vol, from, to, probe))
         cost += MathAbs(probe);
     }
   return cost;
  }

bool LegacyCampaign_TightMarketBasket()
  {
   // MT4 had a lower protection profile in choppy/range conditions.
   // Use it whenever the live campaign contains only CHOP/RANGE exposure.
   bool hasTight = (CountEnginePositions("CHOP_") > 0 || CountEngineOrders("CHOP_") > 0 ||
                    CountEnginePositions("RANGE_") > 0 || CountEngineOrders("RANGE_") > 0 ||
                    CountEnginePositions("FB_CHOP_") > 0 || CountEngineOrders("FB_CHOP_") > 0);
   bool hasDirectional = (CountEnginePositions("SWING_") > 0 || CountEngineOrders("SWING_") > 0 ||
                          CountEnginePositions("MONSTER_") > 0 || CountEngineOrders("MONSTER_") > 0 ||
                          CountEnginePositions("REVERSAL_") > 0 || CountEngineOrders("REVERSAL_") > 0 ||
                          CountEnginePositions("FB_TREND_") > 0 || CountEngineOrders("FB_TREND_") > 0 ||
                          CountEnginePositions("FB_MON_") > 0 || CountEngineOrders("FB_MON_") > 0 ||
                          CountEnginePositions("FB_REV_") > 0 || CountEngineOrders("FB_REV_") > 0);
   return (hasTight && !hasDirectional);
  }

double LegacyCampaign_BasketBEUSD()
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   if(LegacyCampaignBasketUsePercent)
      return base * LegacyCampaignBasketBE_Pct / 100.0;

   // MT4-aligned: CHOP/RANGE use +30; directional/Monster campaigns use +50.
   return LegacyCampaign_TightMarketBasket() ? 30.0 : 50.0;
  }

double LegacyCampaign_BasketTrailStartUSD()
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   if(LegacyCampaignBasketUsePercent)
      return base * LegacyCampaignBasketTrailStart_Pct / 100.0;

   // MT4-aligned: CHOP/RANGE trail at +50; directional/Monster at +80.
   return LegacyCampaign_TightMarketBasket() ? 50.0 : 80.0;
  }

double LegacyCampaign_BasketTrailStepUSD()
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   double target = LegacyCampaignBasketUsePercent
                   ? base * LegacyCampaignBasketTrailStep_Pct / 100.0
                   : LegacyCampaignBasketTrailStepUSD;
   return target;
  }

double LegacyCampaign_BasketLossUSD()
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;
   return LegacyCampaignBasketUsePercent
          ? base * LegacyCampaignBasketLoss_Pct / 100.0
          : LegacyCampaignBasketLossUSD;
  }

double LegacyCampaign_GapPrice()
  {
   double atr = CurrentATR1;
   if(atr <= 0.0) atr = CurrentATR5;
   double gap = (atr > 0.0) ? atr * LegacyCampaignGapATRFactor : LegacyCampaignMinGapPrice;
   gap = Clamp(gap, LegacyCampaignMinGapPrice, LegacyCampaignMaxGapPrice);

   // Keep a real distance from the live spread without ever turning the
   // master ladder into the old 200-point remote Factor-B ladder.
   double spreadPrice = CurrentSpreadPoints * _Point;
   gap = MathMax(gap, spreadPrice * 2.0);
   return Clamp(gap, LegacyCampaignMinGapPrice, LegacyCampaignMaxGapPrice);
  }

double LegacyCampaign_SLDistance()
  {
   double d = LegacyCampaignSLPrice;
   double minStop = StopsLevelPrice();
   if(d < minStop * 2.0) d = minStop * 2.0;
   return d;
  }

double LegacyCampaign_TPDistance()
  {
   double d = LegacyCampaignTPPrice;
   double sl = LegacyCampaign_SLDistance();
   if(d < sl * 2.0) d = sl * 2.0;
   return d;
  }

bool LegacyCampaign_PendingExistsNear(ENUM_ORDER_TYPE type, double price, double minDistance)
  {
   for(int i = OrdersTotal()-1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol || ordInfo.Magic() != MagicNumber) continue;
      if(!LegacyCampaign_IsComment(ordInfo.Comment())) continue;
      if(ordInfo.OrderType() != type) continue;
      if(MathAbs(ordInfo.PriceOpen() - price) <= minDistance) return true;
     }
   return false;
  }

bool LegacyCampaign_SendStop(bool isBuy, double price, double lots, string cmt)
  {
   if(lots <= 0.0) return false;
   if(LegacyCampaign_CountPending() >= LegacyCampaignMaxPendingOrders) return false;
   if(LegacyCampaign_CountPositions() >= LegacyCampaignMaxOpenPositions) return false;

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return false;

   double minDist = StopsLevelPrice();
   if(isBuy && price - ask < minDist) return false;
   if(!isBuy && bid - price < minDist) return false;

   double slDist = LegacyCampaign_SLDistance();
   double tpDist = LegacyCampaign_TPDistance();
   double sl = isBuy ? price - slDist : price + slDist;
   double tp = isBuy ? price + tpDist : price - tpDist;

   ENUM_ORDER_TYPE type = isBuy ? ORDER_TYPE_BUY_STOP : ORDER_TYPE_SELL_STOP;
   lots=USDHybrid_ScaleRequestedLots(lots);
   if(lots<=0.0) return false;
   if(V1RiskLayerEnabled)
     {
      double requestedLots=lots;
      lots=V1Risk_RiskLimitedLots(type,price,sl,requestedLots,V1Risk_EngineRiskPctFromComment(cmt));
      if(lots<=0.0)
        {
         PrintFormat("[V1 LEGACY CAMPAIGN STOP BLOCK] risk governor rejected %s symbol=%s requestedLots=%.4f",cmt,_Symbol,requestedLots);
         return false;
        }
     }
   else lots = ValidateLot(lots);
   if(lots <= 0.0) return false;
   if(LegacyCampaign_TotalLots()+lots > LegacyCampaignMaxTotalLots + 1e-12) return false;
   if(!MsgBudget_CanSend()) return false;

   int attempts = UseTransientRetryV2 ? TransientMaxRetries : 1;

   for(int a = 0; a < attempts; a++)
     {
      MqlTradeRequest req;
      BuildReq(req, TRADE_ACTION_PENDING, type,
               NormalizeDouble(price, _Digits), lots,
               NormalizeDouble(sl, _Digits), NormalizeDouble(tp, _Digits), cmt);

      if(OrderCheckPass(req))
        {
         MqlTradeResult res;
         ZeroMemory(res);
         if(!MsgBudget_ReserveEntryRequest(cmt)) return false;
         bool ok = OrderSend(req, res);
         if(ok && (res.retcode == TRADE_RETCODE_DONE ||
                   res.retcode == TRADE_RETCODE_PLACED))
           {
            MsgBudget_TickOpen();
            if(UseSlippageReAnchorV2)
               Anchor_Store(cmt, price, sl, tp);
            return true;
           }

         if(IsTransientRetcode(res.retcode) && a < attempts - 1)
           {
            Sleep(TransientRetryDelayMs);
            continue;
           }
         PrintFormat("[LEGACY CAMPAIGN STOP FAIL] %s ret=%u %s", cmt, res.retcode, res.comment);
        }
      return false;
     }
   return false;
  }

string LegacyCampaign_EnginePrefixFromComment(string cmt)
  {
   if(StringFind(cmt, "SWING_")    >= 0) return "SWING_";
   if(StringFind(cmt, "MONSTER_")  >= 0) return "MONSTER_";
   if(StringFind(cmt, "RANGE_")    >= 0) return "RANGE_";
   if(StringFind(cmt, "REVERSAL_") >= 0) return "REVERSAL_";
   if(StringFind(cmt, "CHOP_")     >= 0) return "CHOP_";
   if(StringFind(cmt, "FB_CHOP_")  >= 0) return "FB_CHOP_";
   if(StringFind(cmt, "FB_TREND_") >= 0) return "FB_TREND_";
   if(StringFind(cmt, "FB_MON_")   >= 0) return "FB_MON_";
   if(StringFind(cmt, "FB_REV_")   >= 0) return "FB_REV_";
   return "";
  }

void LegacyCampaign_CancelCompetingPendings(string activePrefix)
  {
   // V2: pending orders are disposable when a stronger/new engine takes control.
   // Filled positions are deliberately NOT touched; they remain in the unified basket.
   string pfx[9] = {"SWING_","MONSTER_","RANGE_","REVERSAL_","CHOP_",
                    "FB_CHOP_","FB_TREND_","FB_MON_","FB_REV_"};
   for(int i = 0; i < 9; i++)
     {
      if(pfx[i] == activePrefix) continue;
      DeleteOrdersPrefix(pfx[i]);
     }
  }

void LegacyCampaign_ResetState(bool keepCloseTime)
  {
   g_TM_Active         = false;
   g_TM_Start          = 0;
   g_TM_LastReinforce  = 0;
   g_TM_LastSignalDir  = 0;
   g_TM_LastSignalScore= 0.0;
   g_TM_PeakPnL        = 0.0;
   g_TM_TrailFloor     = 0.0;
   g_TM_BEArmed        = false;
   g_TM_TrailArmed     = false;
   g_TM_Reinforcements  = 0;
   g_GenTrackCount      = 0;
   ArrayInitialize(g_GenTrackTicket,0);
   ArrayInitialize(g_GenTrackRiskMoney,0.0);
   ArrayInitialize(g_GenTrackOpen,0);
   g_GenShockBar        = 0;
   g_GenShockActive     = false;
   g_GenShockDir        = 0;
   g_GenShockUntil      = 0;
   g_GenShockPeakR      = 0.0;
   g_GenShockPeakPrice  = 0.0;
   g_GenShockArmPnL     = 0.0;
   g_GenShockHarvested  = false;
   g_GenMFEArmed        = false;
   g_GenPeakR           = 0.0;
   g_GenTrailFloorR     = 0.0;
   if(!keepCloseTime) g_TM_LastClose = 0;
  }

double LegacyCampaign_PositionRiskMoneyFromStop()
  {
   double total = 0.0;
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      double open=posInfo.PriceOpen(), sl=posInfo.StopLoss(), vol=posInfo.Volume();
      if(open<=0.0 || sl<=0.0 || vol<=0.0) continue;
      ENUM_ORDER_TYPE t=(posInfo.PositionType()==POSITION_TYPE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
      double r=V1Risk_OrderRiskMoney(t,open,sl,vol);
      if(r>0.0) total+=r;
     }
   return total;
  }

void Genesis_TrackPositions()
  {
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      ulong ticket=posInfo.Ticket();
      bool found=false;
      for(int j=0;j<g_GenTrackCount;j++)
        {
         if(g_GenTrackTicket[j]==ticket) { found=true; break; }
        }
      if(found) continue;
      if(g_GenTrackCount>=64) continue;
      double open=posInfo.PriceOpen(), sl=posInfo.StopLoss(), vol=posInfo.Volume();
      double risk=0.0;
      if(open>0.0 && sl>0.0 && vol>0.0)
        {
         ENUM_ORDER_TYPE t=(posInfo.PositionType()==POSITION_TYPE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         risk=V1Risk_OrderRiskMoney(t,open,sl,vol);
        }
      if(risk<=0.0)
         risk=0.0;
      g_GenTrackTicket[g_GenTrackCount]=ticket;
      g_GenTrackRiskMoney[g_GenTrackCount]=risk;
      g_GenTrackOpen[g_GenTrackCount]=TimeCurrent();
      g_GenTrackCount++;
     }
  }

double Genesis_CampaignRiskMoney()
  {
   Genesis_TrackPositions();
   double total=0.0;
   for(int i=0;i<g_GenTrackCount;i++) total+=g_GenTrackRiskMoney[i];
   if(total>0.0) return total;
   // Fallback is deliberately small and balance-relative; this is only used
   // if broker-side stop information is temporarily unavailable.
   double eq=AccountInfoDouble(ACCOUNT_EQUITY);
   return (eq>0.0 ? eq*0.005 : 0.0);
  }

double Genesis_CampaignR(double pnl)
  {
   double risk=Genesis_CampaignRiskMoney();
   if(risk<=0.0) return 0.0;
   return pnl/risk;
  }

bool Genesis_DetectShockCandle(int &dir,double &strength)
  {
   dir=0; strength=0.0;
   if(!GenesisUseCandleAwareMFE) return false;
   double o=TfOpen(PERIOD_M1,0), c=TfClose(PERIOD_M1,0);
   double h=TfHigh(PERIOD_M1,0), l=TfLow(PERIOD_M1,0);
   if(o<=0.0 || c<=0.0 || h<=0.0 || l<=0.0) return false;
   double atr=CurrentATR1;
   if(atr<=0.0) return false;
   double range=h-l;
   if(range<atr*GenesisShockRangeATR || range<=0.0) return false;
   double bodyRatio=MathAbs(c-o)/range;
   if(bodyRatio<GenesisShockBodyRatio) return false;
   double avgVol=0.0; int vc=0;
   for(int i=2;i<=21;i++)
     {
      long v=TfVolume(PERIOD_M1,i);
      if(v>0){avgVol+=(double)v;vc++;}
     }
   if(vc>0) avgVol/=(double)vc;
   double volRatio=(avgVol>0.0)?(double)TfVolume(PERIOD_M1,0)/avgVol:0.0;
   int candleDir=(c>o?1:(c<o?-1:0));
   if(candleDir==0) return false;
   double flow=FlowComposite()*(double)candleDir;
   bool cvdShock=(CVDAccelerationNormalized*(double)candleDir >= GenesisShockCVDAccel);
   bool pressure=(flow>=GenesisShockFlowScore ||
                  (g_CUSUMDir==candleDir && g_CUSUMDir!=0) ||
                  VNFlowTradeRateSurge() ||
                  cvdShock ||
                  VNFlowCVDAccelerationStrong(candleDir));
   if(volRatio<GenesisShockVolumeRatio && !pressure) return false;
   if(!pressure && volRatio<1.60) return false;
   dir=candleDir;
   strength=MathMax(range/atr,bodyRatio*2.0);
   return true;
  }

void Genesis_UpdateShockState()
  {
   datetime bar=TfTime(PERIOD_M1,0);
   int dir=0; double strength=0.0;
   bool detected=Genesis_DetectShockCandle(dir,strength);

   if(bar>0 && bar!=g_GenShockBar)
     {
      // Preserve the last shock's MFE through the short settling window. This
      // is essential because +40 -> -30 -> +69 may span the candle boundary.
      bool wasShock=(g_GenShockActive || TimeCurrent()<=g_GenShockUntil);
      if(wasShock)
         g_GenShockUntil=TimeCurrent()+GenesisShockSettleSeconds;
      else
        {
         g_GenShockPeakR=0.0;
         g_GenShockPeakPrice=0.0;
         g_GenShockHarvested=false;
        }
      g_GenShockBar=bar;
      g_GenShockActive=false;
      g_GenShockDir=0;
     }

   if(detected)
     {
      if(!g_GenShockActive && g_GenShockBar==bar && g_GenShockPeakR<=0.0)
        {
         g_GenShockPeakPrice=0.0;
         g_GenShockHarvested=false;
        }
      g_GenShockActive=true;
      g_GenShockDir=dir;
      g_GenShockUntil=TimeCurrent()+GenesisShockSettleSeconds;
      double px=MidPrice();
      if(px>0.0)
        {
         if(g_GenShockPeakPrice<=0.0) g_GenShockPeakPrice=px;
         if(dir==1) g_GenShockPeakPrice=MathMax(g_GenShockPeakPrice,px);
         else       g_GenShockPeakPrice=MathMin(g_GenShockPeakPrice,px);
        }
     }
   else if(TimeCurrent()>g_GenShockUntil)
     {
      g_GenShockActive=false;
      g_GenShockDir=0;
      // Last-shock MFE is now consumed; the normal campaign MFE remains in
      // g_GenPeakR/g_GenTrailFloorR.
      if(g_GenShockPeakR>0.0)
        {
         g_GenShockPeakR=0.0;
         g_GenShockPeakPrice=0.0;
         g_GenShockHarvested=false;
        }
     }
  }

bool Genesis_M5TrueReversal()
  {
   if(!GenesisUseM5TrueReversal) return false;
   int dir=g_V1Risk_CampaignDir;
   if(dir==0)
     {
      for(int i=PositionsTotal()-1;i>=0;i--)
        {
         if(!posInfo.SelectByIndex(i)) continue;
         if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
         dir=(posInfo.PositionType()==POSITION_TYPE_BUY)?1:-1;
         break;
        }
     }
   if(dir==0) return false;
   bool structOpp=V1Risk_OppositeStructure(dir);
   bool flowOpp=V1Risk_OppositeFlow(dir);
   int confirms=(structOpp?1:0)+(flowOpp?1:0);
   double oppScore=0.0;
   if(g_M5ThesisDir==-dir) oppScore=MathMax(oppScore,g_M5ThesisScore);
   if(VNSMC_TrendBreak(-dir)) oppScore=MathMax(oppScore,70.0);
   return (confirms>=GenesisM5ReversalConfirmations && oppScore>=GenesisM5ReversalScore);
  }

void Genesis_HarvestCampaign(int pct,string reason)
  {
   if(pct<=0) return;
   int total=CountOurPositions();
   if(total<=0) return;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      double vol=posInfo.Volume();
      double closeVol=NormalizeLots(vol*(double)pct/100.0);
      if(closeVol<=0.0 || closeVol>=vol || closeVol<g_LotMin) continue;
      MsgBudget_Count(1); // shared account-wide outbound request
      if(trade.PositionClosePartial(posInfo.Ticket(),closeVol))
         MsgBudget_TickModify();
     }
   PrintFormat("[GENESIS HARVEST] %d%% reason=%s peakR=%.2f nowR=%.2f",pct,reason,g_GenPeakR,Genesis_CampaignR(LegacyCampaign_FloatingPnL()));
  }

void LegacyCampaign_SyncState()
  {
   int p = LegacyCampaign_CountPositions();
   int q = LegacyCampaign_CountPending();
   if(p <= 0 && q <= 0)
     {
      LegacyCampaign_ResetState(true);
      return;
     }

   g_TM_Active = true;
   if(g_TM_Start == 0) g_TM_Start = TimeCurrent();
   Genesis_TrackPositions();
   double pnl = LegacyCampaign_FloatingPnL();
   if(pnl > g_TM_PeakPnL) g_TM_PeakPnL = pnl;
  }

int LegacyCampaign_CandleIntentDir(double &score)
  {
   score = 0.0;
   if(!LegacyCampaignUseCandleIntent) return 0;

   double o1 = TfOpen(PERIOD_M1,1), c1 = TfClose(PERIOD_M1,1);
   double h1 = TfHigh(PERIOD_M1,1), l1 = TfLow(PERIOD_M1,1);
   double o2 = TfOpen(PERIOD_M1,2), c2 = TfClose(PERIOD_M1,2);
   double h2 = TfHigh(PERIOD_M1,2), l2 = TfLow(PERIOD_M1,2);
   if(o1<=0 || c1<=0 || h1<=0 || l1<=0 || o2<=0 || c2<=0) return 0;

   double r1 = h1-l1;
   if(r1<=0) return 0;
   double body1 = MathAbs(c1-o1);
   double upper = h1-MathMax(o1,c1);
   double lower = MathMin(o1,c1)-l1;
   double closePos = (c1-l1)/r1;

   int bull=0, bear=0;

   // Engulfing
   if(c2<o2 && c1>o1 && o1<=c2 && c1>=o2 && body1>MathAbs(c2-o2)) bull += 25;
   if(c2>o2 && c1<o1 && o1>=c2 && c1<=o2 && body1>MathAbs(c2-o2)) bear += 25;

   // Hammer / shooting-star geometry
   if(lower >= body1*2.5 && upper <= body1*0.8 && closePos >= 0.60) bull += 20;
   if(upper >= body1*2.5 && lower <= body1*0.8 && closePos <= 0.40) bear += 20;

   // Morning / evening star-like three-candle intent
   double o3 = TfOpen(PERIOD_M1,3), c3 = TfClose(PERIOD_M1,3);
   if(o3>0 && c3>0)
     {
      double r2 = h2-l2;
      bool small2 = (r2>0 && MathAbs(c2-o2) <= r2*0.35);
      if(c3<o3 && small2 && c1>o1 && c1 > (o3+c3)*0.5) bull += 15;
      if(c3>o3 && small2 && c1<o1 && c1 < (o3+c3)*0.5) bear += 15;
     }

   // Kicker-like displacement continuation
   if(c2<o2 && o1>=o2 && c1>o1 && closePos>=0.70) bull += 10;
   if(c2>o2 && o1<=o2 && c1<o1 && closePos<=0.30) bear += 10;

   if(MathMax(bull,bear) < LegacyCampaignMinPatternScore) return 0;
   if(bull > bear) { score = bull; return 1; }
   if(bear > bull) { score = bear; return -1; }
   return 0;
  }

bool LegacyCampaign_LiveImpulse(int &dir, double &score)
  {
   dir = 0; score = 0.0;
   double o = TfOpen(PERIOD_M1,0), c = TfClose(PERIOD_M1,0);
   double h = TfHigh(PERIOD_M1,0), l = TfLow(PERIOD_M1,0);
   double atr = CurrentATR1;
   if(o<=0 || c<=0 || h<=0 || l<=0 || atr<=0) return false;

   double range = h-l;
   if(range <= 0.0) return false;
   double bodyRatio = MathAbs(c-o)/range;
   double closePos = (c-l)/range;
   if(range < atr*LegacyCampaignLiveImpulseATR || bodyRatio < LegacyCampaignLiveBodyRatio) return false;

   if(c>o && closePos>=LegacyCampaignLiveCloseLocation)
     { dir=1; score=40.0 + MathMin(25.0, range/atr*10.0); return true; }
   if(c<o && closePos<=1.0-LegacyCampaignLiveCloseLocation)
     { dir=-1; score=40.0 + MathMin(25.0, range/atr*10.0); return true; }
   return false;
  }

void LegacyCampaign_SignalScore(int &bestDir, double &bestScore)
  {
   bestDir = 0; bestScore = 0.0;
   double bull=0.0, bear=0.0;

   // Closed M1 structure/event evidence — the strongest part of the existing
   // LegacyFast/V2 intelligence.
   if(M1PA_BullSweep) bull += 25.0;
   if(M1PA_BullMSS)   bull += 25.0;
   if(M1PA_BullDisp)  bull += 20.0;
   if(M1PA_BullFVG)   bull += 10.0;
   if(M1PA_BearSweep) bear += 25.0;
   if(M1PA_BearMSS)   bear += 25.0;
   if(M1PA_BearDisp)  bear += 20.0;
   if(M1PA_BearFVG)   bear += 10.0;

   // M1 PA score is an existing aggregate; use it as a small reinforcement,
   // not as a duplicate full vote.
   if(M1PA_Dir==1)  bull += MathMin(15.0, M1PA_Score*0.15);
   if(M1PA_Dir==-1) bear += MathMin(15.0, M1PA_Score*0.15);

   // Existing LegacyFast shock engines are signal providers, not separate trade
   // owners. A fresh CUSUM/KillShot/Monster event can therefore arm the
   // LegacyCampaign campaign before the ordinary M1 bar-close dispatcher.
   if(g_CUSUMDir == 1 && TimeCurrent() <= g_CUSUMOverrideUntil) bull += 20.0;
   if(g_CUSUMDir == -1 && TimeCurrent() <= g_CUSUMOverrideUntil) bear += 20.0;
   if(g_MonsterDir == 1 && g_MonsterPhase != MP_IDLE) bull += 15.0;
   if(g_MonsterDir == -1 && g_MonsterPhase != MP_IDLE) bear += 15.0;
   int ksDir=0;
   if(UseKillShot && KillShotTrigger(ksDir))
     {
      if(ksDir==1) bull += 20.0;
      if(ksDir==-1) bear += 20.0;
     }

   double candleScore=0.0; int candleDir=LegacyCampaign_CandleIntentDir(candleScore);
   if(candleDir==1) bull += candleScore*0.60;
   if(candleDir==-1) bear += candleScore*0.60;

   if(M5Direction==1 || g_SMC.m5_bias==1) bull += 15.0;
   if(M5Direction==-1 || g_SMC.m5_bias==-1) bear += 15.0;
   if(g_SMC.m15_bias==1) bull += 5.0;
   if(g_SMC.m15_bias==-1) bear += 5.0;
   if(UseFastTrendScore && g_FastTrendDir==1) bull += 10.0;
   if(UseFastTrendScore && g_FastTrendDir==-1) bear += 10.0;

   int liveDir=0; double liveScore=0.0;
   if(LegacyCampaign_LiveImpulse(liveDir, liveScore))
     {
      if(liveDir==1) bull += liveScore*0.50;
      else if(liveDir==-1) bear += liveScore*0.50;
     }

   // A strong counter-context M1 event is allowed to arm the campaign; a
   // weak counter-context event is ignored rather than fighting M5 blindly.
   if(bull > bear)
     {
      if((M5Direction==-1 || g_SMC.m5_bias==-1) && bull < LegacyCampaignCounterOverrideScore) return;
      bestDir=1; bestScore=Clamp(bull,0.0,100.0);
     }
   else if(bear > bull)
     {
      if((M5Direction==1 || g_SMC.m5_bias==1) && bear < LegacyCampaignCounterOverrideScore) return;
      bestDir=-1; bestScore=Clamp(bear,0.0,100.0);
     }
  }

bool LegacyCampaign_ArmTrigger(int &dir, double &score)
  {
   LegacyCampaign_SignalScore(dir, score);
   if(dir!=0 && score>=LegacyCampaignMinArmScore) return true;

   // Keep the live M1 impulse path available even if the closed-bar aggregate
   // has not yet caught up.
   int liveDir=0; double liveScore=0.0;
   if(LegacyCampaign_LiveImpulse(liveDir, liveScore))
     {
      bool m5Aligned = (M5Direction==liveDir || g_SMC.m5_bias==liveDir);
      if(m5Aligned || liveScore>=LegacyCampaignCounterOverrideScore)
        {
         dir=liveDir; score=liveScore;
         return (score>=LegacyCampaignMinArmScore);
        }
     }
   return false;
  }

bool LegacyCampaign_PlaceInitialStraddle(int signalDir, double signalScore)
  {
   if(!V1LegacyCampaignEnabled) return false;
   if(LegacyCampaign_CountAllExposure()>0) return false;
   if(TotalOurLots() > 1e-12) return false;
   if(TimeCurrent()-g_TM_LastClose < LegacyCampaignRearmCooldownSec) return false;
   if(LegacyCampaignInitialBuyOrders + LegacyCampaignInitialSellOrders > LegacyCampaignMaxPendingOrders) return false;

   double gap = LegacyCampaign_GapPrice();
   double ask = AskPrice(), bid = BidPrice();
   if(ask<=0 || bid<=0) return false;

   int placedBuy=0, placedSell=0;
   for(int i=0; i<LegacyCampaignInitialBuyOrders; i++)
     {
      double price = NormalizeDouble(ask + gap*(i+1), _Digits);
      if(!LegacyCampaign_PendingExistsNear(ORDER_TYPE_BUY_STOP, price, gap*0.20))
        {
         string cmt = "TM_B"+IntegerToString(i);
         if(LegacyCampaign_SendStop(true, price, LegacyCampaignBaseLot, cmt)) placedBuy++;
        }
     }
   for(int i=0; i<LegacyCampaignInitialSellOrders; i++)
     {
      double price = NormalizeDouble(bid - gap*(i+1), _Digits);
      if(!LegacyCampaign_PendingExistsNear(ORDER_TYPE_SELL_STOP, price, gap*0.20))
        {
         string cmt = "TM_S"+IntegerToString(i);
         if(LegacyCampaign_SendStop(false, price, LegacyCampaignBaseLot, cmt)) placedSell++;
        }
     }

   int placed=placedBuy+placedSell;
   if(placed<=0) return false;

   g_TM_Active          = true;
   g_TM_Start           = TimeCurrent();
   g_TM_LastSignalDir   = signalDir;
   g_TM_LastSignalScore = signalScore;
   g_TM_PeakPnL         = LegacyCampaign_FloatingPnL();
   g_TM_TrailFloor      = 0.0;
   g_TM_BEArmed         = false;
   g_TM_TrailArmed      = false;
   g_TM_Reinforcements  = 0;
   g_TM_Sequence++;

   PrintFormat("[LEGACY CAMPAIGN START] seq=%d signal=%s score=%.1f buy=%d sell=%d lot=%.2f gap=%.2f SL=%.2f TP=%.2f",
               g_TM_Sequence, DirStr(signalDir), signalScore,
               placedBuy, placedSell, LegacyCampaignBaseLot, gap,
               LegacyCampaign_SLDistance(), LegacyCampaign_TPDistance());
   return true;
  }

bool LegacyCampaign_ReinforcePair(int signalDir, double signalScore)
  {
   if(!g_TM_Active || signalDir==0 || signalScore<LegacyCampaignMinReinforceScore) return false;
   if(LegacyCampaign_CountPositions()<=0) return false;
   if(g_TM_Reinforcements>=LegacyCampaignMaxReinforcements) return false;
   if(TimeCurrent()-g_TM_LastReinforce < LegacyCampaignReinforceCooldownSec) return false;

   double gap = LegacyCampaign_GapPrice();
   double ask = AskPrice(), bid = BidPrice();
   if(ask<=0 || bid<=0) return false;

   // Every meaningful new directional event adds one order on EACH side.
   // This preserves the campaign's two-choice mathematics while keeping the
   // reservoir close to the current M1 price path.
   int n = g_TM_Reinforcements + 1;
   double buyPrice = NormalizeDouble(ask + gap, _Digits);
   double sellPrice= NormalizeDouble(bid - gap, _Digits);
   bool buyOK=false, sellOK=false;

   if(LegacyCampaign_CountPending() < LegacyCampaignMaxPendingOrders &&
      !LegacyCampaign_PendingExistsNear(ORDER_TYPE_BUY_STOP, buyPrice, gap*0.20))
      buyOK = LegacyCampaign_SendStop(true, buyPrice, LegacyCampaignReinforceLot,
                              "TM_RB"+IntegerToString(n));

   if(LegacyCampaign_CountPending() < LegacyCampaignMaxPendingOrders &&
      !LegacyCampaign_PendingExistsNear(ORDER_TYPE_SELL_STOP, sellPrice, gap*0.20))
      sellOK = LegacyCampaign_SendStop(false, sellPrice, LegacyCampaignReinforceLot,
                               "TM_RS"+IntegerToString(n));

   if(buyOK || sellOK)
     {
      g_TM_Reinforcements++;
      g_TM_LastReinforce = TimeCurrent();
      g_TM_LastSignalDir = signalDir;
      g_TM_LastSignalScore = signalScore;
      PrintFormat("[LEGACY CAMPAIGN REINFORCE] n=%d signal=%s score=%.1f gap=%.2f buy=%d sell=%d",
                  g_TM_Reinforcements, DirStr(signalDir), signalScore,
                  gap, (int)buyOK, (int)sellOK);
      return true;
     }
   return false;
  }

void LegacyCampaign_MoveAllToBE()
  {
   double spreadBuf = CurrentSpreadPoints * _Point * 1.5;
   double buf = MathMax(LegacyCampaignBEOffsetPrice, spreadBuf);

   for(int i=PositionsTotal()-1; i>=0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      if(!LegacyCampaign_IsComment(posInfo.Comment())) continue;

      bool isBuy = (posInfo.PositionType()==POSITION_TYPE_BUY);
      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      double tp   = posInfo.TakeProfit();
      double desired = isBuy ? open + buf : open - buf;

      if(isBuy)
        {
         desired = MathMin(desired, BidPrice()-spreadBuf);
         if(desired > stop + _Point)
            SafeModify(posInfo.Ticket(), NormalizeDouble(desired,_Digits), tp);
        }
      else
        {
         desired = MathMax(desired, AskPrice()+spreadBuf);
         if(stop==0.0 || desired < stop - _Point)
            SafeModify(posInfo.Ticket(), NormalizeDouble(desired,_Digits), tp);
        }
     }
  }

void LegacyCampaign_UpdatePositionTrail()
  {
   double trailGap = MathMax(LegacyCampaignPositionTrailPrice,
                             CurrentSpreadPoints*_Point*LegacyCampaignPositionTrailSpreadMult);
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      if(!LegacyCampaign_IsComment(posInfo.Comment())) continue;

      bool isBuy = (posInfo.PositionType()==POSITION_TYPE_BUY);
      double stop = posInfo.StopLoss();
      double tp = posInfo.TakeProfit();
      double desired = isBuy ? BidPrice()-trailGap : AskPrice()+trailGap;
      desired = NormalizeDouble(desired,_Digits);

      if(isBuy && (stop<=0.0 || desired > stop+_Point))
         SafeModify(posInfo.Ticket(), desired, tp);
      if(!isBuy && (stop<=0.0 || desired < stop-_Point))
         SafeModify(posInfo.Ticket(), desired, tp);
     }
  }

void LegacyCampaign_CloseCampaign(string reason)
  {
   // Unified campaign close: delete ALL pending orders and close ALL positions
   // for this symbol + magic, regardless of which engine created them.
   DeleteOrdersPrefix("");
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      ClosePosition(posInfo.Ticket());
     }

   PrintFormat("[LEGACY CAMPAIGN CLOSE] reason=%s peak=%.2f trailFloor=%.2f finalPnL=%.2f",
               reason, g_TM_PeakPnL, g_TM_TrailFloor, LegacyCampaign_FloatingPnL());
   g_TM_LastClose = TimeCurrent();
   for(int fi=0; fi<4; fi++) g_FB_LastClose[fi] = g_TM_LastClose;
   LegacyCampaign_ResetState(true);
  }

void LegacyCampaign_DeleteExpiredPendings()
  {
   // V2: pending lifetime remains engine-owned. The LegacyCampaign does not expire
   // valid SWING/MONSTER/RANGE/CHOP ladders behind the engine's back.
  }

void LegacyCampaign_ManageBasket()
  {
   LegacyCampaign_SyncState();
   if(!g_TM_Active) return;

   int positions=LegacyCampaign_CountPositions();
   int pending=LegacyCampaign_CountPending();
   if(positions<=0)
     {
      if(pending<=0) LegacyCampaign_ResetState(true);
      return;
     }

   Genesis_UpdateShockState();

   double pnl = LegacyCampaign_FloatingPnL();
   double campR = Genesis_CampaignR(pnl);
   if(campR > g_GenPeakR) g_GenPeakR=campR;
   if(campR > g_TM_PeakPnL) g_TM_PeakPnL=pnl;

   // Hard safety: never allow a campaign to drift beyond the broker-side
   // stops because the EA is waiting for a basket signal.
   double hardLossR = -2.00;
   if(campR <= hardLossR)
     {
      LegacyCampaign_CloseCampaign("GENESIS_HARD_LOSS");
      return;
     }

   // M5 thesis reversal is the final thesis-level exit authority.
   if(Genesis_M5TrueReversal())
     {
      LegacyCampaign_CloseCampaign("GENESIS_M5_TRUE_REVERSAL");
      return;
     }

   // ---------------- SHOCK / EXPANSION MODE ----------------
   // No MFE floor ratchets tighter while the current violent M1 candle is
   // alive. This is the direct fix for the observed +40 -> -30 -> +69 path.
   if(g_GenShockActive || TimeCurrent() <= g_GenShockUntil)
     {
      if(campR > g_GenShockPeakR) g_GenShockPeakR=campR;

      // Bank a controlled fraction once the campaign has genuinely earned
      // enough R. This protects profit without killing the runner at the peak.
      if(!g_GenShockHarvested && g_GenShockPeakR >= GenesisShockHarvestArmR)
        {
         Genesis_HarvestCampaign(GenesisShockHarvestPct,"SHOCK_PEAK");
         g_GenShockHarvested=true;
         return;
        }

      // During shock we deliberately do NOT run the old fixed-dollar basket
      // BE/trail. The hard individual SLs remain active at broker level.
      return;
     }

   // ---------------- POST-SHOCK SETTLING ----------------------------
   if(g_GenShockPeakR >= GenesisShockHarvestArmR &&
      campR > GenesisShockFullExitMinR &&
      (g_GenShockPeakR-campR) >= GenesisShockFullExitGivebackR)
     {
      // After a shock candle resolves, a large giveback is allowed only to
      // tighten to the normal campaign floor. Full exit still requires thesis
      // reversal, which was checked above.
      g_GenMFEArmed=true;
     }

   // ---------------- NORMAL CAMPAIGN MFE ----------------------------
   if(g_GenPeakR >= GenesisMFEArmR)
     {
      g_GenMFEArmed=true;
      double floorR=MathMax(GenesisMinimumLockR,
                            g_GenPeakR*(GenesisNormalLockPct/100.0));
      if(g_GenTrailFloorR<=0.0 || floorR > g_GenTrailFloorR+0.05)
         g_GenTrailFloorR=floorR;

      // If price/profit retraces materially after a shock and the flow is no
      // longer supportive, take a second controlled harvest instead of a blind
      // full campaign close.
      if(g_GenShockPeakR >= GenesisShockHarvestArmR &&
         (g_GenShockPeakR-campR) >= GenesisShockHarvestPullbackR &&
         campR > GenesisShockFullExitMinR &&
         !g_GenShockHarvested)
        {
         Genesis_HarvestCampaign(GenesisShockHarvestPct,"SHOCK_PULLBACK");
         g_GenShockHarvested=true;
         return;
        }

      if(campR <= g_GenTrailFloorR && campR > 0.0)
        {
         LegacyCampaign_CloseCampaign("GENESIS_MFE_TRAIL");
         return;
        }
     }

   // Lightweight protective BE after the campaign has clearly cleared noise.
   // It is suppressed in shock mode and never competes with the unified MFE
   // authority.
   if(g_GenPeakR >= 2.0 && !g_GenShockActive && !g_TM_BEArmed)
     {
      LegacyCampaign_MoveAllToBE();
      g_TM_BEArmed=true;
     }
  }

void LegacyCampaign_OnNewM1()
  {
   if(!V1LegacyCampaignEnabled) return;
   LegacyCampaign_SyncState();
   LegacyCampaign_ManageBasket();
  }

void LegacyCampaign_OnTickStart()
  {
   if(!V1LegacyCampaignEnabled) return;
   LegacyCampaign_SyncState();
   LegacyCampaign_ManageBasket();
  }

bool LegacyCampaign_IsActive()
  {
   return (V1LegacyCampaignEnabled &&
           (g_TM_Active || LegacyCampaign_CountPositions()>0 || LegacyCampaign_CountPending()>0));
  }

//===================================================================
// SECTION 103 — LEGACY CAMPAIGN ENGINE DISPATCHER [GENESIS INTELLIGENCE + LEGACY FALLBACK]
//===================================================================
void RunEngines()
  {
   if(UseLegacyFastBaseline) LegacyFast_DeleteStaleContinuationPendings();
   if(TimeCurrent() < PauseUntil) return;
   if(DailyHalted || GlobalHalted) return;
   if(!MsgBudget_CanTrade()) return;

   // Genesis Intelligence is the sole new-entry authority when enabled.
   // Factor B still contributes fallback data, but it cannot compete as a trader.
   if(UseGenesisIntelligence && GenesisIntelBlockLegacy)
     {
      LogFactorSwitchIfChanged();
      if(!GenesisV4Enable) GenesisIntelligence_Dispatch();
      return;
     }

   //--- Base gates for legacy mode
   if(!SpreadOK()) return;
   if(!SessionAllowed()) return;
   if(!HourFilterOK()) return;
   if(WickPauseActive()) return;

   DetectMoveState();
   if(UseFastTrendScore) ComputeFastTrendScore();
   LogFactorSwitchIfChanged();

   if(g_ActiveFactor == FACTOR_B_FALLBACK)
     {
      RunFactorB();
      return;
     }

   if(Rev_Tick()) return;
   if(CUSUMShockRun()) return;
   if(KillShotFastPath()) return;

   if(UseVWAPChopStraddle &&
      (g_R7 == R7_CHOP || g_R7 == R7_COMPRESSION) &&
      UseFastTrendScore && g_FastTrendScore < FastTrend_ChopThreshold)
     {
      if(PlaceVWAPChopStraddle()) return;
     }

   if(Monster_Run()) return;
   if(UseLegacyFastBaseline && LegacyFast_Path_Run()) return;
   if(Swing_Run()) return;
   if(Range_Run()) return;
  }

//===================================================================
// SECTION 104 — DIAGNOSTICS [A5: 60s DIAG-FULL]
//===================================================================
void PrintDiagnostics()
  {
   static datetime lastDiag = 0;
   if(TimeCurrent() - lastDiag < 600) return;
   lastDiag = TimeCurrent();

   PrintFormat("[DIAG] R7=%s conf=%.2f | FastTrend=%.0f dir=%d | Health=%d | "
               "Flow=%s comp=%.1f | Monster=%s Rev=%s | "
               "Pos S/M/R/V=%d/%d/%d/%d | Trades=%d W/L=%d/%d PF=%.2f | "
               "AccountMsgs=%d entryCap=%d hardWarn=%d Grid=%d | Factor=%s",
               Regime7Name(g_R7), g_R7Confidence,
               g_FastTrendScore, g_FastTrendDir,
               (int)g_HealthState,
               FlowStateStr(), FlowComposite(),
               MonsterPhaseStr(), RevStateStr(),
               CountEnginePositions("SWING_"),
               CountEnginePositions("MONSTER_"),
               CountEnginePositions("RANGE_"),
               CountEnginePositions("REVERSAL_"),
               WinCount + LossCount, WinCount, LossCount,
               (TotalLossUSD > 0.0) ? TotalWinUSD / TotalLossUSD : 0.0,
               MsgBudget_GetCount(), MsgBudget_EntryLimit(), MsgBudgetHardLimit,
               g_GridLevelV2,
               FactorStr(g_ActiveFactor));
   if(V1RiskLayerEnabled)
      PrintFormat("[V1] campaign=%d dir=%s reserved=%.2f/%.2f rem=%.2f market=%d/%d pending=%d/%d peakR=%.2f",
                  (int)g_V1Risk_CampaignActive, DirStr(g_V1Risk_CampaignDir),
                  0.0, 0.0, 0.0,
                  g_V1Risk_MarketEntries, V1MaxMarketEntries,
                  CountPendingTotal(), V1Risk_EffectivePairMaxPendingOrders(), g_V1Risk_CampaignPeakR);
  }

void PrintDiagFull()   // [A5] Every 60s full snapshot
  {
   static datetime lastDiagFull = 0;
   if(TimeCurrent() - lastDiagFull < 60) return;
   lastDiagFull = TimeCurrent();

   PrintFormat("[DIAG-FULL] StopsLevel=%.0f Spread=%.0f SLbuf=%.0f "
               "PendTotal=%d CHOP p/o=%d/%d SWING p/o=%d/%d MONSTER p/o=%d/%d REV p/o=%d/%d "
               "Health=%d(%s) R7=%s FastT=%.0f Flow=%s "
               "AccountMsgs=%d entryCap=%d hardWarn=%d",
               StopsLevelPrice() / _Point,
               CurrentSpreadPoints,
               SafeTrailBuffer() / _Point,
               CountPendingTotal(),
               CountEnginePositions("CHOP_"),    CountEngineOrders("CHOP_"),
               CountEnginePositions("SWING_"),   CountEngineOrders("SWING_"),
               CountEnginePositions("MONSTER_"), CountEngineOrders("MONSTER_"),
               CountEnginePositions("REVERSAL_"),CountEngineOrders("REVERSAL_"),
               (int)g_HealthState, g_HealthReason,
               Regime7Name(g_R7),
               g_FastTrendScore,
               FlowStateStr(),
               MsgBudget_GetCount(), MsgBudget_EntryLimit(), MsgBudgetHardLimit);
  }

//===================================================================
// SECTION 105 — CHART DISPLAY [C3]
//===================================================================
void UpdateDisplay()
  {
   if(!ShowDisplay) return;

   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double dayDD   = (DayStartEquity > 0.0)
                    ? (DayStartEquity - equity) / DayStartEquity * 100.0 : 0.0;
   double peakDD  = (PeakEquity > 0.0)
                    ? (PeakEquity - equity) / PeakEquity * 100.0 : 0.0;

   int totalTrades = WinCount + LossCount;
   double winRate = (totalTrades > 0) ? (double)WinCount / (double)totalTrades * 100.0 : 0.0;
   double pf = (TotalLossUSD > 0.0) ? TotalWinUSD / TotalLossUSD : 0.0;
   double net = TotalWinUSD - TotalLossUSD;

   string s = "";
   s += "════════════════════════════════════════════════\n";
   s += " TWO BROTHERS TRADING  ·  BGBI SUPER INTELLIGENCE V1\n";
   s += "════════════════════════════════════════════════\n";
   s += StringFormat(" Account: %s  Currency: %s  Contract: %.2f\n",
                     AccountModeLabel(), g_AcctCurrency, g_ContractSize);
   s += StringFormat(" Symbol: %s  Magic: %d  Factor: %s\n",
                     _Symbol, MagicNumber, FactorStr(g_ActiveFactor));
   s += StringFormat(" Spread=%.0f pts  SL_buf=%.0f  Stops_lvl=%.0f\n",
                     CurrentSpreadPoints, SafeTrailBuffer() / _Point,
                     StopsLevelPrice() / _Point);
   s += StringFormat(" Account msgs today: %d | entry cap=%d | hard warning=%d %s\n",
                     MsgBudget_GetCount(), MsgBudget_EntryLimit(), MsgBudgetHardLimit,
                     (MsgBudget_SoftThrottled() ? "[NEW ENTRIES PAUSED]" : ""));

   s += "─── L1 CONTEXT ───\n";
   s += StringFormat("  Regime: %s  conf=%.2f\n",
                     Regime7Name(g_R7), g_R7Confidence);
   s += StringFormat("  FastTrend: %.0f dir=%s\n",
                     g_FastTrendScore, DirStr(g_FastTrendDir));
   s += StringFormat("  Health: %s (%s)\n", HealthStr(), g_HealthReason);
   s += StringFormat("  Flow: %s  comp=%.1f\n", FlowStateStr(), FlowComposite());
   if(UseBGBIProfileIntel)
     {
      double ps=0.0,psc=0.0,pr=0.0,prc=0.0;
      BPI_NearestLevels(MidPrice(),ps,psc,pr,prc);
      s += StringFormat("  Profile: %s POC=%s BuyEst=%.1f%% S=%s/%.0f R=%s/%.0f\n",
                        (g_BPIValid?"READY":"WARMUP"),DoubleToString(g_BPIPOC,_Digits),
                        g_BPIBuyShare*100.0,(ps>0.0?DoubleToString(ps,_Digits):"--"),psc,
                        (pr>0.0?DoubleToString(pr,_Digits):"--"),prc);
     }

   if(UseGenesisIntelligence)
     {
      s += "─── GENESIS INTELLIGENCE ───\n";
      s += StringFormat("  Phase=%s Action=%s Dir=%s Conf=%.1f\n",
                        g_GI.phaseText, g_GI.actionText, DirStr(g_GI.direction), g_GI.finalConfidence);
      s += StringFormat("  BullCtrl=%.1f BearCtrl=%.1f Flow=%.1f MTF=%.1f Loc=%.1f\n",
                        g_GI.bullControl,g_GI.bearControl,g_GI.flowPressure,g_GI.mtfCoherence,g_GI.locationScore);
      s += StringFormat("  Vol=%.1f Ignition=%.1f Exhaust=%.1f Reversal=%.1f\n",
                        g_GI.volatilityScore,g_GI.ignitionScore,g_GI.exhaustionScore,g_GI.reversalProbability);
      s += StringFormat("  Transition=%.1f Efficiency=%.2f Chase=%.1f Fresh=%.1f\n",
                        g_GI.transitionProbability,g_GI.priceEfficiency,g_GI.chaseRisk,g_GI.signalFreshness);
      s += StringFormat("  M5 EMA=%s score=%.1f spread=%.2fATR Cross=%s%s\n",
                        DirStr(g_GI.m5ThesisDir),g_GI.m5ThesisScore,g_GI.m5ThesisSpreadATR,
                        (g_GI.m5ThesisCrossUp?"B":"-"),(g_GI.m5ThesisCrossDown?"S":"-"));
      s += StringFormat("  M1 EMA=%s lead=%.1f spread=%.3f slope=%.3f Cross=%s%s Confirm=%s\n",
                        DirStr(g_GI.m1LeadDir),g_GI.m1LeadScore,g_GI.m1LeadSpreadATR,g_GI.m1LeadSlopeATR,
                        (g_GI.m1LeadCrossUp?"B":"-"),(g_GI.m1LeadCrossDown?"S":"-"),
                        (g_GI.m1LeadConfirmed?"YES":"no"));
      s += StringFormat("  Proof Market=%s Stop=%s MSS=%s Disp=%s Fresh=%.1f\n",
                        (g_GI.marketProof?"YES":"no"),(g_GI.stopProof?"YES":"no"),
                        (g_GI.m1StructureProof?"YES":"no"),(g_GI.m1DisplacementProof?"YES":"no"),g_GI.m1LeadFreshness);
      s += StringFormat("  FAST_TRANSITION=%s newDir=%s ArmedStop=%s trigger=%.*f\n",
                        (g_GI.fastTransition?"YES":"no"),DirStr(g_GI.transitionDirection),
                        (g_GI_TransitionArmedDir!=0?"YES":"no"),_Digits,g_GI_TransitionTrigger);
      if(GenesisV4Enable)
        {
         s += StringFormat("  M15 Bias=%s Phase=%s\n",DirStr(g_V4_M15Bias),V4_M15PhaseText());
         s += StringFormat("  V4 M5=%s/%.1f M1TACT=%s/%.1f aligned=%s postfill=%s defense=%s contStop=%d\n",
                           DirStr(g_GI.v4M5PrimaryDir),g_GI.v4M5PrimaryScore,
                           DirStr(g_GI.v4M1TacticalDir),g_GI.v4M1TacticalScore,
                           (g_GI.v4DualAligned?"YES":"no"),(g_GI.v4PostFillDefense?"YES":"no"),DirStr(g_GI.v4DefenseDir),g_V4_ContinuationArmCount);
         s += StringFormat("  SUPER HYBRID router=%s reason=%s rangePair=%d pend=%d risk=%.2f/%.2f M5score=%.1f\n",
                           g_V1Route_State,g_V1Route_LastDecision,V1RangeLimit_CountOwnPendings(),CountPendingTotal(),
                           V1Risk_ReservedRiskMoney(),V1Risk_CampaignBudgetMoney(),V1Route_M5ClosedSetupScore(V4_M5PrimaryDir()));
        }
      s += StringFormat("  Lux=BM%d BE%d / RM%d RE%d Flip=%s%s LuxTr=%.1f\n",
                        g_GI.luxBullMomentum,g_GI.luxBullExhaustion,g_GI.luxBearMomentum,g_GI.luxBearExhaustion,
                        (g_GI.luxBullFlip?"B":"-"),(g_GI.luxBearFlip?"S":"-"),g_GI.luxTransitionScore);
      s += StringFormat("  Spectral=%d dir=%s slope=%.2fATR low=%.2f high=%.2f conc=%.2f tr=%.1f\n",
                        g_GI.spectralState,DirStr(g_GI.spectralDirection),g_GI.spectralSlopeATR,
                        g_GI.spectralLowFrac,g_GI.spectralHighFrac,g_GI.spectralConcentration,g_GI.spectralTransition);
      s += StringFormat("  ExposureCap=%d/%d Entries=%d/%d\n",
                        GenesisIntel_MaxPositionsAllowed(),GenesisIntelMaxPositions,g_GI_EntriesCampaign,GenesisIntel_MaxEntriesAllowed());
      s += StringFormat("  Thesis: %s | entries=%d/%d | %s\n",
                        g_GI.reason,g_GI_EntriesCampaign,GenesisIntelMaxEntriesCampaign,
                        (GenesisIntelBlockLegacy?"LEGACY BLOCKED":"LEGACY ON"));
     }

   s += "─── L4 DISPATCH ───\n";
   s += StringFormat("  Last engine: %s\n", EngineName(g_LastEngine));
   s += StringFormat("  CUSUM dir=%d  until=%s\n", g_CUSUMDir,
                     (TimeCurrent() <= g_CUSUMOverrideUntil ? "YES" : "no"));
   s += StringFormat("  Rev sentinel: %s dir=%d checks=%d\n",
                     RevStateStr(), g_RevDir, g_RevConfirmCount);
   s += StringFormat("  Grid=%d  Straddle=%d  FactorB mode=%s\n",
                     g_GridLevelV2, (int)g_StraddleActive,
                     FB_ModeName(g_FB_Mode));

   s += "─── ENGINES (Factor A) ───\n";
   s += StringFormat("  SWING:    %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("SWING_"), CountEngineOrders("SWING_"),
                     PrefixFloatingPnL("SWING_"));
   s += StringFormat("  MONSTER:  %d pos / %d ord  $%+.2f [%s]\n",
                     CountEnginePositions("MONSTER_"), CountEngineOrders("MONSTER_"),
                     PrefixFloatingPnL("MONSTER_"), MonsterPhaseStr());
   s += StringFormat("  RANGE:    %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("RANGE_"), CountEngineOrders("RANGE_"),
                     PrefixFloatingPnL("RANGE_"));
   s += StringFormat("  REVERSAL: %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("REVERSAL_"), CountEngineOrders("REVERSAL_"),
                     PrefixFloatingPnL("REVERSAL_"));
   s += StringFormat("  CHOP:     %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("CHOP_"), CountEngineOrders("CHOP_"),
                     PrefixFloatingPnL("CHOP_"));

   s += "─── ENGINES (Factor B) ───\n";
   s += StringFormat("  FB_CHOP:   %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("FB_CHOP_"), CountEngineOrders("FB_CHOP_"),
                     PrefixFloatingPnL("FB_CHOP_"));
   s += StringFormat("  FB_TREND:  %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("FB_TREND_"), CountEngineOrders("FB_TREND_"),
                     PrefixFloatingPnL("FB_TREND_"));
   s += StringFormat("  FB_MON:    %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("FB_MON_"), CountEngineOrders("FB_MON_"),
                     PrefixFloatingPnL("FB_MON_"));
   s += StringFormat("  FB_REV:    %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("FB_REV_"), CountEngineOrders("FB_REV_"),
                     PrefixFloatingPnL("FB_REV_"));

   if(V1RiskLayerEnabled)
     {
      s += "─── BGBI V1 RISK ───\n";
      s += StringFormat("  Campaign: %s dir=%s age=%dmin\n",
                        (g_V1Risk_CampaignActive ? "ACTIVE" : "IDLE"),
                        DirStr(g_V1Risk_CampaignDir),
                        (g_V1Risk_CampaignStart > 0 ? (int)((TimeCurrent()-g_V1Risk_CampaignStart)/60) : 0));
      s += StringFormat("  Risk reserved=%.2f / %.2f remaining=%.2f Mkt=%d/%d Pend=%d/%d\n",
                        V1Risk_ReservedRiskMoney(), V1Risk_CampaignBudgetMoney(), V1Risk_RemainingRiskMoney(),
                        g_V1Risk_MarketEntries, V1MaxMarketEntries, CountPendingTotal(), V1Risk_EffectivePairMaxPendingOrders());
      s += StringFormat("  Router=%s reason=%s\n",g_V1Route_State,g_V1Route_LastDecision);
      s += StringFormat("  FlowCore=%s AuxHealth=%d\n",
                        (V1CoreFlowReady() ? "LIVE" : "STALE"), (int)g_HealthState);
      s += StringFormat("  ExitGovernor=%s noise=%ds BE=%.2fR protect=%.2fR trail=%.2fR\n",
                        (V1SingleExitControllerEnabled ? "ON" : "OFF"), V1NoiseImmunitySec,
                        V1BE_R, V1Protect_R, V1Trail_R);
     }

   if(V1LegacyCampaignEnabled)
     {
      double tmPnl = LegacyCampaign_FloatingPnL();
      s += "─── LEGACY FAST LEGACY CAMPAIGN ───\n";
      s += StringFormat("  %s dir=%s age=%dmin signal=%s/%.1f repl=%d\n",
                        (LegacyCampaign_IsActive()?"ACTIVE":"IDLE"), DirStr(g_TM_LastSignalDir),
                        (g_TM_Start>0 ? (int)((TimeCurrent()-g_TM_Start)/60) : 0),
                        DirStr(g_TM_LastSignalDir), g_TM_LastSignalScore, g_TM_Reinforcements);
      s += StringFormat("  Pos=%d/%d Pend=%d/%d Lots=%.2f/%.2f PnL=$%+.2f Peak=$%+.2f Floor=$%+.2f\n",
                        LegacyCampaign_CountPositions(), LegacyCampaignMaxOpenPositions,
                        LegacyCampaign_CountPending(), LegacyCampaignMaxPendingOrders,
                        LegacyCampaign_TotalLots(), LegacyCampaignMaxTotalLots, tmPnl,
                        g_TM_PeakPnL, g_TM_TrailFloor);
      s += StringFormat("  BE=%s TRAIL=%s thresholds BE=%.2f START=%.2f STEP=%.2f LOSS=%.2f\n",
                        (g_TM_BEArmed?"ON":"off"), (g_TM_TrailArmed?"ON":"off"),
                        LegacyCampaign_BasketBEUSD(), LegacyCampaign_BasketTrailStartUSD(),
                        LegacyCampaign_BasketTrailStepUSD(), LegacyCampaign_BasketLossUSD());
      s += StringFormat("  Genesis MFE peak=%.2fR floor=%.2fR shock=%s shockPeak=%.2fR harvest=%s\n",
                        g_GenPeakR,g_GenTrailFloorR,
                        ((g_GenShockActive || TimeCurrent()<=g_GenShockUntil)?"ACTIVE":"off"),
                        g_GenShockPeakR,(g_GenShockHarvested?"YES":"no"));
     }

   s += "─── SAFETY ───\n";
   s += StringFormat("  Daily DD=%.2f%%  Peak DD=%.2f%%\n", dayDD, peakDD);
   s += StringFormat("  ConsecLoss=%d/%d  Daily=%d  Global=%d\n",
                     ConsecutiveLosses, MaxConsecutiveLosses,
                     (int)DailyHalted, (int)GlobalHalted);
   s += StringFormat("  Positions=%d/%d  Pend=%d/%d  Lots=%.2f/%.2f\n",
                     CountOurPositions(), V1Risk_EffectivePairMaxPositions(), CountPendingTotal(), MaxPendingTotal,
                     TotalOurLots(), CapTotalLots());

   s += "─── STATS ───\n";
   s += StringFormat("  Trades=%d W/L=%d/%d (%.1f%%) Net=$%+.2f PF=%.2f\n",
                     totalTrades, WinCount, LossCount, winRate, net, pf);
   s += StringFormat("  Balance=$%.2f  Equity=$%.2f\n", balance, equity);
   s += "════════════════════════════════════════════════\n";

   Comment(s);
  }

//===================================================================
// SECTION 106 — INITIALIZATION [C1, C2, B1]
//===================================================================
bool ExpectedSymbolProfileMatchesChart()
  {
   string actual=_Symbol;
   string expected=ExpectedSymbolProfile;
   StringToUpper(actual);
   StringToUpper(expected);
   if(expected=="" || expected=="AUTO") return true;
   // Match exact symbols or suffixes separated by punctuation only.
   // This deliberately rejects XRPUSDT as a match for XRPUSD.
   int expectedLen=StringLen(expected);
   int actualLen=StringLen(actual);
   if(actualLen < expectedLen) return false;
   if(StringSubstr(actual,0,expectedLen) != expected) return false;
   if(actualLen == expectedLen) return true;
   ushort suffix=StringGetCharacter(actual,expectedLen);
   return (suffix=='.' || suffix=='_' || suffix=='-' || suffix=='#');
  }

int OnInit()
  {
   if(!ExpectedSymbolProfileMatchesChart())
     {
      PrintFormat("[PROFILE MISMATCH] preset expects symbol '%s' (or delimiter suffix) but chart is '%s'; initialization refused. Load the matching .set file.",ExpectedSymbolProfile,_Symbol);
      return INIT_PARAMETERS_INCORRECT;
     }
   RefreshLotMeta();
   DetectAccountType();       // [C1] detect cent vs dollar
   MsgBudget_Init();          // initialize/read account-wide shared counter

   if(AccountMode == ACC_AUTO)
      g_ResolvedMode = IsCentAccount() ? ACC_CENT : ACC_DOLLAR;
   else
      g_ResolvedMode = AccountMode;

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(SlippagePoints);
   trade.SetTypeFillingBySymbol(_Symbol);
   trade.LogLevel(LOG_LEVEL_ERRORS);
   if(V1LogAssetProfile)
      PrintFormat("[V1 ASSET PROFILE] symbol=%s class=%s auto=%d BTC_CHOP_ABC=%d referenceEquity=%.2f",
                  _Symbol,V1_AssetClassName(V1_ActiveAssetClass()),(int)V1AutoInstrumentProfile,
                  (int)(V1BTCChopABCEnabled && V1_IsBitcoinSymbol(_Symbol)),V1ReferenceEquityUSD);

   //--- Indicator handles
   hATR_M1   = iATR(_Symbol, PERIOD_M1,  ATR_Period);
   hATR_M5   = iATR(_Symbol, PERIOD_M5,  ATR_Period);
   hATR_M15  = iATR(_Symbol, PERIOD_M15, ATR_Period);

   hEMA10_M15 = iMA(_Symbol, PERIOD_M15, EMA_Fast_M15, 0, MODE_EMA, PRICE_CLOSE);
   hEMA20_M15 = iMA(_Symbol, PERIOD_M15, EMA_Slow_M15, 0, MODE_EMA, PRICE_CLOSE);
   hEMA50_M15 = iMA(_Symbol, PERIOD_M15, EMA_Base_M15, 0, MODE_EMA, PRICE_CLOSE);
   hRSI_M15   = iRSI(_Symbol, PERIOD_M15, RSI_Period_M15, PRICE_CLOSE);
   hADX_M15   = iADX(_Symbol, PERIOD_M15, ADX_Period_M15);
   hMACD_M15  = iMACD(_Symbol, PERIOD_M15, 12, 26, 9, PRICE_CLOSE);

   hEMA10_M5  = iMA(_Symbol, PERIOD_M5, 10, 0, MODE_EMA, PRICE_CLOSE);
   hEMA8_M5   = iMA(_Symbol, PERIOD_M5, EMA_Fast_M5, 0, MODE_EMA, PRICE_CLOSE);
   hEMA21_M5  = iMA(_Symbol, PERIOD_M5, EMA_Slow_M5, 0, MODE_EMA, PRICE_CLOSE);
   hEMA50_M5  = iMA(_Symbol, PERIOD_M5, EMA_Base_M5, 0, MODE_EMA, PRICE_CLOSE);
   hRSI_M5    = iRSI(_Symbol, PERIOD_M5, RSI_Period_M5, PRICE_CLOSE);
   hADX_M5    = iADX(_Symbol, PERIOD_M5, ADX_Period_M5);
   hMACD_M5   = iMACD(_Symbol, PERIOD_M5, 8, 17, 9, PRICE_CLOSE);
   hMom14_M5  = iMomentum(_Symbol, PERIOD_M5, 14, PRICE_CLOSE);

   hGI_M5EMA5  = iMA(_Symbol, PERIOD_M5, GenesisIntelM5EMAFastLen, 0, MODE_EMA, PRICE_CLOSE);
   hGI_M5EMA13 = iMA(_Symbol, PERIOD_M5, GenesisIntelM5EMASlowLen, 0, MODE_EMA, PRICE_CLOSE);
   hGI_M1EMA5  = iMA(_Symbol, PERIOD_M1, GenesisV3M1EMAFastLen, 0, MODE_EMA, PRICE_CLOSE);
   hGI_M1EMA13 = iMA(_Symbol, PERIOD_M1, GenesisV3M1EMASlowLen, 0, MODE_EMA, PRICE_CLOSE);

   hADX_M30   = iADX(_Symbol, PERIOD_M30, 14);

   if(hATR_M1    == INVALID_HANDLE || hATR_M5    == INVALID_HANDLE ||
      hATR_M15   == INVALID_HANDLE ||
      hEMA10_M15 == INVALID_HANDLE || hEMA20_M15 == INVALID_HANDLE ||
      hEMA50_M15 == INVALID_HANDLE || hRSI_M15   == INVALID_HANDLE ||
      hADX_M15   == INVALID_HANDLE || hMACD_M15  == INVALID_HANDLE ||
      hEMA10_M5  == INVALID_HANDLE || hEMA8_M5   == INVALID_HANDLE ||
      hEMA21_M5  == INVALID_HANDLE || hEMA50_M5  == INVALID_HANDLE ||
      hRSI_M5    == INVALID_HANDLE || hADX_M5    == INVALID_HANDLE ||
      hMACD_M5   == INVALID_HANDLE || hMom14_M5  == INVALID_HANDLE ||
      hGI_M5EMA5 == INVALID_HANDLE || hGI_M5EMA13 == INVALID_HANDLE ||
      hGI_M1EMA5 == INVALID_HANDLE || hGI_M1EMA13 == INVALID_HANDLE ||
      hADX_M30   == INVALID_HANDLE)
     {
      Print("[INIT] Indicator handle creation failed.");
      return INIT_FAILED;
     }

   if(OB_MaxStored > 8 || FVG_MaxStored > 8)
     {
      Print("[INIT] OB_MaxStored/FVG_MaxStored must be <= 8.");
      return INIT_PARAMETERS_INCORRECT;
     }

   if(BotMode == "Live" && !MQLInfoInteger(MQL_TESTER))
     {
      string gv = "GOD_ULT_V21_START_" + IntegerToString(MagicNumber) + "_" + _Symbol;
      if(!GlobalVariableCheck(gv))
         GlobalVariableSet(gv, AccountInfoDouble(ACCOUNT_BALANCE));
      StartBalance = GlobalVariableGet(gv);
      if(StartBalance <= 0.0) StartBalance = AccountInfoDouble(ACCOUNT_BALANCE);
     }
   else
      StartBalance = AccountInfoDouble(ACCOUNT_BALANCE);

   DayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
   PeakEquity     = DayStartEquity;
   TodayStamp     = (int)(TimeCurrent() / 86400);

   Health_Init();

   ArrayInitialize(SpreadHistory, 0.0);
   ArrayInitialize(FlowRateHistory, 0.0);
   ArrayInitialize(BasketInitialRiskUSD, 0.0);
   ArrayInitialize(g_HMMProb, 1.0 / 7.0);
   for(int i = 0; i < 40; i++) g_NVP.bins[i] = 0.0;
   for(int i = 0; i < 40; i++) g_FB_VP.bins[i] = 0.0;

   g_R7 = R7_CHOP;
   g_R7Since = TimeCurrent();
   g_GI_PrevSpectralSlopeATR=0.0; g_GI_PrevSpectralLowFrac=0.0; g_GI_PrevSpectralHighFrac=0.0;
   g_GI_PrevSpectralConc=0.0; g_GI_PrevSpectralDir=0; g_GI_LuxTransitionDir=0; g_GI_LuxTransitionTime=0;
   g_BrokerMsgResetDay = (int)(TimeCurrent() / 86400);
   g_V1Risk_LastCUSUMHandled = 0;
   g_V4_LastPosCount=CountOurPositions();
   g_V4_LastFillTime=0; g_V4_DefenseUntil=0; g_V4_DefenseDir=0;
   g_V4_LastPendingDir=0; g_V4_LastPendingTime=0; g_V4_ContinuationArmCount=0;
   g_V4_M15Bias=0; g_V4_M15PreviousBias=0; g_V4_M15Phase=V4_M15_PHASE_UNKNOWN;
   g_V4_M15PhaseBar=0; g_V4_LastStraddleTime=0; g_V4_StraddleBiasAtArm=0; g_V4_StraddleCounterAtArm=0;

   RefreshLegacyContext(true);
   UpdateSpread();
   CurrentATR1  = BufVal(hATR_M1,  0, 1);
   CurrentATR5  = BufVal(hATR_M5,  0, 1);
   CurrentATR15 = BufVal(hATR_M15, 0, 1);
   NormalATR1   = GetNormalATR1();
   NormalATR5   = GetNormalATR5();
   NormalATR15  = GetNormalATR15();

   BuildNativeVP();
   FB_BuildVolumeProfile();
   BPI_Update();

   EventSetTimer(1);

   // BTC LEGACY FAST starts conservative and rebuilds campaign state from
   // broker reality, not from hard-coded cent conversions.
   if(V1RiskLayerEnabled)
     {
      g_V1Risk_MarketEntries = 0;
      V1Risk_RefreshCampaignState();
     }

   if(V1LegacyCampaignEnabled)
     {
      if(LegacyCampaignInitialBuyOrders + LegacyCampaignInitialSellOrders > LegacyCampaignMaxPendingOrders)
         PrintFormat("[LEGACY CAMPAIGN INIT WARN] initial straddle=%d exceeds max pending=%d",
                     LegacyCampaignInitialBuyOrders + LegacyCampaignInitialSellOrders, LegacyCampaignMaxPendingOrders);
      if(LegacyCampaignMaxTotalLots + 1e-12 <
         (LegacyCampaignInitialBuyOrders + LegacyCampaignInitialSellOrders) * LegacyCampaignBaseLot)
         Print("[LEGACY CAMPAIGN INIT WARN] LegacyCampaignMaxTotalLots is below initial straddle nominal lots.");
      LegacyCampaign_SyncState();
     }

   Print("════════════════════════════════════════════════════════");
   Print(" TWO BROTHERS TRADING — BGBI SUPER INTELLIGENCE V1 | GENESIS + SUPER HYBRID EXECUTION");
   Print("════════════════════════════════════════════════════════");
   PrintFormat(" Account mode : %s (currency=%s)", AccountModeLabel(), g_AcctCurrency);
   PrintFormat(" Symbol       : %s   Magic: %d   Contract: %.4f",
               _Symbol, MagicNumber, g_ContractSize);
   PrintFormat(" Start balance: %.2f", StartBalance);
   PrintFormat(" Sizing       : V1 campaign risk=%.2f%% per-entry=%.2f%% lotMin=%.2f",
               V1CampaignRiskPct,V1PerEntryRiskPct,g_LotMin);
   PrintFormat(" Tiers on     : RegimeGate=%d FastTrend=%d Straddle=%d GridV2=%d "
               "TightBE=%d DollarBasket=%d OrderCheck=%d Recovery=%d",
               (int)UseRegimeDirectionGate, (int)UseFastTrendScore,
               (int)UseBiasedStraddle, (int)UseWinGatedGrid,
               (int)UseTightBEV2, (int)UseBasketDollarMode,
               (int)UseOrderCheckBeforeSendV2, (int)UseRecoveryModeV2);
   PrintFormat(" Factor B     : %s  (bridge-failure fallback = V106A port)",
               (UseFactorBFallback ? "ENABLED" : "disabled"));
   PrintFormat(" MsgBudget    : ACCOUNT-WIDE entryCap=%d hardWarning=%d", MsgBudget_EntryLimit(), MsgBudgetHardLimit);
   PrintFormat(" Spread rules : SL=%.1fx TP=%.1fx Trail=%.1fx Basket=%.1fx",
               SpreadMultiplier_SL, SpreadMultiplier_TP,
               SpreadMultiplier_Trail, SpreadMultiplier_Basket);
   PrintFormat(" V1 pair limits: positions<=%d pending<=%d | cash-risk campaign=%.2f%% crypto=%.2f%% per-entry=%.2f%%",
               V1Risk_EffectivePairMaxPositions(),V1Risk_EffectivePairMaxPendingOrders(),
               V1CampaignRiskPct,V1CryptoBasketRiskPct,V1PerEntryRiskPct);
   PrintFormat(" Bridge       : %s  mode=%d",
               (UseBinanceFlow ? BinanceBaseURL : "disabled"), (int)FlowMode);
   PrintFormat(" PairFlow     : native=%d fallback=%d lookback=%d minSamples=%d maxAgeMs=%d minScore=%.1f strong=%.1f fast=%d",
               (int)UseNativePairFlow,(int)AllowNativePairFlowFallbackWhenBridgeDown,PairFlowLookbackTicks,
               PairFlowMinSamples,PairFlowMaxAgeMs,PairFlowMinConfirmScore,PairFlowStrongConfirmScore,(int)UseCryptoFastReaction);
   PrintFormat(" USD Hybrid   : %s (%s) riskScale=%d dirWeight=%.2f",
               (UseUSDHybridBridge ? USDHybridBaseURL : "disabled"),
               (UseUSDHybridBridge ? "FX/gold context" : "off"),
               (int)UseUSDHybridRiskScaling,USDHybridDirectionWeight);
   PrintFormat(" Genesis V4   : Lux=%d Spectral=%d M5EMA=%d (%d/%d) M1EMA=%d (%d/%d) ProofStops=%d TransitionStops=%d MaxPos=%d MaxEntries=%d",
               (int)GenesisIntelUseLuxPhase,(int)GenesisIntelUseSpectral,(int)GenesisIntelUseM5EMAThesis,
               GenesisIntelM5EMAFastLen,GenesisIntelM5EMASlowLen,(int)GenesisV3UseM1EMALead,
               GenesisV3M1EMAFastLen,GenesisV3M1EMASlowLen,(int)GenesisV3UseM1EMALead,
               (int)GenesisIntelUseTransitionStops,GenesisIntelMaxPositions,GenesisIntelMaxEntriesCampaign);
   if(MQLInfoInteger(MQL_TESTER) && UseBinanceFlow)
      Print("[INIT] Tester detected: Factor B active, bridge disabled.");
   if(GenesisV4Enable)
      PrintFormat(" Genesis V4.1 : dual M5/M1=%d stopFirst=%d postFillDefense=%d lifetime=%ds",
                  (int)GenesisV4M5OwnsDirectionalThesis,
                  (int)GenesisV4StopFirstExecution,(int)GenesisV4PostFillDefenseEnable,
                  GenesisV4PendingLifetimeSec);
   Print("════════════════════════════════════════════════════════");

   return INIT_SUCCEEDED;
  }

//===================================================================
// SECTION 107 — DEINITIALIZATION
//===================================================================
void OnDeinit(const int reason)
  {
   EventKillTimer();
   Comment("");

   if(hATR_M1    != INVALID_HANDLE) IndicatorRelease(hATR_M1);
   if(hATR_M5    != INVALID_HANDLE) IndicatorRelease(hATR_M5);
   if(hATR_M15   != INVALID_HANDLE) IndicatorRelease(hATR_M15);
   if(hEMA10_M15 != INVALID_HANDLE) IndicatorRelease(hEMA10_M15);
   if(hEMA20_M15 != INVALID_HANDLE) IndicatorRelease(hEMA20_M15);
   if(hEMA50_M15 != INVALID_HANDLE) IndicatorRelease(hEMA50_M15);
   if(hRSI_M15   != INVALID_HANDLE) IndicatorRelease(hRSI_M15);
   if(hADX_M15   != INVALID_HANDLE) IndicatorRelease(hADX_M15);
   if(hMACD_M15  != INVALID_HANDLE) IndicatorRelease(hMACD_M15);
   if(hEMA10_M5  != INVALID_HANDLE) IndicatorRelease(hEMA10_M5);
   if(hEMA8_M5   != INVALID_HANDLE) IndicatorRelease(hEMA8_M5);
   if(hEMA21_M5  != INVALID_HANDLE) IndicatorRelease(hEMA21_M5);
   if(hEMA50_M5  != INVALID_HANDLE) IndicatorRelease(hEMA50_M5);
   if(hRSI_M5    != INVALID_HANDLE) IndicatorRelease(hRSI_M5);
   if(hADX_M5    != INVALID_HANDLE) IndicatorRelease(hADX_M5);
   if(hMACD_M5   != INVALID_HANDLE) IndicatorRelease(hMACD_M5);
   if(hMom14_M5  != INVALID_HANDLE) IndicatorRelease(hMom14_M5);
   if(hGI_M5EMA5 != INVALID_HANDLE) IndicatorRelease(hGI_M5EMA5);
   if(hGI_M5EMA13 != INVALID_HANDLE) IndicatorRelease(hGI_M5EMA13);
   if(hGI_M1EMA5 != INVALID_HANDLE) IndicatorRelease(hGI_M1EMA5);
   if(hGI_M1EMA13 != INVALID_HANDLE) IndicatorRelease(hGI_M1EMA13);
   if(hADX_M30   != INVALID_HANDLE) IndicatorRelease(hADX_M30);

   PrintFormat("[DEINIT] reason=%d Trades=%d W/L=%d/%d Net=%.2f PF=%.2f Msgs=%d",
               reason, TradeCount, WinCount, LossCount,
               TotalWinUSD - TotalLossUSD,
               (TotalLossUSD > 0.0) ? TotalWinUSD / TotalLossUSD : 0.0,
               MsgBudget_GetCount());
  }
  
//===================================================================
// SECTION 108 — TICK HANDLER [A5: 60s DIAG-FULL]
//===================================================================
void OnTick()
  {
   MsgBudget_Tick();          // [B1] day rollover
   PrintDiagFull();           // [A5] 60s snapshot

   UpdateSpread();

   CurrentATR1  = BufVal(hATR_M1,  0, 1);
   CurrentATR5  = BufVal(hATR_M5,  0, 1);
   CurrentATR15 = BufVal(hATR_M15, 0, 1);

   NormalATR1   = GetNormalATR1();
   NormalATR5   = GetNormalATR5();
   NormalATR15  = GetNormalATR15();
   PairFlow_UpdateNative();

   UpdateWickProtection();
   UpdateLiquiditySessions();
   DailyResetIfNeeded();
   CheckSafety();

   // Price-protection must be evaluated on incoming ticks, not only on the timer.
   if(!V1LegacyCampaignEnabled && V1SingleExitControllerEnabled && V1RiskLayerEnabled)
      V1_ManagePositionProtection();

   //--- BTC LEGACY FAST LEGACY CAMPAIGN runs on every tick so a large M1 candle can arm the
   //--- campaign before the candle closes. Once active, legacy entry engines
   //--- do not compete with the campaign.
   bool tmLocked = false;
   if(V1LegacyCampaignEnabled)
      LegacyCampaign_OnTickStart();

   // Genesis keeps proven engine-native entries available by default. When
   // explicitly enabled, this switch freezes new legacy engine entries while
   // an existing campaign is active; the unified campaign manager remains the
   // sole exit authority.
   if(V1LegacyCampaignEnabled && LegacyCampaignBlockLegacyEngines && LegacyCampaign_IsActive() &&
      !(UseGenesisIntelligence && GenesisIntelBlockLegacy && GenesisV4Enable))
     {
      UpdateDisplay();
      return;
     }

   //================================================================
   // --- FIX 4: TICK-LEVEL FAST PATHS (Instant Reaction) ---
   //================================================================
   // These engines react to market shocks instantly, bypassing the M1 wait.
   if(TimeCurrent() >= PauseUntil && !DailyHalted && MsgBudget_CanTrade() &&
      SpreadOK() && SessionAllowed() && HourFilterOK() && !WickPauseActive())
     {
      // These gates only govern optional legacy fast paths. They must not return
      // from OnTick before Genesis can update/cancel its pending straddle or defend a fill.
      if(!(UseGenesisIntelligence && GenesisIntelBlockLegacy))
        {
         if(UseKillShot)        { if(KillShotFastPath()) return; }
         if(UseCUSUM)           { if(CUSUMShockRun())    return; }
        }
      // Reversal and Genesis V4 dispatch continue below on every tick.
     }
     
      //================================================================
     // --- [TIER 5] M5 THESIS LOCK (once per new M5 bar) ---
    //   Also resets immediately if CUSUM detects a fresh change-point.
   //================================================================
   datetime curM5 = TfTime(PERIOD_M5, 0);
   static datetime lastM5 = 0;
   bool newM5Bar = (curM5 > 0 && curM5 != lastM5);
   bool cusumReset = (UseCUSUM && g_CUSUMDir != 0 &&
                     (TimeCurrent() - g_CUSUMLastFire) <= CUSUMFreshSeconds &&
                     (!V1CUSUMOneShot || g_CUSUMLastFire != g_V1Risk_LastCUSUMHandled));

   if(newM5Bar || cusumReset)
     {
      if(newM5Bar) lastM5 = curM5;
      if(cusumReset)
        {
         PrintFormat("[M5 THESIS RESET] CUSUM dir=%s event=%I64d",
                     DirStr(g_CUSUMDir), (long)g_CUSUMLastFire);
         g_V1Risk_LastCUSUMHandled = g_CUSUMLastFire;
        }
      UpdateM5ThesisLock(cusumReset);
     }
     
  
   //--- [TIER 5] Real-time thesis invalidation
   CheckM5ThesisInvalidation();
   
   //================================================================
   // --- STANDARD M1 BAR CLOSE LOGIC ---
   //================================================================
   datetime curM1 = TfTime(PERIOD_M1, 0);
   static datetime lastM1 = 0;

   if(curM1 > 0 && curM1 != lastM1)
     {
      lastM1 = curM1;

      RefreshLegacyContext();
      V4_UpdateM15Context();
      UpdateM1PA();
      ComputeInternalVWAPZ();
      VNSMC_Update();
      BuildNativeVP();
      BPI_Update(); // cached profile, based only on closed candles

      ComputeAdaptiveRegimeMetrics();
      VNAdvancedMarketUpdate();

      Health_Evaluate();

      if(V1LegacyCampaignEnabled)
        {
         LegacyCampaign_OnNewM1();
        }

      // Run the standard engines (Swing, Monster, Range, VWAP-Chop)
      RunEngines();
     }

   // Live M1 intelligence can react before the candle closes. Higher-timeframe
   // confirmation inside GenesisIntelligence_Update() remains on closed M5/M15 bars.
   if(UseGenesisIntelligence && GenesisIntelBlockLegacy)
     {
      if(GenesisV4Enable)
         GenesisIntelligence_Dispatch();
      else
        {
         GenesisIntelligence_Update();
         GenesisIntelligence_ResetCampaignCounter();
         GenesisIntel_ArmTransitionStop();
         GenesisIntel_CleanPending();
         if(!LegacyCampaign_IsActive()) GenesisIntel_SendEntry();
         else GenesisIntel_Reinforce();
        }
     }

   UpdateDisplay();
  }
//===================================================================
// SECTION 109 — TIMER
//===================================================================
void OnTimer()
  {
   HourlyHardReset();
   HourlyStraddleReset();
   DailyResetIfNeeded();
   MsgBudget_DailyReset();

   //================================================================
   // --- BRIDGE POLLING ---
   //================================================================
   // Always attempt to poll. If WebRequest fails, the Poll functions
   // themselves handle the error and reset the state internally.
   PollBinanceFlow();
   PollCryptoFastReaction();
   PollBinanceVP();
   PollBinanceAux();
   PollBinanceVPIN();
   PollUSDHybridBridge();

   UpdateSpread();

   CurrentATR1  = BufVal(hATR_M1,  0, 1);
   CurrentATR5  = BufVal(hATR_M5,  0, 1);
   CurrentATR15 = BufVal(hATR_M15, 0, 1);
   NormalATR1   = GetNormalATR1();
   NormalATR5   = GetNormalATR5();
   NormalATR15  = GetNormalATR15();

   UpdateWickProtection();
   UpdateLiquiditySessions();
   CheckSafety();
   // V1 exit protection is handled by the single V1_ManagePositionProtection below.
   CancelStalePendingOrders();
   // Independent range-limit cleanup is run by the Genesis router.

   //--- BTC LEGACY FAST LEGACY CAMPAIGN: aggregate campaign management is the primary
   //--- exit authority for TM_ positions.
   if(V1LegacyCampaignEnabled)
     {
      LegacyCampaign_DeleteExpiredPendings();
      LegacyCampaign_ManageBasket();
     }

   //--- Genesis: unified campaign basket is the only campaign exit authority.
   //--- Legacy per-engine exits are deliberately skipped while LegacyCampaign is on.
   if(!V1LegacyCampaignEnabled)
     {
      if(V1SingleExitControllerEnabled && V1RiskLayerEnabled)
        {
         V1_ManagePositionProtection();
        }
      else
        {
         ManagePositions();
         ManageAllTightExits();
         ManageStalePositions();
         CheckWickAbort();
         CheckFlowFlipExit();
         WallGuardExit();
         ManageReversalPartial();
         CheckMonsterThesisExit();

         ManageBasket("SWING",    SwingBE,   SwingTrail,   SwingTrailHigh,   SwingTrailSL);
         ManageBasket("MONSTER",  MonsterBE, MonsterTrail, MonsterTrailHigh, MonsterTrailSL);
         ManageBasket("RANGE",    RangeBE,   RangeTrail,   RangeTrailHigh,   RangeTrailSL);
         ManageBasket("REVERSAL", ReversalBE,ReversalTrail,ReversalTrailHigh,ReversalTrailSL);

         if(UseFactorBFallback)
           {
            FB_BasketManage("FB_CHOP_",  0, g_FB_LastClose[0]);
            FB_BasketManage("FB_TREND_", 1, g_FB_LastClose[1]);
            FB_BasketManage("FB_MON_",   2, g_FB_LastClose[2]);
            FB_BasketManage("FB_REV_",   3, g_FB_LastClose[3]);
           }
        }
     }

   // Legacy partial maintenance is retained only when the unified
   // exit controller is disabled.
   if(!V1SingleExitControllerEnabled || !V1RiskLayerEnabled)
     {
      ManageAllPartialsV3();
      ResetPartialFlagsIfFlat();
     }


   CheckFloatingBudgets();
   ResetMonsterIfIdle();
   ResetRevIfStale();

   // Genesis Intelligence owns entries when enabled; the legacy Win-Gated
   // Grid remains compiled but cannot place competing orders in that mode.
   if(UseWinGatedGrid && !(UseGenesisIntelligence && GenesisIntelBlockLegacy))
      TryGridAddV2();

   V1Risk_RefreshCampaignState();
   UpdateDisplay();
   PrintDiagnostics();
  }

//===================================================================
// SECTION 110 — TRADE TRANSACTION
//===================================================================
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest     &request,
                        const MqlTradeResult      &result)
  {
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD) return;
   ulong deal = trans.deal;
   if(deal == 0) return;
   if(!HistoryDealSelect(deal)) return;

   long   magic  = HistoryDealGetInteger(deal, DEAL_MAGIC);
   string symbol = HistoryDealGetString (deal, DEAL_SYMBOL);
   if(magic != MagicNumber || symbol != _Symbol) return;

   long   entry = HistoryDealGetInteger(deal, DEAL_ENTRY);
   long   dtype = HistoryDealGetInteger(deal, DEAL_TYPE);
   string cmt   = HistoryDealGetString (deal, DEAL_COMMENT);

   //--- ENTRY SIDE
   if(entry == DEAL_ENTRY_IN)
     {
      bool ocoEntryFill=(StringFind(cmt,"GENESIS_INTEL_OCO_")>=0);
      if(!ocoEntryFill && trans.order>0 && HistoryOrderSelect(trans.order))
        {
         string sourceOrderComment=HistoryOrderGetString(trans.order,ORDER_COMMENT);
         ocoEntryFill=(StringFind(sourceOrderComment,"GENESIS_INTEL_OCO_")>=0);
        }
      if(ocoEntryFill)
        {
         // Cancel sibling immediately on the transaction path; still not atomic broker-native OCO.
         V1OCO_CancelAll("FIRST_OCO_LEG_FILLED");
         g_V4_LastPendingTime=TimeCurrent();
        }
      TradeCount++;
      int filledDir = (dtype == DEAL_TYPE_BUY) ? 1 : (dtype == DEAL_TYPE_SELL ? -1 : 0);

      // BTC LEGACY FAST: when a pending order actually fills, cancel the
      // remaining campaign pendings so a dormant sibling cannot wake up
      // later and silently add risk.
      bool pendingFill = V1Risk_IsPendingHistoryOrder(trans.order);
      bool isLegacyCampaignFill = LegacyCampaign_IsComment(cmt);

      if(StringFind(cmt,"GENESIS_INTEL_TRANSITION_")>=0)
        {
         g_GI_TransitionArmedDir=0; g_GI_TransitionArmedTime=0; g_GI_TransitionPendingTicket=0; g_GI_TransitionTrigger=0.0;
         g_GI.transitionArmed=false; g_GI.transitionDirection=0;
         PrintFormat("[GENESIS V2 TRANSITION FILL] dir=%s lots=%.3f",DirStr(filledDir),trans.volume);
        }

      if(isLegacyCampaignFill)
        {
         g_TM_Active = true;
         if(g_TM_Start == 0) g_TM_Start = TimeCurrent();
         PrintFormat("[LEGACY CAMPAIGN FILL] %s dir=%s lots=%.2f positions=%d pending=%d pnl=%.2f",
                     cmt, DirStr(filledDir), trans.volume, LegacyCampaign_CountPositions(),
                     LegacyCampaign_CountPending(), LegacyCampaign_FloatingPnL());
        }

      if(V1RiskLayerEnabled && filledDir != 0)
        {
         g_V1Risk_CampaignActive = true;
         if(g_V1Risk_CampaignStart == 0) g_V1Risk_CampaignStart = TimeCurrent();
         if(g_V1Risk_CampaignDir == 0) g_V1Risk_CampaignDir = filledDir;
        }

      // V1.60 deliberately does not cancel independent range-edge LIMITs on a fill.
      if(StringFind(cmt, "SWING_")    >= 0) CancelOtherEnginePendingOrders("SWING_");
      if(StringFind(cmt, "MONSTER_")  >= 0) CancelOtherEnginePendingOrders("MONSTER_");
      if(StringFind(cmt, "REVERSAL_") >= 0) CancelOtherEnginePendingOrders("REVERSAL_");

      if(filledDir != 0)
        {
         g_LastEntryDir  = filledDir;
         g_LastEntryTime = TimeCurrent();
        }

      //--- Tier 3: SL/TP re-anchor after fill
      if(UseSlippageReAnchorV2 && trans.position > 0)
         ReAnchorStopsAfterFill(trans.position, cmt);

      return;
     }

   //--- EXIT SIDE
   if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_OUT_BY) return;

   long positionId = HistoryDealGetInteger(deal, DEAL_POSITION_ID);

   bool stillOpen = false;
   if(trans.position > 0)
      stillOpen = PositionSelectByTicket(trans.position);

   if(!stillOpen && positionId > 0)
     {
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         if(!posInfo.SelectByIndex(i)) continue;
         if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
         long pid = PositionGetInteger(POSITION_IDENTIFIER);
         if(pid == positionId) { stillOpen = true; break; }
        }
     }
   if(stillOpen) return;

   //--- Sum P&L across all closing deals
   double profit = 0.0;
   if(positionId > 0 && HistorySelectByPosition(positionId))
     {
      int total = HistoryDealsTotal();
      for(int i = 0; i < total; i++)
        {
         ulong cd = HistoryDealGetTicket(i);
         if(cd == 0) continue;
         long   cm = HistoryDealGetInteger(cd, DEAL_MAGIC);
         string cs = HistoryDealGetString (cd, DEAL_SYMBOL);
         long   ce = HistoryDealGetInteger(cd, DEAL_ENTRY);
         if(cm != MagicNumber || cs != _Symbol) continue;
         if(ce != DEAL_ENTRY_OUT && ce != DEAL_ENTRY_OUT_BY) continue;
         profit += HistoryDealGetDouble(cd, DEAL_PROFIT)
                 + HistoryDealGetDouble(cd, DEAL_SWAP)
                 + HistoryDealGetDouble(cd, DEAL_COMMISSION);
        }
     }
   else
     {
      profit = HistoryDealGetDouble(deal, DEAL_PROFIT)
             + HistoryDealGetDouble(deal, DEAL_SWAP)
             + HistoryDealGetDouble(deal, DEAL_COMMISSION);
     }

   int engIdx = EngineIndexFromComment(cmt);

   long closeReason=HistoryDealGetInteger(deal,DEAL_REASON);
   if(profit<0.0 && (closeReason==DEAL_REASON_SL || closeReason==DEAL_REASON_SO || closeReason==DEAL_REASON_EXPERT))
     {
      V1_StartStopLossCooldown();
      DeleteOrdersPrefix("");
     }

   if(profit > 0.0)
     {
      WinCount++;
      ConsecutiveWins++;
      ConsecutiveLosses = 0;
      LastWinTime = TimeCurrent();
      g_LastWasWin = true;
      TotalWinUSD += profit;
      if(engIdx >= 0)
        {
         string engName = (engIdx == 0 ? "SWING" :
                           engIdx == 1 ? "MONSTER" :
                           engIdx == 2 ? "RANGE" : "REVERSAL");
         RecordEngineWin(engName);
         g_EnginePnLToday[engIdx] += profit;
        }
      Recovery_RegisterWin();
     }
   else if(profit < 0.0)
     {
      LossCount++;
      ConsecutiveLosses++;
      ConsecutiveWins = 0;
      LastLossTime = TimeCurrent();
      g_LastWasWin = false;
      TotalLossUSD += MathAbs(profit);
      if(engIdx >= 0)
        {
         string engName = (engIdx == 0 ? "SWING" :
                           engIdx == 1 ? "MONSTER" :
                           engIdx == 2 ? "RANGE" : "REVERSAL");
         RecordEngineLoss(engName);
         g_EnginePnLToday[engIdx] += profit;
        }
      Recovery_RegisterLoss(profit);
     }

   if(StringFind(cmt, "REVERSAL_") >= 0) ReversalPartial = false;

   PrintFormat("[DEAL OUT] pos=%I64d pnl=%.2f W/L=%d/%d streak=%d grid=%d msgs=%d",
               positionId, profit, WinCount, LossCount,
               ConsecutiveLosses, g_GridLevelV2, MsgBudget_GetCount());
  }

//+------------------------------------------------------------------+
//| END OF FILE — BTC LEGACY FAST LEGACY CAMPAIGN V2.00                           |
//| Factor A (bridge-fed) + Factor B (V106A fallback)                |
//+------------------------------------------------------------------+
