﻿//+------------------------------------------------------------------+
//|                 BGBI-INTELLIGENT-PERFECT-V3.5-KRONOS-MINI-INTEGRATED.mq5       |
//|                                                                  |
//|  BGBI-INTELLIGENT-PERFECT V3.5 KRONOS-MINI-INTEGRATED                    |
//|                                                                  |
//|  Factor B (primary): technical confluence / all four engines     |
//|  Factor A (confirm): validated external flow only                |
//|  Ultimate entries + OCO routing/risk/exits — unified owner       |
//|                                                                  |
//|  One risk-reserving router; Factor B remains decision owner.    |
//|                                                                  |
//|  Two Brothers Trading — 2026                                     |
//+------------------------------------------------------------------+
#property copyright "Jaisriram-BTCmaster"
#property version   "3.50"
#property description "BGBI V3.5 — Kronos-Mini advisory forecast + constrained CHOP expansion continuation; DEMO validation candidate"
#property strict

#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include <Trade\OrderInfo.mqh>

CTrade         trade;
CPositionInfo  posInfo;
COrderInfo     ordInfo;

//===================================================================
// SECTION 1 — ENUMS
//===================================================================
enum ENUM_ACCOUNT_MODE
  {
   ACC_AUTO   = 0,
   ACC_CENT   = 1,
   ACC_DOLLAR = 2
  };

enum ENUM_HEALTH
  {
   HEALTH_GREEN  = 0,
   HEALTH_YELLOW = 1,
   HEALTH_RED    = 2,
   HEALTH_BLACK  = 3
  };

enum ENUM_FLOW_MODE
  {
   FLOW_OFF      = 0,
   FLOW_VETO     = 1,
   FLOW_CONFIRM  = 2,
   FLOW_REQUIRED = 3
  };

enum ENUM_REGIME7
  {
   R7_STRONG_UP   = 0,
   R7_STRONG_DOWN = 1,
   R7_WEAK_UP     = 2,
   R7_WEAK_DOWN   = 3,
   R7_CHOP        = 4,
   R7_COMPRESSION = 5,
   R7_EXPANSION   = 6
  };

enum ENUM_MONSTER_PHASE
  {
   MP_IDLE         = 0,
   MP_IGNITION     = 1,
   MP_ACCELERATION = 2,
   MP_HARVEST      = 3
  };

enum ENUM_REV_STATE
  {
   REV_IDLE    = 0,
   REV_WATCH   = 1,
   REV_ALERT   = 2,
   REV_CONFIRM = 3
  };

enum ENUM_ENGINE
  {
   ENG_NONE     = 0,
   ENG_REVERSAL = 1,
   ENG_CUSUM    = 2,
   ENG_KILLSHOT = 3,
   ENG_MONSTER  = 4,
   ENG_TREND    = 5,
   ENG_RANGE    = 6,
   ENG_STRADDLE = 7
  };

enum ENUM_ORDER_MODE
  {
   OMODE_STOP    = 0,
   OMODE_LIMIT   = 1,
   OMODE_DYNAMIC = 2
  };

enum ENUM_BASKET_MODE
  {
   BASKET_R_BASED      = 0,
   BASKET_DOLLAR_BASED = 1
  };

enum ENUM_ACTIVE_FACTOR
  {
   FACTOR_A_BRIDGE   = 0,
   FACTOR_B_FALLBACK = 1
  };

//===================================================================
// SECTION 2 — STRUCTS
//===================================================================
struct S_OrderBlock
  {
   double   high, low, avg;
   int      dir;
   datetime t;
   bool     mitigated;
  };

struct S_FVG
  {
   double   high, low, mid;
   int      dir;
   datetime t;
   bool     mitigated;
  };

struct S_Flow
  {
   bool     valid;
   bool     healthy;
   datetime local_update;
   double   price, flow_score;
   double   buy_pct, sell_pct;
   double   d5, d15;
   double   cvd, book, depth;
   double   trade_rate, buy_rate, sell_rate;
   double   spread_bps, persistence;
   double   velocity, acceleration;
   double   ofi;
   int      persistence_count;
   string   action;
  };

struct S_VP
  {
   bool     valid;
   datetime local_update;
   double   poc, vah, val;
   double   width_pct;
   double   min_p, max_p;
  };

struct S_Aux
  {
   bool     valid;
   datetime local_update;
   double   vroc, range_exp, atr_m1;
   double   vwap, vwap_slope;
   double   funding, oi, oi_delta_1m;
   double   bid_wall_price, bid_wall_size;
   double   ask_wall_price, ask_wall_size;
   double   vpin, vpin_pct, vpin_pressure;
   int      vpin_regime, oi_regime;
   double   naked_above, naked_below;
   int      naked_count;
   double   rolling_vwap, vwap_stdev, vwap_z;
   bool     vwap_exhausted, vroc_sustained;
   double   long_short_ratio;
   double   liquidation_buy, liquidation_sell, liquidation_imbalance;
  };

struct S_NativeVP
  {
   bool     valid;
   double   minP, maxP, binSize;
   double   poc, vah, val;
   double   totalVol, vaWidthPct;
   double   bins[40];
  };

struct S_Health
  {
   string   name;
   datetime lastUpdate;
   int      maxAgeSec;
   bool     healthy;
  };

struct S_SMC
  {
   int      m15_bias, m5_bias, m1_bias;
   int      m15_event, m5_event, m1_event;
   datetime m15_event_time, m5_event_time, m1_event_time;
   double   m15_high, m15_low;
   double   m5_high, m5_low;
   double   m1_high, m1_low;
   double   pd_location;
   bool     bull_zone_near, bear_zone_near;
   bool     bull_liq_sweep, bear_liq_sweep;
   bool     eq_high_active, eq_low_active;
   double   eq_high_level, eq_low_level;
  };

struct S_OU
  {
   bool     valid;
   double   mu, theta, sigma, z;
   double   half_life, reversion_prob;
  };

struct S_SignalPack
  {
   int      dir;
   double   score;
   bool     sweep, mss, displacement, fvg;
   bool     m5_agree, m15_agree;
   bool     flow_agree, flow_strong;
   double   flow_score;
  };

struct S_StraddlePlan
  {
   int      buys, sells;
   double   buyMult, sellMult;
   double   slPrice, tpPrice, gap;
   bool     isExtreme, isJerk;
  };

struct S_Anchor
  {
   string   comment;
   double   requestedEntry;
   double   requestedSL;
   double   requestedTP;
   datetime t;
  };

struct S_StraddlePlanB
  {
   int      buys, sells;
   double   buyMult, sellMult;
   double   slDist, tpDist, gap;
   bool     isExtreme, isJerk;
  };

//===================================================================
// SECTION 3 — INPUTS
//===================================================================

//---------------- GENERAL -----------------------------------------
input group "═══ GENERAL ═══"
input ENUM_ACCOUNT_MODE AccountMode        = ACC_AUTO;
input string   BotMode                     = "Live";
input int      MagicNumber                 = 7770150;
input int      SlippagePoints              = 200;

//---------------- BINANCE BRIDGE ----------------------------------
input group "═══ BINANCE BRIDGE (LIVE) ═══"
input bool     UseBinanceFlow              = true;
input string   BinanceBaseURL              = "http://127.0.0.1:8787";
input int      BinanceHttpTimeoutMs        = 900;
input int      BinancePollSeconds          = 1;
input int      BinanceMaxAgeSeconds        = 5;
input double   BinanceMinFlowScore         = 18.0;
input double   BinanceStrongFlowScore      = 45.0;
input double   BinanceMinPersistence       = 0.20;
input double   CVDAccelMin                 = 0.05;
input ENUM_FLOW_MODE FlowMode              = FLOW_CONFIRM;
input int      BridgeAuxPollSeconds        = 3;
input int      BridgeVPINPollSeconds       = 5;

//---------------- DATA HEALTH GATE ---------------------------------
input group "═══ DATA HEALTH GATE ═══"
input bool     UseHealthGate               = true;
input int      HealthMaxAge_Flow           = 5;
input int      HealthMaxAge_VP             = 10;
input int      HealthMaxAge_VROC           = 10;
input int      HealthMaxAge_VWAPZ          = 15;
input int      HealthMaxAge_VPIN           = 15;
input int      HealthMaxAge_Walls          = 10;
input int      HealthMaxAge_Funding        = 90;

//---------------- REGIME SUPERVISOR --------------------------------
input group "═══ REGIME — 7-STATE AR ═══"
input bool     UseRegimeSupervisor         = true;
input int      Regime_ER_Period            = 20;
input int      Regime_Hurst_Lookback       = 100;
input int      Regime_Autocorr_Window      = 50;
input double   Regime_ER_Weight            = 2.0;
input double   Regime_Hurst_Weight         = 1.0;
input double   Regime_AC_Weight            = 2.0;
input double   Regime_VROC_Weight          = 2.0;
input double   Regime_ATR_Weight           = 1.0;
input int      AdaptiveRegimeStickySec     = 90;
input double   StrongADXThreshold          = 30.0;
input double   WeakADXThreshold            = 20.0;
input double   StrongERThreshold           = 0.45;
input double   WeakERThreshold             = 0.25;
input double   ExpansionATRRatio           = 1.75;
input double   CompressionATRRatio         = 0.70;
input double   CompressionERThreshold      = 0.20;
input bool     UseHMMLikePosterior         = true;
input double   HMMOldStateWeight           = 0.75;

//---------------- CUSUM --------------------------------------------
input group "═══ CUSUM CHANGE-POINT ═══"
input bool     UseCUSUM                    = true;
input int      CUSUMWindow                 = 30;
input double   CUSUMDrift                  = 0.15;
input double   CUSUMThreshold              = 4.00;
input int      CUSUMPauseSeconds           = 120;
input bool     UseFlowCUSUMAugment         = true;
input int      CUSUMFreshSeconds           = 60;    // [A3] bypass regime gate if fresh

//---------------- RISK & SIZING ------------------------------------
input group "═══ RISK & SIZING ═══"
input bool     UsePercentRisk              = true;
input double   RiskPct_Swing               = 0.45;
input double   RiskPct_Monster             = 0.45;
input double   RiskPct_Range               = 0.30;
input double   RiskPct_Reversal            = 0.35;
input double   CapPerOrderDivisor          = 500.0;
input double   CapPerOrderMax              = 1.00;
input double   CapPerOrderMin              = 0.01;
input double   CapTotalLots_Divisor        = 250.0;
input double   CapTotalLots_Max            = 2.00;
input double   Range_Lot                   = 0.05;
input double   Swing_Lot                   = 0.07;
input double   Monster_Lot                 = 0.10;
input double   Reversal_Lot                = 0.05;

//---------------- SL / TP ------------------------------------------
input group "═══ SL / TP ═══"
input double   SL_ATR_Swing                = 1.80;
input double   SL_ATR_Monster              = 1.50;
input double   SL_ATR_Range                = 1.50;
input double   SL_ATR_Reversal             = 1.50;
input double   TP_RR_Swing                 = 3.50;
input double   TP_RR_Monster               = 6.00;
input double   TP_RR_Range                 = 1.50;
input double   TP_RR_Reversal              = 2.00;
input double   SL_SpreadMultiplier         = 2.0;
input double   SL_MinATR                   = 0.65;
input double   SL_MaxUSC                   = 1500.0;

//---------------- SPREAD SAFETY [S1,S2,S3,S4] ---------------------
input group "═══ SPREAD SAFETY (S1–S4) ═══"
input double   SpreadMultiplier_SL         = 3.0;   // SL must exceed 3× current spread
input double   SpreadMultiplier_TP         = 2.0;   // TP must exceed 2× current spread
input double   SpreadMultiplier_Trail      = 1.5;   // trail buffer ≥ 1.5× spread
input double   SpreadMultiplier_Basket     = 2.0;   // basket BE ≥ 2× spread × positions
input double   SpreadMinSLPoints           = 10.0; // legacy compatibility; V2 uses spread/ATR/stops-level floor

//---------------- INDICATORS ---------------------------------------
input group "═══ INDICATORS ═══"
input int      ATR_Period                  = 14;
input int      EMA_Fast_M15                = 10;
input int      EMA_Slow_M15                = 20;
input int      EMA_Base_M15                = 50;
input int      RSI_Period_M15              = 14;
input int      ADX_Period_M15              = 14;
input int      EMA_Fast_M5                 = 8;
input int      EMA_Slow_M5                 = 21;
input int      EMA_Base_M5                 = 50;
input int      RSI_Period_M5               = 14;
input int      ADX_Period_M5               = 14;
input int      KAMA_Length                 = 21;
input int      KAMA_SlopeBars              = 5;
input double   KAMA_SlopeMin               = 0.30;

//---------------- VWAP / VP ----------------------------------------
input group "═══ VWAP / VOLUME PROFILE ═══"
input bool     UseVWAP                     = true;
input int      VWAP_Lookback               = 20;
input double   VWAP_Stdev_Entry            = 1.28;
input int      VP_LookbackBars             = 200;
input int      VP_Bins                     = 30;
input double   VP_ValueAreaPct             = 70.0;
input double   VP_CompressMaxPct           = 0.60;

//---------------- M1 PRICE ACTION ----------------------------------
input group "═══ M1 PRICE ACTION ═══"
input bool     UseM1PA                     = true;
input int      M1PA_SwingLookback          = 30;
input int      M1PA_SwingStrength          = 2;
input double   M1PA_MinSweepATR            = 0.08;
input double   M1PA_MinDisplATR            = 0.70;
input double   M1PA_MinBodyRatio           = 0.55;
input double   M1PA_BoostScore             = 65.0;
input double   M1PA_OverrideScore          = 88.0;
input double   M1PA_FVG_MinATR             = 0.05;

//---------------- M5 CONFIRMATION ----------------------------------
input group "═══ M5 CONFIRMATION ═══"
input bool     UseM5Confirm                = true;
input int      M5SwingLookback             = 20;

//---------------- M15 / H1 VETO ------------------------------------
input group "═══ M15 / H1 VETO ═══"
input bool     UseM15Veto                  = true;
input bool     UseH1Veto                   = true;
input int      M15VetoEventAgeMin          = 15;
input int      H1VetoEventAgeMin           = 30;
input double   M15VetoADXMin               = 25.0;
input double   M15VetoATRChaosMult         = 4.5;
input bool     UseSessionVeto              = true;
input int      VetoSkipHour1Start          = 0;
input int      VetoSkipHour1End            = 6;
input int      VetoSkipHour2Start          = 20;
input int      VetoSkipHour2End            = 21;

//---------------- SMC ---------------------------------------------
input group "═══ SMC STRUCTURE ═══"
input bool     UseSMCStructure             = true;
input int      SMC_M15Lookback             = 80;
input int      SMC_M5Lookback              = 80;
input int      SMC_M1Lookback              = 30;
input int      SMC_InternalPivotLeft       = 2;
input int      SMC_InternalPivotRight      = 2;
input int      SMC_SwingPivotLeft          = 4;
input int      SMC_SwingPivotRight         = 3;
input double   SMC_ZoneDistanceATR         = 1.25;
input double   SMC_MinMonsterScore         = 0.55;
input double   SMC_MinSwingScore           = 0.55;
input double   SMC_MinReversalScore        = 0.52;
input bool     UseEqualLiquidity           = true;
input int      EqualLookback               = 40;
input double   EqualToleranceATR           = 0.10;

//---------------- QUALITY GATE -------------------------------------
input group "═══ QUALITY GATE ═══"
input bool     UseQualityGate              = true;
input double   QualityBase                 = 0.20;
input double   QualityMinMonster           = 0.58;
input double   QualityMinSwing             = 0.55;
input double   QualityMinRange             = 0.50;
input double   QualityMinReversal          = 0.55;

//---------------- MTF CONFLUENCE -----------------------------------
input group "═══ MTF CONFLUENCE ═══"
input bool     UseMTFConfluence            = true;
input double   MTFM5Weight                 = 0.60;
input double   MTFM1Weight                 = 0.40;
input double   MTFMinMonsterConfidence     = 0.55;
input double   MTFMinSwingConfidence       = 0.52;
input double   MTFMaxRangeTrendConf        = 0.66;
input bool     UseBayesianConfluence       = true;
input bool     UseKalmanM1Filter           = true;
input double   KalmanProcessNoise          = 0.02;
input double   KalmanMeasurementNoise      = 0.12;
input bool     UseEntropyFilter            = true;
input double   EntropyHighThreshold        = 0.92;
input bool     UseMutualInformation        = true;
input int      FeatureInfoWindow           = 60;
input int      FractionalDiffWindow        = 30;

//---------------- OU RANGE -----------------------------------------
input group "═══ OU RANGE ENGINE ═══"
input bool     UseOURange                  = true;
input int      OURangeWindow               = 48;
input double   OUMinTheta                  = 0.015;
input double   OUMinAbsZ                   = 1.10;
input double   OUMaxHalfLifeBars           = 45.0;
input double   OURangeMinProbability       = 0.58;
input double   ORangeTargetFraction        = 1.00;
input bool     ORangeAbortOnExpansion      = true;
input int      Range_WindowBars            = 8;
input double   Range_MinWidthATR           = 2.0;
input double   Range_MaxWidthATR           = 20.0;
input int      Range_PendingLifetimeMin    = 8;
input double   Range_GapATR                = 1.5;

//---------------- KILLSHOT -----------------------------------------
input group "═══ KILLSHOT ═══"
input bool     UseKillShot                 = true;
input double   KillShotMinStrength         = 60.0;
input double   KillShotTP_RR               = 4.0;
input double   KillShotSL_Shrink           = 0.75;

//---------------- MONSTER ------------------------------------------
input group "═══ MONSTER LIFECYCLE ═══"
input int      Monster_MaxPyramid          = 2;
input int      Monster_PyramidCooldownS    = 90;
input double   Monster_PyramidMinR         = 1.50;
input double   Monster_HarvestMinR         = 3.50;
input int      Monster_HarvestClosePct     = 25;
input double   Monster_TrailGivebackR      = 1.00;
input int      Monster_HardMaxHoldMin      = 240;

//---------------- ORDER MODE ---------------------------------------
input group "═══ ORDER MODE ═══"
input ENUM_ORDER_MODE OrderMode            = OMODE_STOP;

//---------------- HHLL / SUPERTREND --------------------------------
input group "═══ HHLL / SUPERTREND ═══"
input bool     UseHHLL                     = false;
input ENUM_TIMEFRAMES HHLL_TF              = PERIOD_H1;
input int      HHLL_LB                     = 5;
input int      HHLL_RB                     = 5;
input int      HHLL_MaxAge                 = 200;
input bool     UseSupertrend               = false;
input ENUM_TIMEFRAMES ST_TF                = PERIOD_M15;
input int      ST_ATR                      = 10;
input double   ST_Mult                     = 3.0;

//---------------- MSS M15 ------------------------------------------
input group "═══ MSS M15 ═══"
input bool     UseMSS                      = true;
input int      MSS_LeftBars                = 2;
input int      MSS_RightBars               = 2;
input int      MSS_ConfirmMin              = 15;

//---------------- OB / FVG -----------------------------------------
input group "═══ ORDER BLOCKS / FVG ═══"
input bool     UseOB                       = true;
input int      OB_Periods                  = 5;
input int      OB_MaxStored                = 8;
input bool     UseFVG                      = true;
input double   FVG_MinSizePts              = 5.0;
input int      FVG_MaxStored               = 8;

//---------------- LIQUIDITY SESSIONS -------------------------------
input group "═══ LIQUIDITY SESSIONS ═══"
input bool     UseLiquiditySessions        = true;
input int      LS_SessionStartUTC          = 6;
input int      LS_SessionEndUTC            = 22;
input bool     LS_UseAsian                 = true;
input bool     LS_UseLondon                = true;
input bool     LS_UsePDHPDL                = true;
input bool     LS_UseSwings                = true;
input double   LS_MinWickATR               = 0.5;

//---------------- SPREAD -------------------------------------------
input group "═══ SPREAD ═══"
input double   HardMaxSpreadPoints         = 2000.0;
input double   SoftSpreadPoints            = 800.0;
input bool     RejectIfSpreadExpands       = true;

//---------------- SAFETY -------------------------------------------
input group "═══ SAFETY ═══"
input bool     UseDailyHalt                = true;
input double   DailyLossLimitPct           = 3.0;
input bool     UseGlobalHalt               = true;
input double   GlobalLossLimitPct          = 6.0;
input bool     UsePeakGiveback             = true;
input double   PeakGivebackPct             = 5.0;
input int      PeakGivebackPauseHrs        = 1;
input bool     UseLossStreak               = true;
input int      MaxConsecutiveLosses        = 4;
input int      LossStreakPauseMin          = 60;

//---------------- BGBI-INTELLIGENT-PERFECT V2 -----------------------
input group "═══ BGBI PERFECT V2 — PRIMARY DECISION / RISK / EXIT ═══"
input bool     UseFactorBPrimaryDecisionV2   = true;  // Factor B technical confluence always owns direction/setup
input bool     UseFactorAAsHardVetoV2        = false; // Factor A confirms only; no blanket direction veto
input bool     UseUSDHybridContextV2         = true;  // slow macro/pair context only; never primary direction
input string   USDHybridBaseURLV2            = "http://127.0.0.1:8797";
input int      USDHybridPollSecondsV2         = 30;
input int      USDHybridMaxAgeSecondsV2       = 1800;
input double   USDHybridMaxConfirmPointsV2     = 4.0;

//---------------- KRONOS-MINI FORECAST BRIDGE ----------------------
input group "═══ KRONOS-MINI FORECAST BRIDGE (LOCAL) ═══"
input int      KronosModeV1                  = 1; // 0=OFF, 1=ADVISORY score, 2=CONFIRM MONSTER/SWING
input string   KronosBaseURLV1               = "http://127.0.0.1:8798";
input int      KronosPollSecondsV1           = 5;
input int      KronosM1MaxAgeSecondsV1       = 90;
input int      KronosM5MaxAgeSecondsV1       = 360;
input int      KronosM15MaxAgeSecondsV1      = 960;
input double   KronosM1ScoreWeightV1         = 2.0;
input double   KronosM5ScoreWeightV1         = 3.0;
input double   KronosM15ScoreWeightV1        = 2.0;
input double   KronosMaxScoreShiftV1         = 7.0;
input bool     KronosEnableChopEscapeV1      = true; // only when expansion evidence + AI/technical alignment
input bool     UsePortfolioRiskGovernorV2    = true;
input double   MaxPortfolioRiskPctV2         = 2.50;  // Open + pending worst-case risk across same Magic across symbols
input double   MaxSymbolCampaignRiskPctV2    = 1.25;  // Open + pending risk for this symbol/campaign
input double   MaxSingleLegRiskPctV2         = 0.60;
input int      MaxAccountPositionsV2         = 12;
input int      MaxAccountPendingOrdersV2     = 18;
input double   RiskCostReservePctV2           = 10.0;  // extra risk reserve for costs/slippage

//---------------- BGBI PERFECT V3 — ACTIVE ROUTE REPAIR -------------
input group "═══ BGBI PERFECT V3 — ROUTING / PROFILE / SHARED SAFETY ═══"
input string   V3ExpectedSymbolProfile        = "AUTO"; // set to BTCUSD, EURUSD, etc.; broker suffixes are allowed
input int      V3ExpectedCryptoPort           = 0;      // 0 for non-crypto; exact worker port for crypto
input bool     V3EnableRangeLimitRoute        = true;   // range edges use pending LIMIT, not immediate mean-reversion market orders
input bool     V3EnableRangeBreakoutContingency= true;   // pair one edge LIMIT with one safe breakout STOP beyond that same edge
input double   V3RangeBreakoutBufferATR        = 0.20;   // breakout trigger offset beyond the range boundary
input double   V3RangePairRiskShare            = 0.50;   // split planned range risk between reversal LIMIT and breakout STOP
input bool     V3EnableShockBreakoutStop       = true;   // directional CUSUM shock uses a continuation STOP, not blind market chase
input double   V3ShockBreakoutBufferATR        = 0.12;   // trigger beyond the completed M1 impulse bar
input double   V3ShockMaxChaseATR              = 0.45;   // skip if a valid trigger is already too far away
input int      V3RangeLookbackM5              = 8;
input double   V3RangeEdgeFraction            = 0.16;
input double   V3RangeMinWidthATR             = 1.25;
input double   V3RangeMaxWidthATR             = 4.50;
input double   V3RangeSLBufferATR             = 0.30;
input double   V3RangeMinRewardRisk           = 1.25;
input bool     V3EnableCompressionOCO         = true;   // active only in validated R7_COMPRESSION
input bool     V3RollbackPartialBatches       = true;   // cancel newly placed siblings if batch submission is incomplete
input bool     V3FastImpulseTickCheck         = true;   // debounced intrabar opportunity pulse; signals still use validated closed-bar structure
input int      V3FastImpulseCheckMs           = 500;
input bool     V3SharedAccountSafetyState     = true;   // shared day/peak/halt state across same login + magic charts
input bool     V3RatchetRequireM5Confirmation = false;  // optional legacy confirmation gate; false lets measured peak giveback protect profit promptly
input bool     UseUnifiedExitManagerV2       = true;  // one per-position manager; legacy BE/trail/basket exit owners disabled
input bool     UseNoiseResistantBEV2         = true;
input double   BE_MinInitialR_V2             = 1.00;
input double   BE_MinATRMultipleM1_V2        = 1.50;
input double   BE_CostBufferSpreadMultV2     = 1.50;
input double   TrailStartR_V2                = 2.50;
input double   Trail_ATRMultipleM1_V2        = 1.80;
input double   Trail_StepATR_M1_V2           = 0.50;
input bool     UseReversalConfirmedRatchetV2 = true;
input double   Ratchet_ArmPeakR_V2           = 0.15;
input double   Ratchet_GivebackR_V2          = 0.05;
input double   Ratchet_RetainPeakPct_V2      = 50.0;
input double   Ratchet_MinCurrentR_V2        = 0.05;
input bool     Ratchet_CloseIfLockMissedV2   = true;
input bool     UseAccountWidePendingCapV2    = true;
input bool     UseWickPause                = true;
input double   ViolentCandleMult           = 2.0;
input int      PostWickPauseSec            = 90;
input bool     UseWickAbort                = false; // hard SL + unified reversal ratchet handle exits; enable only after validation
input double   WickAbortPct                = 70.0;
input bool     AvoidRollover               = true;

//---------------- ANTI-CHURN ---------------------------------------
input group "═══ ANTI-CHURN ═══"
input int      Cooldown_Loss               = 180;
input int      Cooldown_Win                = 20;
input int      Cooldown_EngineAfterLoss    = 1800;
input int      MinSecondsBetweenPlaces     = 30;
input int      MaxPendingTotal             = 4;
input int      StaleOrderMinutes           = 60;

//---------------- FLOATING BUDGETS ---------------------------------
input group "═══ FLOATING BUDGETS ═══"
input bool     UseFloatingBudget           = true;
input double   SwingBudgetPct              = -2.00;
input double   MonsterBudgetPct            = -2.00;
input double   RangeBudgetPct              = -1.00;
input double   ReversalBudgetPct           = -1.25;

//---------------- BASKET R-TARGETS ---------------------------------
input group "═══ BASKET R-TARGETS ═══"
input bool     UseBasketRiskTargets        = false;
input double   SwingBasketBE_R             = 1.50;
input double   SwingBasketTrail_R          = 2.25;
input double   SwingBasketStep_R           = 0.75;
input double   MonsterBasketBE_R           = 1.80;
input double   MonsterBasketTrail_R        = 2.75;
input double   MonsterBasketStep_R         = 1.25;
input double   RangeBasketBE_R             = 0.90;
input double   RangeBasketTrail_R          = 1.30;
input double   RangeBasketStep_R           = 0.40;
input double   ReversalBasketBE_R          = 1.25;
input double   ReversalBasketTrail_R       = 1.75;
input double   ReversalBasketStep_R        = 0.50;

//---------------- BASKET %-TARGETS ---------------------------------
input group "═══ BASKET %-TARGETS ═══"
input double   BasketBE_Pct                = 5.00;
input double   BasketTrailStart_Pct        = 8.00;
input double   BasketTrailStep_Pct         = 2.00;
input double   BasketSL_Pct                = -3.00;
input bool     UseBasketManagement         = false;

//---------------- TIER 1 — REGIME GATE -----------------------------
input group "═══ TIER 1 — REGIME DIRECTION GATE ═══"
input bool     UseRegimeDirectionGate      = true;
input double   RegimeGateOppositeSizeMult  = 0.50;
input bool     RegimeGateRequiresFastTrend = true;

//---------------- TIER 1 — FASTTRENDSCORE --------------------------
input group "═══ TIER 1 — FASTTRENDSCORE ═══"
input bool     UseFastTrendScore           = true;
input int      FastTrend_PrimeThreshold    = 60;
input int      FastTrend_ChopThreshold     = 40;
input double   FastTrend_FlowWeight        = 35.0;
input double   FastTrend_M5Weight          = 35.0;
input double   FastTrend_VPWeight          = 20.0;
input double   FastTrend_M15Weight         = 10.0;
input double   FastTrend_DonchianSlopeMin  = 0.20;
input double   FastTrend_DonchianWidthATR  = 3.0;

//---------------- TIER 1 — REVERSAL HARDENING ----------------------
input group "═══ TIER 1 — REVERSAL HARDENING ═══"
input bool     RevRequireSessionSweep      = true;
input bool     RevRequireCVDFlipHardGate   = true;
input bool     RevBlockOnFastTrendOppose   = true;
input int      Rev_WatchMaxMinutes         = 15;

//---------------- TIER 2 — STRADDLE ---------------------------------
input group "═══ TIER 2 — BIASED STRADDLE ═══"
input bool     UseBiasedStraddle           = true;
input int      StraddleStrongOrders        = 2;
input int      StraddleWeakOrders          = 1;
input int      StraddleJerkOrders          = 2;
input int      StraddleExtremeOrders       = 2;
input double   StraddleStrongLotMult       = 1.00;
input double   StraddleWeakLotMult         = 0.35;
input double   StraddleJerkLotMult         = 1.25;
input double   StraddleExtremeLotMult      = 1.50;
input double   StraddleGapATR              = 0.65;
input int      StraddleMessageCapWarn      = 2500;

//---------------- TIER 2 — WIN-GATED GRID ---------------------------
input group "═══ TIER 2 — WIN-GATED GRID ═══"
input bool     UseWinGatedGrid             = false;
input int      GridMaxLevelsV2             = 5;
input double   GridLotMultV2               = 1.25;
input int      GridMinConsecutiveWins      = 1;
input int      GridCooldownSecV2           = 60;
input bool     GridRequireTrendRegime      = true;
input double   GridGapATRMult              = 1.0;

//---------------- TIER 2 — CONTINUOUS COMPOUNDING -------------------
input group "═══ TIER 2 — CONTINUOUS COMPOUNDING ═══"
input bool     UseContinuousCompoundingV2  = false;
input double   CompoundingExponentV2       = 0.50;
input double   CompoundingMaxMult          = 2.0;

//---------------- TIER 2 — TIGHT BE + TRAIL -------------------------
input group "═══ TIER 2 — TIGHT BE + TRAIL ═══"
input bool     UseTightBEV2                = false; // V2 unified exit manager replaces legacy tight BE
input double   TightBE_ATR_Mult_V2         = 0.10;
input double   TightBE_MinPoints_V2        = 2.0;
input double   TightBE_MaxPoints_V2        = 80.0;
input bool     UseTightTrailV2             = false; // V2 unified exit manager replaces legacy tight trail
input double   TightTrail_StartR_V2        = 0.20;
input double   TightTrail_StepR_V2         = 0.15;
input double   TightTrail_MinImprovePts_V2 = 2.0;
input double   TrailMinImprovePts          = 2.0;

//---------------- TIER 2 — SESSION SCORE ----------------------------
input group "═══ TIER 2 — SESSION SCORE ═══"
input bool     UseSessionScoreV2           = true;
input int      SessionPrimeStartUTC        = 13;
input int      SessionPrimeEndUTC          = 16;
input double   SessionPrimeBoost           = 1.30;
input double   SessionOffWindowCut         = 0.75;

//---------------- TIER 2 — BASKET DOLLAR MODE -----------------------
input group "═══ TIER 2 — BASKET DOLLAR MODE ═══"
input bool     UseBasketDollarMode         = false;
input double   BasketBE_USD_PctOfStart     = 5.00;
input double   BasketTrailStart_USD_Pct    = 8.00;
input double   BasketTrailStep_USD_Pct     = 2.00;
input double   BasketSL_USD_Pct            = -10.00;

//---------------- TIER 3 — EXECUTION ---------------------------------
input group "═══ TIER 3 — EXECUTION ═══"
input bool     UseOrderCheckBeforeSendV2   = true;
input bool     UseSlippageReAnchorV2       = true;
input double   SlippageReAnchorTriggerPts  = 3.0;
input bool     UseTransientRetryV2         = true;
input int      TransientMaxRetries         = 3;
input int      TransientRetryDelayMs       = 400;

//---------------- TIER 3 — VWAP CHOP --------------------------------
input group "═══ TIER 3 — VWAP CHOP MODE ═══"
input bool     UseVWAPChopStraddle         = false; // V2: compression-only paired stops; no blind straddle in generic CHOP
input int      VWAPChopBuyOrders           = 2;
input int      VWAPChopSellOrders          = 2;
input double   VWAPChopLotMult             = 0.50;

//---------------- TIER 3 — CLEANUP ----------------------------------
input group "═══ TIER 3 — CLEANUP ═══"
input int      StaleOrderMinutesV2         = 15;
input bool     UseHourlyStraddleReset      = true;

//---------------- TIER 3 — KILLSHOT BOOST ---------------------------
input group "═══ TIER 3 — KILLSHOT BOOST ═══"
input bool     UseKillShotPrimeBoost       = true;
input double   KillShotPrimeSizeMult       = 1.20;

//---------------- TIER 4 — RECOVERY ---------------------------------
input group "═══ TIER 4 — RECOVERY (OPT-IN) ═══"
input bool     UseRecoveryModeV2           = false;
input double   RecoveryTargetUSD           = 5.0;
input double   RecoveryMaxRiskPctEquity    = 2.0;
input int      RecoveryMaxStreak           = 4;
input bool     RecoveryResetOnAnyWin       = true;

//---------------- MESSAGE BUDGET [B1–B4] ----------------------------
input group "═══ MESSAGE BUDGET [B1–B4] ═══"
input bool     UseMsgBudget                = true;
input int      MsgBudgetHardLimit          = 1900;
input int      MsgBudgetSoftLimit          = 1400;
input int      MsgBudgetWarnEvery          = 100;

//---------------- FACTOR B — FALLBACK ENGINE ------------------------
input group "═══ FACTOR B — V106A FALLBACK ═══"
input bool     UseFactorBFallback          = true;
input bool     FB_ShowDashboard            = true;
input double   FB_Chop_Lot                 = 0.02;
input double   FB_Trend_Lot                = 0.05;
input double   FB_Monster_Lot              = 0.08;
input double   FB_Reversal_Lot             = 0.04;
input int      FB_Chop_SL_Pts              = 20000;
input int      FB_Chop_TP_Pts              = 40000;
input int      FB_Chop_Gap_Pts             = 12000;
input int      FB_Trend_SL_Pts             = 25000;
input int      FB_Trend_TP_Pts             = 55000;
input int      FB_Trend_Gap_Pts            = 20000;
input int      FB_Monster_SL_Pts           = 30000;
input int      FB_Monster_TP_Pts           = 80000;
input int      FB_Monster_Gap_Pts          = 15000;
input int      FB_Reversal_SL_Pts          = 20000;
input int      FB_Reversal_TP_Pts          = 44000;
input double   FB_VROC_TrendMin            = 2.5;
input double   FB_VROC_MonsterMin          = 4.5;
input double   FB_RE_TrendMin              = 1.5;
input double   FB_RE_MonsterMin            = 2.2;
input double   FB_VWAP_SlopeMin            = 3.0;
input int      FB_OB_MaxStored             = 8;
input int      FB_OB_MinDistPts            = 3000;
input int      FB_OB_MaxAgeBars            = 300;
input int      FB_FVG_MaxStored            = 8;
input double   FB_FVG_MinSizePts           = 500.0;
input int      FB_MSS_LeftBars             = 2;
input int      FB_MSS_RightBars            = 2;
input int      FB_MSS_ConfirmWindowMin     = 15;
input bool     FB_ReqM1Sweep               = true;
input bool     FB_ReqM1MSS                 = true;
input bool     FB_ReqM1Displ               = true;
input bool     FB_ReqZoneProximity         = true;
input int      FB_TrendLadderDepth         = 3;
input int      FB_MonsterLadderDepth       = 5;
input double   FB_BasketBE_Pct             = 5.0;
input double   FB_BasketTrail_Pct          = 8.0;
input double   FB_BasketStep_Pct           = 2.0;
input double   FB_BasketSL_Pct             = -10.0;
input int      FB_MinSecondsBetweenPlaces  = 30;
input int      FB_MaxPendingTotal          = 8;
input int      FB_Cooldown_Loss            = 180;
input int      FB_Cooldown_Win             = 20;

//---------------- DISPLAY ------------------------------------------
input group "═══ DISPLAY ═══"
input bool     ShowDisplay                 = true;
input bool     ShowTelemetry               = true;
input bool     VerboseFlow                 = false;

//===================================================================
// SECTION 4 — GLOBAL STATE
//===================================================================
S_Flow         gFlow;
S_VP           gBinVP;
S_Aux          gBinAux;
S_NativeVP     g_NVP;
S_SMC          g_SMC;
S_OU           g_OU;
S_SignalPack   g_Sig;
S_Health       g_Health[8];
int            g_HealthCount = 0;

datetime LastFlowPoll   = 0;
datetime LastVPPoll     = 0;
datetime LastAuxPoll    = 0;
datetime LastVPINPoll   = 0;

double   PreviousCVD              = 0.0;
double   PreviousCVDVelocity      = 0.0;
datetime PreviousCVDTime          = 0;
double   LocalCVDVelocity         = 0.0;
double   LocalCVDAcceleration     = 0.0;
double   CVDVelocityNormalized    = 0.0;
double   CVDAccelerationNormalized= 0.0;

double FlowRateHistory[60];
int    FlowRateCount = 0;
int    FlowRateIndex = 0;

// BGBI V2: slow USD hybrid context (supporting evidence only; never owns direction)
double   g_USDHybridPairScoreV2 = 0.0;
double   g_USDHybridStrengthV2 = 0.0;
double   g_USDHybridRiskMultV2 = 1.0;
bool     g_V2BatchLockHeld = false;
bool     g_V3ProfileMatch = true;
ulong    g_V3LastFastPulseMs = 0;
datetime g_USDHybridUpdatedV2 = 0;
datetime g_USDHybridLastPollV2 = 0;
string   g_USDHybridStateV2 = "OFF";
string   g_USDHybridSymbolV2 = "";

ENUM_HEALTH g_HealthState = HEALTH_GREEN;
string      g_HealthReason = "";

ENUM_REGIME7 g_R7                 = R7_CHOP;
ENUM_REGIME7 g_R7Pending          = R7_CHOP;
datetime     g_R7Since            = 0;
datetime     g_R7PendingSince     = 0;
double       g_R7Confidence       = 0.50;
double       g_R7_ER              = 0.0;
double       g_R7_Hurst           = 0.0;
double       g_R7_AC              = 0.0;
double       g_R7_VROC            = 0.0;
double       g_R7_ATR             = 0.0;
double       g_R7Score            = 0.0;
datetime     g_LastRegimeCalcM15  = 0;
double       g_HMMProb[7];
int          g_HMMRegime          = 4;

double   g_CUSUMBull          = 0.0;
double   g_CUSUMBear          = 0.0;
int      g_CUSUMDir           = 0;
datetime g_CUSUMLastFire      = 0;
datetime g_CUSUMOverrideUntil = 0;

ENUM_MONSTER_PHASE g_MonsterPhase        = MP_IDLE;
datetime           g_MonsterStart        = 0;
int                g_MonsterDir          = 0;
int                g_MonsterPyramidCount = 0;
double             g_MonsterPeakR        = 0.0;
datetime           g_LastPyramidAt       = 0;

ENUM_REV_STATE g_RevState         = REV_IDLE;
datetime       g_RevWatchSince    = 0;
int            g_RevDir           = 0;
int            g_RevConfirmCount  = 0;

double g_KalmanPrice    = 0.0;
double g_KalmanVelocity = 0.0;
double g_KalmanP00      = 1.0;
double g_KalmanP01      = 0.0;
double g_KalmanP10      = 0.0;
double g_KalmanP11      = 1.0;
datetime g_KalmanTime   = 0;

double g_VNEntropy       = 0.0;
double g_SignalMI_M5M15  = 0.0;
double g_FractDiff       = 0.0;

int hATR_M1     = INVALID_HANDLE;
int hATR_M5     = INVALID_HANDLE;
int hATR_M15    = INVALID_HANDLE;
int hEMA10_M15  = INVALID_HANDLE;
int hEMA20_M15  = INVALID_HANDLE;
int hEMA50_M15  = INVALID_HANDLE;
int hRSI_M15    = INVALID_HANDLE;
int hADX_M15    = INVALID_HANDLE;
int hMACD_M15   = INVALID_HANDLE;
int hEMA10_M5   = INVALID_HANDLE;
int hEMA8_M5    = INVALID_HANDLE;
int hEMA21_M5   = INVALID_HANDLE;
int hEMA50_M5   = INVALID_HANDLE;
int hRSI_M5     = INVALID_HANDLE;
int hADX_M5     = INVALID_HANDLE;
int hMACD_M5    = INVALID_HANDLE;
int hMom14_M5   = INVALID_HANDLE;
int hADX_M30    = INVALID_HANDLE;
int hExitEMA5_M1  = INVALID_HANDLE;
int hExitEMA13_M1 = INVALID_HANDLE;

double CurrentATR1  = 0.0;
double CurrentATR5  = 0.0;
double CurrentATR15 = 0.0;
double NormalATR1   = 0.0;
double NormalATR5   = 0.0;
double NormalATR15  = 0.0;

double CurrentSpreadPoints = 0.0;
double SpreadAveragePoints = 0.0;
double SpreadHistory[60];
int    SpreadCount = 0;
int    SpreadIndex = 0;

int    M15Direction      = 0;
int    M5Direction       = 0;
int    CombinedDirection = 0;
int    Jerk_M15          = 0;
int    Jerk_M5           = 0;
int    VWAP_Bias         = 0;
int    HHLL_State        = 0;

double KAMA_M15       = 0.0;
double KAMA_M15_Slope = 0.0;
double VWAP_Value     = 0.0;
double VWAP_Upper     = 0.0;
double VWAP_Lower     = 0.0;

double   MSS_LastHigh      = 0.0;
double   MSS_LastLow       = 0.0;
datetime MSS_LastHighTime  = 0;
datetime MSS_LastLowTime   = 0;
int      MSS_LastDir       = 0;
datetime MSS_LastEventTime = 0;
int      MSS_LastEventDir  = 0;

S_OrderBlock BullOBs[8];
S_OrderBlock BearOBs[8];
int BullOBCount = 0, BearOBCount = 0;
S_FVG BullFVGs[8];
S_FVG BearFVGs[8];
int BullFVGCount = 0, BearFVGCount = 0;

double   AsianHigh = 0.0, AsianLow = 0.0;
double   LondonHigh = 0.0, LondonLow = 0.0;
bool     AsianLocked = false, LondonLocked = false;
int      SessionDayOfYear = -1;

double   StartBalance    = 0.0;
double   DayStartEquity  = 0.0;
double   PeakEquity      = 0.0;
int      TodayStamp      = 0;
bool     DailyHalted     = false;
bool     GlobalHalted    = false;
datetime PauseUntil      = 0;
datetime LastLossTime    = 0;
datetime LastWinTime     = 0;
datetime LastViolentCandle = 0;
datetime LastTradeAction = 0;
datetime g_LastPlaceTime = 0;
datetime g_LastRangePlace= 0;

datetime g_EngineCooldown[4]   = {0,0,0,0};
int      g_EngineLossStreak[4] = {0,0,0,0};
int      g_EngineWinStreak[4]  = {0,0,0,0};
double   g_EnginePnLToday[4]   = {0,0,0,0};

int      g_LastEntryDir  = 0;
datetime g_LastEntryTime = 0;

int      TradeCount        = 0;
int      WinCount          = 0;
int      LossCount         = 0;
int      ConsecutiveWins   = 0;
int      ConsecutiveLosses = 0;
double   TotalWinUSD       = 0.0;
double   TotalLossUSD      = 0.0;

bool   SwingBE         = false, SwingTrail    = false;
double SwingTrailHigh  = 0.0,   SwingTrailSL  = 0.0;
bool   MonsterBE       = false, MonsterTrail  = false;
double MonsterTrailHigh= 0.0,   MonsterTrailSL= 0.0;
bool   RangeBE         = false, RangeTrail    = false;
double RangeTrailHigh  = 0.0,   RangeTrailSL  = 0.0;
bool   ReversalBE      = false, ReversalTrail = false;
double ReversalTrailHigh= 0.0,  ReversalTrailSL = 0.0;
bool   ReversalPartial = false;
double BasketInitialRiskUSD[4] = {0.0,0.0,0.0,0.0};

ENUM_ACCOUNT_MODE g_ResolvedMode = ACC_DOLLAR;

double g_InternalVWAP    = 0.0;
double g_InternalVWAPSD  = 0.0;
double g_InternalVWAPZ   = 0.0;
bool   g_InternalExhaust = false;
datetime g_InternalVWAPTime = 0;

ENUM_ENGINE g_LastEngine = ENG_NONE;
string      g_LastModelEngine = "";

int    M1PA_Dir        = 0;
double M1PA_Score      = 0.0;
bool   M1PA_BullSweep  = false;
bool   M1PA_BearSweep  = false;
bool   M1PA_BullDisp   = false;
bool   M1PA_BearDisp   = false;
bool   M1PA_BullMSS    = false;
bool   M1PA_BearMSS    = false;
bool   M1PA_BullFVG    = false;
bool   M1PA_BearFVG    = false;

double g_MTF_buy_prob     = 0.50;
double g_MTF_sell_prob    = 0.50;
double g_MTF_confidence   = 0.50;
int    g_LastModelDir     = 0;
double g_LastSignalConfidence = 0.50;

double ER_Short_M5 = 0.0;
double ER_Med_M5   = 0.0;
double ER_Slow_M15 = 0.0;
double ATR15_Pct   = 0.0;

int    DC_Bias      = 0;
double DC_Upper     = 0.0;
double DC_Lower     = 0.0;
double DC_UpperPrev = 0.0;
double DC_LowerPrev = 0.0;
double DC_Slope     = 0.0;
double MA_Slope     = 0.0;

double DayRangeValue = 0.0;
double ER_M15        = 0.0;
double ADX_M30       = 0.0;
double CI_M30        = 0.0;

bool   VolSurgeBull_sig = false;
bool   VolSurgeBear_sig = false;
double OBV_Val          = 0.0;
double OBV_Sig          = 0.0;

int    CurrentMoveState       = 0;
int    CurrentDirection       = 0;
double CurrentMoveScore       = 0.0;
int    CurrentDirectionSource = 0;

int    ST_Dir = 0;

double g_LotMin    = 0.01;
double g_LotMax    = 100.0;
double g_LotStep   = 0.01;
int    g_LotDigits = 2;

//--- TIER 1-4 STATE ------------------------------------------------
double   g_FastTrendScore      = 0.0;
int      g_FastTrendDir        = 0;
datetime g_LastFastTrendCalc   = 0;

//--- KRONOS-MINI forecast cache (forecast-only; never an order API) ---
struct S_KronosForecast
  {
   bool   available;
   bool   m1_valid, m5_valid, m15_valid;
   int    m1_dir, m5_dir, m15_dir;
   double m1_return_pct, m5_return_pct, m15_return_pct;
   double m1_range_pct, m5_range_pct, m15_range_pct;
   long   m1_updated_epoch, m5_updated_epoch, m15_updated_epoch;
   string status;
  };
S_KronosForecast g_Kronos;
datetime g_KronosLastPoll = 0;
datetime g_KronosLastLog  = 0;
bool     g_KronosChopEscapeActive = false;
int      g_KronosChopEscapeDir = 0;

int      g_BrokerMsgCountToday = 0;
int      g_BrokerMsgResetDay   = 0;

double   g_RecoveryAccumulated = 0.0;
int      g_RecoveryStreak      = 0;

datetime g_LastStraddleReset   = 0;
datetime g_LastGridAddV2       = 0;

int      g_GridLevelV2         = 0;
bool     g_LastWasWin          = false;
bool     g_StraddleActive      = false;
int      g_StraddleDir         = 0;

int      g_DailyOpens          = 0;
int      g_DailyModifies       = 0;
int      g_DailyDeletes        = 0;

double   g_LastRequestedEntry  = 0.0;
ulong    g_LastTicketForAnchor = 0;

//--- SLIPPAGE ANCHOR MAP ------------------------------------------
S_Anchor g_AnchorMap[200];
int      g_AnchorCount = 0;

//--- ACCOUNT DETECTION [C1] ---------------------------------------
bool     g_IsCent       = false;
double   g_ContractSize = 0.0;
double   g_TickValue    = 0.0;
double   g_TickValueLoss= 0.0;
double   g_TickSize     = 0.0;
string   g_AcctCurrency = "";

//--- MESSAGE BUDGET [B1] ------------------------------------------
int      g_MsgBudgetCount     = 0;
int      g_MsgBudgetWarnCount = 0;
int      g_MsgBudgetResetDay  = 0;
datetime g_MsgBudgetLastWarn  = 0;

//--- FACTOR SWITCH [FB2] ------------------------------------------
ENUM_ACTIVE_FACTOR g_ActiveFactor     = FACTOR_A_BRIDGE;
ENUM_ACTIVE_FACTOR g_LastFactor       = FACTOR_A_BRIDGE;
datetime           g_LastFactorSwitch = 0;

//--- FACTOR B STATE [FB1] -----------------------------------------
int      g_FB_Mode            = -1;    // -1 none, 0 CHOP, 1 TREND, 2 MONSTER, 3 REVERSAL
int      g_FB_JerkM15         = 0;
int      g_FB_M15Dir          = 0;
int      g_FB_M5Dir           = 0;
double   g_FB_VROC            = 0.0;
double   g_FB_RangeExp        = 0.0;
double   g_FB_VWAP            = 0.0;
double   g_FB_VWAPSlope       = 0.0;
S_NativeVP g_FB_VP;
S_OrderBlock g_FB_BullOB[8], g_FB_BearOB[8];
int          g_FB_BullOBCount = 0, g_FB_BearOBCount = 0;
S_FVG        g_FB_BullFVG[8], g_FB_BearFVG[8];
int          g_FB_BullFVGCount = 0, g_FB_BearFVGCount = 0;
double   g_FB_MSS_LastHigh     = 0.0;
double   g_FB_MSS_LastLow      = 0.0;
datetime g_FB_MSS_LastHighTime = 0;
datetime g_FB_MSS_LastLowTime  = 0;
int      g_FB_MSS_LastDir      = 0;
datetime g_FB_MSS_LastEventTime= 0;
int      g_FB_MSS_LastEventDir = 0;
datetime g_FB_LastM15Time      = 0;
datetime g_FB_LastM5Time       = 0;
datetime g_FB_LastM1Time       = 0;
datetime g_FB_LastClose[4]     = {0,0,0,0};
bool     g_FB_BE[4]            = {false,false,false,false};
bool     g_FB_Trail[4]         = {false,false,false,false};
double   g_FB_TrailHigh[4]     = {0,0,0,0};
double   g_FB_TrailSL[4]       = {0,0,0,0};
datetime g_FB_LastPlaceTime    = 0;
datetime g_FB_LastLossTime     = 0;
datetime g_FB_LastWinTime      = 0;
int      g_FB_ConsecutiveLosses= 0;

//===================================================================
// SECTION 5 — UTILITY HELPERS
//===================================================================
double Clamp(double v, double lo, double hi)
  {
   if(v < lo) return lo;
   if(v > hi) return hi;
   return v;
  }

double BidPrice() { return SymbolInfoDouble(_Symbol, SYMBOL_BID); }
double AskPrice() { return SymbolInfoDouble(_Symbol, SYMBOL_ASK); }

double MidPrice()
  {
   double b = BidPrice();
   double a = AskPrice();
   if(b <= 0.0 || a <= 0.0) return 0.0;
   return (b + a) * 0.5;
  }

double StopsLevelPrice()
  {
   double pts = (double)SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL);
   if(pts <= 0.0) pts = 5.0;
   return pts * _Point;
  }

double BufVal(int handle, int buffer, int shift)
  {
   if(handle == INVALID_HANDLE) return 0.0;
   double v[];
   if(CopyBuffer(handle, buffer, shift, 1, v) != 1) return 0.0;
   return v[0];
  }

double TfOpen(ENUM_TIMEFRAMES tf, int shift)
  {
   double v[];
   if(CopyOpen(_Symbol, tf, shift, 1, v) != 1) return 0.0;
   return v[0];
  }

double TfClose(ENUM_TIMEFRAMES tf, int shift)
  {
   double v[];
   if(CopyClose(_Symbol, tf, shift, 1, v) != 1) return 0.0;
   return v[0];
  }

double TfHigh(ENUM_TIMEFRAMES tf, int shift)
  {
   double v[];
   if(CopyHigh(_Symbol, tf, shift, 1, v) != 1) return 0.0;
   return v[0];
  }

double TfLow(ENUM_TIMEFRAMES tf, int shift)
  {
   double v[];
   if(CopyLow(_Symbol, tf, shift, 1, v) != 1) return 0.0;
   return v[0];
  }

long TfVolume(ENUM_TIMEFRAMES tf, int shift)
  {
   long v[];
   if(CopyTickVolume(_Symbol, tf, shift, 1, v) != 1) return 0;
   return v[0];
  }

datetime TfTime(ENUM_TIMEFRAMES tf, int shift)
  {
   datetime v[];
   if(CopyTime(_Symbol, tf, shift, 1, v) != 1) return 0;
   return v[0];
  }

string DirStr(int d)
  {
   if(d > 0) return "BUY";
   if(d < 0) return "SELL";
   return "—";
  }

string SignStr(double v, int digits = 1)
  {
   if(v > 0.0) return "+" + DoubleToString(v, digits);
   return DoubleToString(v, digits);
  }

string HealthStr()
  {
   switch(g_HealthState)
     {
      case HEALTH_GREEN:  return "GREEN";
      case HEALTH_YELLOW: return "YELLOW";
      case HEALTH_RED:    return "RED";
      case HEALTH_BLACK:  return "BLACK";
     }
   return "?";
  }

string Regime7Name(ENUM_REGIME7 r)
  {
   switch(r)
     {
      case R7_STRONG_UP:   return "STRONG_UP";
      case R7_STRONG_DOWN: return "STRONG_DOWN";
      case R7_WEAK_UP:     return "WEAK_UP";
      case R7_WEAK_DOWN:   return "WEAK_DOWN";
      case R7_CHOP:        return "CHOP";
      case R7_COMPRESSION: return "COMPRESSION";
      case R7_EXPANSION:   return "EXPANSION";
     }
   return "CHOP";
  }

string MonsterPhaseStr()
  {
   switch(g_MonsterPhase)
     {
      case MP_IDLE:         return "IDLE";
      case MP_IGNITION:     return "IGNITION";
      case MP_ACCELERATION: return "ACCEL";
      case MP_HARVEST:      return "HARVEST";
     }
   return "?";
  }

string RevStateStr()
  {
   switch(g_RevState)
     {
      case REV_IDLE:    return "IDLE";
      case REV_WATCH:   return "WATCH";
      case REV_ALERT:   return "ALERT";
      case REV_CONFIRM: return "CONFIRM";
     }
   return "?";
  }

string FlowStateStr()
  {
   if(!UseBinanceFlow)            return "OFF";
   if(MQLInfoInteger(MQL_TESTER)) return "TESTER";
   if(!gFlow.valid)               return "NO-DATA";
   if(!gFlow.healthy)             return "UNHEALTHY";
   if(gFlow.local_update == 0)    return "NO-DATA";
   if(TimeCurrent() - gFlow.local_update > BinanceMaxAgeSeconds) return "STALE";
   return "LIVE";
  }

string EngineName(ENUM_ENGINE e)
  {
   switch(e)
     {
      case ENG_REVERSAL: return "REVERSAL";
      case ENG_CUSUM:    return "CUSUM";
      case ENG_KILLSHOT: return "KILLSHOT";
      case ENG_MONSTER:  return "MONSTER";
      case ENG_TREND:    return "TREND";
      case ENG_RANGE:    return "RANGE";
      case ENG_STRADDLE: return "STRADDLE";
      default:           return "—";
     }
  }

string FactorStr(ENUM_ACTIVE_FACTOR f)
  {
   return (f == FACTOR_A_BRIDGE) ? "A" : "B";
  }

string FB_ModeName(int m)
  {
   if(m == 0) return "CHOP";
   if(m == 1) return "TREND";
   if(m == 2) return "MONSTER";
   if(m == 3) return "REVERSAL";
   return "?";
  }

//===================================================================
// SECTION 6 — NORMAL ATR
//===================================================================
double GetNormalATR1()
  {
   if(hATR_M1 == INVALID_HANDLE) return 0.0;
   double sum = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      double v = BufVal(hATR_M1, 0, i);
      if(v > 0.0) { sum += v; cnt++; }
     }
   return (cnt > 0) ? sum / (double)cnt : 0.0;
  }

double GetNormalATR5()
  {
   if(hATR_M5 == INVALID_HANDLE) return 0.0;
   double sum = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      double v = BufVal(hATR_M5, 0, i);
      if(v > 0.0) { sum += v; cnt++; }
     }
   return (cnt > 0) ? sum / (double)cnt : 0.0;
  }

double GetNormalATR15()
  {
   if(hATR_M15 == INVALID_HANDLE) return 0.0;
   double sum = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      double v = BufVal(hATR_M15, 0, i);
      if(v > 0.0) { sum += v; cnt++; }
     }
   return (cnt > 0) ? sum / (double)cnt : 0.0;
  }

//===================================================================
// SECTION 7 — EFFICIENCY RATIO
//===================================================================
double CalculateER_TF(ENUM_TIMEFRAMES tf, int period)
  {
   // V3.4: regime efficiency uses COMPLETED candles only on every timeframe.
   // Shift 0 is still forming; reading it here made M5/M15 regime metrics
   // drift on each M1 bar before the corresponding higher-timeframe close.
   if(period < 2) return 0.0;
   const int firstClosedShift = 1;
   double c0 = TfClose(tf, firstClosedShift);
   double cN = TfClose(tf, firstClosedShift + period);
   if(c0 <= 0.0 || cN <= 0.0) return 0.0;

   double net = MathAbs(c0 - cN);
   double path = 0.0;
   for(int i = firstClosedShift; i < firstClosedShift + period; i++)
     {
      double a = TfClose(tf, i);
      double b = TfClose(tf, i + 1);
      if(a > 0.0 && b > 0.0) path += MathAbs(a - b);
     }
   if(path <= 0.0) return 0.0;
   return Clamp(net / path, 0.0, 1.0);
  }

//===================================================================
// SECTION 8 — SPREAD SAFETY [S1–S4]
//===================================================================
double SpreadInPoints()
  {
   double b = BidPrice();
   double a = AskPrice();
   if(b <= 0.0 || a <= 0.0) return 0.0;
   double s = (a - b) / _Point;
   if(s < 0.0) s = 0.0;
   return s;
  }

double SafeSLDistance(double baseSLDistance)
  {
   // Universal V2 floor: current spread + broker stop level + a small ATR allowance.
   // Never apply an absolute BTC-style point floor across FX, metals, indices and crypto.
   double spreadFloor = SpreadInPoints() * SpreadMultiplier_SL * _Point;
   double brokerFloor = MathMax(StopsLevelPrice() * 2.0, _Point * 2.0);
   double atrFloor = (CurrentATR5 > 0.0 ? CurrentATR5 * 0.10 : 0.0);
   return MathMax(baseSLDistance, MathMax(spreadFloor, MathMax(brokerFloor, atrFloor)));
  }

double SafeTPDistance(double baseTPDistance, double slDistance)
  {
   double spreadPts = SpreadInPoints();
   double spreadFloor = spreadPts * SpreadMultiplier_TP * _Point;
   double result = MathMax(baseTPDistance, spreadFloor);

   // Sanity: TP must exceed 1.2× SL
   if(result < slDistance * 1.2) result = slDistance * 1.2;
   return result;
  }

double SafeTrailBuffer()
  {
   double spreadFloor = SpreadInPoints() * SpreadMultiplier_Trail * _Point;
   double brokerFloor = MathMax(StopsLevelPrice() * 1.5, _Point * 2.0);
   return MathMax(spreadFloor, brokerFloor);
  }

//===================================================================
// SECTION 9 — MESSAGE BUDGET MANAGER [B1]
//===================================================================
void MsgBudget_Init()
  {
   g_MsgBudgetResetDay = (int)(TimeCurrent() / 86400);
   g_MsgBudgetCount = 0;
   g_MsgBudgetWarnCount = 0;
  }

void MsgBudget_Tick()
  {
   int today = (int)(TimeCurrent() / 86400);
   if(today != g_MsgBudgetResetDay)
     {
      g_MsgBudgetResetDay = today;
      g_MsgBudgetCount = 0;
      g_MsgBudgetWarnCount = 0;
      PrintFormat("[MSGBUDGET] Daily reset — count=0");
     }
  }

bool MsgBudget_CanSend()
  {
   if(!UseMsgBudget) return true;
   MsgBudget_Tick();
   if(g_MsgBudgetCount >= MsgBudgetHardLimit)
     {
      if(TimeCurrent() - g_MsgBudgetLastWarn >= 300)
        {
         g_MsgBudgetLastWarn = TimeCurrent();
         PrintFormat("[MSGBUDGET] HARD LIMIT %d reached — blocking sends",
                     MsgBudgetHardLimit);
        }
      return false;
     }
   return true;
  }

bool MsgBudget_SoftThrottled()
  {
   if(!UseMsgBudget) return false;
   return (g_MsgBudgetCount >= MsgBudgetSoftLimit);
  }

void MsgBudget_Count(int n = 1)
  {
   if(!UseMsgBudget) return;
   g_MsgBudgetCount += n;
   g_MsgBudgetWarnCount++;
   if(g_MsgBudgetCount >= MsgBudgetSoftLimit &&
      g_MsgBudgetWarnCount % MsgBudgetWarnEvery == 0)
      PrintFormat("[MSGBUDGET] soft throttle — %d/%d",
                  g_MsgBudgetCount, MsgBudgetHardLimit);
  }

int MsgBudget_GetCount() { return g_MsgBudgetCount; }

//===================================================================
// SECTION 10 — ACCOUNT DETECTION [C1, C2]
//===================================================================
void DetectAccountType()
  {
   g_AcctCurrency  = AccountInfoString(ACCOUNT_CURRENCY);
   g_ContractSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_CONTRACT_SIZE);
   g_TickValue     = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   g_TickValueLoss = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE_LOSS);
   g_TickSize      = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);

   if(g_TickValueLoss <= 0.0) g_TickValueLoss = g_TickValue;
   if(g_TickSize <= 0.0)      g_TickSize = _Point;

   g_IsCent = (StringFind(g_AcctCurrency, "USC") >= 0 ||
               StringFind(g_AcctCurrency, "usc") >= 0 ||
               StringFind(g_AcctCurrency, "c") == StringLen(g_AcctCurrency) - 1);

   if(g_IsCent)
      PrintFormat("[ACCT] CENT account: cur=%s contract=%.4f tickVal=%.5f",
                  g_AcctCurrency, g_ContractSize, g_TickValue);
   else
      PrintFormat("[ACCT] DOLLAR account: cur=%s contract=%.4f tickVal=%.5f",
                  g_AcctCurrency, g_ContractSize, g_TickValue);
  }

//===================================================================
// SECTION 11 — FACTOR SELECTOR [FB2]
//===================================================================
ENUM_ACTIVE_FACTOR ActiveFactor()
  {
   // V2 semantics: Factor B (internal technical confluence) is always primary.
   // Factor A bridge is confirmation only and can never take over direction ownership.
   if(UseFactorBPrimaryDecisionV2) return FACTOR_B_FALLBACK;
   // Optional compatibility mode for reproducing the older Ultimate selector.
   if(!UseFactorBFallback) return FACTOR_A_BRIDGE;
   if(MQLInfoInteger(MQL_TESTER)) return FACTOR_B_FALLBACK;
   if(!UseBinanceFlow) return FACTOR_B_FALLBACK;
   if(!gFlow.valid || !gFlow.healthy) return FACTOR_B_FALLBACK;
   if(g_HealthState > HEALTH_YELLOW) return FACTOR_B_FALLBACK;
   return FACTOR_A_BRIDGE;
  }

void LogFactorSwitchIfChanged()
  {
   ENUM_ACTIVE_FACTOR af = ActiveFactor();
   if(af != g_LastFactor)
     {
      PrintFormat("[FACTOR] %s -> %s (bridge=%s health=%d)",
                  FactorStr(g_LastFactor), FactorStr(af),
                  (gFlow.valid && gFlow.healthy ? "OK" : "DOWN"),
                  (int)g_HealthState);
      g_LastFactor = af;
      g_LastFactorSwitch = TimeCurrent();
     }
   g_ActiveFactor = af;
  }

//===================================================================
// END OF PART 1 OF 5
//===================================================================

//===================================================================
// SECTION 12 — JSON HELPERS
//===================================================================
int JsonFindValueStart(const string json, const string key)
  {
   string token = "\"" + key + "\"";
   int p = StringFind(json, token);
   if(p < 0) return -1;

   int colon = StringFind(json, ":", p + StringLen(token));
   if(colon < 0) return -1;

   int n = StringLen(json);
   int i = colon + 1;
   while(i < n)
     {
      ushort ch = StringGetCharacter(json, i);
      if(ch != ' ' && ch != '\t' && ch != '\r' && ch != '\n') break;
      i++;
     }
   return i;
  }

double JsonNumber(const string json, const string key, double fallback = 0.0)
  {
   int start = JsonFindValueStart(json, key);
   if(start < 0) return fallback;

   int n = StringLen(json);
   int end = start;
   while(end < n)
     {
      ushort ch = StringGetCharacter(json, end);
      bool numeric = ((ch >= '0' && ch <= '9') || ch == '-' || ch == '+' ||
                      ch == '.' || ch == 'e' || ch == 'E');
      if(!numeric) break;
      end++;
     }
   if(end <= start) return fallback;
   return StringToDouble(StringSubstr(json, start, end - start));
  }

bool JsonBool(const string json, const string key, bool fallback = false)
  {
   int start = JsonFindValueStart(json, key);
   if(start < 0) return fallback;
   string text = StringSubstr(json, start, 8);
   if(StringFind(text, "true")  >= 0) return true;
   if(StringFind(text, "false") >= 0) return false;
   return fallback;
  }

string JsonString(const string json, const string key, string fallback = "")
  {
   int start = JsonFindValueStart(json, key);
   if(start < 0) return fallback;
   if(StringGetCharacter(json, start) != '"') return fallback;

   int n = StringLen(json);
   int end = start + 1;
   while(end < n)
     {
      if(StringGetCharacter(json, end) == '"' &&
         StringGetCharacter(json, end - 1) != '\\') break;
      end++;
     }
   if(end >= n) return fallback;
   return StringSubstr(json, start + 1, end - start - 1);
  }

//===================================================================
// SECTION 13 — HTTP GET
//===================================================================
bool HttpGet(const string url, string &body, int requestTimeoutMs = 0)
  {
   body = "";
   if(MQLInfoInteger(MQL_TESTER)) return false;

   int timeoutMs = (requestTimeoutMs > 0 ? requestTimeoutMs : BinanceHttpTimeoutMs);
   char data[];
   char result[];
   string headers = "";

   ResetLastError();
   int code = WebRequest("GET", url, "", "", timeoutMs,
                         data, 0, result, headers);
   if(code < 0)
     {
      if(VerboseFlow)
         PrintFormat("[HTTP] err=%d url=%s", GetLastError(), url);
      return false;
     }
   body = CharArrayToString(result, 0, -1, CP_UTF8);
   return (code >= 200 && code < 300 && StringLen(body) > 0);
  }

//===================================================================
// KRONOS-MINI LOCAL FORECAST CLIENT (forecast only; EA owns risk/order)
//===================================================================
void KronosResetState(const string reason)
  {
   g_Kronos.available=false;
   g_Kronos.status=reason;
  }

string KronosEncodeSymbol(string symbol)
  {
   StringReplace(symbol,"%","%25");
   StringReplace(symbol,"#","%23");
   StringReplace(symbol,"&","%26");
   StringReplace(symbol,"+","%2B");
   StringReplace(symbol," ","%20");
   StringReplace(symbol,"?","%3F");
   StringReplace(symbol,"/","%2F");
   return symbol;
  }

void PollKronosForecast()
  {
   if(KronosModeV1<=0) { KronosResetState("OFF"); return; }
   if(MQLInfoInteger(MQL_TESTER)) { KronosResetState("TESTER_NO_REPLAY"); return; }
   datetime now=TimeLocal(); // wall clock keeps retry alive when broker ticks pause
   if(g_KronosLastPoll>0 && now-g_KronosLastPoll<MathMax(1,KronosPollSecondsV1)) return;
   g_KronosLastPoll=now;

   string body="";
   string url=KronosBaseURLV1+"/snapshot?symbol="+KronosEncodeSymbol(_Symbol);
   if(!HttpGet(url,body,350))
     {
      KronosResetState("UNAVAILABLE");
      if(now-g_KronosLastLog>=60)
        { g_KronosLastLog=now; PrintFormat("[KRONOS] forecast bridge unavailable symbol=%s url=%s; AI contribution neutral",_Symbol,KronosBaseURLV1); }
      return;
     }
   string responseSymbol=JsonString(body,"symbol","");
   if(responseSymbol!=_Symbol || !JsonBool(body,"ok",false))
     {
      KronosResetState(responseSymbol!=_Symbol ? "WRONG_SYMBOL" : "NOT_READY");
      if(now-g_KronosLastLog>=60)
        { g_KronosLastLog=now; PrintFormat("[KRONOS] rejected snapshot requested=%s response=%s status=%s",_Symbol,responseSymbol,g_Kronos.status); }
      return;
     }

   g_Kronos.available=true;
   g_Kronos.status=JsonString(body,"status","OK");
   g_Kronos.m1_valid=JsonBool(body,"m1_valid",false);
   g_Kronos.m5_valid=JsonBool(body,"m5_valid",false);
   g_Kronos.m15_valid=JsonBool(body,"m15_valid",false);
   g_Kronos.m1_dir=(int)JsonNumber(body,"m1_dir",0.0);
   g_Kronos.m5_dir=(int)JsonNumber(body,"m5_dir",0.0);
   g_Kronos.m15_dir=(int)JsonNumber(body,"m15_dir",0.0);
   g_Kronos.m1_return_pct=JsonNumber(body,"m1_return_pct",0.0);
   g_Kronos.m5_return_pct=JsonNumber(body,"m5_return_pct",0.0);
   g_Kronos.m15_return_pct=JsonNumber(body,"m15_return_pct",0.0);
   g_Kronos.m1_range_pct=JsonNumber(body,"m1_range_pct",0.0);
   g_Kronos.m5_range_pct=JsonNumber(body,"m5_range_pct",0.0);
   g_Kronos.m15_range_pct=JsonNumber(body,"m15_range_pct",0.0);
   g_Kronos.m1_updated_epoch=(long)JsonNumber(body,"m1_updated_epoch",0.0);
   g_Kronos.m5_updated_epoch=(long)JsonNumber(body,"m5_updated_epoch",0.0);
   g_Kronos.m15_updated_epoch=(long)JsonNumber(body,"m15_updated_epoch",0.0);
  }

bool KronosFreshTF(const int tfMinutes)
  {
   if(!g_Kronos.available) return false;
   bool valid=false; long updated=0; int maxAge=0;
   if(tfMinutes==1)  { valid=g_Kronos.m1_valid;  updated=g_Kronos.m1_updated_epoch;  maxAge=KronosM1MaxAgeSecondsV1; }
   if(tfMinutes==5)  { valid=g_Kronos.m5_valid;  updated=g_Kronos.m5_updated_epoch;  maxAge=KronosM5MaxAgeSecondsV1; }
   if(tfMinutes==15) { valid=g_Kronos.m15_valid; updated=g_Kronos.m15_updated_epoch; maxAge=KronosM15MaxAgeSecondsV1; }
   if(!valid || updated<=0) return false;
   long age=(long)TimeGMT()-updated;
   return (age>=0 && age<=maxAge);
  }

int KronosDirTF(const int tfMinutes)
  {
   if(tfMinutes==1) return g_Kronos.m1_dir;
   if(tfMinutes==5) return g_Kronos.m5_dir;
   if(tfMinutes==15) return g_Kronos.m15_dir;
   return 0;
  }

double KronosScoreAdjustment(const int technicalDir)
  {
   if(KronosModeV1<=0 || technicalDir==0) return 0.0;
   double adjustment=0.0;
   if(KronosFreshTF(1) && g_Kronos.m1_dir!=0)
      adjustment += (g_Kronos.m1_dir==technicalDir ? KronosM1ScoreWeightV1 : -KronosM1ScoreWeightV1);
   if(KronosFreshTF(5) && g_Kronos.m5_dir!=0)
      adjustment += (g_Kronos.m5_dir==technicalDir ? KronosM5ScoreWeightV1 : -KronosM5ScoreWeightV1);
   if(KronosFreshTF(15) && g_Kronos.m15_dir!=0)
      adjustment += (g_Kronos.m15_dir==technicalDir ? KronosM15ScoreWeightV1 : -KronosM15ScoreWeightV1);
   adjustment=Clamp(adjustment,-MathAbs(KronosMaxScoreShiftV1),MathAbs(KronosMaxScoreShiftV1));
   if(MathAbs(adjustment)>0.0 && TimeLocal()-g_KronosLastLog>=60)
     {
      g_KronosLastLog=TimeLocal();
      PrintFormat("[KRONOS SCORE] symbol=%s mode=%d techDir=%d K1=%d K5=%d K15=%d delta=%.1f status=%s",
                  _Symbol,KronosModeV1,technicalDir,
                  (KronosFreshTF(1)?g_Kronos.m1_dir:0),
                  (KronosFreshTF(5)?g_Kronos.m5_dir:0),
                  (KronosFreshTF(15)?g_Kronos.m15_dir:0),adjustment,g_Kronos.status);
     }
   return adjustment;
  }

bool KronosConfirmAllows(const string engine,const int dir)
  {
   if(KronosModeV1<2 || (engine!="MONSTER" && engine!="SWING")) return true;
   if(!KronosFreshTF(1) || !KronosFreshTF(5)) return false;
   if(g_Kronos.m1_dir!=dir || g_Kronos.m5_dir!=dir) return false;
   if(KronosFreshTF(15) && g_Kronos.m15_dir==-dir) return false;
   return true;
  }

//===================================================================
// SECTION 14 — DATA HEALTH GATE [A4: log stale stream names]
//===================================================================
string V2_USDCanonicalSymbol()
  {
   string sym=_Symbol;
   StringToUpper(sym);
   if(StringFind(sym,"EURUSD")>=0) return "EURUSD";
   if(StringFind(sym,"GBPUSD")>=0) return "GBPUSD";
   if(StringFind(sym,"USDJPY")>=0) return "USDJPY";
   if(StringFind(sym,"USDCAD")>=0) return "USDCAD";
   if(StringFind(sym,"XAUUSD")>=0) return "XAUUSD";
   if(StringFind(sym,"DE40")>=0) return "DE40";
   return "";
  }

void PollUSDHybridContextV2()
  {
   if(!UseUSDHybridContextV2) { g_USDHybridStateV2="OFF"; return; }
   if(MQLInfoInteger(MQL_TESTER)) { g_USDHybridStateV2="TESTER-NO-EXTERNAL"; return; }
   datetime now=TimeCurrent();
   if(g_USDHybridLastPollV2>0 && now-g_USDHybridLastPollV2<MathMax(5,USDHybridPollSecondsV2)) return;
   g_USDHybridLastPollV2=now;
   string wanted=V2_USDCanonicalSymbol();
   if(wanted=="") { g_USDHybridStateV2="NOT-MAPPED"; g_USDHybridPairScoreV2=0.0; return; }
   string url=USDHybridBaseURLV2+"/signal?symbol="+wanted;
   string body="";
   if(!HttpGet(url,body))
     { g_USDHybridStateV2="UNAVAILABLE"; return; }
   string responseSym=JsonString(body,"symbol","");
   if(responseSym!=wanted)
     { g_USDHybridStateV2="WRONG-SYMBOL"; g_USDHybridPairScoreV2=0.0; PrintFormat("[USD HYBRID] rejected wrong symbol expected=%s got=%s",wanted,responseSym); return; }
   bool ok=JsonBool(body,"ok",false);
   bool stale=JsonBool(body,"stale",true);
   bool priceOk=JsonBool(body,"price_feed_ok",false);
   long updated=(long)JsonNumber(body,"updated_epoch",0.0);
   long nowGMT=(long)TimeGMT();
   long age=(updated>0 && nowGMT>=updated ? nowGMT-updated : 999999);
   if(!ok || stale || !priceOk || age>USDHybridMaxAgeSecondsV2)
     {
      g_USDHybridStateV2="STALE/UNHEALTHY"; g_USDHybridPairScoreV2=0.0;
      PrintFormat("[USD HYBRID] non-fresh symbol=%s ok=%d stale=%d price=%d age=%d",wanted,(int)ok,(int)stale,(int)priceOk,(int)age);
      return;
     }
   g_USDHybridPairScoreV2=Clamp(JsonNumber(body,"pair_score",0.0),-100.0,100.0);
   g_USDHybridStrengthV2=Clamp(JsonNumber(body,"usd_strength_score",0.0),-100.0,100.0);
   g_USDHybridRiskMultV2=Clamp(JsonNumber(body,"adaptive_risk_multiplier",1.0),0.50,1.0);
   g_USDHybridUpdatedV2=(datetime)updated;
   g_USDHybridSymbolV2=wanted;
   g_USDHybridStateV2="FRESH-CONTEXT";
  }

void ApplyUSDHybridConfirmationV2()
  {
   if(!UseFactorBPrimaryDecisionV2 || !UseUSDHybridContextV2) return;
   if(g_USDHybridStateV2!="FRESH-CONTEXT" || g_USDHybridUpdatedV2<=0) return;
   if(g_FastTrendDir==0 || MathAbs(g_USDHybridPairScoreV2)<20.0) return;
   double aligned=g_USDHybridPairScoreV2*(double)g_FastTrendDir;
   if(aligned>=20.0)
     {
      double bonus=MathMin(USDHybridMaxConfirmPointsV2,MathAbs(g_USDHybridPairScoreV2)/25.0);
      g_FastTrendScore=Clamp(g_FastTrendScore+bonus,0.0,100.0);
      PrintFormat("[USD HYBRID CONFIRM] pair=%s dir=%d score=%.1f bonus=%.1f",g_USDHybridSymbolV2,g_FastTrendDir,g_USDHybridPairScoreV2,bonus);
     }
   else if(aligned<=-40.0)
     {
      // Opposing macro proxy modestly lowers confidence; it cannot veto/change Factor-B direction.
      g_FastTrendScore=Clamp(g_FastTrendScore-2.0,0.0,100.0);
      PrintFormat("[USD HYBRID CONFLICT] pair=%s dir=%d score=%.1f; Factor B keeps direction",g_USDHybridSymbolV2,g_FastTrendDir,g_USDHybridPairScoreV2);
     }
  }

void Health_Register(string name, int maxAgeSec)
  {
   if(g_HealthCount >= 8) return;
   g_Health[g_HealthCount].name       = name;
   g_Health[g_HealthCount].maxAgeSec  = maxAgeSec;
   g_Health[g_HealthCount].healthy    = false;
   g_Health[g_HealthCount].lastUpdate = 0;
   g_HealthCount++;
  }

void Health_Init()
  {
   g_HealthCount = 0;
   // These streams are crypto-bridge telemetry. Do not mark forex, gold, or index
   // charts stale for feeds that their presets intentionally disable.
   if(!UseBinanceFlow)
     {
      g_HealthState = HEALTH_GREEN;
      g_HealthReason = "crypto_bridge_not_applicable";
      return;
     }
   Health_Register("flow",    HealthMaxAge_Flow);
   Health_Register("vp",      HealthMaxAge_VP);
   Health_Register("vroc",    HealthMaxAge_VROC);
   Health_Register("vwapz",   HealthMaxAge_VWAPZ);
   Health_Register("vpin",    HealthMaxAge_VPIN);
   Health_Register("walls",   HealthMaxAge_Walls);
   Health_Register("funding", HealthMaxAge_Funding);
  }

void Health_Tick(string name)
  {
   for(int i = 0; i < g_HealthCount; i++)
      if(g_Health[i].name == name)
        {
         g_Health[i].lastUpdate = TimeCurrent();
         return;
        }
  }

ENUM_HEALTH Health_Evaluate()
  {
   if(!UseHealthGate)
     { g_HealthState = HEALTH_GREEN; g_HealthReason = "disabled"; return g_HealthState; }
   if(MQLInfoInteger(MQL_TESTER))
     { g_HealthState = HEALTH_GREEN; g_HealthReason = "tester"; return g_HealthState; }

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0 || ask < bid)
     { g_HealthState = HEALTH_BLACK; g_HealthReason = "broker_offline"; return g_HealthState; }

   datetime now = TimeCurrent();
   int failCount = 0;

   for(int i = 0; i < g_HealthCount; i++)
     {
      if(g_Health[i].lastUpdate == 0)
        { g_Health[i].healthy = false; failCount++; continue; }
      int age = (int)(now - g_Health[i].lastUpdate);
      bool ok = (age <= g_Health[i].maxAgeSec);
      g_Health[i].healthy = ok;
      if(!ok) failCount++;
     }

   if(failCount >= 3)      { g_HealthState = HEALTH_RED;    g_HealthReason = "multi_stale"; }
   else if(failCount == 2) { g_HealthState = HEALTH_YELLOW; g_HealthReason = "dual_stale"; }
   else if(failCount == 1) { g_HealthState = HEALTH_YELLOW; g_HealthReason = "single_stale"; }
   else                    { g_HealthState = HEALTH_GREEN;  g_HealthReason = "healthy"; }

   //--- [A4] Log which stream(s) are stale (once per 60s) ---------------
   static datetime lastHealthLog = 0;
   if(g_HealthState != HEALTH_GREEN && TimeCurrent() - lastHealthLog >= 60)
     {
      lastHealthLog = TimeCurrent();
      string stale = "";
      for(int i = 0; i < g_HealthCount; i++)
        {
         int age = (g_Health[i].lastUpdate == 0)
                   ? 99999
                   : (int)(now - g_Health[i].lastUpdate);
         if(age > g_Health[i].maxAgeSec)
            stale += g_Health[i].name
                   + "(age=" + IntegerToString(age)
                   + "/max=" + IntegerToString(g_Health[i].maxAgeSec) + ") ";
        }
      PrintFormat("[HEALTH-%d] stale: %s", (int)g_HealthState, stale);
     }

   return g_HealthState;
  }

bool Health_AllowsNewEntries()
  {
   if(MQLInfoInteger(MQL_TESTER)) return true;
   double bid=BidPrice(), ask=AskPrice();
   if(bid<=0.0 || ask<=0.0 || ask<bid) return false; // broker price feed is mandatory
   // Missing Factor-A auxiliary data does not disable Factor-B technical decisions.
   if(UseFactorBPrimaryDecisionV2) return true;
   if(!UseFactorBFallback) return (g_HealthState <= HEALTH_YELLOW);
   if(ActiveFactor() == FACTOR_B_FALLBACK) return true;
   return (g_HealthState <= HEALTH_YELLOW);
  }

double Health_SizeMult()
  {
   // Factor-A flow/auxiliary health is confirmatory; do not zero lots for a missing bridge.
   // Invalid broker quotes are blocked by Health_AllowsNewEntries and sender preflight.
   if(UseFactorBPrimaryDecisionV2) return 1.0;
   switch(g_HealthState)
     {
      case HEALTH_GREEN:  return 1.00;
      case HEALTH_YELLOW: return 0.50;
      default:            return 0.00;
     }
  }

//===================================================================
// SECTION 15 — LOT NORMALIZATION & ACCOUNT MODE
//===================================================================
void RefreshLotMeta()
  {
   g_LotMin = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   g_LotMax = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   g_LotStep= SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   if(g_LotMin <= 0.0) g_LotMin = 0.01;
   if(g_LotMax <= 0.0) g_LotMax = 100.0;
   if(g_LotStep<= 0.0) g_LotStep= 0.01;

   if(g_LotStep < 0.001)     g_LotDigits = 4;
   else if(g_LotStep < 0.01) g_LotDigits = 3;
   else                       g_LotDigits = 2;
  }

double NormalizeLots(double lots)
  {
   if(lots <= 0.0) return 0.0;
   double steps = MathFloor(lots / g_LotStep + 1e-9);
   lots = steps * g_LotStep;
   lots = NormalizeDouble(lots, g_LotDigits);
   if(lots < g_LotMin) return 0.0;
   if(lots > g_LotMax) lots = g_LotMax;
   return lots;
  }

double CapPerOrder()
  {
   double b = AccountInfoDouble(ACCOUNT_BALANCE);
   if(b <= 0.0) return g_LotMin;
   double c = b / CapPerOrderDivisor;
   if(c < CapPerOrderMin) c = CapPerOrderMin;
   if(c > CapPerOrderMax) c = CapPerOrderMax;
   return c;
  }

double CapTotalLots()
  {
   double b = AccountInfoDouble(ACCOUNT_BALANCE);
   if(b <= 0.0) return g_LotMin;
   double c = b / CapTotalLots_Divisor;
   if(c < g_LotMin) c = g_LotMin;
   if(c > CapTotalLots_Max) c = CapTotalLots_Max;
   return c;
  }

double ValidateLot(double lot)
  {
   // V2: never silently round an unaffordable requested size up to broker minimum.
   if(lot <= 0.0) return 0.0;
   double em = CapPerOrder();
   if(g_LotMax < em) em = g_LotMax;
   if(em < g_LotMin || lot < g_LotMin - 1e-10) return 0.0;

   if(lot > em) lot = em;
   double steps = MathFloor(lot / g_LotStep + 1e-9);
   lot = NormalizeDouble(steps * g_LotStep, g_LotDigits);
   if(lot > g_LotMax) lot = g_LotMax;
   if(lot < g_LotMin - 1e-10) return 0.0;
   return lot;
  }

bool IsCentAccount()
  {
   string cur = AccountInfoString(ACCOUNT_CURRENCY);
   int len = StringLen(cur);
   if(len <= 0) return false;
   ushort last = StringGetCharacter(cur, len - 1);
   return (last == 'c' || last == 'C');
  }

string AccountModeLabel()
  {
   if(g_ResolvedMode == ACC_CENT)   return "CENT";
   if(g_ResolvedMode == ACC_DOLLAR) return "DOLLAR";
   return "?";
  }

//===================================================================
// SECTION 16 — SPREAD
//===================================================================
void UpdateSpread()
  {
   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0 || ask < bid) return;

   CurrentSpreadPoints = (ask - bid) / _Point;
   SpreadHistory[SpreadIndex % 60] = CurrentSpreadPoints;
   SpreadIndex++;
   if(SpreadCount < 60) SpreadCount++;

   double sum = 0.0;
   for(int i = 0; i < SpreadCount; i++) sum += SpreadHistory[i];
   SpreadAveragePoints = (SpreadCount > 0)
                         ? sum / (double)SpreadCount
                         : CurrentSpreadPoints;
  }

bool SpreadOK()
  {
   return (CurrentSpreadPoints < HardMaxSpreadPoints);
  }

double SpreadThrottle()
  {
   if(CurrentSpreadPoints <= SoftSpreadPoints)          return 1.00;
   if(CurrentSpreadPoints <= SoftSpreadPoints * 1.5)    return 0.85;
   if(CurrentSpreadPoints <= SoftSpreadPoints * 2.0)    return 0.55;
   if(CurrentSpreadPoints <= HardMaxSpreadPoints)       return 0.30;
   return 0.0;
  }

//===================================================================
// SECTION 17 — WICK PROTECTION
//===================================================================
void UpdateWickProtection()
  {
   if(!UseWickPause || CurrentATR1 <= 0.0) return;
   double range = TfHigh(PERIOD_M1, 1) - TfLow(PERIOD_M1, 1);
   if(range > CurrentATR1 * ViolentCandleMult)
      LastViolentCandle = TimeCurrent();
  }

bool WickPauseActive()
  {
   if(!UseWickPause || LastViolentCandle == 0) return false;
   return (TimeCurrent() - LastViolentCandle < PostWickPauseSec);
  }

//===================================================================
// SECTION 18 — SESSION / HOUR FILTERS
//===================================================================
bool SessionAllowed()
  {
   if(!AvoidRollover && !UseSessionVeto) return true;
   MqlDateTime dt;
   TimeToStruct(TimeGMT(), dt);
   if(AvoidRollover && (dt.hour == 23 || dt.hour < 1)) return false;
   return true;
  }

bool HourFilterOK()
  {
   if(!UseSessionVeto) return true;
   MqlDateTime dt;
   TimeToStruct(TimeGMT(), dt);
   if(dt.hour >= VetoSkipHour1Start && dt.hour < VetoSkipHour1End) return false;
   if(dt.hour >= VetoSkipHour2Start && dt.hour < VetoSkipHour2End) return false;
   return true;
  }

bool ChaosTriggered()
  {
   if(NormalATR15 <= 0.0 || CurrentATR15 <= 0.0) return false;
   return (CurrentATR15 / NormalATR15 >= M15VetoATRChaosMult);
  }

//===================================================================
// SECTION 19 — SESSION SCORE (Tier 2)
//===================================================================
double SessionSizeMult()
  {
   if(!UseSessionScoreV2) return 1.0;
   MqlDateTime dt;
   TimeToStruct(TimeGMT(), dt);
   int h = dt.hour;
   if(h >= SessionPrimeStartUTC && h < SessionPrimeEndUTC) return SessionPrimeBoost;
   return SessionOffWindowCut;
  }

//===================================================================
// SECTION 20 — RECOVERY STATE HELPERS (Tier 4)
//===================================================================
void Recovery_Reset()
  {
   g_RecoveryAccumulated = 0.0;
   g_RecoveryStreak      = 0;
  }

void Recovery_RegisterLoss(double lossUSD)
  {
   if(!UseRecoveryModeV2) return;
   g_RecoveryAccumulated += MathAbs(lossUSD);
   g_RecoveryStreak++;
   if(g_RecoveryStreak >= RecoveryMaxStreak)
      Recovery_Reset();
  }

void Recovery_RegisterWin()
  {
   if(!UseRecoveryModeV2) return;
   if(RecoveryResetOnAnyWin) Recovery_Reset();
  }

double Recovery_RiskUSD(double baseRiskUSD)
  {
   if(!UseRecoveryModeV2) return baseRiskUSD;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   double cap = eq * RecoveryMaxRiskPctEquity / 100.0;
   double want = g_RecoveryAccumulated + RecoveryTargetUSD;
   if(want <= 0.0) want = baseRiskUSD;
   return MathMin(want, cap);
  }

//===================================================================
// SECTION 21 — MESSAGE BUDGET TICK HELPERS (Tier 3 — legacy compat)
//===================================================================
void MsgBudget_TickOpen()
  {
   g_DailyOpens++;
   MsgBudget_Count(1);
  }

void MsgBudget_TickModify()
  {
   g_DailyModifies++;
   MsgBudget_Count(1);
  }

void MsgBudget_TickDelete()
  {
   g_DailyDeletes++;
   MsgBudget_Count(1);
  }

bool MsgBudget_CanTrade()
  {
   return MsgBudget_CanSend();
  }

void MsgBudget_DailyReset()
  {
   int today = (int)(TimeCurrent() / 86400);
   if(today == g_MsgBudgetResetDay) return;
   g_MsgBudgetResetDay   = today;
   g_DailyOpens          = 0;
   g_DailyModifies       = 0;
   g_DailyDeletes        = 0;
   g_MsgBudgetCount      = 0;
   g_MsgBudgetWarnCount  = 0;
  }

//===================================================================
// SECTION 22 — SLIPPAGE ANCHOR MAP (Tier 3)
//===================================================================
void Anchor_Store(string cmt, double reqEntry, double reqSL, double reqTP)
  {
   if(g_AnchorCount >= 200)
     {
      for(int i = 0; i < 199; i++) g_AnchorMap[i] = g_AnchorMap[i + 1];
      g_AnchorCount = 199;
     }
   g_AnchorMap[g_AnchorCount].comment        = cmt;
   g_AnchorMap[g_AnchorCount].requestedEntry = reqEntry;
   g_AnchorMap[g_AnchorCount].requestedSL    = reqSL;
   g_AnchorMap[g_AnchorCount].requestedTP    = reqTP;
   g_AnchorMap[g_AnchorCount].t              = TimeCurrent();
   g_AnchorCount++;
  }

int Anchor_Find(string cmt)
  {
   for(int i = g_AnchorCount - 1; i >= 0; i--)
     {
      if(g_AnchorMap[i].comment == cmt) return i;
      if(TimeCurrent() - g_AnchorMap[i].t > 600) return -1; // 10 min expiry
     }
   return -1;
  }

//===================================================================
// SECTION 23 — BRIDGE POLLING (LIVE) — FLOW
//===================================================================
void ResetFlowState()
  {
   gFlow.valid=false; gFlow.healthy=false; gFlow.local_update=0;
   gFlow.price=0.0; gFlow.flow_score=0.0; gFlow.buy_pct=0.0; gFlow.sell_pct=0.0;
   gFlow.d5=0.0; gFlow.d15=0.0; gFlow.cvd=0.0; gFlow.book=0.0; gFlow.depth=0.0;
   gFlow.trade_rate=0.0; gFlow.buy_rate=0.0; gFlow.sell_rate=0.0;
   gFlow.spread_bps=0.0; gFlow.persistence=0.0; gFlow.velocity=0.0;
   gFlow.acceleration=0.0; gFlow.ofi=0.0; gFlow.persistence_count=0; gFlow.action="";
  }

void ParseFlowJSON(const string json)
  {
   gFlow.valid   = true;
   gFlow.healthy = JsonBool(json, "ok", true);
   gFlow.price = JsonNumber(json, "price", JsonNumber(json, "btc", 0.0));
   gFlow.flow_score = JsonNumber(json, "flow_score", JsonNumber(json, "flow", 0.0));
   gFlow.buy_pct = JsonNumber(json, "buy_pct", JsonNumber(json, "buy", 0.0));
   gFlow.sell_pct = JsonNumber(json, "sell_pct", JsonNumber(json, "sell", 0.0));
   gFlow.d5  = JsonNumber(json, "delta_5s",  JsonNumber(json, "d5", 0.0));
   gFlow.d15 = JsonNumber(json, "delta_15s", JsonNumber(json, "d15", 0.0));
   gFlow.cvd = JsonNumber(json, "cvd", 0.0);
   gFlow.book  = JsonNumber(json, "book_imbalance",  JsonNumber(json, "book", 0.0));
   gFlow.depth = JsonNumber(json, "depth_imbalance", JsonNumber(json, "depth", 0.0));
   gFlow.trade_rate = JsonNumber(json, "trade_rate",
                        JsonNumber(json, "trades_per_sec",
                        JsonNumber(json, "tps", 0.0)));
   gFlow.buy_rate  = JsonNumber(json, "buy_rate",  JsonNumber(json, "buy_per_sec", 0.0));
   gFlow.sell_rate = JsonNumber(json, "sell_rate", JsonNumber(json, "sell_per_sec", 0.0));
   gFlow.spread_bps = JsonNumber(json, "spread_bps", 0.0);
   gFlow.persistence = JsonNumber(json, "flow_persistence",
                        JsonNumber(json, "persistence", 0.0));
   gFlow.velocity = JsonNumber(json, "price_velocity",
                     JsonNumber(json, "velocity", 0.0));
   gFlow.acceleration = JsonNumber(json, "price_acceleration",
                         JsonNumber(json, "acceleration", 0.0));
   gFlow.persistence_count = (int)JsonNumber(json, "flow_persistence_count",
                                 JsonNumber(json, "persistence_count", 0.0));
   gFlow.ofi = JsonNumber(json, "ofi", 0.0);
   gFlow.action = JsonString(json, "action", "");
   gFlow.local_update = TimeCurrent();
  }

void PollBinanceFlow()
  {
   if(!UseBinanceFlow) { ResetFlowState(); return; }
   if(MQLInfoInteger(MQL_TESTER)) { ResetFlowState(); return; }
   if(TimeCurrent() - LastFlowPoll < BinancePollSeconds) return;
   LastFlowPoll = TimeCurrent();

   string sig="";
   if(!HttpGet(BinanceBaseURL + "/signal", sig))
     { gFlow.valid=false; gFlow.healthy=false; return; }
   ParseFlowJSON(sig);
   Health_Tick("flow");

   // Optional state endpoint enrichment
   string state="";
   if(HttpGet(BinanceBaseURL + "/state", state))
     {
      if(gFlow.cvd==0.0)        gFlow.cvd        = JsonNumber(state, "cvd", 0.0);
      if(gFlow.price==0.0)      gFlow.price      = JsonNumber(state, "price", 0.0);
      if(gFlow.trade_rate==0.0) gFlow.trade_rate = JsonNumber(state, "trade_rate", 0.0);
     }

   datetime now = TimeCurrent();
   if(PreviousCVDTime > 0 && now > PreviousCVDTime)
     {
      double dt = (double)(now - PreviousCVDTime);
      LocalCVDVelocity = (gFlow.cvd - PreviousCVD) / dt;
      if(PreviousCVDVelocity != 0.0)
         LocalCVDAcceleration = (LocalCVDVelocity - PreviousCVDVelocity) / dt;
      else
         LocalCVDAcceleration = 0.0;
      double scale = MathMax(1.0, MathAbs(gFlow.d15) / 15.0);
      CVDVelocityNormalized     = Clamp(LocalCVDVelocity     / scale, -3.0, 3.0) / 3.0;
      CVDAccelerationNormalized = Clamp(LocalCVDAcceleration / scale, -3.0, 3.0) / 3.0;
     }
   PreviousCVD = gFlow.cvd;
   PreviousCVDVelocity = LocalCVDVelocity;
   PreviousCVDTime = now;
   gFlow.velocity = LocalCVDVelocity;
   gFlow.acceleration = LocalCVDAcceleration;

   FlowRateHistory[FlowRateIndex % 60] = gFlow.trade_rate;
   FlowRateIndex++;
   if(FlowRateCount < 60) FlowRateCount++;

   if(VerboseFlow)
      PrintFormat("[FLOW] ok=%d price=%.2f flow=%.1f CVDv=%.3f CVDa=%.3f persist=%.2f",
                  (int)gFlow.healthy, gFlow.price, gFlow.flow_score,
                  CVDVelocityNormalized, CVDAccelerationNormalized, gFlow.persistence);
  }

//===================================================================
// SECTION 24 — BRIDGE POLLING — VOLUME PROFILE (bridge-fed)
//===================================================================
void PollBinanceVP()
  {
   if(!UseBinanceFlow || MQLInfoInteger(MQL_TESTER)) return;
   if(TimeCurrent() - LastVPPoll < 5) return;
   LastVPPoll = TimeCurrent();

   string body="";
   if(!HttpGet(BinanceBaseURL + "/vp", body)) { gBinVP.valid=false; return; }

   gBinVP.poc       = JsonNumber(body, "poc", 0.0);
   gBinVP.vah       = JsonNumber(body, "vah", 0.0);
   gBinVP.val       = JsonNumber(body, "val", 0.0);
   gBinVP.width_pct = JsonNumber(body, "width_pct", 0.0);
   gBinVP.min_p     = JsonNumber(body, "min_p", 0.0);
   gBinVP.max_p     = JsonNumber(body, "max_p", 0.0);
   gBinVP.valid     = (gBinVP.poc > 0.0 && gBinVP.vah > gBinVP.val);
   gBinVP.local_update = TimeCurrent();
   if(gBinVP.valid) Health_Tick("vp");
  }

//===================================================================
// SECTION 25 — ADVANCED FLOW PARSER
//===================================================================
void VNParseAdvancedFlowJSON(const string json)
  {
   if(json == "") return;
   gBinAux.long_short_ratio = JsonNumber(json, "long_short_ratio",
                              JsonNumber(json, "ls_ratio", gBinAux.long_short_ratio));
   double lb = JsonNumber(json, "liquidation_buy",
                JsonNumber(json, "liq_buy",  gBinAux.liquidation_buy));
   double ls = JsonNumber(json, "liquidation_sell",
                JsonNumber(json, "liq_sell", gBinAux.liquidation_sell));
   gBinAux.liquidation_buy  = lb;
   gBinAux.liquidation_sell = ls;
   double denom = MathAbs(lb) + MathAbs(ls);
   if(denom > 0.0) gBinAux.liquidation_imbalance = (lb - ls) / denom;
   else            gBinAux.liquidation_imbalance = 0.0;
  }

//===================================================================
// SECTION 26 — BRIDGE POLLING — AUX (vroc / vwap / walls / funding)
//===================================================================
void PollBinanceAux()
  {
   if(!UseBinanceFlow || MQLInfoInteger(MQL_TESTER)) return;
   if(TimeCurrent() - LastAuxPoll < BridgeAuxPollSeconds) return;
   LastAuxPoll = TimeCurrent();

   string b="";

   if(HttpGet(BinanceBaseURL + "/vroc", b))
     {
      gBinAux.vroc           = JsonNumber(b, "vroc", 0.0);
      gBinAux.range_exp      = JsonNumber(b, "range_exp", 0.0);
      gBinAux.atr_m1         = JsonNumber(b, "atr_m1", 0.0);
      gBinAux.vroc_sustained = JsonBool  (b, "vroc_sustained", false);
      Health_Tick("vroc");
     }

   if(HttpGet(BinanceBaseURL + "/vwap", b))
     {
      gBinAux.vwap       = JsonNumber(b, "vwap", 0.0);
      gBinAux.vwap_slope = JsonNumber(b, "slope", 0.0);
     }

   if(HttpGet(BinanceBaseURL + "/walls", b))
     {
      gBinAux.bid_wall_price = JsonNumber(b, "bid_wall_price", 0.0);
      gBinAux.bid_wall_size  = JsonNumber(b, "bid_wall_size", 0.0);
      gBinAux.ask_wall_price = JsonNumber(b, "ask_wall_price", 0.0);
      gBinAux.ask_wall_size  = JsonNumber(b, "ask_wall_size", 0.0);
      Health_Tick("walls");
     }

   if(HttpGet(BinanceBaseURL + "/funding", b))
     {
      gBinAux.funding     = JsonNumber(b, "funding", 0.0);
      gBinAux.oi          = JsonNumber(b, "oi", 0.0);
      gBinAux.oi_delta_1m = JsonNumber(b, "oi_delta_1m", 0.0);
      VNParseAdvancedFlowJSON(b);
      Health_Tick("funding");
     }

   if(HttpGet(BinanceBaseURL + "/futures", b))
      VNParseAdvancedFlowJSON(b);

   if(HttpGet(BinanceBaseURL + "/liquidations", b))
      VNParseAdvancedFlowJSON(b);

   gBinAux.valid = (gBinAux.vroc > 0.0 || gBinAux.vwap > 0.0);
   gBinAux.local_update = TimeCurrent();
  }

//===================================================================
// SECTION 27 — BRIDGE POLLING — VPIN / OI REGIME / NAKED POC / VWAP-Z
//===================================================================
void PollBinanceVPIN()
  {
   if(!UseBinanceFlow || MQLInfoInteger(MQL_TESTER)) return;
   if(TimeCurrent() - LastVPINPoll < BridgeVPINPollSeconds) return;
   LastVPINPoll = TimeCurrent();

   string b="";

   if(HttpGet(BinanceBaseURL + "/vpin", b))
     {
      gBinAux.vpin          = JsonNumber(b, "vpin", 0.0);
      gBinAux.vpin_pct      = JsonNumber(b, "vpin_pct", 0.0);
      gBinAux.vpin_pressure = JsonNumber(b, "pressure", 50.0);
      string regime = JsonString(b, "regime", "Quiet");
      if(regime=="Burst")         gBinAux.vpin_regime=3;
      else if(regime=="Elevated") gBinAux.vpin_regime=2;
      else if(regime=="Normal")   gBinAux.vpin_regime=1;
      else                         gBinAux.vpin_regime=0;
      Health_Tick("vpin");
     }

   if(HttpGet(BinanceBaseURL + "/oiregime", b))
     {
      string regime = JsonString(b, "regime", "NEUTRAL");
      if(regime=="NEW_LONGS")             gBinAux.oi_regime=1;
      else if(regime=="SHORT_COVERING")   gBinAux.oi_regime=2;
      else if(regime=="NEW_SHORTS")       gBinAux.oi_regime=3;
      else if(regime=="LONG_LIQUIDATION") gBinAux.oi_regime=4;
      else                                 gBinAux.oi_regime=0;
     }

   if(HttpGet(BinanceBaseURL + "/nakedpoc", b))
     {
      gBinAux.naked_above = JsonNumber(b, "nearest_above", 0.0);
      gBinAux.naked_below = JsonNumber(b, "nearest_below", 0.0);
      gBinAux.naked_count = (int)JsonNumber(b, "count", 0.0);
     }

   if(HttpGet(BinanceBaseURL + "/vwapz", b))
     {
      gBinAux.rolling_vwap   = JsonNumber(b, "vwap", 0.0);
      gBinAux.vwap_stdev     = JsonNumber(b, "stdev", 0.0);
      gBinAux.vwap_z         = JsonNumber(b, "z", 0.0);
      gBinAux.vwap_exhausted = JsonBool  (b, "exhausted", false);
      Health_Tick("vwapz");
     }
  }

//===================================================================
// SECTION 28 — FLOW COMPOSITE / FRESHNESS / GATES
//===================================================================
bool FlowFresh()
  {
   if(!UseBinanceFlow) return true;
   if(MQLInfoInteger(MQL_TESTER)) return true;
   if(!gFlow.valid || !gFlow.healthy) return false;
   if(gFlow.local_update == 0) return false;
   return (TimeCurrent() - gFlow.local_update <= BinanceMaxAgeSeconds);
  }

bool BridgeReady()
  {
   if(MQLInfoInteger(MQL_TESTER))    return false;
   if(!UseBinanceFlow)                return false;
   if(!gBinAux.valid)                 return false;
   if(!FlowFresh())                   return false;
   if(g_HealthState > HEALTH_YELLOW)  return false;
   return true;
  }

double FlowComposite()
  {
   if(!gFlow.valid) return 0.0;
   double bridge = gFlow.flow_score;
   double book   = gFlow.book  * 100.0;
   double depth  = gFlow.depth * 100.0;
   double cvd    = CVDVelocityNormalized * 100.0;
   const double wB = 0.60, wK = 0.15, wD = 0.15, wC = 0.10;
   double denom = wB + wK + wD + wC;
   double result = (bridge*wB + book*wK + depth*wD + cvd*wC) / denom;
   result += CVDAccelerationNormalized * 5.0;
   return Clamp(result, -100.0, 100.0);
  }

int FlowDirection()
  {
   double score = FlowComposite();
   if(score >=  BinanceMinFlowScore) return  1;
   if(score <= -BinanceMinFlowScore) return -1;
   return 0;
  }

bool Flow_Agrees(int dir, bool strong)
  {
   if(!UseBinanceFlow || FlowMode == FLOW_OFF) return true;
   if(MQLInfoInteger(MQL_TESTER)) return true;
   if(!FlowFresh()) return true; // Factor B can still decide from native structure
   double fc = FlowComposite() * (double)dir;
   double threshold = strong ? BinanceStrongFlowScore : BinanceMinFlowScore;
   bool supports = (fc >= threshold && gFlow.persistence >= BinanceMinPersistence);
   if(supports) return true;
   if(UseFactorBPrimaryDecisionV2 && !UseFactorAAsHardVetoV2)
     {
      // Non-confirmation is logged/scored upstream; it is not a primary veto.
      return true;
     }
   if(FlowMode == FLOW_CONFIRM && fc > -BinanceStrongFlowScore) return true;
   if(FlowMode == FLOW_VETO) return true;
   return false;
  }

bool FactorAFlowConfirms(int dir, bool strong)
  {
   // Only genuine fresh bridge support earns a confirmation bonus. Missing/neutral data is not a vote.
   if(dir==0 || !UseBinanceFlow || FlowMode==FLOW_OFF) return false;
   if(MQLInfoInteger(MQL_TESTER) || !FlowFresh()) return false;
   double fc=FlowComposite()*(double)dir;
   double threshold=strong ? BinanceStrongFlowScore : BinanceMinFlowScore;
   return (fc>=threshold && gFlow.persistence>=BinanceMinPersistence);
  }

bool Flow_NotOpposed(int dir)
  {
   if(!UseBinanceFlow || FlowMode == FLOW_OFF) return true;
   if(MQLInfoInteger(MQL_TESTER)) return true;
   if(!FlowFresh()) return true;
   double fc = FlowComposite() * (double)dir;
   if(UseFactorBPrimaryDecisionV2 && !UseFactorAAsHardVetoV2)
     {
      if(fc <= -BinanceStrongFlowScore && gFlow.persistence >= BinanceMinPersistence)
         PrintFormat("[FACTOR-A CONFLICT] dir=%d flow=%.1f persistence=%.2f; Factor B retains direction ownership",dir,fc,gFlow.persistence);
      return true;
     }
   return (fc > -BinanceStrongFlowScore);
  }

bool FlowVetoes(int dir)
  {
   if(UseFactorBPrimaryDecisionV2 && !UseFactorAAsHardVetoV2) return false;
   if(!UseBinanceFlow || FlowMode == FLOW_OFF) return false;
   if(MQLInfoInteger(MQL_TESTER)) return false;
   if(!FlowFresh()) return false;
   return (FlowComposite() * (double)dir <= -55.0);
  }

double AverageFlowTradeRate()
  {
   if(FlowRateCount <= 0) return 0.0;
   double sum = 0.0;
   for(int i = 0; i < FlowRateCount; i++) sum += FlowRateHistory[i];
   return sum / (double)FlowRateCount;
  }

bool VNFlowTradeRateSurge()
  {
   if(!FlowFresh()) return false;
   if(gFlow.trade_rate <= 0.0 || FlowRateCount < 10) return false;
   double avg = AverageFlowTradeRate();
   if(avg <= 0.0) return false;
   return (gFlow.trade_rate >= avg * 1.40);
  }

bool VNFlowCVDAccelerationStrong(int dir)
  {
   if(!FlowFresh() || dir == 0) return false;
   return (CVDAccelerationNormalized * (double)dir >= 0.20);
  }

bool VNFlowCascade(int dir)
  {
   if(!BridgeReady() || dir == 0) return false;
   double liq = gBinAux.liquidation_imbalance * (double)dir;
   if(MathAbs(gBinAux.liquidation_imbalance) > 0.0 && liq > 0.25) return true;
   if(gBinAux.vpin_regime >= 3 && VNFlowTradeRateSurge()) return true;
   return false;
  }

bool WallInPath(int dir)
  {
   if(!BridgeReady()) return false;
   double mid = MidPrice();
   if(mid <= 0.0) return false;
   if(dir ==  1 && gBinAux.ask_wall_price > 0.0)
     {
      double d = (gBinAux.ask_wall_price - mid) / _Point;
      if(d > 0.0 && d < 150.0) return true;
     }
   if(dir == -1 && gBinAux.bid_wall_price > 0.0)
     {
      double d = (mid - gBinAux.bid_wall_price) / _Point;
      if(d > 0.0 && d < 150.0) return true;
     }
   return false;
  }

//===================================================================
// SECTION 29 — VWAP HELPERS (bridge + internal fallback)
//===================================================================
double GetVWAPZ()
  {
   if(gBinAux.valid && gBinAux.rolling_vwap > 0.0) return gBinAux.vwap_z;
   return g_InternalVWAPZ;
  }

double GetVWAPValue()
  {
   if(gBinAux.valid && gBinAux.rolling_vwap > 0.0) return gBinAux.rolling_vwap;
   return g_InternalVWAP;
  }

bool GetVWAPExhausted()
  {
   if(gBinAux.valid && gBinAux.rolling_vwap > 0.0) return gBinAux.vwap_exhausted;
   return g_InternalExhaust;
  }

//===================================================================
// SECTION 30 — VOLUME PROFILE HELPERS
//===================================================================
bool VPCompressed()
  {
   if(gBinVP.valid) return (gBinVP.width_pct < VP_CompressMaxPct);
   if(g_NVP.valid)  return (g_NVP.vaWidthPct < VP_CompressMaxPct);
   return false;
  }

bool VPPriceInVA()
  {
   double mid = MidPrice();
   if(mid <= 0.0) return false;
   if(gBinVP.valid) return (mid >= gBinVP.val && mid <= gBinVP.vah);
   if(g_NVP.valid)  return (mid >= g_NVP.val && mid <= g_NVP.vah);
   return false;
  }

double VPPositionInVA()
  {
   double mid = MidPrice();
   if(mid <= 0.0) return -1.0;
   if(gBinVP.valid)
     {
      double width = gBinVP.vah - gBinVP.val;
      if(width <= 0.0) return -1.0;
      return (mid - gBinVP.val) / width;
     }
   if(g_NVP.valid)
     {
      double width = g_NVP.vah - g_NVP.val;
      if(width <= 0.0) return -1.0;
      return (mid - g_NVP.val) / width;
     }
   return -1.0;
  }

//===================================================================
// SECTION 31 — FUNDING / OI / LS HELPERS
//===================================================================
int FundingBias()
  {
   if(!gBinAux.valid) return 0;
   if(gBinAux.funding >  0.0005) return -1;
   if(gBinAux.funding < -0.0005) return  1;
   return 0;
  }

bool NearNakedPOC(int dir)
  {
   if(!gBinAux.valid) return false;
   if(gBinAux.naked_count <= 0) return false;
   double mid = MidPrice();
   if(mid <= 0.0) return false;
   double atr = CurrentATR5;
   if(atr <= 0.0) atr = CurrentATR1;
   if(atr <= 0.0) return false;
   double threshold = atr * 0.3;

   if(dir == 1 && gBinAux.naked_below > 0.0)
      if(mid - gBinAux.naked_below <= threshold &&
         mid >= gBinAux.naked_below) return true;

   if(dir == -1 && gBinAux.naked_above > 0.0)
      if(gBinAux.naked_above - mid <= threshold &&
         mid <= gBinAux.naked_above) return true;

   return false;
  }

//===================================================================
// SECTION 32 — NATIVE VOLUME PROFILE (200-bar M1 build)
//===================================================================
void BuildNativeVP()
  {
   g_NVP.valid = false;
   int bins = MathMin(VP_Bins, 40);
   if(Bars(_Symbol, PERIOD_M1) < VP_LookbackBars + 10) return;

   double high = -1e18, low = 1e18;
   for(int i = 0; i < VP_LookbackBars; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      if(h <= 0.0 || l <= 0.0) continue;
      if(h > high) high = h;
      if(l < low)  low  = l;
     }
   if(high <= low) return;

   g_NVP.minP = low;
   g_NVP.maxP = high;
   g_NVP.binSize = (high - low) / (double)bins;
   for(int i = 0; i < bins; i++) g_NVP.bins[i] = 0.0;
   g_NVP.totalVol = 0.0;

   for(int i = 0; i < VP_LookbackBars; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      double v = (double)TfVolume(PERIOD_M1, i);
      if(h <= l || v <= 0.0) continue;
      double barRange = h - l;
      for(int b = 0; b < bins; b++)
        {
         double binLo = g_NVP.minP + b * g_NVP.binSize;
         double binHi = binLo + g_NVP.binSize;
         double ovl   = MathMin(h, binHi) - MathMax(l, binLo);
         if(ovl > 0.0) g_NVP.bins[b] += v * (ovl / barRange);
        }
     }

   double maxVol = 0.0;
   int pocIdx = 0;
   for(int i = 0; i < bins; i++)
     {
      g_NVP.totalVol += g_NVP.bins[i];
      if(g_NVP.bins[i] > maxVol) { maxVol = g_NVP.bins[i]; pocIdx = i; }
     }
   if(g_NVP.totalVol <= 0.0) return;
   g_NVP.poc = g_NVP.minP + (pocIdx + 0.5) * g_NVP.binSize;

   double target = g_NVP.totalVol * VP_ValueAreaPct / 100.0;
   int left = pocIdx, right = pocIdx;
   double cum = g_NVP.bins[pocIdx];
   while(cum < target && (left > 0 || right < bins - 1))
     {
      double lv = (left  > 0)        ? g_NVP.bins[left - 1]  : -1.0;
      double rv = (right < bins - 1) ? g_NVP.bins[right + 1] : -1.0;
      if(rv >= lv && right < bins - 1) { right++; cum += g_NVP.bins[right]; }
      else if(left > 0)                 { left--;  cum += g_NVP.bins[left]; }
      else break;
     }
   g_NVP.val = g_NVP.minP + left * g_NVP.binSize;
   g_NVP.vah = g_NVP.minP + (right + 1) * g_NVP.binSize;
   if(g_NVP.poc > 0.0) g_NVP.vaWidthPct = (g_NVP.vah - g_NVP.val) / g_NVP.poc * 100.0;
   else                g_NVP.vaWidthPct = 100.0;
   g_NVP.valid = true;
  }

bool NativeVPPriceInVA()
  {
   if(!g_NVP.valid) return false;
   double m = MidPrice();
   return (m >= g_NVP.val && m <= g_NVP.vah);
  }

bool NativeVPCompressed()
  {
   if(!g_NVP.valid) return false;
   return (g_NVP.vaWidthPct < VP_CompressMaxPct);
  }

double NativeVPPositionInVA()
  {
   if(!g_NVP.valid) return -1.0;
   double width = g_NVP.vah - g_NVP.val;
   if(width <= 0.0) return -1.0;
   return (MidPrice() - g_NVP.val) / width;
  }

//===================================================================
// SECTION 33 — INTERNAL VWAP-Z (fallback when bridge silent)
//===================================================================
void ComputeInternalVWAPZ()
  {
   datetime nowBar = TfTime(PERIOD_M1, 0);
   if(nowBar == 0 || nowBar == g_InternalVWAPTime) return;
   g_InternalVWAPTime = nowBar;
   if(Bars(_Symbol, PERIOD_M1) < 80) return;

   double pv=0.0, volSum=0.0;
   double typicals[60];
   for(int i = 0; i < 60; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      double c = TfClose(PERIOD_M1, i);
      long   v = TfVolume(PERIOD_M1, i);
      if(h<=0.0||l<=0.0||c<=0.0||v<=0) return;
      double t = (h + l + c) / 3.0;
      typicals[i] = t;
      pv += t * (double)v;
      volSum += (double)v;
     }
   if(volSum <= 0.0) return;
   double vwap = pv / volSum;

   double varSum = 0.0;
   for(int i = 0; i < 60; i++)
     {
      long v = TfVolume(PERIOD_M1, i);
      double diff = typicals[i] - vwap;
      varSum += diff * diff * (double)v;
     }
   double variance = varSum / volSum;
   double sd = (variance > 0.0) ? MathSqrt(variance) : 0.0;

   double price = MidPrice();
   if(price <= 0.0) return;
   double z = (sd > 0.0) ? (price - vwap) / sd : 0.0;

   double avgVol = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      long v = TfVolume(PERIOD_M1, i);
      if(v > 0) { avgVol += (double)v; cnt++; }
     }
   if(cnt > 0) avgVol /= (double)cnt;
   long curVol = TfVolume(PERIOD_M1, 0);
   bool exhausted = (avgVol > 0.0 && (double)curVol < avgVol * 0.5);

   g_InternalVWAP    = vwap;
   g_InternalVWAPSD  = sd;
   g_InternalVWAPZ   = z;
   g_InternalExhaust = exhausted;
  }

//===================================================================
// SECTION 34 — M5 VWAP + KAMA + OBV + VOL SURGE + JERK
//===================================================================
void CalculateVWAP()
  {
   if(!UseVWAP) return;
   double pv=0.0, pv2=0.0, vol=0.0;
   for(int i = 0; i < VWAP_Lookback; i++)
     {
      double h = TfHigh(PERIOD_M5, i);
      double l = TfLow(PERIOD_M5, i);
      double c = TfClose(PERIOD_M5, i);
      double v = (double)TfVolume(PERIOD_M5, i);
      if(h <= 0.0 || l <= 0.0 || c <= 0.0 || v <= 0.0) continue;
      double typical = (h + l + c) / 3.0;
      pv  += typical * v;
      pv2 += typical * typical * v;
      vol += v;
     }
   if(vol <= 0.0) return;
   VWAP_Value = pv / vol;
   double variance = MathMax(0.0, pv2 / vol - VWAP_Value * VWAP_Value);
   double stdev = MathSqrt(variance);
   VWAP_Upper = VWAP_Value + VWAP_Stdev_Entry * stdev;
   VWAP_Lower = VWAP_Value - VWAP_Stdev_Entry * stdev;
  }

int GetVWAPBias()
  {
   if(!UseVWAP) return 0;
   CalculateVWAP();
   double price = MidPrice();
   if(VWAP_Upper <= 0.0 || VWAP_Lower <= 0.0) return 0;
   if(price > VWAP_Upper) return -1;
   if(price < VWAP_Lower) return  1;
   return 0;
  }

double GetKAMA_M15(int shift)
  {
   int period = KAMA_Length;
   double fast = 2.0 / 3.0;
   double slow = 2.0 / 31.0;
   double net = MathAbs(TfClose(PERIOD_M15, shift) - TfClose(PERIOD_M15, shift + period));
   double path = 0.0;
   for(int i = shift; i < shift + period; i++)
      path += MathAbs(TfClose(PERIOD_M15, i) - TfClose(PERIOD_M15, i + 1));
   double eff = (path > 0.0) ? net / path : 0.0;
   double sm  = MathPow(eff * (fast - slow) + slow, 2.0);
   double kama = TfClose(PERIOD_M15, shift + period);
   for(int j = shift + period - 1; j >= shift; j--)
      kama = kama + sm * (TfClose(PERIOD_M15, j) - kama);
   return kama;
  }

double KAMASlope_M15()
  {
   if(CurrentATR15 <= 0.0) return 0.0;
   double cur  = GetKAMA_M15(1); // use the last completed M15 candle
   double prev = GetKAMA_M15(KAMA_SlopeBars + 1); // same closed-bar basis
   return (cur - prev) / (CurrentATR15 * (double)KAMA_SlopeBars);
  }

bool ComputeVolSurgeBull()
  {
   double avg = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      long v = TfVolume(PERIOD_M15, i);
      if(v > 0) { avg += (double)v; cnt++; }
     }
   if(cnt <= 0) return false;
   avg /= (double)cnt;
   double cur = (double)TfVolume(PERIOD_M15, 1);
   double c1 = TfClose(PERIOD_M15, 1);
   double c2 = TfClose(PERIOD_M15, 2);
   if(avg <= 0.0 || cur <= avg * 2.0) return false;
   if(c1 <= c2) return false;
   double b1 = MathAbs(c1 - TfOpen(PERIOD_M15, 1));
   double b2 = MathAbs(c2 - TfOpen(PERIOD_M15, 2));
   return (b1 > b2 * 2.0);
  }

bool ComputeVolSurgeBear()
  {
   double avg = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      long v = TfVolume(PERIOD_M15, i);
      if(v > 0) { avg += (double)v; cnt++; }
     }
   if(cnt <= 0) return false;
   avg /= (double)cnt;
   double cur = (double)TfVolume(PERIOD_M15, 1);
   double c1 = TfClose(PERIOD_M15, 1);
   double c2 = TfClose(PERIOD_M15, 2);
   if(avg <= 0.0 || cur <= avg * 2.0) return false;
   if(c1 >= c2) return false;
   double b1 = MathAbs(c1 - TfOpen(PERIOD_M15, 1));
   double b2 = MathAbs(c2 - TfOpen(PERIOD_M15, 2));
   return (b1 > b2 * 2.0);
  }

double GetOBV_M15(int shift)
  {
   double val = 0.0;
   for(int i = shift + 21; i >= shift; i--)
     {
      double c  = TfClose(PERIOD_M15, i);
      double pc = TfClose(PERIOD_M15, i + 1);
      double v  = (double)TfVolume(PERIOD_M15, i);
      if(c <= 0.0 || pc <= 0.0) continue;
      if(c > pc)      val += v;
      else if(c < pc) val -= v;
     }
   return val;
  }

double GetOBVSig_M15(int shift)
  {
   double sum = 0.0; int cnt = 0;
   for(int i = shift; i < shift + 21; i++) { sum += GetOBV_M15(i); cnt++; }
   return (cnt > 0) ? sum / (double)cnt : 0.0;
  }

int DetectM15Jerk()
  {
   double adx  = BufVal(hADX_M15, 0, 1);
   double pdi  = BufVal(hADX_M15, 1, 1);
   double mdi  = BufVal(hADX_M15, 2, 1);
   double macd = BufVal(hMACD_M15, 0, 1);
   double sig  = BufVal(hMACD_M15, 1, 1);
   int hi = iHighest(_Symbol, PERIOD_M15, MODE_HIGH, 3, 1);
   int lo = iLowest (_Symbol, PERIOD_M15, MODE_LOW,  3, 1);
   if(hi < 0 || lo < 0) return 0;
   double range = TfHigh(PERIOD_M15, hi) - TfLow(PERIOD_M15, lo);
   bool vB = ComputeVolSurgeBull();
   bool vS = ComputeVolSurgeBear();
   double obv  = GetOBV_M15(1); // completed M15 bars only
   double osig = GetOBVSig_M15(1);
   if(adx > 25.0 && pdi > mdi && macd > sig &&
      range > 150.0 * _Point && vB && obv > osig) return 1;
   if(adx > 25.0 && mdi > pdi && macd < sig &&
      range > 150.0 * _Point && vS && obv < osig) return -1;
   return 0;
  }

int DetectM5Jerk()
  {
   double adx = BufVal(hADX_M5, 0, 1);
   double pdi = BufVal(hADX_M5, 1, 1);
   double mdi = BufVal(hADX_M5, 2, 1);
   double avgVol = 0.0; int cnt = 0;
   for(int i = 1; i <= 20; i++)
     {
      long v = TfVolume(PERIOD_M5, i);
      if(v > 0) { avgVol += (double)v; cnt++; }
     }
   if(cnt <= 0) return 0;
   avgVol /= (double)cnt;
   double curVol = (double)TfVolume(PERIOD_M5, 1);
   int hi = iHighest(_Symbol, PERIOD_M5, MODE_HIGH, 3, 1);
   int lo = iLowest (_Symbol, PERIOD_M5, MODE_LOW,  3, 1);
   if(hi < 0 || lo < 0) return 0;
   double range = TfHigh(PERIOD_M5, hi) - TfLow(PERIOD_M5, lo);
   if(adx > 25.0 && pdi > mdi && curVol > avgVol * 2.0 &&
      range > 50.0 * _Point) return 1;
   if(adx > 25.0 && mdi > pdi && curVol > avgVol * 2.0 &&
      range > 50.0 * _Point) return -1;
   return 0;
  }

//===================================================================
// SECTION 35 — M1 PRICE ACTION STACK
//===================================================================
bool M1RecentSwingHigh(double &price)
  {
   int maxShift = MathMax(M1PA_SwingLookback, 10);
   for(int shift = M1PA_SwingStrength + 1; shift < maxShift; shift++)
     {
      double h = TfHigh(PERIOD_M1, shift);
      if(h <= 0.0) continue;
      bool ok = true;
      for(int j = 1; j <= M1PA_SwingStrength; j++)
         if(TfHigh(PERIOD_M1, shift - j) >= h || TfHigh(PERIOD_M1, shift + j) >= h)
           { ok = false; break; }
      if(ok) { price = h; return true; }
     }
   return false;
  }

bool M1RecentSwingLow(double &price)
  {
   int maxShift = MathMax(M1PA_SwingLookback, 10);
   for(int shift = M1PA_SwingStrength + 1; shift < maxShift; shift++)
     {
      double l = TfLow(PERIOD_M1, shift);
      if(l <= 0.0) continue;
      bool ok = true;
      for(int j = 1; j <= M1PA_SwingStrength; j++)
         if(TfLow(PERIOD_M1, shift - j) <= l || TfLow(PERIOD_M1, shift + j) <= l)
           { ok = false; break; }
      if(ok) { price = l; return true; }
     }
   return false;
  }

bool M1BullSweep()
  {
   if(CurrentATR1 <= 0.0) return false;
   double swing = 0.0;
   if(!M1RecentSwingLow(swing)) return false;
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double range = h - l;
   if(range <= 0.0) return false;
   double lowerWick = (MathMin(o, c) - l) / range;
   return (l < swing - CurrentATR1 * MathMax(M1PA_MinSweepATR, 0.08) &&
           c > swing && lowerWick >= 0.30);
  }

bool M1BearSweep()
  {
   if(CurrentATR1 <= 0.0) return false;
   double swing = 0.0;
   if(!M1RecentSwingHigh(swing)) return false;
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double range = h - l;
   if(range <= 0.0) return false;
   double upperWick = (h - MathMax(o, c)) / range;
   return (h > swing + CurrentATR1 * MathMax(M1PA_MinSweepATR, 0.08) &&
           c < swing && upperWick >= 0.30);
  }

bool M1BullDisplacement()
  {
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double range = h - l;
   if(CurrentATR1 <= 0.0 || range <= 0.0 || c <= o) return false;
   double body = (c - o) / range;
   double closePos = (c - l) / range;
   return (range >= CurrentATR1 * MathMax(M1PA_MinDisplATR, 0.70) &&
           body >= M1PA_MinBodyRatio && closePos >= 0.70);
  }

bool M1BearDisplacement()
  {
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double range = h - l;
   if(CurrentATR1 <= 0.0 || range <= 0.0 || c >= o) return false;
   double body = (o - c) / range;
   double closePos = (c - l) / range;
   return (range >= CurrentATR1 * MathMax(M1PA_MinDisplATR, 0.70) &&
           body >= M1PA_MinBodyRatio && closePos <= 0.30);
  }

bool M1BullMSS()
  {
   if(!UseMSS) return false;
   double swing = 0.0;
   if(!M1RecentSwingHigh(swing)) return false;
   return (CurrentATR1 > 0.0 && TfClose(PERIOD_M1, 1) > swing + CurrentATR1 * 0.05);
  }

bool M1BearMSS()
  {
   if(!UseMSS) return false;
   double swing = 0.0;
   if(!M1RecentSwingLow(swing)) return false;
   return (CurrentATR1 > 0.0 && TfClose(PERIOD_M1, 1) < swing - CurrentATR1 * 0.05);
  }

bool M1BullFVG()
  {
   if(!UseFVG || CurrentATR1 <= 0.0) return false;
   double gap = TfLow(PERIOD_M1, 1) - TfHigh(PERIOD_M1, 3);
   return (gap >= CurrentATR1 * MathMax(M1PA_FVG_MinATR, 0.05));
  }

bool M1BearFVG()
  {
   if(!UseFVG || CurrentATR1 <= 0.0) return false;
   double gap = TfLow(PERIOD_M1, 3) - TfHigh(PERIOD_M1, 1);
   return (gap >= CurrentATR1 * MathMax(M1PA_FVG_MinATR, 0.05));
  }

bool M1Exhaustion()
  {
   if(CurrentATR1 <= 0.0) return false;
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double range = h - l;
   if(range <= 0.0 || range < CurrentATR1 * 1.80) return false;
   double body = MathAbs(c - o) / range;
   double upperWick = (h - MathMax(o, c)) / range;
   double lowerWick = (MathMin(o, c) - l) / range;
   return (body <= 0.35 && (upperWick >= 0.55 || lowerWick >= 0.55));
  }

bool IsExplosiveBar(int &outDir, double &outStrength)
  {
   outDir = 0; outStrength = 0.0;
   if(CurrentATR1 <= 0.0) return false;
   double o = TfOpen(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   if(o <= 0.0 || c <= 0.0 || h <= 0.0 || l <= 0.0) return false;
   double r = h - l;
   if(r <= 0.0) return false;
   double body = MathAbs(c - o) / r;
   double bodyATR = MathAbs(c - o) / CurrentATR1;
   double closePos = (c - l) / r;
   double avgVol = 0.0; int cnt = 0;
   for(int i = 2; i <= 21; i++)
     {
      long v = TfVolume(PERIOD_M1, i);
      if(v > 0) { avgVol += (double)v; cnt++; }
     }
   if(cnt > 0) avgVol /= (double)cnt;
   double volRatio = (avgVol > 0.0) ? (double)TfVolume(PERIOD_M1, 1) / avgVol : 1.0;
   bool bull = (c > o && body >= 0.64 && bodyATR >= 1.20 && closePos >= 0.74);
   bool bear = (c < o && body >= 0.64 && bodyATR >= 1.20 && closePos <= 0.26);
   if(!bull && !bear) return false;
   double volBoost = Clamp(volRatio, 0.50, 3.50);
   outDir = bull ? 1 : -1;
   outStrength = body * 35.0 + MathMin(bodyATR, 4.0) * 15.0 + volBoost * 8.0;
   return (outStrength >= 48.0);
  }

void UpdateM1PA()
  {
   M1PA_Dir = 0; M1PA_Score = 0.0;
   M1PA_BullSweep = false; M1PA_BearSweep = false;
   M1PA_BullDisp  = false; M1PA_BearDisp  = false;
   M1PA_BullMSS   = false; M1PA_BearMSS   = false;
   M1PA_BullFVG   = false; M1PA_BearFVG   = false;

   if(!UseM1PA) return;

   M1PA_BullSweep = M1BullSweep();
   M1PA_BearSweep = M1BearSweep();
   M1PA_BullDisp  = M1BullDisplacement();
   M1PA_BearDisp  = M1BearDisplacement();
   M1PA_BullMSS   = M1BullMSS();
   M1PA_BearMSS   = M1BearMSS();
   M1PA_BullFVG   = M1BullFVG();
   M1PA_BearFVG   = M1BearFVG();

   double bull = 0.0, bear = 0.0;
   if(M1PA_BullSweep) bull += 35.0;
   if(M1PA_BullDisp)  bull += 35.0;
   if(M1PA_BullMSS)   bull += 30.0;
   if(M1PA_BullFVG)   bull += 10.0;
   if(M1PA_BearSweep) bear += 35.0;
   if(M1PA_BearDisp)  bear += 35.0;
   if(M1PA_BearMSS)   bear += 30.0;
   if(M1PA_BearFVG)   bear += 10.0;

   if(bull >= bear && bull >= M1PA_BoostScore)
     { M1PA_Dir =  1; M1PA_Score = MathMin(100.0, bull); }
   else if(bear > bull && bear >= M1PA_BoostScore)
     { M1PA_Dir = -1; M1PA_Score = MathMin(100.0, bear); }
  }

//===================================================================
// SECTION 36 — M5 DIRECTION / SUPER8 / DONCHIAN / MA SLOPE
//===================================================================
int CalcM15Direction()
  {
   int score = 0;
   double fast = BufVal(hEMA10_M15, 0, 1);
   double slow = BufVal(hEMA20_M15, 0, 1);
   double base = BufVal(hEMA50_M15, 0, 1);
   double adx  = BufVal(hADX_M15,   0, 1);
   double pdi  = BufVal(hADX_M15,   1, 1);
   double mdi  = BufVal(hADX_M15,   2, 1);
   double price = TfClose(PERIOD_M15, 1);
   if(fast > slow) score += 2; else if(fast < slow) score -= 2;
   if(price > base) score += 2; else if(price < base) score -= 2;
   if(adx >= 20.0)
     {
      if(pdi > mdi) score += (adx >= StrongADXThreshold ? 2 : 1);
      else if(mdi > pdi) score -= (adx >= StrongADXThreshold ? 2 : 1);
     }
   if(KAMA_M15_Slope >  KAMA_SlopeMin) score += 1;
   else if(KAMA_M15_Slope < -KAMA_SlopeMin) score -= 1;
   if(score >= 3) return 1;
   if(score <= -3) return -1;
   return 0;
  }

int CalcM5Direction()
  {
   int score = 0;
   double fast = BufVal(hEMA8_M5,  0, 1);
   double slow = BufVal(hEMA21_M5, 0, 1);
   double base = BufVal(hEMA50_M5, 0, 1);
   double rsi  = BufVal(hRSI_M5,   0, 1);
   double mom  = BufVal(hMom14_M5, 0, 1);
   double price = TfClose(PERIOD_M5, 1);
   if(fast > slow) score += 2; else if(fast < slow) score -= 2;
   if(price > base) score += 2; else if(price < base) score -= 2;
   if(mom > 100.0) score += 1; else if(mom > 0.0 && mom < 100.0) score -= 1;
   if(rsi > 55.0) score += 1; else if(rsi < 45.0) score -= 1;
   if(score >= 3) return 1;
   if(score <= -3) return -1;
   return 0;
  }

int GetSuper8()
  {
   // Stable Factor-B thesis: confirmed/closed M5 bar only. Intrabar timing is separate.
   double emaF = BufVal(hEMA10_M5, 0, 1);
   double emaS = BufVal(hEMA50_M5, 0, 1);
   if(emaF <= 0.0 || emaS <= 0.0) return 0;
   double adx = BufVal(hADX_M5, 0, 1);
   double pdi = BufVal(hADX_M5, 1, 1);
   double mdi = BufVal(hADX_M5, 2, 1);
   double macdM = BufVal(hMACD_M5, 0, 1);
   double macdS = BufVal(hMACD_M5, 1, 1);
   double volSum = 0.0; int cnt = 0;
   for(int i = 2; i < 22; i++)
     {
      long v = TfVolume(PERIOD_M5, i);
      if(v > 0) { volSum += (double)v; cnt++; }
     }
   double volSMA = (cnt > 0) ? volSum / (double)cnt : 0.0;
   long volNow = TfVolume(PERIOD_M5, 1);
   double c = TfClose(PERIOD_M5, 1);
   double o = TfOpen (PERIOD_M5, 1);
   int bull = 0, bear = 0;
   if(emaF > emaS) bull++; else bear++;
   if(adx > 15.0) { if(pdi > mdi) bull += 2; if(mdi > pdi) bear += 2; }
   if(macdM > macdS) bull++; else bear++;
   if(volSMA > 0.0 && (double)volNow > volSMA * 0.4)
     {
      if(c > o) bull++;
      if(c < o) bear++;
     }
   if(bull > bear) return  1;
   if(bear > bull) return -1;
   return 0;
  }

void UpdateDonchian()
  {
   int N = 20;
   if(Bars(_Symbol, PERIOD_M5) < N + 5) return;
   double hiHigh = 0.0;
   double loLow  = 1e20;
   for(int i = 1; i <= N; i++)
     {
      double h = TfHigh(PERIOD_M5, i);
      double l = TfLow(PERIOD_M5, i);
      if(h > hiHigh) hiHigh = h;
      if(l < loLow && l > 0.0) loLow = l;
     }
   if(hiHigh <= 0.0 || loLow <= 0.0) return;
   DC_UpperPrev = DC_Upper;
   DC_LowerPrev = DC_Lower;
   DC_Upper = hiHigh;
   DC_Lower = loLow;
   if(DC_UpperPrev > 0.0 && DC_LowerPrev > 0.0)
     {
      double wN = DC_Upper - DC_Lower;
      double wP = DC_UpperPrev - DC_LowerPrev;
      DC_Slope = (wP > 0.0) ? (wN - wP) / wP : 0.0;
     }
  }

void UpdateMA_Slope()
  {
   double emaNow  = BufVal(hEMA50_M5, 0, 1); // last completed M5 bar
   double emaPrev = BufVal(hEMA50_M5, 0, 6); // five-bar slope on completed candles
   if(emaNow <= 0.0 || emaPrev <= 0.0) { MA_Slope = 0.0; return; }
   double atr5 = CurrentATR5;
   if(atr5 <= 0.0) atr5 = CurrentATR1;
   if(atr5 <= 0.0) { MA_Slope = 0.0; return; }
   MA_Slope = (emaNow - emaPrev) / (atr5 * 5.0);
  }

void UpdateTrendBias()
  {
   UpdateDonchian();
   UpdateMA_Slope();
   double price = MidPrice();
   if(price <= 0.0 || DC_Upper <= 0.0 || DC_Lower <= 0.0) { DC_Bias = 0; return; }
   double adx = BufVal(hADX_M15, 0, 1);
   bool trendExists = (adx > 16.0);
   bool brokeUpper = (price >= DC_UpperPrev && DC_UpperPrev > 0.0);
   bool brokeLower = (price <= DC_LowerPrev && DC_LowerPrev > 0.0);
   if(trendExists && brokeUpper && MA_Slope >  0.02) DC_Bias = 1;
   else if(trendExists && brokeLower && MA_Slope < -0.02) DC_Bias = -1;
   else DC_Bias = 0;
   if(DC_Bias == 0 && trendExists)
     {
      double width = DC_Upper - DC_Lower;
      if(CurrentATR5 > 0.0 && width > CurrentATR5 * 3.0)
        {
         if(MA_Slope >  0.20) DC_Bias =  1;
         if(MA_Slope < -0.20) DC_Bias = -1;
        }
     }
  }

//===================================================================
// END OF PART 2 OF 5
//===================================================================

//===================================================================
// SECTION 37 — HHLL / SUPERTREND / MSS M15
//===================================================================
int GetHHLLStructure(ENUM_TIMEFRAMES tf, int leftBars, int rightBars, int maxAge)
  {
   int bars = Bars(_Symbol, tf);
   if(bars < maxAge + leftBars + rightBars + 10) return 0;
   double h1=0,h2=0,l1=0,l2=0;
   int hc=0, lc=0;
   for(int i = rightBars; i < maxAge && (hc < 2 || lc < 2); i++)
     {
      if(hc < 2)
        {
         double h = TfHigh(tf, i);
         bool ok = true;
         for(int j = 1; j <= leftBars; j++)
            if(TfHigh(tf, i + j) >= h) { ok = false; break; }
         if(ok) for(int j = 1; j <= rightBars; j++)
            if(TfHigh(tf, i - j) >= h) { ok = false; break; }
         if(ok && h > 0.0) { if(hc==0) h1=h; else h2=h; hc++; }
        }
      if(lc < 2)
        {
         double l = TfLow(tf, i);
         bool ok = true;
         for(int j = 1; j <= leftBars; j++)
            if(TfLow(tf, i + j) <= l) { ok = false; break; }
         if(ok) for(int j = 1; j <= rightBars; j++)
            if(TfLow(tf, i - j) <= l) { ok = false; break; }
         if(ok && l > 0.0) { if(lc==0) l1=l; else l2=l; lc++; }
        }
     }
   if(hc < 2 || lc < 2) return 0;
   if(h1 > h2 && l1 > l2) return  1;
   if(h1 < h2 && l1 < l2) return -1;
   return 0;
  }

int GetSupertrend()
  {
   int bars = Bars(_Symbol, ST_TF);
   if(bars < ST_ATR + 50) return 0;
   int count = MathMin(200, bars - ST_ATR - 5);
   if(count < 10) return 0;
   double upper[200], lower[200], atr[200];
   int trend[200];
   int hAtrST = iATR(_Symbol, ST_TF, ST_ATR);
   if(hAtrST == INVALID_HANDLE) return 0;
   for(int i = 0; i < count; i++) atr[i] = BufVal(hAtrST, 0, i);
   IndicatorRelease(hAtrST);
   int oldest = count - 1;
   double hl2 = (TfHigh(ST_TF, oldest) + TfLow(ST_TF, oldest)) / 2.0;
   upper[oldest] = hl2 - ST_Mult * atr[oldest];
   lower[oldest] = hl2 + ST_Mult * atr[oldest];
   trend[oldest] = 1;
   for(int i = oldest - 1; i >= 0; i--)
     {
      double middle = (TfHigh(ST_TF, i) + TfLow(ST_TF, i)) / 2.0;
      if(atr[i] <= 0.0)
        { upper[i]=upper[i+1]; lower[i]=lower[i+1]; trend[i]=trend[i+1]; continue; }
      double rawUpper = middle - ST_Mult * atr[i];
      double rawLower = middle + ST_Mult * atr[i];
      double prevC = TfClose(ST_TF, i + 1);
      upper[i] = (prevC > upper[i+1]) ? MathMax(rawUpper, upper[i+1]) : rawUpper;
      lower[i] = (prevC < lower[i+1]) ? MathMin(rawLower, lower[i+1]) : rawLower;
      double curC = TfClose(ST_TF, i);
      if(trend[i+1] == -1 && curC > lower[i+1]) trend[i] = 1;
      else if(trend[i+1] == 1 && curC < upper[i+1]) trend[i] = -1;
      else trend[i] = trend[i+1];
     }
   return trend[0];
  }

int DetectMSS_Event()
  {
   int bars = Bars(_Symbol, PERIOD_M15);
   if(bars < MSS_LeftBars + MSS_RightBars + 10) return 0;
   int depth = MathMin(100, bars - MSS_LeftBars - MSS_RightBars - 1);
   double pH=0, pL=0;
   datetime tH=0, tL=0;
   for(int i = MSS_RightBars; i < depth; i++)
     {
      double h = TfHigh(PERIOD_M15, i);
      if(h > 0.0)
        {
         bool ok = true;
         for(int j=1;j<=MSS_LeftBars;j++) if(TfHigh(PERIOD_M15,i+j)>=h){ok=false;break;}
         if(ok) for(int j=1;j<=MSS_RightBars;j++) if(TfHigh(PERIOD_M15,i-j)>=h){ok=false;break;}
         if(ok && pH == 0.0) { pH = h; tH = TfTime(PERIOD_M15, i); }
        }
      double l = TfLow(PERIOD_M15, i);
      if(l > 0.0)
        {
         bool ok = true;
         for(int j=1;j<=MSS_LeftBars;j++) if(TfLow(PERIOD_M15,i+j)<=l){ok=false;break;}
         if(ok) for(int j=1;j<=MSS_RightBars;j++) if(TfLow(PERIOD_M15,i-j)<=l){ok=false;break;}
         if(ok && pL == 0.0) { pL = l; tL = TfTime(PERIOD_M15, i); }
        }
      if(pH > 0.0 && pL > 0.0) break;
     }
   if(pH > 0.0 && tH > MSS_LastHighTime) { MSS_LastHigh = pH; MSS_LastHighTime = tH; }
   if(pL > 0.0 && tL > MSS_LastLowTime)  { MSS_LastLow  = pL; MSS_LastLowTime  = tL; }
   double closed = TfClose(PERIOD_M15, 1);
   if(closed <= 0.0) return 0;
   int dir = 0;
   if(MSS_LastHigh > 0.0 && closed > MSS_LastHigh && MSS_LastDir !=  1) dir =  1;
   else if(MSS_LastLow  > 0.0 && closed < MSS_LastLow  && MSS_LastDir != -1) dir = -1;
   if(dir != 0)
     {
      MSS_LastDir = dir;
      MSS_LastEventDir = dir;
      MSS_LastEventTime = TimeCurrent();
     }
   return dir;
  }

bool MSSFresh(int direction)
  {
   if(MSS_LastEventDir != direction || MSS_LastEventTime == 0) return false;
   return (TimeCurrent() - MSS_LastEventTime <= M15VetoEventAgeMin * 60);
  }

//===================================================================
// SECTION 38 — OB / FVG / SESSIONS / LIQUIDITY SWEEP
//===================================================================
void StoreBullOB(double high, double low, datetime t)
  {
   int maxKeep = MathMin(OB_MaxStored, 8);
   if(maxKeep < 1) return;
   if(BullOBCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) BullOBs[i]=BullOBs[i-1]; BullOBCount=maxKeep-1; }
   else
     { for(int i=BullOBCount;i>0;i--) BullOBs[i]=BullOBs[i-1]; }
   BullOBs[0].high=high; BullOBs[0].low=low; BullOBs[0].avg=(high+low)/2.0;
   BullOBs[0].dir=1; BullOBs[0].t=t; BullOBs[0].mitigated=false;
   BullOBCount++;
  }

void StoreBearOB(double high, double low, datetime t)
  {
   int maxKeep = MathMin(OB_MaxStored, 8);
   if(maxKeep < 1) return;
   if(BearOBCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) BearOBs[i]=BearOBs[i-1]; BearOBCount=maxKeep-1; }
   else
     { for(int i=BearOBCount;i>0;i--) BearOBs[i]=BearOBs[i-1]; }
   BearOBs[0].high=high; BearOBs[0].low=low; BearOBs[0].avg=(high+low)/2.0;
   BearOBs[0].dir=-1; BearOBs[0].t=t; BearOBs[0].mitigated=false;
   BearOBCount++;
  }

void ScanOB()
  {
   if(!UseOB) { BullOBCount=0; BearOBCount=0; return; }
   if(Bars(_Symbol, PERIOD_M15) < OB_Periods + 10) return;
   double o = TfOpen(PERIOD_M15, 1);
   double c = TfClose(PERIOD_M15, 1);
   double h = TfHigh(PERIOD_M15, 1);
   double l = TfLow(PERIOD_M15, 1);
   datetime t = TfTime(PERIOD_M15, 1);
   if(o<=0.0||c<=0.0||h<=0.0||l<=0.0||t==0) return;

   int bullCnt=0, bearCnt=0;
   for(int i = 2; i <= OB_Periods + 1; i++)
     {
      double bo = TfOpen(PERIOD_M15, i);
      double bc = TfClose(PERIOD_M15, i);
      if(bc > bo)      bullCnt++;
      else if(bc < bo) bearCnt++;
     }
   if(c < o && bullCnt == OB_Periods)
     {
      bool ex=false;
      for(int i=0;i<BullOBCount;i++) if(BullOBs[i].t==t){ex=true;break;}
      if(!ex) StoreBullOB(o, l, t);
     }
   if(c > o && bearCnt == OB_Periods)
     {
      bool ex=false;
      for(int i=0;i<BearOBCount;i++) if(BearOBs[i].t==t){ex=true;break;}
      if(!ex) StoreBearOB(h, o, t);
     }
   double current = TfClose(PERIOD_M15, 0);
   for(int i=0;i<BullOBCount;i++)
      if(!BullOBs[i].mitigated && current < BullOBs[i].low) BullOBs[i].mitigated=true;
   for(int i=0;i<BearOBCount;i++)
      if(!BearOBs[i].mitigated && current > BearOBs[i].high) BearOBs[i].mitigated=true;
  }

void StoreBullFVG(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FVG_MaxStored, 8);
   if(maxKeep < 1) return;
   if(BullFVGCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) BullFVGs[i]=BullFVGs[i-1]; BullFVGCount=maxKeep-1; }
   else
     { for(int i=BullFVGCount;i>0;i--) BullFVGs[i]=BullFVGs[i-1]; }
   BullFVGs[0].high=high; BullFVGs[0].low=low; BullFVGs[0].mid=(high+low)/2.0;
   BullFVGs[0].dir=1; BullFVGs[0].t=t; BullFVGs[0].mitigated=false;
   BullFVGCount++;
  }

void StoreBearFVG(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FVG_MaxStored, 8);
   if(maxKeep < 1) return;
   if(BearFVGCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) BearFVGs[i]=BearFVGs[i-1]; BearFVGCount=maxKeep-1; }
   else
     { for(int i=BearFVGCount;i>0;i--) BearFVGs[i]=BearFVGs[i-1]; }
   BearFVGs[0].high=high; BearFVGs[0].low=low; BearFVGs[0].mid=(high+low)/2.0;
   BearFVGs[0].dir=-1; BearFVGs[0].t=t; BearFVGs[0].mitigated=false;
   BearFVGCount++;
  }

void ScanFVG()
  {
   if(!UseFVG) { BullFVGCount=0; BearFVGCount=0; return; }
   if(Bars(_Symbol, PERIOD_M5) < 20) return;
   double h1 = TfHigh(PERIOD_M5, 1);
   double l1 = TfLow(PERIOD_M5, 1);
   double h3 = TfHigh(PERIOD_M5, 3);
   double l3 = TfLow(PERIOD_M5, 3);
   double c2 = TfClose(PERIOD_M5, 2);
   datetime t = TfTime(PERIOD_M5, 1);
   if(h1<=0.0||l1<=0.0||h3<=0.0||l3<=0.0||c2<=0.0) return;
   double fvgFloor = MathMax(FVG_MinSizePts * _Point, (CurrentATR5 > 0.0 ? CurrentATR5 * 0.04 : 0.0));
   if(l1 > h3 && c2 > h3 && (l1-h3) >= fvgFloor)
     {
      bool ex=false;
      for(int i=0;i<BullFVGCount;i++) if(BullFVGs[i].t==t){ex=true;break;}
      if(!ex) StoreBullFVG(l1, h3, t);
     }
   if(h1 < l3 && c2 < l3 && (l3-h1) >= fvgFloor)
     {
      bool ex=false;
      for(int i=0;i<BearFVGCount;i++) if(BearFVGs[i].t==t){ex=true;break;}
      if(!ex) StoreBearFVG(l3, h1, t);
     }
   double current = TfClose(PERIOD_M5, 0);
   for(int i=0;i<BullFVGCount;i++)
      if(!BullFVGs[i].mitigated && current < BullFVGs[i].low) BullFVGs[i].mitigated=true;
   for(int i=0;i<BearFVGCount;i++)
      if(!BearFVGs[i].mitigated && current > BearFVGs[i].high) BearFVGs[i].mitigated=true;
  }

bool NearStoredZone(int dir, double distanceATR)
  {
   double price = MidPrice();
   if(price <= 0.0 || CurrentATR1 <= 0.0) return false;
   if(dir > 0)
     {
      for(int i=0;i<BullOBCount;i++)
        {
         if(BullOBs[i].mitigated) continue;
         double d = 0.0;
         if(price < BullOBs[i].low) d = BullOBs[i].low - price;
         else if(price > BullOBs[i].high) d = price - BullOBs[i].high;
         if(d <= CurrentATR1 * distanceATR) return true;
        }
      for(int i=0;i<BullFVGCount;i++)
        {
         if(BullFVGs[i].mitigated) continue;
         double d = 0.0;
         if(price < BullFVGs[i].low) d = BullFVGs[i].low - price;
         else if(price > BullFVGs[i].high) d = price - BullFVGs[i].high;
         if(d <= CurrentATR1 * distanceATR) return true;
        }
     }
   else
     {
      for(int i=0;i<BearOBCount;i++)
        {
         if(BearOBs[i].mitigated) continue;
         double d = 0.0;
         if(price < BearOBs[i].low) d = BearOBs[i].low - price;
         else if(price > BearOBs[i].high) d = price - BearOBs[i].high;
         if(d <= CurrentATR1 * distanceATR) return true;
        }
      for(int i=0;i<BearFVGCount;i++)
        {
         if(BearFVGs[i].mitigated) continue;
         double d = 0.0;
         if(price < BearFVGs[i].low) d = BearFVGs[i].low - price;
         else if(price > BearFVGs[i].high) d = price - BearFVGs[i].high;
         if(d <= CurrentATR1 * distanceATR) return true;
        }
     }
   return false;
  }

void UpdateLiquiditySessions()
  {
   if(!UseLiquiditySessions)
     {
      AsianHigh=0.0; AsianLow=0.0; LondonHigh=0.0; LondonLow=0.0;
      AsianLocked=false; LondonLocked=false;
      return;
     }
   MqlDateTime dt;
   TimeToStruct(TimeGMT(), dt);
   if(dt.day_of_year != SessionDayOfYear)
     {
      SessionDayOfYear = dt.day_of_year;
      AsianHigh=0.0; AsianLow=0.0; LondonHigh=0.0; LondonLow=0.0;
      AsianLocked=false; LondonLocked=false;
     }
   double h = TfHigh(PERIOD_M5, 1);
   double l = TfLow(PERIOD_M5, 1);
   if(h<=0.0 || l<=0.0) return;
   if(dt.hour >= 0 && dt.hour < 8)
     {
      if(AsianHigh == 0.0 || h > AsianHigh) AsianHigh = h;
      if(AsianLow  == 0.0 || l < AsianLow)  AsianLow  = l;
     }
   else if(!AsianLocked && AsianHigh > 0.0 && AsianLow > 0.0) AsianLocked = true;
   if(dt.hour >= 8 && dt.hour < 12)
     {
      if(LondonHigh == 0.0 || h > LondonHigh) LondonHigh = h;
      if(LondonLow  == 0.0 || l < LondonLow)  LondonLow  = l;
     }
   else if(!LondonLocked && LondonHigh > 0.0 && LondonLow > 0.0) LondonLocked = true;
  }

int DetectLiquiditySweep(string &source)
  {
   source = "";
   double c = TfClose(PERIOD_M5, 1);
   double h = TfHigh(PERIOD_M5, 1);
   double l = TfLow(PERIOD_M5, 1);
   if(c<=0.0 || h<=0.0 || l<=0.0) return 0;
   double minWick = CurrentATR5 * LS_MinWickATR;
   if(minWick <= 0.0) minWick = 500.0 * _Point;

   if(LS_UseAsian && AsianLocked)
     {
      if(l < AsianLow && c > AsianLow && AsianLow - l >= minWick) { source="AsianLow"; return 1; }
      if(h > AsianHigh && c < AsianHigh && h - AsianHigh >= minWick) { source="AsianHigh"; return -1; }
     }
   if(LS_UseLondon && LondonLocked)
     {
      if(l < LondonLow && c > LondonLow && LondonLow - l >= minWick) { source="LondonLow"; return 1; }
      if(h > LondonHigh && c < LondonHigh && h - LondonHigh >= minWick) { source="LondonHigh"; return -1; }
     }
   if(LS_UsePDHPDL)
     {
      double pdh = TfHigh(PERIOD_D1, 1);
      double pdl = TfLow(PERIOD_D1, 1);
      if(pdl > 0.0 && l < pdl && c > pdl && pdl - l >= minWick) { source="PDL"; return 1; }
      if(pdh > 0.0 && h > pdh && c < pdh && h - pdh >= minWick) { source="PDH"; return -1; }
     }
   if(LS_UseSwings)
     {
      int hi = iHighest(_Symbol, PERIOD_M5, MODE_HIGH, 10, 2);
      int lo = iLowest (_Symbol, PERIOD_M5, MODE_LOW,  10, 2);
      if(hi >= 0 && lo >= 0)
        {
         double sh = TfHigh(PERIOD_M5, hi);
         double sl = TfLow(PERIOD_M5, lo);
         if(sl > 0.0 && l < sl && c > sl && sl - l >= minWick) { source="SwingLow"; return 1; }
         if(sh > 0.0 && h > sh && c < sh && h - sh >= minWick) { source="SwingHigh"; return -1; }
        }
     }
   return 0;
  }

//===================================================================
// SECTION 39 — SMC STRUCTURE (M15/M5/M1 bias + events)
//===================================================================
bool VNSMC_FindSwings(ENUM_TIMEFRAMES tf, int lookback, int leftBars, int rightBars,
                      double &lastHigh, double &prevHigh,
                      double &lastLow,  double &prevLow)
  {
   lastHigh=prevHigh=lastLow=prevLow=0.0;
   int bars = Bars(_Symbol, tf);
   if(bars < lookback + leftBars + rightBars + 10) return false;
   int highCount=0, lowCount=0;
   int maxShift = (int)MathMin(lookback, bars - leftBars - rightBars - 2);
   for(int shift = rightBars + 1; shift <= maxShift; shift++)
     {
      double h = TfHigh(tf, shift);
      bool isHigh = (h > 0.0);
      if(isHigh)
        {
         for(int j=1;j<=leftBars && isHigh;j++) if(TfHigh(tf,shift+j)>=h) isHigh=false;
         for(int j=1;j<=rightBars && isHigh;j++) if(TfHigh(tf,shift-j)>=h) isHigh=false;
        }
      if(isHigh)
        {
         if(highCount==0) lastHigh=h; else if(highCount==1) prevHigh=h;
         highCount++;
        }
      double l = TfLow(tf, shift);
      bool isLow = (l > 0.0);
      if(isLow)
        {
         for(int j=1;j<=leftBars && isLow;j++) if(TfLow(tf,shift+j)<=l) isLow=false;
         for(int j=1;j<=rightBars && isLow;j++) if(TfLow(tf,shift-j)<=l) isLow=false;
        }
      if(isLow)
        {
         if(lowCount==0) lastLow=l; else if(lowCount==1) prevLow=l;
         lowCount++;
        }
      if(highCount >= 2 && lowCount >= 2) break;
     }
   return (highCount >= 2 && lowCount >= 2);
  }

int VNSMC_StructureBias(ENUM_TIMEFRAMES tf, int lookback, int &eventDir,
                        double &lastHigh, double &lastLow, datetime &eventTime)
  {
   eventDir = 0; eventTime = 0;
   double prevHigh=0.0, prevLow=0.0;
   int useLeft  = (tf == PERIOD_M1) ? SMC_InternalPivotLeft  : SMC_SwingPivotLeft;
   int useRight = (tf == PERIOD_M1) ? SMC_InternalPivotRight : SMC_SwingPivotRight;
   if(!VNSMC_FindSwings(tf, lookback, useLeft, useRight, lastHigh, prevHigh, lastLow, prevLow))
      return 0;
   int bias = 0;
   if(lastHigh > prevHigh && lastLow > prevLow) bias = 1;
   else if(lastHigh < prevHigh && lastLow < prevLow) bias = -1;
   double c1 = TfClose(tf, 1);
   double c2 = TfClose(tf, 2);
   if(c1 > 0.0 && c2 > 0.0 && lastHigh > 0.0 && c1 > lastHigh && c2 <= lastHigh)
     { eventDir = 1; eventTime = TfTime(tf, 1); if(bias <= 0) bias = 1; }
   else if(c1 > 0.0 && c2 > 0.0 && lastLow > 0.0 && c1 < lastLow && c2 >= lastLow)
     { eventDir = -1; eventTime = TfTime(tf, 1); if(bias >= 0) bias = -1; }
   return bias;
  }

bool VNSMC_FindEqualLiquidity(ENUM_TIMEFRAMES tf, int lookback,
                              double &eqHigh, double &eqLow)
  {
   eqHigh = 0.0; eqLow = 0.0;
   if(!UseEqualLiquidity) return false;
   int bars = Bars(_Symbol, tf);
   if(bars < lookback + SMC_SwingPivotLeft + SMC_SwingPivotRight + 10) return false;
   int maxShift = (int)MathMin(lookback, bars - SMC_SwingPivotLeft - SMC_SwingPivotRight - 2);
   double tol = MathMax(CurrentATR1, _Point * 10.0) * EqualToleranceATR;
   if(tf == PERIOD_M5  && CurrentATR5  > 0.0) tol = CurrentATR5  * EqualToleranceATR;
   if(tf == PERIOD_M15 && CurrentATR15 > 0.0) tol = CurrentATR15 * EqualToleranceATR;
   if(tol <= 0.0) tol = 20.0 * _Point;

   double bestHighA=0,bestHighB=0;
   for(int shift = SMC_SwingPivotRight + 1; shift <= maxShift; shift++)
     {
      double h = TfHigh(tf, shift);
      bool isH = h > 0.0;
      for(int j=1;j<=SMC_SwingPivotLeft && isH;j++) if(TfHigh(tf,shift+j)>=h) isH=false;
      for(int j=1;j<=SMC_SwingPivotRight && isH;j++) if(TfHigh(tf,shift-j)>=h) isH=false;
      if(isH)
        {
         for(int s = shift + 1; s <= maxShift; s++)
           {
            double h2 = TfHigh(tf, s);
            bool isH2 = h2 > 0.0;
            for(int j=1;j<=SMC_SwingPivotLeft && isH2;j++) if(TfHigh(tf,s+j)>=h2) isH2=false;
            for(int j=1;j<=SMC_SwingPivotRight && isH2;j++) if(TfHigh(tf,s-j)>=h2) isH2=false;
            if(isH2 && MathAbs(h - h2) <= tol) { bestHighA=h; bestHighB=h2; break; }
           }
         if(bestHighA > 0.0) break;
        }
     }

   double bestLowA=0,bestLowB=0;
   for(int shift = SMC_SwingPivotRight + 1; shift <= maxShift; shift++)
     {
      double l = TfLow(tf, shift);
      bool isL = l > 0.0;
      for(int j=1;j<=SMC_SwingPivotLeft && isL;j++) if(TfLow(tf,shift+j)<=l) isL=false;
      for(int j=1;j<=SMC_SwingPivotRight && isL;j++) if(TfLow(tf,shift-j)<=l) isL=false;
      if(isL)
        {
         for(int s = shift + 1; s <= maxShift; s++)
           {
            double l2 = TfLow(tf, s);
            bool isL2 = l2 > 0.0;
            for(int j=1;j<=SMC_SwingPivotLeft && isL2;j++) if(TfLow(tf,s+j)<=l2) isL2=false;
            for(int j=1;j<=SMC_SwingPivotRight && isL2;j++) if(TfLow(tf,s-j)<=l2) isL2=false;
            if(isL2 && MathAbs(l - l2) <= tol) { bestLowA=l; bestLowB=l2; break; }
           }
         if(bestLowA > 0.0) break;
        }
     }
   if(bestHighA > 0.0) eqHigh = 0.5 * (bestHighA + bestHighB);
   if(bestLowA  > 0.0) eqLow  = 0.5 * (bestLowA  + bestLowB);
   return (eqHigh > 0.0 || eqLow > 0.0);
  }

bool VNSMC_EqualLiquiditySweep(int dir, double level)
  {
   if(level <= 0.0) return false;
   double h = TfHigh(PERIOD_M1, 1);
   double l = TfLow(PERIOD_M1, 1);
   double c = TfClose(PERIOD_M1, 1);
   if(h<=0.0 || l<=0.0 || c<=0.0) return false;
   double buffer = MathMax(_Point * 2.0, CurrentATR1 * 0.03);
   if(dir == 1)  return (l < level - buffer && c > level);
   if(dir == -1) return (h > level + buffer && c < level);
   return false;
  }

void VNSMC_Update()
  {
   if(!UseSMCStructure) return;
   g_SMC.m15_bias = VNSMC_StructureBias(PERIOD_M15, SMC_M15Lookback,
                                         g_SMC.m15_event, g_SMC.m15_high, g_SMC.m15_low,
                                         g_SMC.m15_event_time);
   g_SMC.m5_bias  = VNSMC_StructureBias(PERIOD_M5, SMC_M5Lookback,
                                         g_SMC.m5_event, g_SMC.m5_high, g_SMC.m5_low,
                                         g_SMC.m5_event_time);
   g_SMC.m1_bias  = VNSMC_StructureBias(PERIOD_M1, SMC_M1Lookback,
                                         g_SMC.m1_event, g_SMC.m1_high, g_SMC.m1_low,
                                         g_SMC.m1_event_time);
   double rHigh=0.0, rLow=0.0, rPrevH=0.0, rPrevL=0.0;
   if(VNSMC_FindSwings(PERIOD_M5, 24, 2, 2, rHigh, rPrevH, rLow, rPrevL) && rHigh > rLow)
     {
      double mid = 0.5 * (rHigh + rLow);
      double span = rHigh - rLow;
      double price = MidPrice();
      g_SMC.pd_location = (span > 0.0) ? (price - mid) / span : 0.0;
     }
   else g_SMC.pd_location = 0.0;

   g_SMC.bull_zone_near = NearStoredZone(1, SMC_ZoneDistanceATR);
   g_SMC.bear_zone_near = NearStoredZone(-1, SMC_ZoneDistanceATR);
   g_SMC.bull_liq_sweep = M1BullSweep();
   g_SMC.bear_liq_sweep = M1BearSweep();

   double eqH=0.0, eqL=0.0;
   VNSMC_FindEqualLiquidity(PERIOD_M5, EqualLookback, eqH, eqL);
   g_SMC.eq_high_level = eqH;
   g_SMC.eq_low_level  = eqL;
   g_SMC.eq_high_active = (eqH > 0.0);
   g_SMC.eq_low_active  = (eqL > 0.0);
   if(g_SMC.eq_low_active  && VNSMC_EqualLiquiditySweep(1,  eqL)) g_SMC.bull_liq_sweep = true;
   if(g_SMC.eq_high_active && VNSMC_EqualLiquiditySweep(-1, eqH)) g_SMC.bear_liq_sweep = true;
  }

double VNSMC_StructureScore(int dir, string engine)
  {
   if(!UseSMCStructure || dir == 0) return 0.50;
   double score = 0.10;
   if(g_SMC.m15_bias == dir) score += 0.22;
   if(g_SMC.m5_bias  == dir) score += 0.25;
   if(g_SMC.m1_bias  == dir) score += 0.15;
   if(g_SMC.m15_event == dir) score += 0.10;
   if(g_SMC.m5_event  == dir) score += 0.12;
   if(g_SMC.m1_event  == dir) score += 0.08;
   if(dir ==  1 && g_SMC.bull_zone_near) score += 0.08;
   if(dir == -1 && g_SMC.bear_zone_near) score += 0.08;
   if(dir ==  1 && g_SMC.bull_liq_sweep) score += 0.10;
   if(dir == -1 && g_SMC.bear_liq_sweep) score += 0.10;
   if(dir ==  1 && g_SMC.pd_location <= -0.20) score += 0.08;
   if(dir == -1 && g_SMC.pd_location >=  0.20) score += 0.08;
   if(engine == "RANGE")
     {
      if(g_SMC.m15_bias == -dir) score -= 0.18;
      if(g_SMC.m5_bias  == -dir) score -= 0.18;
     }
   return Clamp(score, 0.0, 1.0);
  }

bool VNSMC_TrendBreak(int dir)
  {
   if(dir == 0 || !UseSMCStructure) return false;
   if(dir == 1)  return (g_SMC.m1_event == 1  || g_SMC.m5_event == 1);
   return (g_SMC.m1_event == -1 || g_SMC.m5_event == -1);
  }

//===================================================================
// SECTION 40 — QUALITY GATE
//===================================================================
double QualityTriggerScore(int dir)
  {
   int c = 0;
   if(dir ==  1) { if(M1PA_BullDisp) c++; if(M1PA_BullMSS) c++; if(M1PA_BullSweep) c++; if(M1PA_BullFVG) c++; }
   if(dir == -1) { if(M1PA_BearDisp) c++; if(M1PA_BearMSS) c++; if(M1PA_BearSweep) c++; if(M1PA_BearFVG) c++; }
   if(c >= 3) return 1.00;
   if(c == 2) return 0.85;
   if(c == 1) return 0.65;
   return 0.45;
  }

double ComputeQualityScore(string engine, int dir)
  {
   if(dir == 0) return 0.0;
   double smc = VNSMC_StructureScore(dir, engine);
   double trig = QualityTriggerScore(dir);
   double loc = 0.50;
   if(dir ==  1 && g_SMC.bull_zone_near) loc = 0.85;
   if(dir == -1 && g_SMC.bear_zone_near) loc = 0.85;
   if(dir ==  1 && g_SMC.bull_liq_sweep) loc = MathMax(loc, 0.85);
   if(dir == -1 && g_SMC.bear_liq_sweep) loc = MathMax(loc, 0.85);
   double volRatio = (NormalATR1 > 0.0) ? CurrentATR1 / NormalATR1 : 1.0;
   double volScore = Clamp(0.50 + (volRatio - 1.0) * 0.30, 0.25, 1.00);
   double flowScore = 0.50;
   if(BridgeReady())
     {
      double fc = FlowComposite() * (double)dir;
      flowScore = Clamp(0.50 + fc / 200.0, 0.20, 0.85);
      if(VNFlowCVDAccelerationStrong(dir)) flowScore += 0.10;
      if(VNFlowCascade(dir))               flowScore += 0.05;
      flowScore = Clamp(flowScore, 0.0, 1.0);
     }
   double q = QualityBase + smc * 0.30 + trig * 0.20 + loc * 0.10 +
              volScore * 0.10 + flowScore * 0.05;
   if(g_R7 == R7_EXPANSION && engine == "MONSTER") q += 0.05;
   if(g_R7 == R7_CHOP      && engine == "RANGE")   q += 0.05;
   return Clamp(q, 0.0, 1.0);
  }

double QualityFloorForEngine(string engine)
  {
   if(engine == "MONSTER")  return QualityMinMonster;
   if(engine == "SWING")    return QualityMinSwing;
   if(engine == "RANGE")    return QualityMinRange;
   if(engine == "REVERSAL") return QualityMinReversal;
   return QualityMinSwing;
  }

bool QualityGateAllows(string engine, int dir)
  {
   if(!UseQualityGate) return true;
   return (ComputeQualityScore(engine, dir) >= QualityFloorForEngine(engine));
  }

//===================================================================
// SECTION 41 — STATISTICAL HELPERS
//===================================================================
double VNLogistic(double x)
  {
   x = Clamp(x, -35.0, 35.0);
   return 1.0 / (1.0 + MathExp(-x));
  }

double VNBayesUpdate(double prior, double evidenceProb, double weight)
  {
   prior        = Clamp(prior, 0.001, 0.999);
   evidenceProb = Clamp(evidenceProb, 0.001, 0.999);
   weight       = MathMax(0.0, weight);
   double priorOdds = prior / (1.0 - prior);
   double evOdds    = evidenceProb / (1.0 - evidenceProb);
   double postOdds  = priorOdds * MathPow(evOdds, weight);
   return Clamp(postOdds / (1.0 + postOdds), 0.001, 0.999);
  }

double VNEntropyM1(int lookback)
  {
   if(lookback < 8) lookback = 8;
   if(Bars(_Symbol, PERIOD_M1) < lookback + 5) return 1.0;
   int up=0, down=0, flat=0;
   for(int i = 1; i <= lookback; i++)
     {
      double c0 = TfClose(PERIOD_M1, i);
      double c1 = TfClose(PERIOD_M1, i + 1);
      if(c0 <= 0.0 || c1 <= 0.0) continue;
      double r = c0 - c1;
      if(r > 0.0) up++; else if(r < 0.0) down++; else flat++;
     }
   double total = (double)(up + down + flat);
   if(total <= 0.0) return 1.0;
   double h = 0.0;
   if(up > 0)   { double p = up   / total; h -= p * MathLog(p); }
   if(down > 0) { double p = down / total; h -= p * MathLog(p); }
   if(flat > 0) { double p = flat / total; h -= p * MathLog(p); }
   double maxH = MathLog(3.0);
   if(maxH <= 0.0) return 1.0;
   return Clamp(h / maxH, 0.0, 1.0);
  }

double VNMutualInformationM5M15(int lookback)
  {
   if(lookback < 12) lookback = 12;
   if(Bars(_Symbol, PERIOD_M5) < lookback + 5 ||
      Bars(_Symbol, PERIOD_M15) < (lookback / 3) + 5) return 0.0;
   int count[3][3];
   ArrayInitialize(count, 0);
   for(int i = 1; i <= lookback; i++)
     {
      double m5c0 = TfClose(PERIOD_M5, i);
      double m5c1 = TfClose(PERIOD_M5, i + 1);
      datetime t  = TfTime(PERIOD_M5, i);
      if(m5c0 <= 0.0 || m5c1 <= 0.0 || t == 0) continue;
      int a = 1;
      double r5 = m5c0 - m5c1;
      if(r5 > 0.0) a = 2; else if(r5 < 0.0) a = 0;
      int sh15 = iBarShift(_Symbol, PERIOD_M15, t, false);
      if(sh15 < 1) continue;
      double m15c0 = TfClose(PERIOD_M15, sh15);
      double m15c1 = TfClose(PERIOD_M15, sh15 + 1);
      if(m15c0 <= 0.0 || m15c1 <= 0.0) continue;
      int b = 1;
      double r15 = m15c0 - m15c1;
      if(r15 > 0.0) b = 2; else if(r15 < 0.0) b = 0;
      count[a][b]++;
     }
   double total = 0.0;
   for(int i=0;i<3;i++) for(int j=0;j<3;j++) total += (double)count[i][j];
   if(total <= 0.0) return 0.0;
   double px[3]={0,0,0}, py[3]={0,0,0};
   for(int i=0;i<3;i++) for(int j=0;j<3;j++) { px[i]+=count[i][j]; py[j]+=count[i][j]; }
   double mi = 0.0;
   for(int i=0;i<3;i++) for(int j=0;j<3;j++)
     {
      if(count[i][j] <= 0 || px[i] <= 0.0 || py[j] <= 0.0) continue;
      double pxy = (double)count[i][j] / total;
      double denom = (px[i] / total) * (py[j] / total);
      if(denom > 0.0) mi += pxy * MathLog(pxy / denom);
     }
   return Clamp(mi / MathLog(3.0), 0.0, 1.0);
  }

double VNFracDiffCurrent(int window, double d)
  {
   if(window < 4) window = 4;
   if(window > 60) window = 60;
   if(Bars(_Symbol, PERIOD_M1) < window + 5) return 0.0;
   double w[];
   ArrayResize(w, window);
   w[0] = 1.0;
   for(int k = 1; k < window; k++)
      w[k] = -w[k - 1] * ((d - (double)k + 1.0) / (double)k);
   double result = 0.0;
   double c0 = TfClose(PERIOD_M1, 1);
   if(c0 <= 0.0) return 0.0;
   double scale = MathAbs(c0);
   if(scale <= 0.0) return 0.0;
   for(int k = 0; k < window; k++)
     {
      double c = TfClose(PERIOD_M1, k + 1);
      if(c <= 0.0) continue;
      result += w[k] * (c / scale);
     }
   return result;
  }

double VNFracDiffFromBars(int window, double d)
  {
   return VNFracDiffCurrent(window, d);
  }

//===================================================================
// SECTION 42 — KALMAN FILTER
//===================================================================
void VNKalmanUpdate()
  {
   datetime bar = TfTime(PERIOD_M1, 1);
   if(bar == 0 || bar == g_KalmanTime) return;
   double z = TfClose(PERIOD_M1, 1);
   if(z <= 0.0) return;
   g_KalmanTime = bar;
   if(g_KalmanPrice <= 0.0)
     {
      g_KalmanPrice = z; g_KalmanVelocity = 0.0;
      g_KalmanP00 = 1.0; g_KalmanP01 = 0.0;
      g_KalmanP10 = 0.0; g_KalmanP11 = 1.0;
      return;
     }
   double q = MathMax(0.000001, KalmanProcessNoise);
   double r = MathMax(0.000001, KalmanMeasurementNoise);
   double x0 = g_KalmanPrice + g_KalmanVelocity;
   double x1 = g_KalmanVelocity;
   double p00 = g_KalmanP00 + g_KalmanP01 + g_KalmanP10 + g_KalmanP11 + q;
   double p01 = g_KalmanP01 + g_KalmanP11;
   double p10 = g_KalmanP10 + g_KalmanP11;
   double p11 = g_KalmanP11 + q;
   double s = p00 + r;
   if(s <= 0.0) return;
   double k0 = p00 / s;
   double k1 = p10 / s;
   double innov = z - x0;
   g_KalmanPrice    = x0 + k0 * innov;
   g_KalmanVelocity = x1 + k1 * innov;
   g_KalmanP00 = (1.0 - k0) * p00;
   g_KalmanP01 = (1.0 - k0) * p01;
   g_KalmanP10 = p10 - k1 * p00;
   g_KalmanP11 = p11 - k1 * p01;
  }

//===================================================================
// SECTION 43 — OU MEAN REVERSION MODEL
//===================================================================
bool VNComputeOU()
  {
   g_OU.valid=false; g_OU.mu=0.0; g_OU.theta=0.0; g_OU.sigma=0.0;
   g_OU.z=0.0; g_OU.half_life=999.0; g_OU.reversion_prob=0.0;
   int n = OURangeWindow;
   if(n < 20) n = 20;
   if(n > 180) n = 180;
   if(Bars(_Symbol, PERIOD_M1) < n + 5) return false;
   double x[]; ArrayResize(x, n);
   double sum = 0.0;
   for(int i = 0; i < n; i++)
     {
      double c = TfClose(PERIOD_M1, i + 1);
      if(c <= 0.0) return false;
      x[i] = c; sum += c;
     }
   double mu = sum / (double)n;
   if(BridgeReady() && gBinAux.rolling_vwap > 0.0) mu = gBinAux.rolling_vwap;
   else if(g_InternalVWAP > 0.0) mu = g_InternalVWAP;
   double num=0.0, den=0.0;
   for(int i = 1; i < n; i++)
     {
      double a = x[i-1] - mu;
      double b = x[i]   - mu;
      num += a * b;
      den += b * b;
     }
   if(den <= 0.0) return false;
   double phi = Clamp(num / den, -0.999, 0.999);
   double rss=0.0; int rc=0;
   for(int i = 1; i < n; i++)
     {
      double expected = mu + phi * (x[i] - mu);
      double e = x[i-1] - expected;
      rss += e * e; rc++;
     }
   if(rc <= 2) return false;
   double sigma = MathSqrt(rss / (double)rc);
   if(sigma <= 0.0) return false;
   if(phi <= 0.0 || phi >= 1.0) return false;
   double theta = -MathLog(phi);
   if(theta <= 0.0) return false;
   double price = MidPrice();
   if(price <= 0.0) return false;
   double z = (price - mu) / sigma;
   double halfLife = MathLog(2.0) / theta;
   double quality = MathAbs(z) * MathMin(3.0, theta / MathMax(0.000001, OUMinTheta));
   double prob = VNLogistic((quality - 1.2) * 1.4);
   g_OU.valid=true; g_OU.mu=mu; g_OU.theta=theta; g_OU.sigma=sigma;
   g_OU.z=z; g_OU.half_life=halfLife; g_OU.reversion_prob=Clamp(prob, 0.0, 1.0);
   return true;
  }

bool VNOUAllowsRange(int dir)
  {
   if(!UseOURange) return true;
   if(dir == 0 || !g_OU.valid) return false;
   if(MathAbs(g_OU.z) < OUMinAbsZ) return false;
   if(g_OU.theta < OUMinTheta) return false;
   if(g_OU.half_life > OUMaxHalfLifeBars) return false;
   if(g_OU.reversion_prob < OURangeMinProbability) return false;
   if(dir ==  1 && g_OU.z >= 0.0) return false;
   if(dir == -1 && g_OU.z <= 0.0) return false;
   if(g_R7 == R7_EXPANSION || g_R7 == R7_COMPRESSION) return false;
   if(g_CUSUMDir != 0 && TimeCurrent() <= g_CUSUMOverrideUntil) return false;
   if(M15Direction != 0 && M5Direction == M15Direction &&
      (g_R7 == R7_STRONG_UP || g_R7 == R7_STRONG_DOWN)) return false;
   return true;
  }

//===================================================================
// SECTION 44 — CUSUM CHANGE-POINT [A3: bypass regime when fresh]
//===================================================================
bool VNUpdateCUSUM()
  {
   if(!UseCUSUM) return false;
   static datetime lastBar = 0;
   datetime bar = TfTime(PERIOD_M1, 1);
   if(bar == 0 || bar == lastBar) return false;
   lastBar = bar;
   int n = CUSUMWindow;
   if(n < 10) n = 10;
   if(n > 80) n = 80;
   if(Bars(_Symbol, PERIOD_M1) < n + 5) return false;
   double sum=0.0, sq=0.0; int cnt=0;
   for(int i = 2; i < n + 2; i++)
     {
      double c0 = TfClose(PERIOD_M1, i);
      double c1 = TfClose(PERIOD_M1, i + 1);
      if(c0 <= 0.0 || c1 <= 0.0) continue;
      double r = MathLog(c0 / c1);
      sum += r; sq += r * r; cnt++;
     }
   if(cnt < 8) return false;
   double mean = sum / (double)cnt;
   double var = MathMax(0.0, sq / (double)cnt - mean * mean);
   double sd = MathSqrt(var);
   if(sd <= 0.0) return false;
   double cNow0 = TfClose(PERIOD_M1, 1);
   double cNow1 = TfClose(PERIOD_M1, 2);
   if(cNow0 <= 0.0 || cNow1 <= 0.0) return false;
   double zr = (MathLog(cNow0 / cNow1) - mean) / sd;
   double drift = MathMax(0.0, CUSUMDrift);
   g_CUSUMBull = MathMax(0.0, g_CUSUMBull + zr - drift);
   g_CUSUMBear = MathMax(0.0, g_CUSUMBear - zr - drift);
   bool fired = false;
   if(g_CUSUMBull >= CUSUMThreshold)
     {
      g_CUSUMDir = 1;
      g_CUSUMLastFire = TimeCurrent();
      g_CUSUMOverrideUntil = TimeCurrent() + CUSUMPauseSeconds;
      g_CUSUMBull = 0.0; g_CUSUMBear = 0.0;
      fired = true;
     }
   else if(g_CUSUMBear >= CUSUMThreshold)
     {
      g_CUSUMDir = -1;
      g_CUSUMLastFire = TimeCurrent();
      g_CUSUMOverrideUntil = TimeCurrent() + CUSUMPauseSeconds;
      g_CUSUMBull = 0.0; g_CUSUMBear = 0.0;
      fired = true;
     }
   else if(TimeCurrent() > g_CUSUMOverrideUntil)
      g_CUSUMDir = 0;
   if(fired)
      PrintFormat("[CUSUM] change-point dir=%s", DirStr(g_CUSUMDir));
   return fired;
  }

bool VNFlowCUSUMAugmented()
  {
   if(!UseFlowCUSUMAugment) return false;
   if(!BridgeReady()) return false;
   if(g_CUSUMDir == 0) return false;
   if(TimeCurrent() > g_CUSUMOverrideUntil) return false;
   bool catalyst = VNFlowTradeRateSurge() ||
                   VNFlowCVDAccelerationStrong(g_CUSUMDir) ||
                   VNFlowCascade(g_CUSUMDir);
   if(catalyst)
     {
      datetime newUntil = TimeCurrent() + 60;
      if(newUntil > g_CUSUMOverrideUntil) g_CUSUMOverrideUntil = newUntil;
      return true;
     }
   return false;
  }

bool VNShockEligible(int dir)
  {
   if(!UseCUSUM || dir == 0) return false;
   if(g_CUSUMDir != dir) return false;
   if(TimeCurrent() > g_CUSUMOverrideUntil) return false;
   bool pa = (dir == 1)
             ? (M1BullDisplacement() || M1BullMSS() || M1BullSweep())
             : (M1BearDisplacement() || M1BearMSS() || M1BearSweep());
   return pa;
  }

//===================================================================
// SECTION 45 — 7-STATE REGIME + HMM POSTERIOR
//===================================================================
double CRG_ComputeHurst(ENUM_TIMEFRAMES tf, int N)
  {
   if(N < 20) return 0.5;
   if(Bars(_Symbol, tf) < N + 5) return 0.5;
   double r[]; ArrayResize(r, N);
   double sum = 0.0;
   for(int i = 0; i < N; i++)
     {
      double c0 = TfClose(tf, i);
      double c1 = TfClose(tf, i + 1);
      if(c0 <= 0.0 || c1 <= 0.0) return 0.5;
      double lr = MathLog(c0 / c1);
      r[i] = lr; sum += lr;
     }
   double mean = sum / (double)N;
   double varSum = 0.0;
   for(int i = 0; i < N; i++) { double d = r[i] - mean; varSum += d * d; }
   double sd = MathSqrt(varSum / (double)N);
   if(sd <= 0.0) return 0.5;
   double cum=0.0, cumMin=1e18, cumMax=-1e18;
   for(int i = 0; i < N; i++)
     {
      cum += r[i] - mean;
      if(cum < cumMin) cumMin = cum;
      if(cum > cumMax) cumMax = cum;
     }
   double R = cumMax - cumMin;
   if(R <= 0.0) return 0.5;
   double H = MathLog(R / sd) / MathLog((double)N / 2.0);
   return Clamp(H, 0.0, 1.0);
  }

double CRG_ComputeAutocorr(ENUM_TIMEFRAMES tf, int N)
  {
   if(N < 10) return 0.0;
   if(Bars(_Symbol, tf) < N + 5) return 0.0;
   double r[]; ArrayResize(r, N);
   double sum = 0.0;
   for(int i = 0; i < N; i++)
     {
      double c0 = TfClose(tf, i);
      double c1 = TfClose(tf, i + 1);
      if(c0 <= 0.0 || c1 <= 0.0) return 0.0;
      r[i] = MathLog(c0 / c1);
      sum += r[i];
     }
   double mean = sum / (double)N;
   double num=0.0, den=0.0;
   for(int i = 0; i < N - 1; i++) num += (r[i] - mean) * (r[i+1] - mean);
   for(int i = 0; i < N; i++)     { double d = r[i] - mean; den += d * d; }
   if(den <= 0.0) return 0.0;
   return num / den;
  }

double CalculateATR15_Pct()
  {
   double atrNow = BufVal(hATR_M15, 0, 1);
   if(atrNow <= 0.0) return 0.0;
   double sum = 0.0; int c = 0;
   for(int i = 1; i <= 100; i++)
     {
      double v = BufVal(hATR_M15, 0, i);
      if(v > 0.0) { sum += v; c++; }
     }
   if(c <= 0) return 0.0;
   double avg = sum / c;
   if(avg <= 0.0) return 0.0;
   return atrNow / avg;
  }

void ComputeAdaptiveRegimeMetrics()
  {
   ER_Short_M5 = CalculateER_TF(PERIOD_M5, 10);
   ER_Med_M5   = CalculateER_TF(PERIOD_M5, 30);
   ER_Slow_M15 = CalculateER_TF(PERIOD_M15, 30);
   ATR15_Pct   = CalculateATR15_Pct();
  }

ENUM_REGIME7 ComputeRegime7()
  {
   if(!UseRegimeSupervisor) return R7_CHOP;

   double adx15 = BufVal(hADX_M15, 0, 1);
   double adx5  = BufVal(hADX_M5,  0, 1);
   double er15  = Clamp(CalculateER_TF(PERIOD_M15, Regime_ER_Period), 0.0, 1.0);
   double atrRatio = (NormalATR5 > 0.0 && CurrentATR5 > 0.0)
                     ? CurrentATR5 / NormalATR5 : 1.0;
   double m5Range = TfHigh(PERIOD_M5, 1) - TfLow(PERIOD_M5, 1);
   double m5RangeAtr = (CurrentATR5 > 0.0) ? m5Range / CurrentATR5 : 1.0;

   bool expansion = (atrRatio >= ExpansionATRRatio || m5RangeAtr >= 1.75 ||
                     VNFlowTradeRateSurge() ||
                     (gBinAux.valid && gBinAux.range_exp >= 2.0));
   bool compression = (atrRatio <= CompressionATRRatio &&
                       er15 <= CompressionERThreshold &&
                       adx5 < WeakADXThreshold);

   ENUM_REGIME7 next = R7_CHOP;

   if(expansion)         next = R7_EXPANSION;
   else if(compression)  next = R7_COMPRESSION;
   else
     {
      bool bull = (M15Direction == 1 && M5Direction == 1);
      bool bear = (M15Direction == -1 && M5Direction == -1);
      if(bull && adx15 >= StrongADXThreshold && adx5 >= StrongADXThreshold &&
         er15 >= StrongERThreshold) next = R7_STRONG_UP;
      else if(bear && adx15 >= StrongADXThreshold && adx5 >= StrongADXThreshold &&
              er15 >= StrongERThreshold) next = R7_STRONG_DOWN;
      else if(bull || (M15Direction == 1  && adx15 >= WeakADXThreshold)) next = R7_WEAK_UP;
      else if(bear || (M15Direction == -1 && adx15 >= WeakADXThreshold)) next = R7_WEAK_DOWN;
      else next = R7_CHOP;
     }

   // A single CUSUM event is a direction/impulse candidate, not enough by itself
   // to re-label a visibly stable range as EXPANSION. Require independent volatility
   // expansion or a completed M1 displacement + market-structure break in that direction.
   bool cusumActive=(g_CUSUMDir!=0 && TimeCurrent()<=g_CUSUMOverrideUntil);
   bool cusumStructureBreak=false;
   if(cusumActive)
     {
      if(g_CUSUMDir==1)
         cusumStructureBreak=(M1BullDisplacement() && M1BullMSS());
      else if(g_CUSUMDir==-1)
         cusumStructureBreak=(M1BearDisplacement() && M1BearMSS());
     }
   if(cusumActive && (expansion || cusumStructureBreak))
      next = R7_EXPANSION;

   datetime now = TimeCurrent();
   if(g_R7Since == 0) g_R7Since = now;

   if(next != g_R7)
     {
      if(next != g_R7Pending)
        { g_R7Pending = next; g_R7PendingSince = now; }
      else if(now - g_R7PendingSince >= AdaptiveRegimeStickySec)
        {
         PrintFormat("[REGIME] %s -> %s ATRr=%.2f ER=%.2f ADX15=%.1f ADX5=%.1f",
                     Regime7Name(g_R7), Regime7Name(next),
                     atrRatio, er15, adx15, adx5);
         g_R7 = next;
         g_R7Since = now;
         g_R7Pending = R7_CHOP;
        }
     }
   else
      g_R7Pending = R7_CHOP;

   return g_R7;
  }

void VNUpdateHMMPosterior()
  {
   if(!UseHMMLikePosterior) return;
   double emission[7];
   double atrRatio = (NormalATR5 > 0.0 && CurrentATR5 > 0.0)
                     ? CurrentATR5 / NormalATR5 : 1.0;
   int rdir = 0;
   if(g_R7 == R7_STRONG_UP || g_R7 == R7_WEAK_UP)     rdir =  1;
   if(g_R7 == R7_STRONG_DOWN || g_R7 == R7_WEAK_DOWN) rdir = -1;
   double align = 0.0;
   if(M15Direction != 0 && M5Direction == M15Direction) align = (double)M15Direction;
   for(int i = 0; i < 7; i++)
     {
      double e = 0.05;
      if(i == (int)g_R7) e += 0.55;
      if(i == (int)g_R7 && rdir != 0) e += 0.10;
      if(i == (int)R7_EXPANSION   && atrRatio > 1.4) e += 0.25;
      if(i == (int)R7_COMPRESSION && atrRatio < 0.8) e += 0.25;
      if(i == (int)R7_STRONG_UP   && align > 0.0) e += 0.20;
      if(i == (int)R7_STRONG_DOWN && align < 0.0) e += 0.20;
      if(i == (int)R7_CHOP        && g_VNEntropy > 0.90) e += 0.15;
      emission[i] = MathMax(0.0001, e);
     }
   double sum = 0.0;
   double out[7];
   for(int i = 0; i < 7; i++)
     {
      out[i] = g_HMMProb[i] * HMMOldStateWeight + emission[i] * (1.0 - HMMOldStateWeight);
      sum += out[i];
     }
   if(sum <= 0.0) return;
   int best = 0; double bestP = 0.0;
   for(int i = 0; i < 7; i++)
     {
      g_HMMProb[i] = out[i] / sum;
      if(g_HMMProb[i] > bestP) { bestP = g_HMMProb[i]; best = i; }
     }
   g_HMMRegime = best;
   g_R7Confidence = bestP;
  }

double Regime_SizeMult()
  {
   switch(g_R7)
     {
      case R7_EXPANSION:   return 1.15;
      case R7_STRONG_UP:
      case R7_STRONG_DOWN: return 1.00;
      case R7_WEAK_UP:
      case R7_WEAK_DOWN:   return 0.90;
      case R7_CHOP:        return 0.80;
      case R7_COMPRESSION: return 0.70;
     }
   return 0.80;
  }

bool Regime_AllowsEngine(string engine)
  {
   if(!UseRegimeSupervisor) return true;
   switch(g_R7)
     {
      case R7_EXPANSION:
         return (engine == "MONSTER" || engine == "SWING" || engine == "REVERSAL");
      case R7_STRONG_UP:
      case R7_STRONG_DOWN:
         return (engine == "MONSTER" || engine == "SWING");
      case R7_WEAK_UP:
      case R7_WEAK_DOWN:
         return (engine == "SWING" || engine == "REVERSAL" || engine == "RANGE");
      case R7_CHOP:
         return (engine == "RANGE" || engine == "REVERSAL" || engine == "SWING");
      case R7_COMPRESSION:
         return (engine == "RANGE");
     }
   return true;
  }

//===================================================================
// SECTION 46 — FASTTRENDSCORE
//===================================================================
double ComputeFastTrendScore()
  {
   double score = 0.0;
   int    dirSum = 0;

   //--- Component 1: Bridge flow
   double flowScore = 0.0;
   int    flowDir   = 0;
   if(BridgeReady())
     {
      double fc = FlowComposite();
      int flowSign = 0;
      if(fc >  BinanceMinFlowScore) flowSign =  1;
      if(fc < -BinanceMinFlowScore) flowSign = -1;

      if(flowSign != 0)
        {
         flowScore += 15.0;
         if(MathAbs(fc) >= BinanceStrongFlowScore) flowScore += 10.0;
        }
      if(VNFlowCVDAccelerationStrong(1))  { flowScore += 10.0; flowSign =  1; }
      if(VNFlowCVDAccelerationStrong(-1)) { flowScore += 10.0; flowSign = -1; }

      if(gBinAux.oi_regime == 1 || gBinAux.oi_regime == 4) { if(flowSign == 0) flowSign =  1; }
      if(gBinAux.oi_regime == 2 || gBinAux.oi_regime == 3) { if(flowSign == 0) flowSign = -1; }

      if(flowScore > FastTrend_FlowWeight) flowScore = FastTrend_FlowWeight;
      flowDir = flowSign;
     }

   // Factor A flow remains a measured candidate direction, but Factor B alone resolves direction.
   // Do not turn an unaligned/high-magnitude bridge reading into automatic quality points.

   //--- Component 2: M5 structure
   double m5Score = 0.0;
   int    m5Dir   = 0;
   {
      bool trendExists = (BufVal(hADX_M15, 0, 1) > 16.0);
      bool brokeUpper  = (MidPrice() >= DC_UpperPrev && DC_UpperPrev > 0.0);
      bool brokeLower  = (MidPrice() <= DC_LowerPrev && DC_LowerPrev > 0.0);

      if(trendExists && brokeUpper && MA_Slope >  FastTrend_DonchianSlopeMin)
        { m5Score += 20.0; m5Dir =  1; }
      else if(trendExists && brokeLower && MA_Slope < -FastTrend_DonchianSlopeMin)
        { m5Score += 20.0; m5Dir = -1; }

      double width = DC_Upper - DC_Lower;
      if(CurrentATR5 > 0.0 && width > CurrentATR5 * FastTrend_DonchianWidthATR)
         m5Score += 5.0;

      if(g_SMC.m5_bias != 0 && g_SMC.m5_bias == M15Direction)
        { m5Score += 10.0; if(m5Dir == 0) m5Dir = g_SMC.m5_bias; }

      if(m5Score > FastTrend_M5Weight) m5Score = FastTrend_M5Weight;
     }

   //--- Component 3: VP acceptance
   double vpScore = 0.0;
   int    vpDir   = 0;
   {
      double price = MidPrice();
      if(g_NVP.valid)
        {
         double buffer = CurrentATR5 * 0.5;
         if(buffer <= 0.0) buffer = CurrentATR1 * 0.5;
         if(price > g_NVP.vah + buffer) { vpScore += 10.0; vpDir =  1; }
         if(price < g_NVP.val - buffer) { vpScore += 10.0; vpDir = -1; }
         if(g_NVP.vaWidthPct > VP_CompressMaxPct * 1.5) vpScore += 10.0;
        }
      if(vpScore > FastTrend_VPWeight) vpScore = FastTrend_VPWeight;
     }

   //--- Component 4: M15 SMC
   double m15Score = 0.0;
   int    m15Dir   = 0;
   {
      if(g_SMC.m15_bias != 0)
        {
         m15Score = 10.0;
         m15Dir   = g_SMC.m15_bias;
        }
      if(m15Score > FastTrend_M15Weight) m15Score = FastTrend_M15Weight;
     }

   //--- Component 5: Super 8 confirmed M5 direction (primary Factor-B context).
   // GetSuper8() reads completed M5 bars; live M1 timing remains separate.
   int super8Dir = GetSuper8();
   double super8Score = (super8Dir != 0 ? 12.0 : 0.0);

   //--- Compose Factor-B technical thesis first; Factor A can confirm but never select direction.
   double technicalScore = m5Score + vpScore + m15Score;
   dirSum = (UseFactorBPrimaryDecisionV2 ? 0 : flowDir * 4) + m5Dir * 3 + vpDir * 2 + m15Dir * 2 + super8Dir * 2;
   int finalDir = 0;
   if(dirSum >  1) finalDir =  1;
   if(dirSum < -1) finalDir = -1;

   if(UseFactorBPrimaryDecisionV2)
     {
      score = technicalScore;
      if(finalDir!=0 && super8Dir==finalDir) score += super8Score;
      else if(finalDir!=0 && super8Dir==-finalDir && super8Dir!=0) score -= 6.0; // conflict reduces quality, does not choose direction
      if(finalDir!=0 && flowDir==finalDir && flowDir!=0 && BridgeReady())
        score += MathMin(10.0,flowScore); // Factor A alignment is confirmation only
      else if(finalDir!=0 && flowDir!=0 && flowDir!=finalDir && BridgeReady())
        PrintFormat("[FACTOR-A FLOW CONFLICT] FactorBDir=%d FactorAFlowDir=%d flow=%.1f; direction remains Factor B",finalDir,flowDir,FlowComposite());
     }
   else score = flowScore + technicalScore;
   // Kronos is a bounded secondary forecast signal; it never chooses the technical direction.
   if(KronosModeV1>0 && finalDir!=0) score += KronosScoreAdjustment(finalDir);
   score = Clamp(score, 0.0, 100.0);

   g_FastTrendScore = score;
   g_FastTrendDir   = finalDir;
   return score;
  }

int FastTrendDir() { return g_FastTrendDir; }

//===================================================================
// SECTION 47 — REGIME DIRECTION GATE
//===================================================================
bool RegimeGateAllows(int dir, string engine)
  {
   if(!UseRegimeDirectionGate) return true;
   if(dir == 0) return false;

   if(g_R7 == R7_CHOP || g_R7 == R7_COMPRESSION) return true;

   if(g_R7 == R7_STRONG_UP || g_R7 == R7_WEAK_UP)
     {
      if(dir == 1) return true;
      if(!RegimeGateRequiresFastTrend) return true;
      if(UseFastTrendScore && g_FastTrendScore >= FastTrend_PrimeThreshold) return false;
      bool smcOppose = (g_SMC.m15_bias == -1 || g_SMC.m5_bias == -1);
      bool flowOppose = !BridgeReady() || (FlowComposite() < -BinanceMinFlowScore);
      return (smcOppose && flowOppose);
     }

   if(g_R7 == R7_STRONG_DOWN || g_R7 == R7_WEAK_DOWN)
     {
      if(dir == -1) return true;
      if(!RegimeGateRequiresFastTrend) return true;
      if(UseFastTrendScore && g_FastTrendScore >= FastTrend_PrimeThreshold) return false;
      bool smcOppose = (g_SMC.m15_bias == 1 || g_SMC.m5_bias == 1);
      bool flowOppose = !BridgeReady() || (FlowComposite() > BinanceMinFlowScore);
      return (smcOppose && flowOppose);
     }

   return true;
  }

double RegimeGateSizeMult(int dir)
  {
   if(!UseRegimeDirectionGate) return 1.0;
   if(g_R7 == R7_STRONG_UP || g_R7 == R7_WEAK_UP)
      return (dir == 1) ? 1.0 : RegimeGateOppositeSizeMult;
   if(g_R7 == R7_STRONG_DOWN || g_R7 == R7_WEAK_DOWN)
      return (dir == -1) ? 1.0 : RegimeGateOppositeSizeMult;
   return 1.0;
  }

//===================================================================
// SECTION 48 — MASTER STATISTICAL UPDATE
//===================================================================
void VNAdvancedMarketUpdate()
  {
   VNKalmanUpdate();
   g_VNEntropy      = VNEntropyM1(FeatureInfoWindow);
   g_SignalMI_M5M15 = VNMutualInformationM5M15(FeatureInfoWindow);
   g_FractDiff      = VNFracDiffFromBars(FractionalDiffWindow, 0.40);
   VNComputeOU();
   VNUpdateCUSUM();
   if(BridgeReady()) VNFlowCUSUMAugmented();
   ComputeRegime7();
   VNUpdateHMMPosterior();
   if(UseFastTrendScore) ComputeFastTrendScore();
  }

//===================================================================
// SECTION 49 — DIRECTION CALC (M1 + M5 vote, M15/H1 veto)
//===================================================================
int LegacyFinalDirection(int &source)
  {
   source = 0;
   if(UseM1PA && M1PA_Dir != 0 && M1PA_Score >= M1PA_OverrideScore)
     { source = 5; return M1PA_Dir; }
   if(Jerk_M15 != 0) { source = 1; return Jerk_M15; }
   if(Jerk_M5  != 0) { source = 2; return Jerk_M5;  }
   if(CombinedDirection == 0)
     {
      if(UseM1PA && M1PA_Dir != 0 && M1PA_Score >= M1PA_BoostScore)
        { source = 5; return M1PA_Dir; }
      return 0;
     }
   int direction = (CombinedDirection > 0) ? 1 : -1;
   if(direction ==  1 && KAMA_M15_Slope < -KAMA_SlopeMin) { source = 4; return -1; }
   if(direction == -1 && KAMA_M15_Slope >  KAMA_SlopeMin) { source = 4; return  1; }
   if(UseM1PA && M1PA_Dir == direction && M1PA_Score >= M1PA_BoostScore) source = 5;
   else source = 3;
   return direction;
  }

int FastDirection()
  {
   int dirV = 0;
   double vroc = (BridgeReady() && gBinAux.vroc > 0.0) ? gBinAux.vroc : 0.0;
   if(vroc >= 2.5)
     {
      double o = TfOpen(PERIOD_M1, 0);
      double c = TfClose(PERIOD_M1, 0);
      if(o > 0.0 && c > 0.0)
        {
         if(c > o + 5 * _Point) dirV =  1;
         if(c < o - 5 * _Point) dirV = -1;
        }
     }
   int dirC = 0;
   if(FlowFresh())
     {
      if(CVDAccelerationNormalized >  0.05 && CVDVelocityNormalized > 0) dirC =  1;
      if(CVDAccelerationNormalized < -0.05 && CVDVelocityNormalized < 0) dirC = -1;
     }
   int dirW = 0;
   if(gBinAux.valid)
     {
      if(gBinAux.vwap_slope >  3.0) dirW =  1;
      if(gBinAux.vwap_slope < -3.0) dirW = -1;
     }
   else
     {
      if(VWAP_Bias != 0) dirW = VWAP_Bias;
     }

   if(MQLInfoInteger(MQL_TESTER))
     {
      if(dirV ==  1 && dirW >= 0) return  1;
      if(dirV == -1 && dirW <= 0) return -1;
      return 0;
     }
   int votes = dirV + dirC + dirW;
   if(dirV ==  1 && votes >=  1) return  1;
   if(dirV == -1 && votes <= -1) return -1;
   return 0;
  }

void RefreshLegacyContext(bool force = false)
  {
   static datetime lastM15 = 0;
   static datetime lastM5  = 0;
   static datetime lastH1  = 0;
   datetime curM15 = TfTime(PERIOD_M15, 0);
   datetime curM5  = TfTime(PERIOD_M5,  0);
   datetime curH1  = TfTime(PERIOD_H1,  0);

   if(force || (curM15 > 0 && curM15 != lastM15))
     {
      lastM15 = curM15;
      Jerk_M15 = DetectM15Jerk();
      M15Direction = CalcM15Direction();
      VolSurgeBull_sig = ComputeVolSurgeBull();
      VolSurgeBear_sig = ComputeVolSurgeBear();
      OBV_Val = GetOBV_M15(1);
      OBV_Sig = GetOBVSig_M15(1);
      KAMA_M15 = GetKAMA_M15(1);
      KAMA_M15_Slope = KAMASlope_M15();
      VWAP_Bias = GetVWAPBias();
      DetectMSS_Event();
      ScanOB();
      UpdateTrendBias();
     }
   if(force || (curM5 > 0 && curM5 != lastM5))
     {
      lastM5 = curM5;
      Jerk_M5 = DetectM5Jerk();
      M5Direction = CalcM5Direction();
      CombinedDirection = 0;
      if(M15Direction > 0 && M5Direction > 0)      CombinedDirection =  2;
      else if(M15Direction < 0 && M5Direction < 0) CombinedDirection = -2;
      else if(M15Direction != 0)                   CombinedDirection = M15Direction;
      else                                         CombinedDirection = M5Direction;
      VWAP_Bias = GetVWAPBias();
      UpdateTrendBias();
      ScanFVG();
     }
   if(force || (curH1 > 0 && curH1 != lastH1))
     {
      lastH1 = curH1;
      if(UseHHLL) HHLL_State = GetHHLLStructure(HHLL_TF, HHLL_LB, HHLL_RB, HHLL_MaxAge);
      if(UseSupertrend) ST_Dir = GetSupertrend();
     }
  }

//===================================================================
// SECTION 50 — MOVE STATE
//===================================================================
void DetectMoveState()
  {
   RefreshLegacyContext();
   UpdateM1PA();

   int m15Direction = M15Direction;
   int m5Direction  = M5Direction;

   bool bullSweep = M1BullSweep();
   bool bearSweep = M1BearSweep();
   bool bullDisplacement = M1BullDisplacement();
   bool bearDisplacement = M1BearDisplacement();
   bool bullMSS = M1BullMSS();
   bool bearMSS = M1BearMSS();
   bool bullFVG = M1BullFVG();
   bool bearFVG = M1BearFVG();

   double previousRange = TfHigh(PERIOD_M1, 1) - TfLow(PERIOD_M1, 1);
   double normalATR = (NormalATR1 > 0.0) ? NormalATR1 : CurrentATR1;
   double rangeRatio = (normalATR > 0.0) ? previousRange / normalATR : 0.0;

   double flowScore = FlowComposite();
   int flowDirection = FlowDirection();
   double averageTradeRate = AverageFlowTradeRate();
   bool tradeRateSurge = (gFlow.trade_rate >=
                          MathMax(2.0, averageTradeRate * 1.40));

   CurrentMoveState = 0; CurrentDirection = 0;
   CurrentMoveScore = 20.0; CurrentDirectionSource = 0;

   // REVERSAL
   if((bullSweep && bullMSS && bullDisplacement) ||
      (bearSweep && bearMSS && bearDisplacement))
     {
      int direction = (bullSweep && bullMSS && bullDisplacement) ? 1 : -1;
      double score = 50.0;
      if((direction ==  1 && bullFVG) || (direction == -1 && bearFVG)) score += 8.0;
      if(direction == m5Direction)  score += 6.0;
      if(direction == m15Direction) score += 6.0;
      if(MSSFresh(direction))       score += 7.0;
      if(FactorAFlowConfirms(direction, false)) score += 18.0;
      if(FactorAFlowConfirms(direction, true))  score += 6.0;
      if(NearStoredZone(direction, 1.50)) score += 5.0;
      CurrentMoveState = 6;
      CurrentDirection = direction;
      CurrentMoveScore = Clamp(score, 0.0, 100.0);
      CurrentDirectionSource = 1;
      return;
     }

   // MONSTER
   bool liveFlow = UseBinanceFlow && !MQLInfoInteger(MQL_TESTER) && FlowFresh();
   bool monsterCondition = (rangeRatio >= 1.35) &&
     (((liveFlow && tradeRateSurge && MathAbs(flowScore) >= BinanceStrongFlowScore)) ||
      ((!liveFlow) && (Jerk_M15 != 0 || Jerk_M5 != 0 || bullDisplacement || bearDisplacement)));

   if(monsterCondition)
     {
      int direction = 0;
      if(g_R7 == R7_STRONG_UP)   direction =  1;
      if(g_R7 == R7_STRONG_DOWN) direction = -1;
      if(g_R7 == R7_EXPANSION && DC_Bias != 0) direction = DC_Bias;

      if(direction == 0 && liveFlow)
         direction = (flowScore > 0.0) ? 1 : -1;

      if(direction == 0)
        {
         if(bullDisplacement && !bearDisplacement) direction =  1;
         else if(bearDisplacement && !bullDisplacement) direction = -1;
         else if(Jerk_M15 != 0) direction = Jerk_M15;
         else direction = Jerk_M5;
        }

      if(direction != 0)
        {
         double dayOpen  = TfOpen(PERIOD_D1, 0);
         double dayClose = TfClose(PERIOD_D1, 0);
         if(dayOpen > 0.0 && dayClose > 0.0)
           {
            if((dayClose - dayOpen) > CurrentATR15 * 0.50 && direction == -1) direction = 1;
            if((dayOpen - dayClose) > CurrentATR15 * 0.50 && direction ==  1) direction = -1;
           }
        }

      if(direction != 0)
        {
         double score = 58.0;
         if(direction == m15Direction) score += 8.0;
         if(direction == m5Direction)  score += 8.0;
         if((direction ==  1 && bullDisplacement) || (direction == -1 && bearDisplacement)) score += 12.0;
         if((direction ==  1 && bullMSS) || (direction == -1 && bearMSS)) score += 6.0;
         if(liveFlow && gFlow.persistence >= 0.50) score += 7.0;
         if(liveFlow && (CVDVelocityNormalized * direction) >= 0.20) score += 5.0;
         CurrentMoveState = 3;
         CurrentDirection = direction;
         CurrentMoveScore = Clamp(score, 0.0, 100.0);
         CurrentDirectionSource = 2;
         return;
        }
     }

   // BREAKOUT
   if(rangeRatio >= 1.15)
     {
      int direction = 0;
      if(bullDisplacement && !bearDisplacement) direction =  1;
      else if(bearDisplacement && !bullDisplacement) direction = -1;
      else direction = flowDirection;

      if(direction != 0)
        {
         double score = 48.0;
         if(direction == m15Direction) score += 10.0;
         if(direction == m5Direction)  score += 10.0;
         if((direction ==  1 && bullMSS) || (direction == -1 && bearMSS)) score += 8.0;
         if(FactorAFlowConfirms(direction, false)) score += 18.0;
         if(NearStoredZone(direction, 1.0)) score += 4.0;
         CurrentMoveState = 3;
         CurrentDirection = direction;
         CurrentMoveScore = Clamp(score, 0.0, 100.0);
         CurrentDirectionSource = 3;
         return;
        }
     }

   // CONTINUATION
   if(m15Direction != 0 && m5Direction == m15Direction &&
      ((m15Direction == 1 && bullDisplacement) || (m15Direction == -1 && bearDisplacement)))
     {
      int direction = m15Direction;
      double score = 48.0;
      if((direction ==  1 && bullMSS) || (direction == -1 && bearMSS)) score += 8.0;
      if((direction ==  1 && bullFVG) || (direction == -1 && bearFVG)) score += 6.0;
      if(FactorAFlowConfirms(direction, false)) score += 18.0;
      if(CombinedDirection == 2 || CombinedDirection == -2) score += 5.0;
      CurrentMoveState = 4;
      CurrentDirection = direction;
      CurrentMoveScore = Clamp(score, 0.0, 100.0);
      CurrentDirectionSource = 4;
      return;
     }

   // COMPRESSION / LIQUIDITY
   double averageRange = 0.0; int rangeCount = 0;
   for(int i = 1; i <= 8; i++)
     {
      double range = TfHigh(PERIOD_M1, i) - TfLow(PERIOD_M1, i);
      if(range > 0.0) { averageRange += range; rangeCount++; }
     }
   if(rangeCount > 0) averageRange /= rangeCount;
   bool compression = (normalATR > 0.0 && averageRange <= normalATR * 0.85);

   if(compression)
     {
      bool liquidity = (MathAbs(flowScore) >= BinanceMinFlowScore) ||
                       (averageTradeRate > 0.0 && gFlow.trade_rate > averageTradeRate);
      CurrentMoveState = liquidity ? 2 : 1;
      if(flowDirection != 0) CurrentDirection = flowDirection;
      else if(m5Direction != 0) CurrentDirection = m5Direction;
      else CurrentDirection = m15Direction;
      CurrentMoveScore = liquidity ? 50.0 : 35.0;
      CurrentDirectionSource = 5;
      return;
     }

   // EXHAUSTION
   if(rangeRatio >= 1.80 && M1Exhaustion())
     {
      CurrentMoveState = 5;
      CurrentDirection = flowDirection;
      CurrentMoveScore = 55.0;
      CurrentDirectionSource = 6;
      return;
     }

   CurrentMoveState = 0;
   CurrentDirection = (flowDirection != 0) ? flowDirection
                     : ((m5Direction != 0) ? m5Direction : m15Direction);
   CurrentMoveScore = 20.0;
   CurrentDirectionSource = 7;
  }

int DetectMode()
  {
   bool bSweep = M1BullSweep(); bool sSweep = M1BearSweep();
   bool bMSS   = M1BullMSS();   bool sMSS   = M1BearMSS();
   bool bDisp  = M1BullDisplacement(); bool sDisp = M1BearDisplacement();

   if(bSweep && bMSS && bDisp) return 3;
   if(sSweep && sMSS && sDisp) return 3;

   double vroc = (BridgeReady() && gBinAux.vroc > 0.0) ? gBinAux.vroc : 0.0;
   double re   = (BridgeReady() && gBinAux.range_exp > 0.0) ? gBinAux.range_exp : 0.0;

   if(vroc >= 4.5 && re >= 2.2) return 2;
   if(vroc >= 2.5 && re >= 1.5) return 1;

   if(g_NVP.valid && NativeVPPriceInVA()) return 0;
   if(gBinVP.valid && VPPriceInVA())      return 0;

   return 1;
  }

//===================================================================
// END OF PART 3 OF 5
//===================================================================

//===================================================================
// SECTION 51 — HARD GATES
//===================================================================
bool HardGatesPass(string engine, int dir)
  {
   if(dir == 0) return false;

   if(UseSMCStructure)
     {
      double smc = VNSMC_StructureScore(dir, engine);
      double floor = SMC_MinSwingScore;
      if(engine == "MONSTER")  floor = SMC_MinMonsterScore;
      if(engine == "REVERSAL") floor = SMC_MinReversalScore;
      if(smc < floor) return false;
     }

   if(!QualityGateAllows(engine, dir)) return false;
   if(!Regime_AllowsEngine(engine))    return false;

   if(BridgeReady())
     {
      if(gBinAux.oi_regime != 0)
        {
         if(dir ==  1 && gBinAux.oi_regime == 2) return false;
         if(dir == -1 && gBinAux.oi_regime == 4) return false;
        }
      if(gBinAux.vpin_regime >= 3) return false;

      if(WallInPath(dir)) return false;

      double fundAbs = MathAbs(gBinAux.funding) * 100.0;
      if(fundAbs >= 0.05)
        {
         if(dir ==  1 && gBinAux.funding > 0.0) return false;
         if(dir == -1 && gBinAux.funding < 0.0) return false;
        }

      if(gBinAux.long_short_ratio > 0.0)
        {
         if(dir ==  1 && gBinAux.long_short_ratio >= 2.00) return false;
         if(dir == -1 && gBinAux.long_short_ratio <= 0.50) return false;
        }
     }
   return true;
  }

//===================================================================
// SECTION 52 — SIZING (continuous compounding + session + recovery)
//===================================================================
double ContinuousGrowthMultiplier()
  {
   if(!UseContinuousCompoundingV2 || StartBalance <= 0.0) return 1.0;
   double growth = AccountInfoDouble(ACCOUNT_BALANCE) / StartBalance;
   if(growth <= 1.0) return 1.0;
   double mult = MathPow(growth, CompoundingExponentV2);
   return Clamp(mult, 1.0, CompoundingMaxMult);
  }

double RiskPercentForEngine(string engine)
  {
   if(engine == "MONSTER")  return MathMin(RiskPct_Monster,  10.0);
   if(engine == "SWING")    return MathMin(RiskPct_Swing,    10.0);
   if(engine == "RANGE")    return MathMin(RiskPct_Range,    10.0);
   if(engine == "REVERSAL") return MathMin(RiskPct_Reversal, 10.0);
   return MathMin(RiskPct_Swing, 10.0);
  }

double BaseLotForEngine(string engine)
  {
   if(engine == "SWING")    return Swing_Lot;
   if(engine == "MONSTER")  return Monster_Lot;
   if(engine == "RANGE")    return Range_Lot;
   if(engine == "REVERSAL") return Reversal_Lot;
   return Swing_Lot;
  }

double MoneyRiskPerLot(double stopDistance)
  {
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE_LOSS);
   if(tickValue <= 0.0) tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || stopDistance <= 0.0) return 0.0;
   return (stopDistance / tickSize) * tickValue;
  }

double CalcLots(string engine, int direction, double slDistance)
  {
   //--- Fixed-lot fallback
   if(!UsePercentRisk)
     {
      double base   = BaseLotForEngine(engine);
      double lots   = base * ContinuousGrowthMultiplier() * SpreadThrottle();
      lots *= Regime_SizeMult();
      lots *= Health_SizeMult();
      lots *= SessionSizeMult();
      lots *= RegimeGateSizeMult(direction);
      return ValidateLot(lots);
     }

   //--- % risk mode
   if(slDistance <= 0.0 || direction == 0) return 0.0;

   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   if(equity <= 0.0) return 0.0;

   double riskPct = RiskPercentForEngine(engine);
   double moneyRisk = equity * riskPct / 100.0;

   if(UseRecoveryModeV2)
      moneyRisk = Recovery_RiskUSD(moneyRisk);

   if(moneyRisk <= 0.0) return 0.0;

   double entry = (direction > 0) ? AskPrice() : BidPrice();
   if(entry <= 0.0) return 0.0;
   double stop = (direction > 0) ? entry - slDistance : entry + slDistance;

   ENUM_ORDER_TYPE type = (direction > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   double lossPerLot = 0.0;
   double profit = 0.0;
   if(OrderCalcProfit(type, _Symbol, 1.0, entry, stop, profit))
      lossPerLot = MathAbs(profit);
   if(lossPerLot <= 0.0) lossPerLot = MoneyRiskPerLot(slDistance);
   if(lossPerLot <= 0.0) return 0.0;

   double rawLots = moneyRisk / lossPerLot;
   rawLots *= SpreadThrottle();
   rawLots *= Regime_SizeMult();
   rawLots *= Health_SizeMult();
   rawLots *= ContinuousGrowthMultiplier();
   rawLots *= SessionSizeMult();
   rawLots *= RegimeGateSizeMult(direction);

   return ValidateLot(rawLots);
  }

//===================================================================
// SECTION 53 — SL / TP COMPUTATION [S1: spread-aware]
//===================================================================
double SL_ATR_Mult_ForEngine(string engine)
  {
   if(engine == "TREND" || engine == "SWING") return SL_ATR_Swing;
   if(engine == "MONSTER")  return SL_ATR_Monster;
   if(engine == "RANGE")    return SL_ATR_Range;
   if(engine == "REVERSAL") return SL_ATR_Reversal;
   return SL_ATR_Swing;
  }

double SL_Floor_USC(string engine)
  {
   if(engine == "TREND" || engine == "SWING") return 400.0;
   if(engine == "MONSTER")  return 700.0;
   if(engine == "RANGE")    return 250.0;
   if(engine == "REVERSAL") return 150.0;
   return 400.0;
  }

double ComputeSLDistance(string engine)
  {
   double atr = CurrentATR5;
   if(atr <= 0.0) atr = CurrentATR1;
   if(atr <= 0.0) atr = 100.0 * _Point;
   double slByATR    = atr * SL_ATR_Mult_ForEngine(engine);
   // SlippagePoints is an execution-deviation limit only. Do not inflate the
   // protective stop with the allowed execution deviation. Stop distance is
   // governed by ATR, current spread, broker stop level and the safety floor.
   double slBySpread = MathMax(0.0, CurrentSpreadPoints) * _Point * SL_SpreadMultiplier;
   double slByMin    = atr * SL_MinATR;
   double sl = MathMax(slByATR, MathMax(slBySpread, slByMin));
   double cap = SL_MaxUSC * _Point * 100.0;
   if(sl > cap) sl = cap;

   //--- [S1] spread floor: SL ≥ 3× current spread
   sl = SafeSLDistance(sl);
   return sl;
  }

double TP_RR_ForEngine(string engine)
  {
   if(engine == "SWING")    return TP_RR_Swing;
   if(engine == "MONSTER")  return TP_RR_Monster;
   if(engine == "RANGE")    return TP_RR_Range;
   if(engine == "REVERSAL") return TP_RR_Reversal;
   return TP_RR_Swing;
  }

double ComputeTPDistance(string engine, double slDistance)
  {
   double tp = slDistance * TP_RR_ForEngine(engine);
   double minTp = StopsLevelPrice() * 1.5;
   if(tp < minTp) tp = minTp;

   //--- [S1] spread floor: TP ≥ 2× current spread
   tp = SafeTPDistance(tp, slDistance);
   return tp;
  }

//===================================================================
// SECTION 54 — EXPOSURE COUNTERS
//===================================================================
int CountOurPositions()
  {
   int c = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      c++;
     }
   return c;
  }

double TotalOurLots()
  {
   double lots = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      lots += posInfo.Volume();
     }
   return lots;
  }

int CountEnginePositions(string prefix)
  {
   int c = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), prefix) >= 0) c++;
     }
   return c;
  }

int CountEngineOrders(string prefix)
  {
   int c = 0;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol) continue;
      if(ordInfo.Magic() != MagicNumber) continue;
      if(StringFind(ordInfo.Comment(), prefix) >= 0) c++;
     }
   return c;
  }

int CountPendingTotal()
  {
   int c = 0;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol) continue;
      if(ordInfo.Magic() != MagicNumber) continue;
      c++;
     }
   return c;
  }

double PrefixFloatingPnL(string prefix)
  {
   double pnl = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), prefix) < 0) continue;
      pnl += posInfo.Profit() + posInfo.Swap() + posInfo.Commission();
     }
   return pnl;
  }

void CloseEnginePositions(string prefix)
  {
   DeleteOrdersPrefix(prefix);
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), prefix) < 0) continue;
      trade.PositionClose(posInfo.Ticket());
     }
  }

void CancelOtherEnginePendingOrders(string activePrefix)
  {
   string all[4] = {"SWING_","MONSTER_","RANGE_","REVERSAL_"};
   for(int i = 0; i < 4; i++)
     {
      if(all[i] == activePrefix) continue;
      DeleteOrdersPrefix(all[i]);
     }
  }

void CancelOppositePendingOrders(string prefix, int filledDirection)
  {
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol) continue;
      if(ordInfo.Magic() != MagicNumber) continue;
      if(StringFind(ordInfo.Comment(), prefix) < 0) continue;
      ENUM_ORDER_TYPE ot = ordInfo.OrderType();
      bool opposite = false;
      if(filledDirection ==  1 && (ot == ORDER_TYPE_SELL_STOP || ot == ORDER_TYPE_SELL_LIMIT))
         opposite = true;
      if(filledDirection == -1 && (ot == ORDER_TYPE_BUY_STOP  || ot == ORDER_TYPE_BUY_LIMIT))
         opposite = true;
      if(opposite) trade.OrderDelete(ordInfo.Ticket());
     }
  }

int EngineIndexFromName(string engine)
  {
   if(engine == "SWING")    return 0;
   if(engine == "MONSTER")  return 1;
   if(engine == "RANGE")    return 2;
   if(engine == "REVERSAL") return 3;
   return -1;
  }

int EngineIndexFromComment(string comment)
  {
   if(StringFind(comment, "SWING_")    >= 0) return 0;
   if(StringFind(comment, "MONSTER_")  >= 0) return 1;
   if(StringFind(comment, "RANGE_")    >= 0) return 2;
   if(StringFind(comment, "REVERSAL_") >= 0) return 3;
   return -1;
  }

double CalculateBasketRiskUSD(string prefix)
  {
   double risk = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), prefix) < 0) continue;
      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(open <= 0.0 || stop <= 0.0) continue;
      double vol = posInfo.Volume();
      double loss = 0.0;
      ENUM_ORDER_TYPE type = (posInfo.PositionType() == POSITION_TYPE_BUY)
                             ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
      if(OrderCalcProfit(type, _Symbol, vol, open, stop, loss)) risk += MathAbs(loss);
     }
   return risk;
  }

int BasketEngineIndex(string engine) { return EngineIndexFromName(engine); }

double EngineBasketRiskR(string engine, int which)
  {
   if(engine == "SWING")
     {
      if(which == 0) return SwingBasketBE_R;
      if(which == 1) return SwingBasketTrail_R;
      return SwingBasketStep_R;
     }
   if(engine == "MONSTER")
     {
      if(which == 0) return MonsterBasketBE_R;
      if(which == 1) return MonsterBasketTrail_R;
      return MonsterBasketStep_R;
     }
   if(engine == "RANGE")
     {
      if(which == 0) return RangeBasketBE_R;
      if(which == 1) return RangeBasketTrail_R;
      return RangeBasketStep_R;
     }
   if(which == 0) return ReversalBasketBE_R;
   if(which == 1) return ReversalBasketTrail_R;
   return ReversalBasketStep_R;
  }

bool EngineBudgetOK(string engine)
  {
   int idx = EngineIndexFromName(engine);
   if(idx < 0) return true;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(eq <= 0.0) return true;
   double lossPct = g_EnginePnLToday[idx] / eq * 100.0;
   double limit = -100.0;
   if(idx == 0) limit = SwingBudgetPct;
   if(idx == 1) limit = MonsterBudgetPct;
   if(idx == 2) limit = RangeBudgetPct;
   if(idx == 3) limit = ReversalBudgetPct;
   return (lossPct > limit);
  }

bool EngineCooldownOK(string engine)
  {
   int idx = EngineIndexFromName(engine);
   if(idx < 0) return true;
   return (TimeCurrent() >= g_EngineCooldown[idx]);
  }

void RecordEngineWin(string engine)
  {
   int idx = EngineIndexFromName(engine);
   if(idx < 0) return;
   g_EngineLossStreak[idx] = 0;
   g_EngineWinStreak[idx]++;
  }

void RecordEngineLoss(string engine)
  {
   int idx = EngineIndexFromName(engine);
   if(idx < 0) return;
   g_EngineLossStreak[idx]++;
   g_EngineWinStreak[idx] = 0;
   if(g_EngineLossStreak[idx] >= 3)
     {
      g_EngineCooldown[idx] = TimeCurrent() + Cooldown_EngineAfterLoss;
      g_EngineLossStreak[idx] = 0;
      PrintFormat("[COOLDOWN] %s paused %d min", engine, Cooldown_EngineAfterLoss / 60);
     }
  }

//===================================================================
// V3.4 — DIRECTIONAL HIGHER-TIMEFRAME ALIGNMENT
// M1 still times the trigger. Directional MONSTER/SWING orders need the
// completed M5 direction to agree; completed M15 context may be neutral but
// must not directly oppose. RANGE and REVERSAL retain their dedicated routes.
//===================================================================
bool V3_HTFEntryGate(string engine, int dir)
  {
   if(dir == 0) return false;
   if(engine != "MONSTER" && engine != "SWING") return true;
   if(!UseM5Confirm && !UseMTFConfluence) return true;

   int m5Dir = M5Direction;
   if(m5Dir == 0 && g_SMC.m5_bias != 0) m5Dir = g_SMC.m5_bias;
   int m15Dir = M15Direction;
   if(m15Dir == 0 && g_SMC.m15_bias != 0) m15Dir = g_SMC.m15_bias;

   if(UseM5Confirm && m5Dir != dir)
     {
      PrintFormat("[V3.5 HTF BLOCK] engine=%s dir=%s M5=%d M15=%d reason=M5_not_aligned",engine,DirStr(dir),m5Dir,m15Dir);
      return false;
     }
   if(UseMTFConfluence && m15Dir == -dir)
     {
      PrintFormat("[V3.5 HTF BLOCK] engine=%s dir=%s M5=%d M15=%d reason=M15_opposes",engine,DirStr(dir),m5Dir,m15Dir);
      return false;
     }
   return true;
  }

//===================================================================
// SECTION 55 — MASTER ENTRY GATE [B4: msg budget gate]
//===================================================================
bool EntryAllowed(string engine, double lots, int dir)
  {
   static datetime lastLog[4] = {0,0,0,0};
   int dbgIdx = EngineIndexFromName(engine);
   datetime nowT = TimeCurrent();

   #define BLOCK_LOG(reason) \
      if(dbgIdx >= 0 && nowT - lastLog[dbgIdx] > 5) \
        { PrintFormat("[BLOCK] %s: %s", engine, reason); lastLog[dbgIdx] = nowT; }

   if(!Health_AllowsNewEntries())                { BLOCK_LOG("health");       return false; }
   if(TimeCurrent() < PauseUntil)                { BLOCK_LOG("pause");        return false; }
   if(DailyHalted)                               { BLOCK_LOG("daily_halt");   return false; }
   if(GlobalHalted)                              { BLOCK_LOG("global_halt");  return false; }

   if(BridgeReady() && gBinAux.vpin_regime >= 3) { BLOCK_LOG("vpin_burst");   return false; }

   if(CurrentSpreadPoints > HardMaxSpreadPoints) { BLOCK_LOG("spread_hard");  return false; }
   if(RejectIfSpreadExpands && SpreadAveragePoints > 0.0 &&
      CurrentSpreadPoints > SpreadAveragePoints * 1.80)
     { BLOCK_LOG("spread_expand"); return false; }

   if(!SessionAllowed()) { BLOCK_LOG("session");    return false; }
   if(!HourFilterOK())   { BLOCK_LOG("hour");       return false; }
   if(WickPauseActive()) { BLOCK_LOG("wick_pause"); return false; }

   if(M1Exhaustion() && engine != "MONSTER")
     { BLOCK_LOG("m1_exhaust"); return false; }

   if(CountOurPositions() >= 2)                    { BLOCK_LOG("exposure_pos"); return false; }
   if(CountEnginePositions(engine + "_") >= 1)     { BLOCK_LOG("engine_pos");   return false; }
   if(CountPendingTotal() >= MaxPendingTotal)      { BLOCK_LOG("pend_cap");     return false; }
   if(TotalOurLots() + lots > CapTotalLots() + 1e-12)
     { BLOCK_LOG("total_lots"); return false; }

   if(g_LastPlaceTime > 0 && TimeCurrent() - g_LastPlaceTime < MinSecondsBetweenPlaces)
     { BLOCK_LOG("min_seconds"); return false; }

   if(LastLossTime > 0 && TimeCurrent() - LastLossTime < Cooldown_Loss)
     { BLOCK_LOG("loss_cooldown"); return false; }
   if(LastWinTime  > 0 && TimeCurrent() - LastWinTime  < Cooldown_Win)
     { BLOCK_LOG("win_cooldown");  return false; }

   //--- Tier 1: regime and completed higher-timeframe alignment gates
   if(!RegimeGateAllows(dir, engine))
     { BLOCK_LOG("regime_gate"); return false; }
   if(!V3_HTFEntryGate(engine, dir))
     { BLOCK_LOG("htf_alignment"); return false; }
   if(!KronosConfirmAllows(engine,dir))
     { BLOCK_LOG("kronos_confirm"); return false; }
   if(g_KronosChopEscapeActive && (engine=="MONSTER" || engine=="SWING") && dir!=g_KronosChopEscapeDir)
     { BLOCK_LOG("kronos_chop_direction"); return false; }

   if(!M15VetoAllows(dir)) { BLOCK_LOG("m15_veto"); return false; }
   if(!H1VetoAllows(dir))  { BLOCK_LOG("h1_veto");  return false; }
   if(ChaosTriggered())    { BLOCK_LOG("chaos");    return false; }

   //--- [B4] msg budget gate
   if(!MsgBudget_CanTrade()) { BLOCK_LOG("msg_budget"); return false; }

   return true;

   #undef BLOCK_LOG
  }

//===================================================================
// SECTION 56 — VETO LAYER (M15 / H1)
//===================================================================
bool M15VetoAllows(int dir)
  {
   if(!UseM15Veto || dir == 0) return true;

   if(UseSMCStructure)
     {
      bool biasOpp = (g_SMC.m15_bias == -dir);
      bool freshOpp = (g_SMC.m15_event == -dir) &&
                      (TimeCurrent() - g_SMC.m15_event_time <= M15VetoEventAgeMin * 60);
      if(biasOpp && freshOpp) return false;
     }

   double adx15 = BufVal(hADX_M15, 0, 1);
   double pdi   = BufVal(hADX_M15, 1, 1);
   double mdi   = BufVal(hADX_M15, 2, 1);
   if(adx15 >= M15VetoADXMin)
     {
      if(dir ==  1 && mdi > pdi) return false;
      if(dir == -1 && pdi > mdi) return false;
     }

   if(MSSFresh(-dir)) return false;

   return true;
  }

bool H1VetoAllows(int dir)
  {
   if(!UseH1Veto || dir == 0) return true;
   static datetime h1BiasTime = 0;
   static int      h1Bias     = 0;
   datetime h1Bar = TfTime(PERIOD_H1, 0);
   if(h1Bar != h1BiasTime)
     {
      h1BiasTime = h1Bar;
      double h1_high=0, h1_prevH=0, h1_low=0, h1_prevL=0;
      int evt; datetime evtT;
      h1Bias = VNSMC_StructureBias(PERIOD_H1, 60, evt, h1_high, h1_low, evtT);
     }
   if(h1Bias == -dir) return false;
   return true;
  }

//===================================================================
// SECTION 57 — TRADE RESULT / FILLING HELPERS
//===================================================================
bool TradeResultOK(bool requestResult)
  {
   uint rc = trade.ResultRetcode();
   return (requestResult &&
          (rc == TRADE_RETCODE_DONE ||
           rc == TRADE_RETCODE_DONE_PARTIAL ||
           rc == TRADE_RETCODE_PLACED));
  }

bool IsFillingAllowed(int symFillConst)
  {
   int filling = (int)SymbolInfoInteger(_Symbol, SYMBOL_FILLING_MODE);
   return ((filling & symFillConst) == symFillConst);
  }

bool IsTransientRetcode(uint rc)
  {
   return (rc == TRADE_RETCODE_REQUOTE       ||
           rc == TRADE_RETCODE_REJECT        ||
           rc == TRADE_RETCODE_PRICE_CHANGED ||
           rc == TRADE_RETCODE_PRICE_OFF     ||
           rc == TRADE_RETCODE_TIMEOUT       ||
           rc == TRADE_RETCODE_CONNECTION    ||
           rc == TRADE_RETCODE_TOO_MANY_REQUESTS);
  }

//===================================================================
// SECTION 58 — REQUEST BUILDER
//===================================================================
void BuildReq(MqlTradeRequest &req,
              ENUM_TRADE_REQUEST_ACTIONS act,
              ENUM_ORDER_TYPE type,
              double price,
              double lots,
              double sl,
              double tp,
              string cmt)
  {
   ZeroMemory(req);
   req.action    = act;
   req.symbol    = _Symbol;
   req.type      = type;
   req.volume    = lots;
   req.price     = price;
   req.sl        = sl;
   req.tp        = tp;
   req.deviation = (ulong)SlippagePoints;
   req.magic     = (ulong)MagicNumber;
   req.comment   = cmt;

   if(act == TRADE_ACTION_PENDING)
     {
      req.type_time  = ORDER_TIME_GTC;
      req.expiration = 0;

      if(IsFillingAllowed(SYMBOL_FILLING_FOK))
         req.type_filling = ORDER_FILLING_FOK;
      else if(IsFillingAllowed(SYMBOL_FILLING_IOC))
         req.type_filling = ORDER_FILLING_IOC;
      else
         req.type_filling = ORDER_FILLING_RETURN;
     }
   else
     {
      if(IsFillingAllowed(SYMBOL_FILLING_FOK))
         req.type_filling = ORDER_FILLING_FOK;
      else if(IsFillingAllowed(SYMBOL_FILLING_IOC))
         req.type_filling = ORDER_FILLING_IOC;
      else
         req.type_filling = ORDER_FILLING_RETURN;
     }
  }

bool OrderCheckPass(MqlTradeRequest &req)
  {
   if(!UseOrderCheckBeforeSendV2) return true;

   MqlTradeCheckResult check;
   ZeroMemory(check);
   if(!OrderCheck(req, check))
     {
      PrintFormat("[ORDERCHECK] %s ret=%u", check.comment, check.retcode);
      return false;
     }
   return true;
  }

//===================================================================
// BGBI PERFECT V2 — ACCOUNT-WIDE RISK RESERVATION
//===================================================================
string V2_RiskLockName()
  {
   return "BGP2RL_" + IntegerToString((long)AccountInfoInteger(ACCOUNT_LOGIN)) + "_" + IntegerToString(MagicNumber);
  }

bool V2_AcquireRiskLock(string &lockName, double &lockToken)
  {
   lockName = V2_RiskLockName();
   lockToken = 0.0;
   if(!GlobalVariableCheck(lockName)) GlobalVariableSet(lockName, 0.0);
   datetime nowStamp = TimeLocal();
   for(int attempt=0; attempt<20; attempt++)
     {
      double current = GlobalVariableGet(lockName);
      datetime nowTime = TimeLocal();
      bool freeLock = (current == 0.0);
      bool staleLock = (current > 0.0 && nowTime > (datetime)current && (nowTime-(datetime)current) > 30);
      if(freeLock || staleLock)
        {
         // Fractional suffix makes concurrent attempts distinct while preserving an epoch-based 30-second stale timeout to avoid stealing the lock during slow multi-order batches.
         double token = (double)nowStamp + 0.001*(double)(attempt+1);
         if(GlobalVariableSetOnCondition(lockName, token, current))
           { lockToken = token; return true; }
        }
      Sleep(5);
      nowStamp = TimeLocal();
     }
   Print("[V2 RISK] account risk lock busy; order deferred safely");
   return false;
  }

void V2_ReleaseRiskLock(string lockName, double lockToken)
  {
   if(lockName == "" || lockToken <= 0.0 || !GlobalVariableCheck(lockName)) return;
   double current = GlobalVariableGet(lockName);
   if(MathAbs(current-lockToken) < 0.1) GlobalVariableSetOnCondition(lockName, 0.0, lockToken);
  }

bool V2_IsBuyOrderType(ENUM_ORDER_TYPE type)
  {
   return (type == ORDER_TYPE_BUY || type == ORDER_TYPE_BUY_LIMIT || type == ORDER_TYPE_BUY_STOP || type == ORDER_TYPE_BUY_STOP_LIMIT);
  }

int V2_CountAccountPositions()
  {
   int count=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Magic() != MagicNumber) continue;
      count++;
     }
   return count;
  }

int V2_CountAccountPendingOrders()
  {
   int count=0;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0) continue;
      if((long)OrderGetInteger(ORDER_MAGIC) != MagicNumber) continue;
      ENUM_ORDER_TYPE type=(ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      if(type==ORDER_TYPE_BUY_LIMIT || type==ORDER_TYPE_SELL_LIMIT ||
         type==ORDER_TYPE_BUY_STOP || type==ORDER_TYPE_SELL_STOP ||
         type==ORDER_TYPE_BUY_STOP_LIMIT || type==ORDER_TYPE_SELL_STOP_LIMIT)
         count++;
     }
   return count;
  }

double V2_MoneyRiskAtSL(string symbol, bool isBuy, double volume, double entry, double sl)
  {
   if(volume<=0.0 || entry<=0.0 || sl<=0.0 || symbol=="") return AccountInfoDouble(ACCOUNT_EQUITY)*10.0;
   if(!SymbolSelect(symbol,true)) { /* fall through to tick-value calculation */ }
   ENUM_ORDER_TYPE marketType = isBuy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   double pl=0.0;
   double loss=0.0;
   if(OrderCalcProfit(marketType,symbol,volume,entry,sl,pl)) loss=MathMax(0.0,-pl);
   if(loss<=0.0)
     {
      double tickSize=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
      double tickValue=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE_LOSS);
      if(tickValue<=0.0) tickValue=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE);
      if(tickSize<=0.0 || tickValue<=0.0) return AccountInfoDouble(ACCOUNT_EQUITY)*10.0;
      loss=MathMax(0.0,MathAbs(entry-sl)/tickSize*tickValue*volume);
      if((isBuy && sl>=entry) || (!isBuy && sl<=entry)) loss=0.0;
     }
   double tickSize=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
   double tickValue=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE);
   double bid=SymbolInfoDouble(symbol,SYMBOL_BID), ask=SymbolInfoDouble(symbol,SYMBOL_ASK);
   double spreadCost=0.0;
   if(tickSize>0.0 && tickValue>0.0 && ask>=bid && bid>0.0)
      spreadCost=((ask-bid)/tickSize)*tickValue*volume;
   // Keep a transaction-cost reserve even after a profitable stop is moved beyond entry.
   double total=loss*(1.0+MathMax(0.0,RiskCostReservePctV2)/100.0) + spreadCost;
   return MathMax(0.0,total);
  }

double V2_CurrentRiskMoney(bool symbolOnly)
  {
   double total=0.0;
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Magic()!=MagicNumber) continue;
      string symbol=posInfo.Symbol();
      if(symbolOnly && symbol!=_Symbol) continue;
      double sl=posInfo.StopLoss();
      if(sl<=0.0) return equity*10.0; // unprotected BGBI position blocks new risk
      bool isBuy=(posInfo.PositionType()==POSITION_TYPE_BUY);
      total += V2_MoneyRiskAtSL(symbol,isBuy,posInfo.Volume(),posInfo.PriceOpen(),sl);
     }
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0) continue;
      if((long)OrderGetInteger(ORDER_MAGIC)!=MagicNumber) continue;
      string symbol=OrderGetString(ORDER_SYMBOL);
      if(symbolOnly && symbol!=_Symbol) continue;
      ENUM_ORDER_TYPE type=(ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      if(type!=ORDER_TYPE_BUY_LIMIT && type!=ORDER_TYPE_SELL_LIMIT &&
         type!=ORDER_TYPE_BUY_STOP && type!=ORDER_TYPE_SELL_STOP &&
         type!=ORDER_TYPE_BUY_STOP_LIMIT && type!=ORDER_TYPE_SELL_STOP_LIMIT) continue;
      double sl=OrderGetDouble(ORDER_SL);
      if(sl<=0.0) return equity*10.0; // pending without SL is not accepted as safe exposure
      double entry=OrderGetDouble(ORDER_PRICE_OPEN);
      double volume=OrderGetDouble(ORDER_VOLUME_CURRENT);
      if(volume<=0.0) volume=OrderGetDouble(ORDER_VOLUME_INITIAL);
      total += V2_MoneyRiskAtSL(symbol,V2_IsBuyOrderType(type),volume,entry,sl);
     }
   return total;
  }

//===================================================================
// BGBI PERFECT V3 — PROFILE IDENTITY / INPUT VALIDATION
//===================================================================
bool V3_ProfileMatchesChart()
  {
   string expected=V3ExpectedSymbolProfile;
   StringToUpper(expected);
   string chart=_Symbol;
   StringToUpper(chart);
   if(expected!="" && expected!="AUTO" && StringFind(chart,expected)!=0)
     {
      PrintFormat("[V3 PROFILE MISMATCH] expected=%s chart=%s; new entries blocked, position management remains active",expected,_Symbol);
      return false;
     }
   bool cryptoExpected=(V3ExpectedCryptoPort>0);
   if(UseBinanceFlow && !cryptoExpected)
     {
      PrintFormat("[V3 PROFILE MISMATCH] Binance flow enabled for non-crypto profile %s; new entries blocked",_Symbol);
      return false;
     }
   if(UseBinanceFlow && cryptoExpected)
     {
      string portNeed=":"+IntegerToString(V3ExpectedCryptoPort);
      if(StringFind(BinanceBaseURL,portNeed)<0)
        {
         PrintFormat("[V3 BRIDGE MISMATCH] expected port=%d URL=%s; new entries blocked",V3ExpectedCryptoPort,BinanceBaseURL);
         return false;
        }
     }
   return true;
  }

// Snapshot same-symbol/same-magic pending tickets for an atomic batch attempt.
int V3_SnapshotPendingTickets(ulong &tickets[])
  {
   ArrayResize(tickets,0);
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0) continue;
      if(OrderGetString(ORDER_SYMBOL)!=_Symbol) continue;
      if((long)OrderGetInteger(ORDER_MAGIC)!=MagicNumber) continue;
      ENUM_ORDER_TYPE type=(ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      if(type!=ORDER_TYPE_BUY_LIMIT && type!=ORDER_TYPE_SELL_LIMIT &&
         type!=ORDER_TYPE_BUY_STOP && type!=ORDER_TYPE_SELL_STOP &&
         type!=ORDER_TYPE_BUY_STOP_LIMIT && type!=ORDER_TYPE_SELL_STOP_LIMIT) continue;
      int n=ArraySize(tickets); ArrayResize(tickets,n+1); tickets[n]=ticket;
     }
   return ArraySize(tickets);
  }

bool V3_TicketWasPresent(ulong ticket,const ulong &beforeTickets[])
  {
   for(int i=0;i<ArraySize(beforeTickets);i++) if(beforeTickets[i]==ticket) return true;
   return false;
  }

int V3_RollbackNewPendingOrders(string commentPrefix,const ulong &beforeTickets[])
  {
   int removed=0;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0) continue;
      if(OrderGetString(ORDER_SYMBOL)!=_Symbol || (long)OrderGetInteger(ORDER_MAGIC)!=MagicNumber) continue;
      if(StringFind(OrderGetString(ORDER_COMMENT),commentPrefix)!=0) continue;
      ENUM_ORDER_TYPE type=(ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      if(type!=ORDER_TYPE_BUY_LIMIT && type!=ORDER_TYPE_SELL_LIMIT &&
         type!=ORDER_TYPE_BUY_STOP && type!=ORDER_TYPE_SELL_STOP &&
         type!=ORDER_TYPE_BUY_STOP_LIMIT && type!=ORDER_TYPE_SELL_STOP_LIMIT) continue;
      if(V3_TicketWasPresent(ticket,beforeTickets)) continue;
      if(trade.OrderDelete(ticket)) { MsgBudget_TickDelete(); removed++; }
      else PrintFormat("[V3 BATCH ROLLBACK FAIL] ticket=%I64u prefix=%s ret=%u %s",ticket,commentPrefix,trade.ResultRetcode(),trade.ResultRetcodeDescription());
     }
   return removed;
  }

// Shared account safety state: same terminal login + magic, across all configured pair charts.
string V3_AccountSafetyKey(string suffix)
  {
   return "BGP3_"+IntegerToString((long)AccountInfoInteger(ACCOUNT_LOGIN))+"_"+IntegerToString(MagicNumber)+"_"+suffix;
  }

void V3_SyncAccountSafetyState()
  {
   if(!V3SharedAccountSafetyState) return;
   string lockName=""; double lockToken=0.0;
   if(!V2_AcquireRiskLock(lockName,lockToken)) return;
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   double balance=AccountInfoDouble(ACCOUNT_BALANCE);
   int today=(int)(TimeCurrent()/86400);
   string startKey=V3_AccountSafetyKey("START");
   string dayKey=V3_AccountSafetyKey("DAY");
   string dayEqKey=V3_AccountSafetyKey("DAYEQ");
   string peakKey=V3_AccountSafetyKey("PEAK");
   string dailyKey=V3_AccountSafetyKey("DH");
   string globalKey=V3_AccountSafetyKey("GH");
   string pauseKey=V3_AccountSafetyKey("PAUSE");
   if(!GlobalVariableCheck(startKey)) GlobalVariableSet(startKey,(StartBalance>0.0?StartBalance:balance));
   if(!GlobalVariableCheck(dayKey)) GlobalVariableSet(dayKey,(double)today);
   if(!GlobalVariableCheck(dayEqKey)) GlobalVariableSet(dayEqKey,equity);
   if(!GlobalVariableCheck(peakKey)) GlobalVariableSet(peakKey,equity);
   if(!GlobalVariableCheck(dailyKey)) GlobalVariableSet(dailyKey,0.0);
   if(!GlobalVariableCheck(globalKey)) GlobalVariableSet(globalKey,0.0);
   if(!GlobalVariableCheck(pauseKey)) GlobalVariableSet(pauseKey,0.0);
   if((int)GlobalVariableGet(dayKey)!=today)
     {
      GlobalVariableSet(dayEqKey,equity);
      GlobalVariableSet(dayKey,(double)today);
      GlobalVariableSet(dailyKey,0.0);
      GlobalVariableSet(globalKey,0.0);
     }
   if(equity>GlobalVariableGet(peakKey)) GlobalVariableSet(peakKey,equity);
   StartBalance=GlobalVariableGet(startKey);
   DayStartEquity=GlobalVariableGet(dayEqKey);
   PeakEquity=GlobalVariableGet(peakKey);
   DailyHalted=(GlobalVariableGet(dailyKey)>0.5);
   GlobalHalted=(GlobalVariableGet(globalKey)>0.5);
   datetime sharedPause=(datetime)GlobalVariableGet(pauseKey);
   if(sharedPause>PauseUntil) PauseUntil=sharedPause;
   else if(PauseUntil>sharedPause) GlobalVariableSet(pauseKey,(double)PauseUntil);
   V2_ReleaseRiskLock(lockName,lockToken);
  }

void V3_PersistAccountSafetyState()
  {
   if(!V3SharedAccountSafetyState) return;
   string lockName=""; double lockToken=0.0;
   if(!V2_AcquireRiskLock(lockName,lockToken))
     {
      // The local safety action still applies on this chart; next tick retries shared persistence.
      return;
     }
   string startKey=V3_AccountSafetyKey("START");
   string dayKey=V3_AccountSafetyKey("DAY");
   string dayEqKey=V3_AccountSafetyKey("DAYEQ");
   string peakKey=V3_AccountSafetyKey("PEAK");
   string dailyKey=V3_AccountSafetyKey("DH");
   string globalKey=V3_AccountSafetyKey("GH");
   string pauseKey=V3_AccountSafetyKey("PAUSE");
   if(!GlobalVariableCheck(startKey)) GlobalVariableSet(startKey,StartBalance>0.0?StartBalance:AccountInfoDouble(ACCOUNT_BALANCE));
   if(!GlobalVariableCheck(dayKey)) GlobalVariableSet(dayKey,(double)TodayStamp);
   if(!GlobalVariableCheck(dayEqKey)) GlobalVariableSet(dayEqKey,DayStartEquity);
   if(!GlobalVariableCheck(peakKey)) GlobalVariableSet(peakKey,PeakEquity);
   if(PeakEquity>GlobalVariableGet(peakKey)) GlobalVariableSet(peakKey,PeakEquity);
   if(DailyHalted) GlobalVariableSet(dailyKey,1.0);
   if(GlobalHalted) GlobalVariableSet(globalKey,1.0);
   if(PauseUntil>(datetime)GlobalVariableGet(pauseKey)) GlobalVariableSet(pauseKey,(double)PauseUntil);
   V2_ReleaseRiskLock(lockName,lockToken);
  }


bool V2_RiskGovernorCanPlace(bool isBuy, double lots, double entry, double sl, string comment)
  {
   if(!UsePortfolioRiskGovernorV2) return true;
   if(entry<=0.0 || sl<=0.0 || (isBuy && sl>=entry) || (!isBuy && sl<=entry))
     { PrintFormat("[V2 RISK] invalid stop geometry %s entry=%.5f SL=%.5f side=%s",comment,entry,sl,(isBuy?"BUY":"SELL")); return false; }
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   if(equity<=0.0) { Print("[V2 RISK] invalid equity"); return false; }
   if(BidPrice()<=0.0 || AskPrice()<=0.0 || AskPrice()<BidPrice())
     { PrintFormat("[V2 RISK] invalid broker quotes for %s",comment); return false; }
   if(MaxAccountPositionsV2>0 && V2_CountAccountPositions()>=MaxAccountPositionsV2)
     { PrintFormat("[V2 RISK] account position cap blocks %s",comment); return false; }
   if(UseAccountWidePendingCapV2 && MaxAccountPendingOrdersV2>0 && V2_CountAccountPendingOrders()>=MaxAccountPendingOrdersV2)
     { PrintFormat("[V2 RISK] account pending cap blocks %s",comment); return false; }
   if(MaxPendingTotal>0 && CountPendingTotal()>=MaxPendingTotal)
     { PrintFormat("[V2 RISK] symbol pending cap blocks %s",comment); return false; }

   double newRisk=V2_MoneyRiskAtSL(_Symbol,isBuy,lots,entry,sl);
   double singleCap=equity*MaxSingleLegRiskPctV2/100.0;
   if(newRisk<=0.0 || newRisk>singleCap+0.01)
     { PrintFormat("[V2 RISK] single leg rejected %s risk=%.2f cap=%.2f lots=%.4f",comment,newRisk,singleCap,lots); return false; }
   double symbolRisk=V2_CurrentRiskMoney(true);
   double accountRisk=V2_CurrentRiskMoney(false);
   double symbolCap=equity*MaxSymbolCampaignRiskPctV2/100.0;
   double accountCap=equity*MaxPortfolioRiskPctV2/100.0;
   if(symbolRisk+newRisk>symbolCap+0.02)
     { PrintFormat("[V2 RISK] symbol campaign cap rejected %s existing=%.2f new=%.2f cap=%.2f",comment,symbolRisk,newRisk,symbolCap); return false; }
   if(accountRisk+newRisk>accountCap+0.02)
     { PrintFormat("[V2 RISK] portfolio cap rejected %s existing=%.2f new=%.2f cap=%.2f",comment,accountRisk,newRisk,accountCap); return false; }
   return true;
  }

//===================================================================
// SECTION 59 — MARKET ORDER SENDER (V2) [B2: msg budget]
//===================================================================
bool SendMarketV2(int type, double lots, double sl, double tp, string cmt)
  {
   if(lots<=0.0) return false;
   bool isBuy=(type==ORDER_TYPE_BUY);
   double entryRef=isBuy ? AskPrice() : BidPrice();
   string lockName=""; double lockToken=0.0;
   bool localLock=false;
   if(UsePortfolioRiskGovernorV2)
     {
      if(!g_V2BatchLockHeld)
        {
         if(!V2_AcquireRiskLock(lockName,lockToken)) return false;
         localLock=true;
        }
      if(!V2_RiskGovernorCanPlace(isBuy,lots,entryRef,sl,cmt))
        { if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false; }
     }
   if(!MsgBudget_CanSend())
     {
      PrintFormat("[MSGBUDGET] blocked MARKET %s",cmt);
      if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false;
     }
   int attempts=UseTransientRetryV2 ? TransientMaxRetries : 1;
   for(int a=0;a<attempts;a++)
     {
      MqlTradeRequest req;
      BuildReq(req,TRADE_ACTION_DEAL,(ENUM_ORDER_TYPE)type,entryRef,lots,sl,tp,cmt);
      if(!OrderCheckPass(req))
        { if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false; }
      MqlTradeResult res; ZeroMemory(res);
      bool ok=OrderSend(req,res);
      if(ok && (res.retcode==TRADE_RETCODE_DONE || res.retcode==TRADE_RETCODE_PLACED || res.retcode==TRADE_RETCODE_DONE_PARTIAL))
        {
         MsgBudget_TickOpen();
         if(UseSlippageReAnchorV2) Anchor_Store(cmt,entryRef,sl,tp);
         if(localLock) V2_ReleaseRiskLock(lockName,lockToken);
         return true;
        }
      if(IsTransientRetcode(res.retcode) && a<attempts-1)
        { Sleep(TransientRetryDelayMs); continue; }
      PrintFormat("[MARKET FAIL] %s ret=%u %s",cmt,res.retcode,res.comment);
      if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false;
     }
   if(localLock) V2_ReleaseRiskLock(lockName,lockToken);
   return false;
  }

//===================================================================
// SECTION 60 — PENDING STOP SENDER (V2) [B2: msg budget]
//===================================================================
bool SendStopV2(bool isBuy, double price, double lots,
                double sl, double tp, string cmt)
  {
   if(lots<=0.0) return false;
   double minDist=StopsLevelPrice();
   if(isBuy && (price-AskPrice()<minDist))
     { PrintFormat("[STOP REJECT] %s buy dist=%.0f min=%.0f",cmt,(price-AskPrice())/_Point,minDist/_Point); return false; }
   if(!isBuy && (BidPrice()-price<minDist))
     { PrintFormat("[STOP REJECT] %s sell dist=%.0f min=%.0f",cmt,(BidPrice()-price)/_Point,minDist/_Point); return false; }
   string lockName=""; double lockToken=0.0;
   bool localLock=false;
   if(UsePortfolioRiskGovernorV2)
     {
      if(!g_V2BatchLockHeld)
        {
         if(!V2_AcquireRiskLock(lockName,lockToken)) return false;
         localLock=true;
        }
      if(!V2_RiskGovernorCanPlace(isBuy,lots,price,sl,cmt))
        { if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false; }
     }
   if(!MsgBudget_CanSend())
     { PrintFormat("[MSGBUDGET] blocked STOP %s",cmt); if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false; }
   ENUM_ORDER_TYPE type=isBuy ? ORDER_TYPE_BUY_STOP : ORDER_TYPE_SELL_STOP;
   int attempts=UseTransientRetryV2 ? TransientMaxRetries : 1;
   for(int a=0;a<attempts;a++)
     {
      MqlTradeRequest req;
      BuildReq(req,TRADE_ACTION_PENDING,type,price,lots,sl,tp,cmt);
      if(!OrderCheckPass(req)) { if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false; }
      MqlTradeResult res; ZeroMemory(res);
      bool ok=OrderSend(req,res);
      if(ok && (res.retcode==TRADE_RETCODE_DONE || res.retcode==TRADE_RETCODE_PLACED))
        {
         MsgBudget_TickOpen();
         if(UseSlippageReAnchorV2) Anchor_Store(cmt,price,sl,tp);
         if(localLock) V2_ReleaseRiskLock(lockName,lockToken);
         return true;
        }
      if(IsTransientRetcode(res.retcode) && a<attempts-1) { Sleep(TransientRetryDelayMs); continue; }
      PrintFormat("[STOP FAIL] %s ret=%u %s",cmt,res.retcode,res.comment);
      if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false;
     }
   if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false;
  }

//===================================================================
// SECTION 61 — PENDING LIMIT SENDER (V2) [B2: msg budget]
//===================================================================
bool SendLimitV2(bool isBuy, double price, double lots,
                 double sl, double tp, string cmt)
  {
   if(lots<=0.0) return false;
   double minDist=StopsLevelPrice();
   if(isBuy && (BidPrice()-price<minDist))
     { PrintFormat("[LIMIT REJECT] %s buy dist=%.0f min=%.0f",cmt,(BidPrice()-price)/_Point,minDist/_Point); return false; }
   if(!isBuy && (price-AskPrice()<minDist))
     { PrintFormat("[LIMIT REJECT] %s sell dist=%.0f min=%.0f",cmt,(price-AskPrice())/_Point,minDist/_Point); return false; }
   string lockName=""; double lockToken=0.0;
   bool localLock=false;
   if(UsePortfolioRiskGovernorV2)
     {
      if(!g_V2BatchLockHeld)
        {
         if(!V2_AcquireRiskLock(lockName,lockToken)) return false;
         localLock=true;
        }
      if(!V2_RiskGovernorCanPlace(isBuy,lots,price,sl,cmt))
        { if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false; }
     }
   if(!MsgBudget_CanSend())
     { PrintFormat("[MSGBUDGET] blocked LIMIT %s",cmt); if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false; }
   ENUM_ORDER_TYPE type=isBuy ? ORDER_TYPE_BUY_LIMIT : ORDER_TYPE_SELL_LIMIT;
   int attempts=UseTransientRetryV2 ? TransientMaxRetries : 1;
   for(int a=0;a<attempts;a++)
     {
      MqlTradeRequest req;
      BuildReq(req,TRADE_ACTION_PENDING,type,price,lots,sl,tp,cmt);
      if(!OrderCheckPass(req)) { if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false; }
      MqlTradeResult res; ZeroMemory(res);
      bool ok=OrderSend(req,res);
      if(ok && (res.retcode==TRADE_RETCODE_DONE || res.retcode==TRADE_RETCODE_PLACED))
        {
         MsgBudget_TickOpen();
         if(UseSlippageReAnchorV2) Anchor_Store(cmt,price,sl,tp);
         if(localLock) V2_ReleaseRiskLock(lockName,lockToken);
         return true;
        }
      if(IsTransientRetcode(res.retcode) && a<attempts-1) { Sleep(TransientRetryDelayMs); continue; }
      PrintFormat("[LIMIT FAIL] %s ret=%u %s",cmt,res.retcode,res.comment);
      if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false;
     }
   if(localLock) V2_ReleaseRiskLock(lockName,lockToken); return false;
  }

//===================================================================
// SECTION 61b — BACKWARD-COMPAT WRAPPERS
//===================================================================
bool SendMarket(int type, double lots, double sl, double tp, string comment)
  { return SendMarketV2(type, lots, sl, tp, comment); }

bool SendBuyStop(double price, double lots, double sl, double tp, string comment)
  { return SendStopV2(true, price, lots, sl, tp, comment); }

bool SendSellStop(double price, double lots, double sl, double tp, string comment)
  { return SendStopV2(false, price, lots, sl, tp, comment); }

bool SendBuyLimit(double price, double lots, double sl, double tp, string comment)
  { return SendLimitV2(true, price, lots, sl, tp, comment); }

bool SendSellLimit(double price, double lots, double sl, double tp, string comment)
  { return SendLimitV2(false, price, lots, sl, tp, comment); }

//===================================================================
// SECTION 62 — SAFE MODIFY [A1 + S2: hardened + spread-aware]
//===================================================================
bool SafeModify(ulong ticket, double sl, double tp)
  {
   //--- [B2] msg budget check
   if(!MsgBudget_CanSend())
     {
      Print("[MSGBUDGET] blocked MODIFY");
      return false;
     }

   if(!PositionSelectByTicket(ticket)) return false;

   long type = PositionGetInteger(POSITION_TYPE);
   double bid = BidPrice(), ask = AskPrice();

   //--- [S2] spread-aware minimum distance (1.5× spread floor)
   double minDist = SafeTrailBuffer();

   //--- [A1] PRE-FLIGHT: reject clearly-invalid modify
   if(type == POSITION_TYPE_BUY)
     {
      if(sl > 0.0 && (bid - sl) < minDist) return false;
      if(tp > 0.0 && (tp - ask) < minDist) return false;
      if(sl > 0.0 && tp > 0.0 && tp <= sl)  return false;
     }
   else if(type == POSITION_TYPE_SELL)
     {
      if(sl > 0.0 && (sl - ask) < minDist) return false;
      if(tp > 0.0 && (bid - tp) < minDist) return false;
      if(sl > 0.0 && tp > 0.0 && tp >= sl)  return false;
     }

   //--- Attempt modify
   trade.SetExpertMagicNumber(MagicNumber);
   uint result = trade.PositionModify(ticket, sl, tp);
   bool ok = (result == TRADE_RETCODE_DONE ||
              result == TRADE_RETCODE_PLACED ||
              result == TRADE_RETCODE_DONE_PARTIAL);
   if(ok) MsgBudget_TickModify();
   return ok;
  }

//===================================================================
// SECTION 63 — CLOSE POSITION (V2)
//===================================================================
bool ClosePosition(ulong ticket)
  {
   if(!PositionSelectByTicket(ticket)) return false;
   trade.SetExpertMagicNumber(MagicNumber);
   bool ok = TradeResultOK(trade.PositionClose(ticket));
   return ok;
  }

//===================================================================
// SECTION 64 — DELETE ORDERS BY PREFIX
//===================================================================
void DeleteOrdersPrefix(string prefix)
  {
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol) continue;
      if(ordInfo.Magic() != MagicNumber) continue;
      if(StringFind(ordInfo.Comment(), prefix) < 0) continue;
      bool ok = trade.OrderDelete(ordInfo.Ticket());
      if(ok) MsgBudget_TickDelete();
     }
  }

//===================================================================
// SECTION 65 — SLIPPAGE RE-ANCHOR [A7: no round-number snap]
//===================================================================
void ReAnchorStopsAfterFill(ulong positionTicket, string comment)
  {
   if(!UseSlippageReAnchorV2) return;
   if(!PositionSelectByTicket(positionTicket)) return;

   int idx = Anchor_Find(comment);
   if(idx < 0) return;

   double reqEntry = g_AnchorMap[idx].requestedEntry;
   double reqSL    = g_AnchorMap[idx].requestedSL;
   double reqTP    = g_AnchorMap[idx].requestedTP;

   double fillPrice = PositionGetDouble(POSITION_PRICE_OPEN);
   if(fillPrice <= 0.0 || reqEntry <= 0.0) return;

   double slipPts = MathAbs(fillPrice - reqEntry) / _Point;
   if(slipPts < SlippageReAnchorTriggerPts) return;

   double slipDelta = fillPrice - reqEntry;
   bool isBuy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);

   //--- [A7] Do NOT snap to round numbers — preserve broker precision
   double newSL = reqSL;
   double newTP = reqTP;
   if(reqSL > 0.0) newSL = reqSL + slipDelta;
   if(reqTP > 0.0) newTP = reqTP + slipDelta;

   // Sanity checks
   if(isBuy)
     {
      if(newSL > 0.0 && newSL >= fillPrice) return;
      if(newTP > 0.0 && newTP <= fillPrice) return;
     }
   else
     {
      if(newSL > 0.0 && newSL <= fillPrice) return;
      if(newTP > 0.0 && newTP >= fillPrice) return;
     }

   double curSL = PositionGetDouble(POSITION_SL);
   double curTP = PositionGetDouble(POSITION_TP);

   SafeModify(positionTicket, newSL, newTP);

   PrintFormat("[RE-ANCHOR] tkt=%I64u slip=%.0fpts SL %.5f->%.5f TP %.5f->%.5f",
               positionTicket, slipPts, curSL, newSL, curTP, newTP);
  }

//===================================================================
// SECTION 66 — BASKET USD HELPERS [S3: spread-aware floor]
//===================================================================
double BasketBEUSD(string engine)
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   double pctTarget = 0.0;

   if(UseBasketDollarMode)
      pctTarget = base * BasketBE_USD_PctOfStart / 100.0;
   else
     {
      int bi = BasketEngineIndex(engine);
      if(UseBasketRiskTargets && bi >= 0 && BasketInitialRiskUSD[bi] > 0.0)
         pctTarget = BasketInitialRiskUSD[bi] * EngineBasketRiskR(engine, 0);
      else
         pctTarget = base * BasketBE_Pct / 100.0;
     }

   //--- [S3] spread floor: BE must exceed 2× spread across all positions
   int posCount = MathMax(1, CountEnginePositions(engine + "_"));
   double lotTotal = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), engine + "_") < 0) continue;
      lotTotal += posInfo.Volume();
     }
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double spreadUSD = SpreadInPoints() * posCount * lotTotal * tickValue;
   double spreadFloor = spreadUSD * SpreadMultiplier_Basket;

   return MathMax(pctTarget, spreadFloor);
  }

double BasketTrailStartUSD(string engine)
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   double pctTarget = 0.0;

   if(UseBasketDollarMode)
      pctTarget = base * BasketTrailStart_USD_Pct / 100.0;
   else
     {
      int bi = BasketEngineIndex(engine);
      if(UseBasketRiskTargets && bi >= 0 && BasketInitialRiskUSD[bi] > 0.0)
         pctTarget = BasketInitialRiskUSD[bi] * EngineBasketRiskR(engine, 1);
      else
         pctTarget = base * BasketTrailStart_Pct / 100.0;
     }

   //--- [S3] Trail start must exceed BE by at least 50%
   double be = BasketBEUSD(engine);
   if(pctTarget < be * 1.5) pctTarget = be * 1.5;
   return pctTarget;
  }

double BasketTrailStepUSD(string engine)
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   double pctTarget = 0.0;

   if(UseBasketDollarMode)
      pctTarget = base * BasketTrailStep_USD_Pct / 100.0;
   else
     {
      int bi = BasketEngineIndex(engine);
      if(UseBasketRiskTargets && bi >= 0 && BasketInitialRiskUSD[bi] > 0.0)
         pctTarget = BasketInitialRiskUSD[bi] * EngineBasketRiskR(engine, 2);
      else
         pctTarget = base * BasketTrailStep_Pct / 100.0;
     }

   //--- [S3] Step must exceed 1.5× spread
   int posCount = MathMax(1, CountEnginePositions(engine + "_"));
   double lotTotal = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), engine + "_") < 0) continue;
      lotTotal += posInfo.Volume();
     }
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double spreadUSD = SpreadInPoints() * posCount * lotTotal * tickValue;
   double spreadFloor = spreadUSD * SpreadMultiplier_Basket * 0.75;

   return MathMax(pctTarget, spreadFloor);
  }

double BasketSLUSD(string engine)
  {
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return 0.0;

   if(UseBasketDollarMode)
      return base * BasketSL_USD_Pct / 100.0;

   return -base * MathAbs(BasketSL_Pct) / 100.0;
  }

//===================================================================
// SECTION 67 — MOVE PREFIX TO BREAKEVEN [S2: spread-aware offset]
//===================================================================
void MovePrefixToBE(string prefix)
  {
   double buf = SafeTrailBuffer();   // [S2] 1.5× spread minimum

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), prefix) < 0) continue;

      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      double take = posInfo.TakeProfit();
      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);

      if(isBuy)
        {
         double ns = NormalizeDouble(open + buf, _Digits);
         if(ns > stop && ns < BidPrice() - buf) SafeModify(posInfo.Ticket(), ns, take);
        }
      else
        {
         double ns = NormalizeDouble(open - buf, _Digits);
         if(ns < stop && ns > AskPrice() + buf) SafeModify(posInfo.Ticket(), ns, take);
        }
     }
  }

//===================================================================
// SECTION 68 — BASKET MANAGEMENT (R-based + dollar-based) [S3]
//===================================================================
void ManageBasket(string engine,
                  bool   &beDone, bool &trailOn,
                  double &trailHigh, double &trailSL)
  {
   if(!UseBasketManagement) return;
   string prefix = engine + "_";
   int posCount = CountEnginePositions(prefix);
   int ordCount = CountEngineOrders(prefix);
   int basketIdx = BasketEngineIndex(engine);

   if(posCount <= 0)
     {
      if(ordCount == 0)
        {
         beDone = false; trailOn = false;
         trailHigh = 0.0; trailSL = 0.0;
         if(basketIdx >= 0) BasketInitialRiskUSD[basketIdx] = 0.0;
        }
      return;
     }

   if(basketIdx >= 0 && BasketInitialRiskUSD[basketIdx] <= 0.0)
     {
      double br = CalculateBasketRiskUSD(prefix);
      if(br > 0.0) BasketInitialRiskUSD[basketIdx] = br;
     }

   double pnl    = PrefixFloatingPnL(prefix);
   double beUSD  = BasketBEUSD(engine);
   double tsUSD  = BasketTrailStartUSD(engine);
   double tstUSD = BasketTrailStepUSD(engine);
   double slUSD  = BasketSLUSD(engine);

   if(pnl <= slUSD)
     {
      DeleteOrdersPrefix(prefix);
      CloseEnginePositions(prefix);
      beDone = false; trailOn = false;
      trailHigh = 0.0; trailSL = 0.0;
      if(basketIdx >= 0) BasketInitialRiskUSD[basketIdx] = 0.0;
      PrintFormat("[BASKET SL] %s pnl=%.2f <= %.2f", engine, pnl, slUSD);
      return;
     }

   if(!beDone && pnl >= beUSD)
     {
      MovePrefixToBE(prefix);
      beDone = true;
      PrintFormat("[BASKET BE] %s pnl=%.2f", engine, pnl);
     }

   if(!trailOn && pnl >= tsUSD)
     {
      trailOn = true;
      trailHigh = pnl;
      trailSL = pnl - tstUSD;
      PrintFormat("[BASKET TRAIL START] %s pnl=%.2f", engine, pnl);
     }

   if(trailOn)
     {
      if(pnl > trailHigh) { trailHigh = pnl; trailSL = pnl - tstUSD; }
      if(pnl <= trailSL && pnl > 0.0)
        {
         DeleteOrdersPrefix(prefix);
         CloseEnginePositions(prefix);
         beDone = false; trailOn = false;
         trailHigh = 0.0; trailSL = 0.0;
         if(basketIdx >= 0) BasketInitialRiskUSD[basketIdx] = 0.0;
         PrintFormat("[BASKET TRAIL] %s pnl=%.2f", engine, pnl);
        }
     }
  }

//===================================================================
// SECTION 69 — FLOATING BUDGETS
//===================================================================
void CheckFloatingBudgets()
  {
   if(!UseFloatingBudget) return;
   double base = (StartBalance > 0.0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   if(base <= 0.0) return;
   double swingLimit   = base * SwingBudgetPct    / 100.0;
   double monsterLimit = base * MonsterBudgetPct  / 100.0;
   double rangeLimit   = base * RangeBudgetPct    / 100.0;
   double revLimit     = base * ReversalBudgetPct / 100.0;

   if(CountEnginePositions("SWING_") > 0 && PrefixFloatingPnL("SWING_") <= swingLimit)
     { CloseEnginePositions("SWING_");   Print("[BUDGET] SWING closed"); }
   if(CountEnginePositions("MONSTER_") > 0 && PrefixFloatingPnL("MONSTER_") <= monsterLimit)
     { CloseEnginePositions("MONSTER_"); Print("[BUDGET] MONSTER closed"); }
   if(CountEnginePositions("RANGE_") > 0 && PrefixFloatingPnL("RANGE_") <= rangeLimit)
     { CloseEnginePositions("RANGE_");   Print("[BUDGET] RANGE closed"); }
   if(CountEnginePositions("REVERSAL_") > 0 && PrefixFloatingPnL("REVERSAL_") <= revLimit)
     { CloseEnginePositions("REVERSAL_"); Print("[BUDGET] REVERSAL closed"); }
  }

//===================================================================
// SECTION 70 — STALE PENDING CLEANUP
//===================================================================
void CancelStalePendingOrders()
  {
   int limit = UseHourlyStraddleReset ? StaleOrderMinutesV2 : StaleOrderMinutes;
   if(limit <= 0) return;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol() != _Symbol || ordInfo.Magic() != MagicNumber) continue;
      if(TimeCurrent() - ordInfo.TimeSetup() >= limit * 60)
        {
         bool ok = trade.OrderDelete(ordInfo.Ticket());
         if(ok) MsgBudget_TickDelete();
        }
     }
  }

//===================================================================
// SECTION 71 — CLOSE ALL
//===================================================================
void CloseAllOurPositions()
  {
   // V3 account halt: close all positions and cancel all pending orders sharing this system's magic across symbols.
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Magic()!=MagicNumber) continue;
      ClosePosition(posInfo.Ticket());
     }
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0 || (long)OrderGetInteger(ORDER_MAGIC)!=MagicNumber) continue;
      ENUM_ORDER_TYPE type=(ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      if(type!=ORDER_TYPE_BUY_LIMIT && type!=ORDER_TYPE_SELL_LIMIT &&
         type!=ORDER_TYPE_BUY_STOP && type!=ORDER_TYPE_SELL_STOP &&
         type!=ORDER_TYPE_BUY_STOP_LIMIT && type!=ORDER_TYPE_SELL_STOP_LIMIT) continue;
      if(trade.OrderDelete(ticket)) MsgBudget_TickDelete();
      else PrintFormat("[V3 ACCOUNT HALT] pending cancel failed symbol=%s ticket=%I64u ret=%u %s",OrderGetString(ORDER_SYMBOL),ticket,trade.ResultRetcode(),trade.ResultRetcodeDescription());
     }
  }

//===================================================================
// SECTION 72 — PER-POSITION MANAGEMENT [S4: spread-aware trailing]
//===================================================================
string V2_PositionStateKey(ulong ticket,string suffix)
  {
   return "BGP2_"+IntegerToString(MagicNumber)+"_"+StringFormat("%I64u",ticket)+"_"+suffix;
  }

double V2_GetOrSetState(string key,double seed)
  {
   if(GlobalVariableCheck(key)) return GlobalVariableGet(key);
   GlobalVariableSet(key,seed);
   return seed;
  }

double V3_PositionNetProfit(ulong ticket)
  {
   if(!PositionSelectByTicket(ticket)) return 0.0;
   double net=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
   long identifier=PositionGetInteger(POSITION_IDENTIFIER);
   if(identifier>0 && HistorySelectByPosition((ulong)identifier))
     {
      for(int i=0;i<HistoryDealsTotal();i++)
        {
         ulong deal=HistoryDealGetTicket(i);
         if(deal==0) continue;
         net+=HistoryDealGetDouble(deal,DEAL_COMMISSION);
        }
     }
   return net;
  }

void V3_InitializePositionState(ulong ticket)
  {
   if(!PositionSelectByTicket(ticket)) return;
   if((long)PositionGetInteger(POSITION_MAGIC)!=MagicNumber) return;
   double open=PositionGetDouble(POSITION_PRICE_OPEN), sl=PositionGetDouble(POSITION_SL);
   double volume=PositionGetDouble(POSITION_VOLUME);
   if(open<=0.0 || sl<=0.0 || volume<=0.0) return;
   bool isBuy=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
   string rKey=V2_PositionStateKey(ticket,"R");
   string rmKey=V2_PositionStateKey(ticket,"RM");
   string pkKey=V2_PositionStateKey(ticket,"PK");
   string npKey=V2_PositionStateKey(ticket,"NP");
   if(!GlobalVariableCheck(rKey)) GlobalVariableSet(rKey,MathAbs(open-sl));
   if(!GlobalVariableCheck(rmKey)) GlobalVariableSet(rmKey,V2_MoneyRiskAtSL(_Symbol,isBuy,volume,open,sl));
   double net=V3_PositionNetProfit(ticket);
   if(!GlobalVariableCheck(pkKey)) GlobalVariableSet(pkKey,0.0);
   if(!GlobalVariableCheck(npKey)) GlobalVariableSet(npKey,MathMax(0.0,net));
  }

bool V2_ConfirmedAdverseReversal(bool isBuy)
  {
   if(hExitEMA5_M1==INVALID_HANDLE || hExitEMA13_M1==INVALID_HANDLE) return false;
   double f1=BufVal(hExitEMA5_M1,0,1), s1=BufVal(hExitEMA13_M1,0,1);
   double f2=BufVal(hExitEMA5_M1,0,2), s2=BufVal(hExitEMA13_M1,0,2);
   double c1=TfClose(PERIOD_M1,1);
   if(f1<=0.0 || s1<=0.0 || f2<=0.0 || s2<=0.0 || c1<=0.0) return false;
   double atr=(CurrentATR1>0.0 ? CurrentATR1 : CurrentATR5);
   double pad=MathMax(_Point*2.0,atr*0.05);
   if(isBuy)
     {
      double lo2=TfLow(PERIOD_M1,2),lo3=TfLow(PERIOD_M1,3),lo4=TfLow(PERIOD_M1,4);
      double swing=MathMin(lo2,MathMin(lo3,lo4));
      bool emaAgainst=(f1<s1 && f2<s2);
      bool structureBreak=(swing>0.0 && c1<swing-pad);
      return (emaAgainst && structureBreak);
     }
   else
     {
      double hi2=TfHigh(PERIOD_M1,2),hi3=TfHigh(PERIOD_M1,3),hi4=TfHigh(PERIOD_M1,4);
      double swing=MathMax(hi2,MathMax(hi3,hi4));
      bool emaAgainst=(f1>s1 && f2>s2);
      bool structureBreak=(swing>0.0 && c1>swing+pad);
      return (emaAgainst && structureBreak);
     }
  }

bool V3_ConfirmedAdverseReversal(bool isBuy)
  {
   if(!V2_ConfirmedAdverseReversal(isBuy)) return false;
   if(!V3RatchetRequireM5Confirmation) return true;
   // Require independent completed-M5 deterioration in addition to the M1 EMA + swing-break pattern.
   double ema10=BufVal(hEMA10_M5,0,1), ema21=BufVal(hEMA21_M5,0,1);
   double close5=TfClose(PERIOD_M5,1);
   if(ema10<=0.0 || ema21<=0.0 || close5<=0.0) return false;
   bool m5Against=isBuy ? (ema10<ema21 && close5<ema21) : (ema10>ema21 && close5>ema21);
   bool smcAgainst=isBuy ? (g_SMC.m5_event==-1) : (g_SMC.m5_event==1);
   return (m5Against || smcAgainst);
  }


void V2_ManageOnePosition(ulong ticket)
  {
   if(!PositionSelectByTicket(ticket)) return;
   if(PositionGetString(POSITION_SYMBOL)!=_Symbol || (long)PositionGetInteger(POSITION_MAGIC)!=MagicNumber) return;
   double open=PositionGetDouble(POSITION_PRICE_OPEN);
   double stop=PositionGetDouble(POSITION_SL);
   double take=PositionGetDouble(POSITION_TP);
   double volume=PositionGetDouble(POSITION_VOLUME);
   bool isBuy=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
   if(open<=0.0 || stop<=0.0 || volume<=0.0) return;
   double initialRisk=MathAbs(open-stop);
   if(initialRisk<=0.0) return;
   string riskKey=V2_PositionStateKey(ticket,"R");
   string riskMoneyKey=V2_PositionStateKey(ticket,"RM");
   string peakKey=V2_PositionStateKey(ticket,"PK");
   string netPeakKey=V2_PositionStateKey(ticket,"NP");
   string ratchetKey=V2_PositionStateKey(ticket,"RT");
   double storedRisk=V2_GetOrSetState(riskKey,initialRisk);
   double storedRiskMoney=V2_GetOrSetState(riskMoneyKey,V2_MoneyRiskAtSL(_Symbol,isBuy,volume,open,stop));
   if(storedRiskMoney<=0.0) { GlobalVariableSet(riskMoneyKey,V2_MoneyRiskAtSL(_Symbol,isBuy,volume,open,stop)); storedRiskMoney=V2_GetOrSetState(riskMoneyKey,0.0); }
   double netNow=V3_PositionNetProfit(ticket);
   double netPeak=V2_GetOrSetState(netPeakKey,MathMax(0.0,netNow));
   if(netNow>netPeak+0.01) { netPeak=netNow; GlobalVariableSet(netPeakKey,netPeak); }
   if(storedRisk<=0.0) { GlobalVariableSet(riskKey,initialRisk); storedRisk=initialRisk; }
   // Persist the first valid stop distance. Later BE/trailing changes must not change the R denominator.
   double currentPrice=isBuy ? BidPrice() : AskPrice();
   if(currentPrice<=0.0) return;
   double profitDist=isBuy ? currentPrice-open : open-currentPrice;
   double currentR=profitDist/storedRisk;
   double peakR=V2_GetOrSetState(peakKey,MathMax(0.0,currentR));
   if(currentR>peakR+1e-6) { peakR=currentR; GlobalVariableSet(peakKey,peakR); }
   double spreadBuf=MathMax(SafeTrailBuffer()*BE_CostBufferSpreadMultV2,SpreadInPoints()*_Point*2.0)+_Point*2.0;
   double atr1=(CurrentATR1>0.0 ? CurrentATR1 : CurrentATR5);

   // 1) Noise-resistant, cost-aware break-even. Initial-risk R is persistent across stop changes.
   if(UseNoiseResistantBEV2)
     {
      double beTrigger=MathMax(storedRisk*BE_MinInitialR_V2,atr1*BE_MinATRMultipleM1_V2);
      bool beSecured=isBuy ? (stop>=open+spreadBuf*0.50) : (stop<=open-spreadBuf*0.50);
      if(!beSecured && profitDist>=beTrigger)
        {
         double beSL=NormalizeDouble(isBuy ? open+spreadBuf : open-spreadBuf,_Digits);
         bool safeToPlace=isBuy ? (beSL<BidPrice()-SafeTrailBuffer()) : (beSL>AskPrice()+SafeTrailBuffer());
         if(safeToPlace && (isBuy ? beSL>stop+_Point : beSL<stop-_Point))
           {
            if(SafeModify(ticket,beSL,take))
              {
               stop=beSL;
               PrintFormat("[V2 BE LOCK] ticket=%I64u side=%s R=%.2f initialRisk=%.5f SL=%.5f",ticket,(isBuy?"BUY":"SELL"),currentR,storedRisk,beSL);
              }
            else PrintFormat("[V2 BE MODIFY FAILED] ticket=%I64u desired=%.5f",ticket,beSL);
           }
        }
     }

   // Refresh broker-confirmed stop after a possible BE modification.
   if(!PositionSelectByTicket(ticket)) return;
   stop=PositionGetDouble(POSITION_SL);
   take=PositionGetDouble(POSITION_TP);
   bool beProtected=isBuy ? (stop>=open+spreadBuf*0.50) : (stop<=open-spreadBuf*0.50);

   // 2) Step trailing only after cost-aware BE, leaving room for normal M1 noise.
   if(beProtected && currentR>=TrailStartR_V2 && atr1>0.0)
     {
      double trailDist=MathMax(atr1*Trail_ATRMultipleM1_V2,SafeTrailBuffer()*1.5);
      double candidate=NormalizeDouble(isBuy ? BidPrice()-trailDist : AskPrice()+trailDist,_Digits);
      double minImprove=MathMax(atr1*Trail_StepATR_M1_V2,_Point*3.0);
      bool valid=isBuy ? (candidate>stop+minImprove && candidate<BidPrice()-SafeTrailBuffer())
                       : (candidate<stop-minImprove && candidate>AskPrice()+SafeTrailBuffer());
      if(valid)
        {
         if(SafeModify(ticket,candidate,take))
           { stop=candidate; PrintFormat("[V2 STEP TRAIL] ticket=%I64u R=%.2f peakR=%.2f SL=%.5f",ticket,currentR,peakR,candidate); }
         else PrintFormat("[V2 TRAIL MODIFY FAILED] ticket=%I64u desired=%.5f",ticket,candidate);
        }
     }

   // 3) V3.1 PEAK-PROFIT RATCHET.
   // Measured giveback from a tracked net peak is itself the trigger. Do not make
   // profit protection wait for M1/M5 structure: those confirmations can arrive
   // only after open profit has already disappeared. The optional confirmation
   // switch is retained for compatibility but defaults OFF in the V3.2 presets.
   double netGivebackTrigger=MathMax(storedRiskMoney*Ratchet_GivebackR_V2,MathMax(0.0,netPeak)*0.20);
   bool netPeakGiveback=(netPeak>0.0 && (netPeak-netNow)>=netGivebackTrigger);
   bool pricePeakGiveback=(peakR>=Ratchet_ArmPeakR_V2 &&
                           (peakR-currentR)>=Ratchet_GivebackR_V2);
   bool optionalConfirmationOK=(!V3RatchetRequireM5Confirmation || V3_ConfirmedAdverseReversal(isBuy));
   if(UseReversalConfirmedRatchetV2 && pricePeakGiveback && netPeakGiveback && optionalConfirmationOK)
     {
      double peakDist=peakR*storedRisk;
      double fraction=Clamp(Ratchet_RetainPeakPct_V2/100.0,0.10,0.90);
      double lockDist=peakDist*fraction;
      // Lock at least the spread/cost buffer and a small positive fraction of initial R.
      lockDist=MathMax(lockDist,MathMax(spreadBuf,storedRisk*Ratchet_MinCurrentR_V2));
      double desired=NormalizeDouble(isBuy ? open+lockDist : open-lockDist,_Digits);
      double mark=isBuy ? BidPrice() : AskPrice();
      bool canPlace=isBuy ? (desired<mark-SafeTrailBuffer()) : (desired>mark+SafeTrailBuffer());
      bool improves=isBuy ? (desired>stop+_Point) : (desired<stop-_Point);
      if(canPlace && improves)
        {
         if(SafeModify(ticket,desired,take))
           {
            GlobalVariableSet(ratchetKey,1.0);
            PrintFormat("[V3.4 PEAK-PROFIT RATCHET] ticket=%I64u peakR=%.2f currentR=%.2f peakNet=%.2f currentNet=%.2f giveback=%.2f riskMoney=%.2f retained=%.0f%% SL=%.5f",ticket,peakR,currentR,netPeak,netNow,netPeak-netNow,storedRiskMoney,fraction*100.0,desired);
           }
         else PrintFormat("[V3.4 PEAK RATCHET MODIFY FAILED] ticket=%I64u desired=%.5f",ticket,desired);
        }
      else if(!canPlace && Ratchet_CloseIfLockMissedV2)
        {
         PrintFormat("[V3.4 PEAK LOCK MISSED] ticket=%I64u peakR=%.2f nowR=%.2f peakNet=%.2f currentNet=%.2f; target lock price already crossed, closing fallback",ticket,peakR,currentR,netPeak,netNow);
         if(ClosePosition(ticket)) GlobalVariableSet(ratchetKey,1.0);
        }
     }
  }

void ManagePositions()
  {
   // V2 unified per-ticket manager runs each timer tick, independent of bridge health.
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol()!=_Symbol || posInfo.Magic()!=MagicNumber) continue;
      V2_ManageOnePosition(posInfo.Ticket());
     }
  }

//===================================================================
// SECTION 73 — TIGHT BE + TRAIL (TIER 2 — ATR-ADAPTIVE)
//===================================================================
void ManageTightExit(ulong ticket)
  {
   if(!UseTightBEV2 && !UseTightTrailV2) return;
   if(!PositionSelectByTicket(ticket)) return;

   double open  = PositionGetDouble(POSITION_PRICE_OPEN);
   double stop  = PositionGetDouble(POSITION_SL);
   double take  = PositionGetDouble(POSITION_TP);
   bool   isBuy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);

   if(open <= 0.0 || stop <= 0.0) return;
   double risk = MathAbs(open - stop);
   if(risk <= 0.0) return;

   double profitDist = isBuy ? (BidPrice() - open) : (open - AskPrice());
   double rr = profitDist / risk;

   //--- [S4] spread-aware buffer
   double buf = SafeTrailBuffer();

   //--- TIGHT BE (ATR-adaptive + spread floor)
   if(UseTightBEV2)
     {
      double beTrigPts = 0.0;
      double atrRef = CurrentATR1;
      if(atrRef > 0.0) beTrigPts = (atrRef * TightBE_ATR_Mult_V2) / _Point;
      beTrigPts = Clamp(beTrigPts, TightBE_MinPoints_V2, TightBE_MaxPoints_V2);

      //--- [S4] ensure BE trigger exceeds spread floor
      double spreadFloor = SpreadInPoints() * SpreadMultiplier_Trail;
      if(beTrigPts < spreadFloor) beTrigPts = spreadFloor;

      double beTrigPrice = beTrigPts * _Point;
      bool alreadyBE = isBuy ? (stop >= open) : (stop <= open);

      if(!alreadyBE && profitDist >= beTrigPrice)
        {
         double newSL = NormalizeDouble(open, _Digits);
         if(SafeModify(ticket, newSL, take))
            PrintFormat("[TIGHT-BE] %I64u BE at +%.1fpts",
                        ticket, profitDist / _Point);
         return;
        }
     }

   //--- TIGHT TRAIL (spread-aware)
   if(UseTightTrailV2 && rr >= TightTrail_StartR_V2)
     {
      double trailDist = risk * TightTrail_StepR_V2;
      if(trailDist < buf) trailDist = buf;   // [S4] spread floor

      double newSL;
      if(isBuy)
        {
         newSL = NormalizeDouble(BidPrice() - trailDist, _Digits);
         if(newSL > stop + TightTrail_MinImprovePts_V2 * _Point &&
            newSL < BidPrice() - buf)
            SafeModify(ticket, newSL, take);
        }
      else
        {
         newSL = NormalizeDouble(AskPrice() + trailDist, _Digits);
         if(newSL < stop - TightTrail_MinImprovePts_V2 * _Point &&
            newSL > AskPrice() + buf)
            SafeModify(ticket, newSL, take);
        }
     }
  }

void ManageAllTightExits()
  {
   if(UseUnifiedExitManagerV2) return;
   if(!UseTightBEV2 && !UseTightTrailV2) return;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      ManageTightExit(posInfo.Ticket());
     }
  }

//===================================================================
// SECTION 74 — STALE POSITION EXIT
//===================================================================
void ManageStalePositions()
  {
   if(UseUnifiedExitManagerV2) return;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;

      datetime opened = (datetime)posInfo.Time();
      int ageMin = (int)((TimeCurrent() - opened) / 60);
      int engineIdx = EngineIndexFromComment(posInfo.Comment());
      int maxHold = (engineIdx == 1) ? Monster_HardMaxHoldMin : 90;

      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(stop <= 0.0) continue;
      double risk = MathAbs(open - stop);
      if(risk <= 0.0) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      double profitDist = isBuy ? (BidPrice() - open) : (open - AskPrice());
      double rr = profitDist / risk;

      bool stale = (ageMin >= 15 && rr < 0.20);
      bool hardExit = (ageMin >= maxHold);

      if(stale || hardExit)
         ClosePosition(posInfo.Ticket());
     }
  }

//===================================================================
// SECTION 75 — WICK ABORT
//===================================================================
void CheckWickAbort()
  {
   if(!UseWickAbort) return;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;

      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(stop <= 0.0) continue;

      double stopDist = MathAbs(open - stop);
      if(stopDist <= 0.0) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      double adverse = isBuy ? (open - BidPrice()) : (AskPrice() - open);

      if(adverse >= stopDist * WickAbortPct / 100.0)
         ClosePosition(posInfo.Ticket());
     }
  }

//===================================================================
// SECTION 76 — FLOW FLIP EXIT
//===================================================================
void CheckFlowFlipExit()
  {
   if(UseUnifiedExitManagerV2 && UseFactorBPrimaryDecisionV2) return; // Factor A confirms; does not independently close
   if(MQLInfoInteger(MQL_TESTER)) return;
   if(!UseBinanceFlow || !FlowFresh()) return;

   double fc = FlowComposite();
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      int dir = isBuy ? 1 : -1;
      int engineIdx = EngineIndexFromComment(posInfo.Comment());

      double profit = posInfo.Profit() + posInfo.Swap() + posInfo.Commission();
      if(profit <= 0.0) continue;

      if(fc * (double)dir <= -BinanceStrongFlowScore &&
         gFlow.persistence >= 0.50)
        {
         if(engineIdx == 1 && !VNSMC_TrendBreak(-dir)) continue;

         PrintFormat("[FLOW-FLIP] close %s pnl=%.2f fc=%.1f",
                     posInfo.Comment(), profit, fc);
         ClosePosition(posInfo.Ticket());
        }
     }
  }

//===================================================================
// SECTION 77 — WALL GUARD EXIT [A2: min profit + tighter wall]
//===================================================================
void WallGuardExit()
  {
   if(UseUnifiedExitManagerV2 && UseFactorBPrimaryDecisionV2) return; // wall/depth signal is supporting evidence only
   if(MQLInfoInteger(MQL_TESTER)) return;
   if(!gBinAux.valid) return;

   double mid = MidPrice();
   if(mid <= 0.0) return;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      int dir = isBuy ? 1 : -1;
      int engineIdx = EngineIndexFromComment(posInfo.Comment());

      double profit = posInfo.Profit() + posInfo.Swap() + posInfo.Commission();
      if(profit <= 0.0) continue;

      //--- [A2] minimum profit gate: 0.5R
      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(stop <= 0.0) continue;
      double riskUSD = MathAbs(open - stop) * posInfo.Volume()
                     / SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE)
                     * SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE_LOSS);
      if(riskUSD <= 0.0) continue;
      if(profit < riskUSD * 0.5) continue;

      if(engineIdx == 1 && !VNSMC_TrendBreak(-dir)) continue;

      //--- [A2] tighter wall distance: 50 pts (was 150)
      if(dir ==  1 && gBinAux.ask_wall_price > 0.0)
        {
         double d = (gBinAux.ask_wall_price - mid) / _Point;
         if(d > 0.0 && d < 50.0)
           {
            PrintFormat("[WALL-EXIT] BUY d=%.0f pnl=%.2f riskUSD=%.2f",
                        d, profit, riskUSD);
            ClosePosition(posInfo.Ticket());
           }
        }

      if(dir == -1 && gBinAux.bid_wall_price > 0.0)
        {
         double d = (mid - gBinAux.bid_wall_price) / _Point;
         if(d > 0.0 && d < 50.0)
           {
            PrintFormat("[WALL-EXIT] SELL d=%.0f pnl=%.2f riskUSD=%.2f",
                        d, profit, riskUSD);
            ClosePosition(posInfo.Ticket());
           }
        }
     }
  }

//===================================================================
// SECTION 78 — REVERSAL PARTIAL CLOSE (1.5R → 50% out)
//===================================================================
void ManageReversalPartial()
  {
   if(ReversalPartial) return;
   if(CountEnginePositions("REVERSAL_") <= 0) return;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), "REVERSAL_") < 0) continue;

      double open = posInfo.PriceOpen();
      double stop = posInfo.StopLoss();
      if(stop <= 0.0) continue;

      double risk = MathAbs(open - stop);
      if(risk <= 0.0) continue;

      bool isBuy = (posInfo.PositionType() == POSITION_TYPE_BUY);
      double prof = isBuy ? (BidPrice() - open) : (open - AskPrice());
      if(prof < risk * 1.50) continue;

      double vol = posInfo.Volume();
      double closeVol = NormalizeLots(vol * 0.50);
      if(closeVol <= 0.0 || closeVol >= vol) continue;
      if(closeVol < g_LotMin) continue;

      if(trade.PositionClosePartial(posInfo.Ticket(), closeVol))
        {
         ReversalPartial = true;
         MsgBudget_TickModify();
         PrintFormat("[REVERSAL PARTIAL] closed %.4f of %.4f",
                     closeVol, vol);
        }
      return;
     }
  }

//===================================================================
// SECTION 79 — MONSTER THESIS EXIT
//===================================================================
void CheckMonsterThesisExit()
  {
   if(UseUnifiedExitManagerV2) return; // V2 per-ticket reversal ratchet is sole Monster exit owner
   if(g_MonsterPhase == MP_IDLE) return;
   if(g_MonsterDir == 0) return;
   if(CountEnginePositions("MONSTER_") <= 0) return;

   int mbi = EngineIndexFromName("MONSTER");
   double basketRisk = (mbi >= 0) ? BasketInitialRiskUSD[mbi] : 0.0;
   double pnl = PrefixFloatingPnL("MONSTER_");
   double monsterR = (basketRisk > 0.0) ? pnl / basketRisk : 0.0;

   bool oppositeBreak = VNSMC_TrendBreak(-g_MonsterDir);
   bool expansionLost = (g_R7 != R7_EXPANSION && !VNFlowTradeRateSurge());

   if(oppositeBreak && expansionLost && monsterR > 0.0)
     {
      PrintFormat("[MONSTER THESIS EXIT] R=%.2f opposite BOS/CHoCH", monsterR);
      CloseEnginePositions("MONSTER_");
      g_MonsterPhase = MP_IDLE;
      g_MonsterDir   = 0;
     }
  }

//===================================================================
// SECTION 80 — MONSTER / REVERSAL RESET HELPERS
//===================================================================
void ResetMonsterIfIdle()
  {
   if(g_MonsterPhase == MP_IDLE) return;
   if(CountEnginePositions("MONSTER_") > 0) return;
   if(CountEngineOrders("MONSTER_") > 0) return;
   g_MonsterPhase        = MP_IDLE;
   g_MonsterDir          = 0;
   g_MonsterPyramidCount = 0;
   g_MonsterPeakR        = 0.0;
   g_LastModelEngine     = "";
  }

void ResetRevIfStale()
  {
   if(g_RevState == REV_IDLE) return;
   if(g_RevState == REV_WATCH &&
      TimeCurrent() - g_RevWatchSince > Rev_WatchMaxMinutes * 60)
     {
      g_RevState = REV_IDLE;
      g_RevDir = 0;
      g_RevConfirmCount = 0;
     }
  }

//===================================================================
// SECTION 81 — HOURLY STRADDLE FLAG RESET
//===================================================================
void HourlyStraddleReset()
  {
   if(!UseHourlyStraddleReset) return;
   static datetime lastReset = 0;
   if(TimeCurrent() - lastReset < 3600) return;
   lastReset = TimeCurrent();
   g_StraddleActive = false;
   g_StraddleDir    = 0;
   g_GridLevelV2    = 0;
  }

//===================================================================
// SECTION 82 — HOURLY HARD RESET
//===================================================================
void HourlyHardReset()
  {
   static datetime lastHour = 0;
   if(TimeCurrent() - lastHour < 3600) return;
   lastHour = TimeCurrent();
   for(int i = 0; i < 4; i++)
     {
      g_EnginePnLToday[i]   = 0.0;
      g_EngineLossStreak[i] = 0;
     }
  }

//===================================================================
// SECTION 83 — DAILY RESET
//===================================================================
void DailyResetIfNeeded()
  {
   int today = (int)(TimeCurrent() / 86400);
   if(today == TodayStamp) return;
   TodayStamp = today;
   DayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
   DailyHalted = false;
   GlobalHalted = false;
   ConsecutiveLosses = 0;
   ConsecutiveWins = 0;
   g_GridLevelV2 = 0;
   Recovery_Reset();
   MsgBudget_DailyReset();
   for(int i = 0; i < 4; i++) g_EnginePnLToday[i] = 0.0;
   V3_SyncAccountSafetyState();
   PrintFormat("[DAILY RESET] shared DayStartEquity=%.2f", DayStartEquity);
  }

//===================================================================
// SECTION 84 — SAFETY STACK
//===================================================================
void CheckSafety()
  {
   static ulong lastSharedSyncMs=0;
   ulong syncNow=GetTickCount64();
   if(!V3SharedAccountSafetyState || lastSharedSyncMs==0 || syncNow<lastSharedSyncMs || syncNow-lastSharedSyncMs>=1000)
     { V3_SyncAccountSafetyState(); lastSharedSyncMs=syncNow; }
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   if(equity > PeakEquity) PeakEquity = equity;

   if(UseDailyHalt && DayStartEquity > 0.0)
     {
      double dd = (DayStartEquity - equity) / DayStartEquity * 100.0;
      if(dd >= DailyLossLimitPct && !DailyHalted)
        {
         DailyHalted = true;
         PauseUntil = TimeCurrent() + 3600;
         V3_PersistAccountSafetyState();
         CloseAllOurPositions();
         PrintFormat("[SAFETY] Daily halt %.2f%%", dd);
        }
     }

   if(UseGlobalHalt && StartBalance > 0.0)
     {
      double dd = (StartBalance - equity) / StartBalance * 100.0;
      if(dd >= GlobalLossLimitPct && !GlobalHalted)
        {
         GlobalHalted = true;
         PauseUntil = TimeCurrent() + 6 * 3600;
         V3_PersistAccountSafetyState();
         CloseAllOurPositions();
         PrintFormat("[SAFETY] Global halt %.2f%%", dd);
        }
     }

   if(UsePeakGiveback && PeakEquity > 0.0)
     {
      double gb = (PeakEquity - equity) / PeakEquity * 100.0;
      if(gb >= PeakGivebackPct && TimeCurrent() >= PauseUntil)
        {
         PauseUntil = TimeCurrent() + PeakGivebackPauseHrs * 3600;
         V3_PersistAccountSafetyState();
         CloseAllOurPositions();
         PeakEquity = equity;
         V3_PersistAccountSafetyState();
         PrintFormat("[PEAK-LOCK] giveback %.2f%%", gb);
        }
     }

   if(UseLossStreak && ConsecutiveLosses >= MaxConsecutiveLosses)
     {
      PauseUntil = MathMax(PauseUntil, TimeCurrent() + LossStreakPauseMin * 60);
      PrintFormat("[LOSS-STREAK] pause %d min", LossStreakPauseMin);
      V3_PersistAccountSafetyState();
      ConsecutiveLosses = 0;
     }
  }

//===================================================================
// END OF PART 4 OF 5
//===================================================================

//===================================================================
// SECTION 85 — BIASED STRADDLE PLAN BUILDER
//===================================================================
S_StraddlePlan BuildStraddlePlan(string engine, int direction,
                                 int moveState, bool isJerk, bool isExtreme,
                                 double atr5)
  {
   S_StraddlePlan p;
   p.buys = 0; p.sells = 0;
   p.buyMult = 1.0; p.sellMult = 1.0;
   p.isExtreme = isExtreme;
   p.isJerk    = isJerk;

   if(direction == 0) return p;

   if(isJerk || isExtreme)
     {
      int cnt = isExtreme ? StraddleExtremeOrders : StraddleJerkOrders;
      double mult = isExtreme ? StraddleExtremeLotMult : StraddleJerkLotMult;
      if(direction == 1)
        { p.buys = cnt; p.sells = 0; p.buyMult = mult; }
      else
        { p.buys = 0; p.sells = cnt; p.sellMult = mult; }
     }
   else
     {
      if(direction == 1)
        {
         p.buys  = StraddleStrongOrders;
         p.sells = StraddleWeakOrders;
         p.buyMult  = StraddleStrongLotMult;
         p.sellMult = StraddleWeakLotMult;
        }
      else
        {
         p.buys  = StraddleWeakOrders;
         p.sells = StraddleStrongOrders;
         p.buyMult  = StraddleWeakLotMult;
         p.sellMult = StraddleStrongLotMult;
        }
     }

   p.gap = atr5 * StraddleGapATR;
   // Pair-aware spacing: no fixed BTC point floors on FX/metals/index symbols.
   double minGap = MathMax(StopsLevelPrice()*2.0, SafeTrailBuffer()*2.0);
   double atrGapFloor = atr5 * ((engine == "MONSTER") ? 0.45 : 0.30);
   if(atrGapFloor > minGap) minGap=atrGapFloor;
   if(p.gap < minGap) p.gap=minGap;

   p.slPrice = ComputeSLDistance(engine);
   p.tpPrice = ComputeTPDistance(engine, p.slPrice);

   return p;
  }

//===================================================================
// SECTION 86 — BIASED STRADDLE PLACER
//===================================================================
double V2_StraddlePlannedRisk(const S_StraddlePlan &p,double bid,double ask,double lotBuy,double lotSell)
  {
   double total=0.0;
   for(int i=0;i<p.buys;i++)
     {
      if(lotBuy<=0.0) continue;
      double entry=NormalizeDouble(ask+p.gap*(i+1),_Digits);
      double sl=NormalizeDouble(entry-p.slPrice,_Digits);
      total+=V2_MoneyRiskAtSL(_Symbol,true,lotBuy,entry,sl);
     }
   for(int i=0;i<p.sells;i++)
     {
      if(lotSell<=0.0) continue;
      double entry=NormalizeDouble(bid-p.gap*(i+1),_Digits);
      double sl=NormalizeDouble(entry+p.slPrice,_Digits);
      total+=V2_MoneyRiskAtSL(_Symbol,false,lotSell,entry,sl);
     }
   return total;
  }

bool V2_ScaleStraddleToRisk(const S_StraddlePlan &p,double bid,double ask,double &lotBuy,double &lotSell,string engine)
  {
   if(!UsePortfolioRiskGovernorV2) return (lotBuy>0.0 || lotSell>0.0);
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   if(equity<=0.0) return false;
   double currentSymbol=V2_CurrentRiskMoney(true);
   double currentAccount=V2_CurrentRiskMoney(false);
   double symbolRemaining=equity*MaxSymbolCampaignRiskPctV2/100.0-currentSymbol;
   double accountRemaining=equity*MaxPortfolioRiskPctV2/100.0-currentAccount;
   double singleCap=equity*MaxSingleLegRiskPctV2/100.0;
   double planRisk=V2_StraddlePlannedRisk(p,bid,ask,lotBuy,lotSell);
   if(planRisk<=0.0 || symbolRemaining<=0.0 || accountRemaining<=0.0) return false;
   double maxLeg=0.0;
   for(int i=0;i<p.buys;i++)
     {
      double entry=NormalizeDouble(ask+p.gap*(i+1),_Digits);
      maxLeg=MathMax(maxLeg,V2_MoneyRiskAtSL(_Symbol,true,lotBuy,entry,NormalizeDouble(entry-p.slPrice,_Digits)));
     }
   for(int i=0;i<p.sells;i++)
     {
      double entry=NormalizeDouble(bid-p.gap*(i+1),_Digits);
      maxLeg=MathMax(maxLeg,V2_MoneyRiskAtSL(_Symbol,false,lotSell,entry,NormalizeDouble(entry+p.slPrice,_Digits)));
     }
   double scale=1.0;
   if(planRisk>symbolRemaining) scale=MathMin(scale,symbolRemaining/planRisk);
   if(planRisk>accountRemaining) scale=MathMin(scale,accountRemaining/planRisk);
   if(maxLeg>singleCap) scale=MathMin(scale,singleCap/maxLeg);
   if(scale<0.999999)
     {
      // Small extra cushion against volume-step rounding.
      scale*=0.98;
      if(lotBuy>0.0) lotBuy=NormalizeLots(lotBuy*scale);
      if(lotSell>0.0) lotSell=NormalizeLots(lotSell*scale);
      if((p.buys>0 && lotBuy<=0.0) && (p.sells>0 && lotSell<=0.0))
        { PrintFormat("[V2 STRADDLE] %s rejected: broker minimum lot exceeds campaign risk",engine); return false; }
      planRisk=V2_StraddlePlannedRisk(p,bid,ask,lotBuy,lotSell);
     }
   if(planRisk>symbolRemaining+0.02 || planRisk>accountRemaining+0.02)
     { PrintFormat("[V2 STRADDLE] %s rejected total=%.2f symbolFree=%.2f accountFree=%.2f",engine,planRisk,symbolRemaining,accountRemaining); return false; }
   PrintFormat("[V2 STRADDLE RESERVE] %s legs=%d risk=%.2f symbolFree=%.2f accountFree=%.2f lots(B/S)=%.4f/%.4f",engine,p.buys+p.sells,planRisk,symbolRemaining,accountRemaining,lotBuy,lotSell);
   return (lotBuy>0.0 || lotSell>0.0);
  }

bool PlaceBiasedStraddle(string engine, int direction, bool isJerk, bool isExtreme)
  {
   if(!UseBiasedStraddle) return false;
   if(direction == 0) return false;
   if(!MsgBudget_CanTrade()) return false;

   double atr5 = CurrentATR5;
   if(atr5 <= 0.0) atr5 = CurrentATR1;
   if(atr5 <= 0.0) return false;

   S_StraddlePlan p = BuildStraddlePlan(engine, direction, CurrentMoveState,
                                        isJerk, isExtreme, atr5);
   if(p.buys + p.sells == 0) return false;

   double baseLotBuy  = CalcLots(engine,  1, p.slPrice);
   double baseLotSell = CalcLots(engine, -1, p.slPrice);
   if(baseLotBuy <= 0.0 && baseLotSell <= 0.0) return false;

   double lotBuy  = (baseLotBuy  > 0.0) ? ValidateLot(baseLotBuy  * p.buyMult)  : 0.0;
   double lotSell = (baseLotSell > 0.0) ? ValidateLot(baseLotSell * p.sellMult) : 0.0;

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return false;

   // Hold one account-wide lock for preflight and all legs, preventing another chart from consuming reserved risk mid-batch.
   string batchLockName=""; double batchLockToken=0.0;
   bool ownBatchLock=false;
   if(UsePortfolioRiskGovernorV2)
     {
      if(!V2_AcquireRiskLock(batchLockName,batchLockToken)) return false;
      ownBatchLock=true; g_V2BatchLockHeld=true;
     }
   // Trim weak-side legs first if the per-symbol pending budget cannot fit the whole plan.
   int availSymbol=MathMax(0,MaxPendingTotal-CountPendingTotal());
   int availAccount=UseAccountWidePendingCapV2 ? MathMax(0,MaxAccountPendingOrdersV2-V2_CountAccountPendingOrders()) : availSymbol;
   int avail=MathMin(availSymbol,availAccount);
   while(p.buys+p.sells>avail)
     {
      bool favorBuy=(p.buyMult>=p.sellMult);
      if(favorBuy && p.sells>0) p.sells--;
      else if(!favorBuy && p.buys>0) p.buys--;
      else if(p.buys>0) p.buys--;
      else if(p.sells>0) p.sells--;
      else break;
     }
   if(p.buys+p.sells<=0)
     {
      Print("[V2 STRADDLE] no pending slots available");
      g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken);
      return false;
     }
   if(!V2_ScaleStraddleToRisk(p,bid,ask,lotBuy,lotSell,engine))
     { g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken); return false; }

   string prefix = engine + "_";
   ulong beforeTickets[];
   V3_SnapshotPendingTickets(beforeTickets);
   int expectedLegs=p.buys+p.sells;
   if((p.buys>0 && lotBuy<=0.0) || (p.sells>0 && lotSell<=0.0))
     {
      g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken);
      PrintFormat("[V3 STRADDLE REJECT] %s one planned side has no risk-valid lot",engine);
      return false;
     }
   int placed = 0;

   for(int i = 0; i < p.buys; i++)
     {
      if(lotBuy <= 0.0) break;
      double price = NormalizeDouble(ask + p.gap * (i + 1), _Digits);
      double sl    = NormalizeDouble(price - p.slPrice, _Digits);
      double tp    = NormalizeDouble(price + p.tpPrice, _Digits);
      if(SendStopV2(true, price, lotBuy, sl, tp,
                    prefix + "B" + IntegerToString(i))) placed++;
     }

   for(int i = 0; i < p.sells; i++)
     {
      if(lotSell <= 0.0) break;
      double price = NormalizeDouble(bid - p.gap * (i + 1), _Digits);
      double sl    = NormalizeDouble(price + p.slPrice, _Digits);
      double tp    = NormalizeDouble(price - p.tpPrice, _Digits);
      if(SendStopV2(false, price, lotSell, sl, tp,
                    prefix + "S" + IntegerToString(i))) placed++;
     }

   if(placed>0 && placed<expectedLegs && V3RollbackPartialBatches)
     {
      int removed=V3_RollbackNewPendingOrders(prefix,beforeTickets);
      PrintFormat("[V3 BATCH ROLLBACK] engine=%s expected=%d placed=%d removed=%d",engine,expectedLegs,placed,removed);
      g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken);
      return false;
     }
   if(placed == expectedLegs)
     {
      g_LastPlaceTime = TimeCurrent();
      g_LastEntryDir  = direction;
      g_LastEntryTime = TimeCurrent();
      g_StraddleActive = true;
      g_StraddleDir    = direction;

      PrintFormat("[STRADDLE %s] dir=%s buys=%d sells=%d lotB=%.3f lotS=%.3f "
                  "gap=%.0fpts SL=%.0f TP=%.0f",
                  engine, DirStr(direction), p.buys, p.sells,
                  lotBuy, lotSell,
                  p.gap / _Point,
                  p.slPrice / _Point, p.tpPrice / _Point);
      PrintFormat("[V3 BATCH COMPLETE] engine=%s expected=%d placed=%d accountPending=%d",engine,expectedLegs,placed,V2_CountAccountPendingOrders());
      g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken);
      return true;
     }

   if(placed>0 && V3RollbackPartialBatches)
     {
      int removed=V3_RollbackNewPendingOrders(prefix,beforeTickets);
      PrintFormat("[V3 BATCH ROLLBACK] engine=%s expected=%d placed=%d removed=%d",engine,expectedLegs,placed,removed);
     }
   g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken);
   return false;
  }

//===================================================================
// SECTION 87 — WIN-GATED GRID V2
//===================================================================
bool TryGridAddV2()
  {
   if(!UseWinGatedGrid) return false;
   if(g_GridLevelV2 >= GridMaxLevelsV2) return false;
   if(TimeCurrent() - g_LastGridAddV2 < GridCooldownSecV2) return false;
   if(!g_LastWasWin) return false;
   if(ConsecutiveWins < GridMinConsecutiveWins) return false;
   if(!MsgBudget_CanTrade()) return false;

   if(GridRequireTrendRegime)
     {
      if(g_R7 != R7_STRONG_UP && g_R7 != R7_STRONG_DOWN &&
         g_R7 != R7_EXPANSION && g_R7 != R7_WEAK_UP && g_R7 != R7_WEAK_DOWN)
         return false;
     }

   string prefixes[4] = {"SWING_","MONSTER_","RANGE_","REVERSAL_"};
   string activeEngine = "";
   for(int i = 0; i < 4; i++)
     {
      if(CountEnginePositions(prefixes[i]) > 0 ||
         CountEngineOrders(prefixes[i]) > 0)
        { activeEngine = prefixes[i]; break; }
     }
   if(activeEngine == "") return false;

   int dir = 0;
   if(g_R7 == R7_STRONG_UP || g_R7 == R7_WEAK_UP || g_R7 == R7_EXPANSION) dir = 1;
   if(g_R7 == R7_STRONG_DOWN || g_R7 == R7_WEAK_DOWN) dir = -1;
   if(UseFastTrendScore && g_FastTrendDir != 0 && g_FastTrendScore >= FastTrend_PrimeThreshold)
      dir = g_FastTrendDir;
   if(dir == 0) return false;

   string engineShort = activeEngine;
   StringReplace(engineShort, "_", "");

   double atr5 = CurrentATR5;
   if(atr5 <= 0.0) return false;

   double slPrice = ComputeSLDistance(engineShort);
   double tpPrice = ComputeTPDistance(engineShort, slPrice);
   double gap     = atr5 * GridGapATRMult;

   double baseLot = BaseLotForEngine(engineShort);
   if(baseLot <= 0.0) baseLot = Range_Lot;

   double lotMult = MathPow(GridLotMultV2, (double)(ConsecutiveWins + g_GridLevelV2));
   double gridLot = ValidateLot(baseLot * lotMult);
   if(gridLot <= 0.0) return false;

   if(TotalOurLots() + gridLot > CapTotalLots() + 1e-12) return false;

   double bid = BidPrice(), ask = AskPrice();
   bool ok = false;
   string cmt = activeEngine + "G" + IntegerToString(g_GridLevelV2 + 1);

   if(dir == 1)
     {
      double price = NormalizeDouble(ask + gap, _Digits);
      double sl    = NormalizeDouble(price - slPrice, _Digits);
      double tp    = NormalizeDouble(price + tpPrice, _Digits);
      ok = SendStopV2(true, price, gridLot, sl, tp, cmt);
     }
   else
     {
      double price = NormalizeDouble(bid - gap, _Digits);
      double sl    = NormalizeDouble(price + slPrice, _Digits);
      double tp    = NormalizeDouble(price - tpPrice, _Digits);
      ok = SendStopV2(false, price, gridLot, sl, tp, cmt);
     }

   if(ok)
     {
      g_GridLevelV2++;
      g_LastGridAddV2 = TimeCurrent();
      PrintFormat("[GRID V2] level=%d engine=%s dir=%d lot=%.3f wins=%d",
                  g_GridLevelV2, engineShort, dir, gridLot, ConsecutiveWins);
     }
   return ok;
  }

//===================================================================
// SECTION 88 — VWAP CHOP STRADDLE [A6: log outcome]
//===================================================================
bool PlaceVWAPChopStraddle()
  {
   if(!UseVWAPChopStraddle && !V3EnableCompressionOCO) return false;
   if(!MsgBudget_CanTrade()) return false;
   // V2: paired stops are only for measurable neutral compression, never generic CHOP.
   if(g_R7 != R7_COMPRESSION) return false;
   if(UseFastTrendScore && g_FastTrendScore >= FastTrend_ChopThreshold) return false;
   if(CountEnginePositions("CHOP_") > 0 || CountEngineOrders("CHOP_") > 0) return false;
   if(CurrentATR5 <= 0.0 || Bars(_Symbol,PERIOD_M5) < 12) return false;

   double rangeHigh=TfHigh(PERIOD_M5,1), rangeLow=TfLow(PERIOD_M5,1);
   if(rangeHigh<=0.0 || rangeLow<=0.0) return false;
   for(int bar=2;bar<=8;bar++)
     {
      double bh=TfHigh(PERIOD_M5,bar), bl=TfLow(PERIOD_M5,bar);
      if(bh<=0.0 || bl<=0.0) return false;
      rangeHigh=MathMax(rangeHigh,bh); rangeLow=MathMin(rangeLow,bl);
     }
   double rangeWidth=rangeHigh-rangeLow;
   if(rangeWidth<=0.0 || rangeWidth>CurrentATR5*4.0) return false;

   double bid=BidPrice(), ask=AskPrice();
   if(bid<=0.0 || ask<=0.0 || ask<bid) return false;

   int bias = GetVWAPBias();
   int buys  = VWAPChopBuyOrders;
   int sells = VWAPChopSellOrders;
   if(bias == 1)  { buys = MathMax(1,VWAPChopBuyOrders); sells = MathMax(1,VWAPChopSellOrders-1); }
   if(bias == -1) { buys = MathMax(1,VWAPChopBuyOrders-1); sells = MathMax(1,VWAPChopSellOrders); }

   double atr = CurrentATR5; // confirmed M5 volatility controls the compression boundary
   double slDist = ComputeSLDistance("RANGE");
   double tpDist = ComputeTPDistance("RANGE", slDist);
   double baseGap = MathMax(atr*0.35, MathMax(SafeTrailBuffer()*2.0,StopsLevelPrice()*2.0));
   // True OCO boundaries are beyond the measured compression high/low, not just a fixed gap from mid.
   double boundaryBuffer=MathMax(SafeTrailBuffer(),atr*0.08);
   double buyGap=MathMax(baseGap,rangeHigh+boundaryBuffer-ask);
   double sellGap=MathMax(baseGap,bid-(rangeLow-boundaryBuffer));
   buyGap=MathMax(buyGap,StopsLevelPrice()*2.0);
   sellGap=MathMax(sellGap,StopsLevelPrice()*2.0);
   double riskGap=MathMax(buyGap,sellGap);

   double baseLot = Range_Lot * VWAPChopLotMult;
   double lot = CalcLots("RANGE", bias == -1 ? -1 : 1, slDist);
   if(lot <= 0.0) lot = ValidateLot(baseLot);
   lot = ValidateLot(lot);
   if(lot <= 0.0) return false;

   // Quotes were validated above and are reused for all preflight calculations.

   // Reserve risk for every intended leg before sending either side; hold lock across the batch.
   S_StraddlePlan chopPlan;
   chopPlan.buys=buys; chopPlan.sells=sells; chopPlan.buyMult=1.0; chopPlan.sellMult=1.0;
   chopPlan.slPrice=slDist; chopPlan.tpPrice=tpDist; chopPlan.gap=riskGap;
   chopPlan.isExtreme=false; chopPlan.isJerk=false;
   string batchLockName=""; double batchLockToken=0.0; bool ownBatchLock=false;
   if(UsePortfolioRiskGovernorV2)
     {
      if(!V2_AcquireRiskLock(batchLockName,batchLockToken)) return false;
      ownBatchLock=true; g_V2BatchLockHeld=true;
     }
   double lotBuy=lot, lotSell=lot;
   if(!V2_ScaleStraddleToRisk(chopPlan,bid,ask,lotBuy,lotSell,"CHOP_OCO"))
     { g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken); return false; }
   int availSymbol=MathMax(0,MaxPendingTotal-CountPendingTotal());
   int availAccount=UseAccountWidePendingCapV2 ? MathMax(0,MaxAccountPendingOrdersV2-V2_CountAccountPendingOrders()) : availSymbol;
   int avail=MathMin(availSymbol,availAccount);
   if(buys+sells>avail)
     {
      PrintFormat("[V3 COMPRESSION OCO] rejected: legs=%d symbolSlots=%d accountSlots=%d",buys+sells,availSymbol,availAccount);
      g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken); return false;
     }

   ulong beforeTickets[];
   V3_SnapshotPendingTickets(beforeTickets);
   int placed = 0;
   int expectedLegs=buys+sells;

   for(int i = 0; i < sells; i++)
     {
      double price = NormalizeDouble(bid - sellGap * (i + 1), _Digits);
      double sl    = NormalizeDouble(price + slDist, _Digits);
      double tp    = NormalizeDouble(price - tpDist, _Digits);
      if(SendStopV2(false, price, lotSell, sl, tp,
                    "CHOP_S" + IntegerToString(i))) placed++;
     }

   for(int i = 0; i < buys; i++)
     {
      double price = NormalizeDouble(ask + buyGap * (i + 1), _Digits);
      double sl    = NormalizeDouble(price - slDist, _Digits);
      double tp    = NormalizeDouble(price + tpDist, _Digits);
      if(SendStopV2(true, price, lotBuy, sl, tp,
                    "CHOP_B" + IntegerToString(i))) placed++;
     }

   if(placed>0 && placed<expectedLegs && V3RollbackPartialBatches)
     {
      int removed=V3_RollbackNewPendingOrders("CHOP_",beforeTickets);
      PrintFormat("[V3 BATCH ROLLBACK] route=COMPRESSION_OCO expected=%d placed=%d removed=%d",expectedLegs,placed,removed);
      g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken);
      return false;
     }
   if(placed == expectedLegs)
     {
      g_LastPlaceTime = TimeCurrent();
      //--- [A6] log CHOP order outcome with pending count
      PrintFormat("[V3 COMPRESSION OCO] bias=%d buys=%d sells=%d lotB/S=%.3f/%.3f gap=%.0fpts placed=%d pendingNow=%d",
                  bias, buys, sells, lotBuy, lotSell, riskGap / _Point, placed, CountPendingTotal());
      g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken);
      return true;
     }
   if(placed>0 && V3RollbackPartialBatches)
     {
      int removed=V3_RollbackNewPendingOrders("CHOP_",beforeTickets);
      PrintFormat("[V3 BATCH ROLLBACK] route=COMPRESSION_OCO expected=%d placed=%d removed=%d",expectedLegs,placed,removed);
     }
   g_V2BatchLockHeld=false; if(ownBatchLock) V2_ReleaseRiskLock(batchLockName,batchLockToken);
   return false;
  }

//===================================================================
// SECTION 89 — STRADDLE / CHOP HELPERS
//===================================================================
bool IsStraddleJerkContext()
  {
   if(Jerk_M15 != 0 && MSSFresh(Jerk_M15)) return true;
   if(Jerk_M5  != 0 && Jerk_M5 == M15Direction) return true;
   return false;
  }

bool IsStraddleExtremeContext()
  {
   if(!BridgeReady()) return false;
   if(!VNFlowTradeRateSurge()) return false;
   if(gFlow.persistence < 0.60) return false;
   if(MathAbs(FlowComposite()) < BinanceStrongFlowScore) return false;
   return true;
  }

void CleanupStraddleIfFilled()
  {
   if(!g_StraddleActive) return;
   int posCount = CountOurPositions();
   if(posCount > 0) return;
  }

//===================================================================
// SECTION 90 — REVERSAL 11-CHECK COUNTER
//===================================================================
bool Rev_Check_POCFail(int dir)
  {
   double price = MidPrice();
   if(price <= 0.0) return false;
   if(gBinAux.valid)
     {
      if(dir ==  1 && gBinAux.naked_below > 0.0 && price < gBinAux.naked_below) return true;
      if(dir == -1 && gBinAux.naked_above > 0.0 && price > gBinAux.naked_above) return true;
     }
   double h=-1e18, l=1e18;
   for(int i=1;i<=12;i++)
     {
      h = MathMax(h, TfHigh(PERIOD_M5, i));
      l = MathMin(l, TfLow (PERIOD_M5, i));
     }
   if(dir ==  1) return (price <= l + CurrentATR1 * 0.25);
   return (price >= h - CurrentATR1 * 0.25);
  }

bool Rev_Check_VWAPFail(int dir)
  {
   double vwap = GetVWAPValue();
   if(vwap <= 0.0) return false;
   double price = MidPrice();
   if(price <= 0.0 || CurrentATR1 <= 0.0) return false;
   if(dir ==  1) return (price < vwap - CurrentATR1 * 0.35);
   return (price > vwap + CurrentATR1 * 0.35);
  }

bool Rev_Check_CVDFlip(int dir)
  {
   if(MQLInfoInteger(MQL_TESTER)) return false;
   if(!FlowFresh()) return false;
   double fc = FlowComposite() * (double)dir;
   return (fc <= -BinanceStrongFlowScore);
  }

bool Rev_Check_StructureBreak(int dir)
  {
   if(CurrentATR1 <= 0.0) return false;
   if(dir ==  1) return M1BullMSS() || g_SMC.m1_event == 1;
   if(dir == -1) return M1BearMSS() || g_SMC.m1_event == -1;
   return false;
  }

bool Rev_Check_OrderbookFail(int dir)
  {
   if(!gBinAux.valid) return false;
   double price = MidPrice();
   if(price <= 0.0) return false;
   if(dir ==  1 && gBinAux.ask_wall_price > 0.0)
      return ((gBinAux.ask_wall_price - price) / _Point < 100.0);
   if(dir == -1 && gBinAux.bid_wall_price > 0.0)
      return ((price - gBinAux.bid_wall_price) / _Point < 100.0);
   return false;
  }

bool Rev_Check_PriceActionShift(int dir)
  {
   if(dir ==  1) return (M1BullSweep() || M1BullMSS() || M1BullFVG());
   if(dir == -1) return (M1BearSweep() || M1BearMSS() || M1BearFVG());
   return false;
  }

bool Rev_Check_SMCShift(int dir)
  {
   if(!UseSMCStructure) return false;
   return (dir ==  1) ? (g_SMC.m1_event == 1  || g_SMC.m5_event == 1)
                      : (g_SMC.m1_event == -1 || g_SMC.m5_event == -1);
  }

bool Rev_Check_EqualLiqSweep(int dir)
  {
   if(!UseEqualLiquidity) return false;
   return (dir ==  1 && g_SMC.bull_liq_sweep) || (dir == -1 && g_SMC.bear_liq_sweep);
  }

bool Rev_Check_LiqSessionSweep(int dir)
  {
   string source = "";
   int d = DetectLiquiditySweep(source);
   return (d == dir);
  }

bool Rev_Check_M1FVG(int dir)
  {
   return (dir ==  1 && M1BullFVG()) || (dir == -1 && M1BearFVG());
  }

bool Rev_Check_Displacement(int dir)
  {
   return (dir ==  1 && M1BullDisplacement()) || (dir == -1 && M1BearDisplacement());
  }

int Rev_CountConfirmations(int dir)
  {
   int n = 0;
   if(Rev_Check_POCFail(dir))           n++;
   if(Rev_Check_VWAPFail(dir))          n++;
   if(Rev_Check_CVDFlip(dir))           n++;
   if(Rev_Check_StructureBreak(dir))    n++;
   if(Rev_Check_OrderbookFail(dir))     n++;
   if(Rev_Check_PriceActionShift(dir))  n++;
   if(Rev_Check_SMCShift(dir))          n++;
   if(Rev_Check_EqualLiqSweep(dir))     n++;
   if(Rev_Check_LiqSessionSweep(dir))   n++;
   if(Rev_Check_M1FVG(dir))             n++;
   if(Rev_Check_Displacement(dir))      n++;
   return n;
  }

//===================================================================
// SECTION 91 — TIER 1 REVERSAL HARD GATES
//===================================================================
bool Rev_SessionSweepPresent(int dir)
  {
   if(!RevRequireSessionSweep) return true;
   string source = "";
   int d = DetectLiquiditySweep(source);
   if(d == dir && source != "") return true;
   if(dir ==  1 && g_SMC.bull_liq_sweep) return true;
   if(dir == -1 && g_SMC.bear_liq_sweep) return true;
   if(g_NVP.valid)
     {
      double price = MidPrice();
      if(dir ==  1 && price < g_NVP.val) return true;
      if(dir == -1 && price > g_NVP.vah) return true;
     }
   return false;
  }

bool Rev_CVDFlipHardGatePasses(int dir)
  {
   if(!RevRequireCVDFlipHardGate) return true;
   if(MQLInfoInteger(MQL_TESTER)) return true;
   if(!FlowFresh()) return true;
   double fc = FlowComposite() * (double)dir;
   if(fc <= -BinanceStrongFlowScore) return false;
   return true;
  }

bool Rev_FastTrendNotOpposed(int dir)
  {
   if(!RevBlockOnFastTrendOppose) return true;
   if(!UseFastTrendScore) return true;
   if(g_FastTrendScore >= FastTrend_PrimeThreshold)
     {
      if(g_FastTrendDir != 0 && g_FastTrendDir != dir) return false;
     }
   return true;
  }

bool Rev_HardGatesPass(int dir)
  {
   if(!Rev_SessionSweepPresent(dir))     { Print("[REV BLOCK] no session sweep");   return false; }
   if(!Rev_CVDFlipHardGatePasses(dir))   { Print("[REV BLOCK] CVD strongly opposes"); return false; }
   if(!Rev_FastTrendNotOpposed(dir))     { Print("[REV BLOCK] FastTrend opposes");   return false; }
   if(!RegimeGateAllows(dir, "REVERSAL"))
     { Print("[REV BLOCK] regime gate"); return false; }
   return true;
  }

//===================================================================
// SECTION 92 — REVERSAL CLOSE-ALL [A8: close confirmed, not just profitable]
//===================================================================
void ReversalCloseAllIfProfitable()
  {
   int totalPos = CountOurPositions();
   if(totalPos <= 0)
     {
      DeleteOrdersPrefix("SWING_");
      DeleteOrdersPrefix("MONSTER_");
      DeleteOrdersPrefix("RANGE_");
      DeleteOrdersPrefix("CHOP_");
      return;
     }

   double totalPnL = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      totalPnL += posInfo.Profit() + posInfo.Swap() + posInfo.Commission();
     }

   //--- [A8] If profitable, close all. If losing and reversal is confirmed, still close all.
   // A confirmed reversal means the trend is going against us — holding losers is worse.
   bool hasStrongReversal = (g_RevConfirmCount >= 8);

   if(totalPnL < 0.0 && !hasStrongReversal)
     {
      PrintFormat("[REV CYCLE] floating %.2f < 0 and weak confirm — close-all skipped",
                  totalPnL);
      return;
     }

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      ClosePosition(posInfo.Ticket());
     }
   DeleteOrdersPrefix("SWING_");
   DeleteOrdersPrefix("MONSTER_");
   DeleteOrdersPrefix("RANGE_");
   DeleteOrdersPrefix("CHOP_");

   for(int i = 0; i < 4; i++)
     {
      g_EngineLossStreak[i] = 0;
      g_EngineWinStreak[i]  = 0;
     }
   g_GridLevelV2   = 0;
   g_StraddleActive = false;
   g_StraddleDir    = 0;

   PrintFormat("[REV CYCLE RESET] closed all, floating=%.2f confirm=%d",
               totalPnL, g_RevConfirmCount);
  }

//===================================================================
// SECTION 93 — REVERSAL EXECUTOR
//===================================================================
bool PlaceReversalSingle(int direction)
  {
   if(direction == 0) return false;
   if(!Health_AllowsNewEntries()) return false;
   if(!EngineBudgetOK("REVERSAL"))   return false;
   if(!EngineCooldownOK("REVERSAL")) return false;
   if(!MsgBudget_CanTrade()) return false;

   ReversalCloseAllIfProfitable();

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      int pdir = (posInfo.PositionType() == POSITION_TYPE_BUY) ? 1 : -1;
      if(pdir != direction) ClosePosition(posInfo.Ticket());
     }

   double atr5 = CurrentATR5;
   if(atr5 <= 0.0) atr5 = CurrentATR1;
   if(atr5 <= 0.0) return false;

   double slDist = ComputeSLDistance("REVERSAL");
   double tpDist = ComputeTPDistance("REVERSAL", slDist);

   double lots = CalcLots("REVERSAL", direction, slDist);
   if(lots <= 0.0)
     {
      double fallback = BaseLotForEngine("REVERSAL") * ContinuousGrowthMultiplier()
                        * SpreadThrottle();
      lots = ValidateLot(fallback);
     }
   if(lots <= 0.0) return false;

   if(!EntryAllowed("REVERSAL", lots, direction)) return false;

   double entry = (direction == 1) ? AskPrice() : BidPrice();
   if(entry <= 0.0) return false;
   double sl = (direction == 1) ? entry - slDist : entry + slDist;
   double tp = (direction == 1) ? entry + tpDist : entry - tpDist;

   string cmt = "REVERSAL_" + (direction == 1 ? "B" : "S");

   bool ok = SendMarketV2(
      (direction == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
      lots,
      NormalizeDouble(sl, _Digits),
      NormalizeDouble(tp, _Digits),
      cmt);

   if(ok)
     {
      g_LastPlaceTime = TimeCurrent();
      g_LastEntryDir  = direction;
      g_LastEntryTime = TimeCurrent();
      g_LastEngine    = ENG_REVERSAL;
      g_LastModelEngine = "REVERSAL";
      CancelOtherEnginePendingOrders("REVERSAL_");
      ReversalPartial = false;

      int ridx = EngineIndexFromName("REVERSAL");
      if(ridx >= 0)
         g_EngineCooldown[ridx] = TimeCurrent() + 30 * 60;

      PrintFormat("[REVERSAL] dir=%s lots=%.4f SL=%.0f TP=%.0f checks=%d",
                  DirStr(direction), lots, slDist / _Point, tpDist / _Point,
                  g_RevConfirmCount);
     }
   return ok;
  }

bool Rev_Tick()
  {
   int posCount = CountOurPositions();
   if(posCount > 0)
     {
      if(g_RevState != REV_IDLE)
        {
         g_RevState = REV_IDLE;
         g_RevDir   = 0;
         g_RevConfirmCount = 0;
        }
      return false;
     }

   if(!EngineBudgetOK("REVERSAL"))   return false;
   if(!EngineCooldownOK("REVERSAL")) return false;

   double range = TfHigh(PERIOD_M1, 1) - TfLow(PERIOD_M1, 1);
   bool wickPresent = (CurrentATR1 > 0.0 && range >= CurrentATR1 * 1.8);

   if(g_RevState == REV_IDLE)
     {
      if(wickPresent)
        {
         double o = TfOpen(PERIOD_M1, 1);
         double c = TfClose(PERIOD_M1, 1);
         g_RevDir = (c < o) ? 1 : -1;
         g_RevState = REV_WATCH;
         g_RevWatchSince = TimeCurrent();
         g_RevConfirmCount = 0;
         PrintFormat("[REV WATCH] candidate dir=%d range=%.0fpts",
                     g_RevDir, range / _Point);
        }
      return false;
     }

   if(g_RevState == REV_WATCH)
     {
      if(TimeCurrent() - g_RevWatchSince > Rev_WatchMaxMinutes * 60)
        {
         g_RevState = REV_IDLE;
         return false;
        }
      int n = Rev_CountConfirmations(g_RevDir);
      if(n >= 4)
        {
         g_RevState = REV_ALERT;
         g_RevConfirmCount = n;
         PrintFormat("[REV ALERT] dir=%d checks=%d", g_RevDir, n);
        }
      return false;
     }

   if(g_RevState == REV_ALERT)
     {
      int n = Rev_CountConfirmations(g_RevDir);
      g_RevConfirmCount = n;

      if(n >= 7)
        {
         if(!Rev_HardGatesPass(g_RevDir))
           {
            Print("[REV ABORT] hard gate");
            g_RevState = REV_IDLE;
            return false;
           }
         if(!M15VetoAllows(g_RevDir)) { Print("[REV ABORT] M15 veto"); g_RevState = REV_IDLE; return false; }
         if(!H1VetoAllows(g_RevDir))  { Print("[REV ABORT] H1 veto");  g_RevState = REV_IDLE; return false; }

         g_RevState = REV_CONFIRM;
         bool ok = PlaceReversalSingle(g_RevDir);
         g_RevState = REV_IDLE;
         return ok;
        }
      if(n < 4)
         g_RevState = REV_IDLE;
     }
   return false;
  }

//===================================================================
// SECTION 94 — CUSUM SHOCK [A3: bypass regime gate when fresh]
//===================================================================
bool CUSUMShockRun()
  {
   if(!UseCUSUM) return false;
   if((V3EnableRangeLimitRoute && g_R7==R7_CHOP) ||
      (V3EnableCompressionOCO && g_R7==R7_COMPRESSION)) return false;
   if(g_CUSUMDir == 0) return false;
   if(TimeCurrent() > g_CUSUMOverrideUntil) return false;

   if(CountOurPositions() > 0) return false;
   if(CountPendingTotal() > 0)  return false;
   if(!EngineCooldownOK("MONSTER")) return false;
   if(!EngineBudgetOK("MONSTER"))   return false;
   if(!MsgBudget_CanTrade()) return false;

   int dir = g_CUSUMDir;
   bool pa = (dir ==  1)
             ? (M1BullDisplacement() || M1BullMSS() || M1BullSweep())
             : (M1BearDisplacement() || M1BearMSS() || M1BearSweep());
   if(!pa) return false;
   if(!Flow_NotOpposed(dir)) return false;

   //--- [A3] Bypass regime gate if CUSUM is fresh (change-point is stronger signal)
   bool cusumFresh = (TimeCurrent() - g_CUSUMLastFire <= CUSUMFreshSeconds);
   if(!cusumFresh && !RegimeGateAllows(dir, "MONSTER"))
     {
      Print("[CUSUM BLOCK] regime gate");
      return false;
     }

   double slDist = ComputeSLDistance("MONSTER") * 0.80;
   slDist = MathMax(slDist, StopsLevelPrice() * 2.0);
   double tpDist = slDist * TP_RR_Monster;

   double lots = CalcLots("MONSTER", dir, slDist);
   if(lots <= 0.0) return false;
   if(!HardGatesPass("MONSTER", dir)) return false;
   if(!EntryAllowed("MONSTER", lots, dir)) return false;

   if(UseBiasedStraddle && !V3EnableShockBreakoutStop && !IsStraddleExtremeContext())
     {
      if(PlaceBiasedStraddle("MONSTER", dir, true, false))
        {
         g_LastModelEngine = "MONSTER_SHOCK";
         g_LastEngine      = ENG_CUSUM;
         g_MonsterPhase    = MP_ACCELERATION;
         g_MonsterStart    = TimeCurrent();
         g_MonsterDir      = dir;
         g_MonsterPyramidCount = 0;
         g_MonsterPeakR    = 0.0;
         g_LastPyramidAt   = TimeCurrent();
         int mbi = EngineIndexFromName("MONSTER");
         if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
         CancelOtherEnginePendingOrders("MONSTER_");
         PrintFormat("[CUSUM SHOCK STRADDLE] dir=%s", DirStr(dir));
         return true;
        }
     }

   double marketRef = (dir == 1) ? AskPrice() : BidPrice();
   if(marketRef <= 0.0) return false;
   double entry = marketRef;
   double stop = 0.0, take = 0.0;
   bool ok=false;
   string cmt = "MONSTER_SHOCK_" + (dir == 1 ? "B" : "S");

   if(V3EnableShockBreakoutStop)
     {
      // Do not buy/sell the end of the impulse candle. Wait for price to
      // continue through its completed-bar extreme; if it immediately reverses,
      // the pending order is never triggered.
      double impulseHigh=TfHigh(PERIOD_M1,1);
      double impulseLow =TfLow(PERIOD_M1,1);
      double spreadPrice=MathMax(0.0,AskPrice()-BidPrice());
      double safeBuffer=MathMax(CurrentATR1*MathMax(0.05,V3ShockBreakoutBufferATR),
                                MathMax(StopsLevelPrice()*2.0,MathMax(SafeTrailBuffer(),spreadPrice*2.0)));
      double minDist=MathMax(StopsLevelPrice()*1.25,spreadPrice*2.0);
      if(dir==1)
         entry=NormalizeDouble(MathMax(impulseHigh+safeBuffer,AskPrice()+minDist),_Digits);
      else
         entry=NormalizeDouble(MathMin(impulseLow-safeBuffer,BidPrice()-minDist),_Digits);

      double extension=MathAbs(entry-marketRef);
      double maxChase=MathMax(CurrentATR1*MathMax(0.10,V3ShockMaxChaseATR),minDist*1.10);
      if(CurrentATR1<=0.0 || impulseHigh<=impulseLow || extension>maxChase)
        {
         PrintFormat("[V3.4 SHOCK SKIP] dir=%s trigger too extended; quote=%.5f trigger=%.5f extension=%.5f max=%.5f ATR1=%.5f",
                     DirStr(dir),marketRef,entry,extension,maxChase,CurrentATR1);
         return true; // consume this valid shock candidate; do not let another engine market-enter the same impulse
        }
      stop=(dir==1) ? entry-slDist : entry+slDist;
      take=(dir==1) ? entry+tpDist : entry-tpDist;
      cmt="MONSTER_SHOCK_STOP_"+(dir==1 ? "B" : "S");
      ok=SendStopV2(dir==1,entry,lots,NormalizeDouble(stop,_Digits),NormalizeDouble(take,_Digits),cmt);
      if(ok)
         PrintFormat("[V3.4 SHOCK STOP ARMED] dir=%s trigger=%.5f quote=%.5f extensionATR=%.2f lots=%.4f SL=%.5f TP=%.5f",
                     DirStr(dir),entry,marketRef,(CurrentATR1>0.0?extension/CurrentATR1:0.0),lots,NormalizeDouble(stop,_Digits),NormalizeDouble(take,_Digits));
     }
   else
     {
      stop=(dir==1) ? entry-slDist : entry+slDist;
      take=(dir==1) ? entry+tpDist : entry-tpDist;
      ok=SendMarketV2((dir==1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,lots,
                      NormalizeDouble(stop,_Digits),NormalizeDouble(take,_Digits),cmt);
     }

   if(ok)
     {
      g_MonsterPhase        = MP_ACCELERATION;
      g_MonsterStart        = TimeCurrent();
      g_MonsterDir          = dir;
      g_MonsterPyramidCount = 0;
      g_MonsterPeakR        = 0.0;
      g_LastPyramidAt       = TimeCurrent();
      g_LastPlaceTime       = TimeCurrent();
      g_LastEntryDir        = dir;
      g_LastEntryTime       = TimeCurrent();
      g_LastModelEngine     = "MONSTER_SHOCK";
      g_LastEngine          = ENG_CUSUM;
      int mbi = EngineIndexFromName("MONSTER");
      if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
      CancelOtherEnginePendingOrders("MONSTER_");
      PrintFormat("[CUSUM SHOCK %s] dir=%s lots=%.4f SL=%.0f TP=%.0f",
                  (V3EnableShockBreakoutStop?"STOP":"MARKET"),DirStr(dir),lots,slDist/_Point,tpDist/_Point);
     }
   if(V3EnableShockBreakoutStop) return true; // shock route owns the signal even if order validation/risk says wait
   return ok;
  }

//===================================================================
// SECTION 95 — KILLSHOT TRIGGER
//===================================================================
bool KillShotTrigger(int &outDir)
  {
   outDir = 0;
   if(!UseKillShot) return false;
   if(CountOurPositions() > 0) return false;
   if(CountPendingTotal()  > 0) return false;
   if(!EngineCooldownOK("MONSTER")) return false;
   if(!EngineBudgetOK("MONSTER"))   return false;

   int expDir = 0; double expStr = 0.0;
   if(!IsExplosiveBar(expDir, expStr)) return false;
   if(expStr < KillShotMinStrength)    return false;

   int c = 0;
   if(M5Direction  == expDir || M5Direction  == 0) c++;
   if(M15Direction == expDir || M15Direction == 0) c++;
   if(VNSMC_TrendBreak(expDir)) c++;

   double avgVol = 0.0; int vc = 0;
   for(int i = 3; i <= 22; i++)
     {
      long v = TfVolume(PERIOD_M1, i);
      if(v > 0) { avgVol += (double)v; vc++; }
     }
   if(vc > 0) avgVol /= (double)vc;
   long v1 = TfVolume(PERIOD_M1, 1);
   long v2 = TfVolume(PERIOD_M1, 2);
   if(avgVol > 0.0 && (double)v1 >= avgVol * 1.5 && (double)v2 >= avgVol * 1.5) c++;

   int sameDir = 0;
   for(int i = 2; i <= 4; i++)
     {
      double o = TfOpen(PERIOD_M1, i);
      double cc = TfClose(PERIOD_M1, i);
      if(o <= 0.0 || cc <= 0.0) continue;
      if(expDir ==  1 && cc > o) sameDir++;
      if(expDir == -1 && cc < o) sameDir++;
     }
   if(sameDir < 3) c++;

   double barRange = TfHigh(PERIOD_M1, 1) - TfLow(PERIOD_M1, 1);
   if(NormalATR1 > 0.0 && barRange >= NormalATR1 * 1.8) c++;

   int liveC = 0;
   if(BridgeReady())
     {
      if(CVDVelocityNormalized * expDir >= 0.20) liveC++;
      if(!WallInPath(expDir)) liveC++;
     }

   if(c < 5) return false;

   int s8 = GetSuper8();
   if(s8 != 0 && s8 != expDir) return false;

   if(!Flow_NotOpposed(expDir)) return false;
   if(!RegimeGateAllows(expDir, "MONSTER"))
     { Print("[KILLSHOT BLOCK] regime gate"); return false; }

   outDir = expDir;
   return true;
  }

bool KillShotFastPath()
  {
   if((V3EnableRangeLimitRoute && g_R7==R7_CHOP) ||
      (V3EnableCompressionOCO && g_R7==R7_COMPRESSION)) return false;
   int dir = 0;
   if(!KillShotTrigger(dir)) return false;
   if(!MsgBudget_CanTrade()) return false;

   double atr = CurrentATR5;
   if(atr <= 0.0) return false;

   double slDist = ComputeSLDistance("MONSTER") * KillShotSL_Shrink;
   slDist = MathMax(slDist, StopsLevelPrice() * 2.0);
   double tpDist = slDist * KillShotTP_RR;

   double sizeBoost = 1.0;
   if(UseKillShotPrimeBoost)
     {
      MqlDateTime dt;
      TimeToStruct(TimeGMT(), dt);
      if(dt.hour >= SessionPrimeStartUTC && dt.hour < SessionPrimeEndUTC)
         sizeBoost = KillShotPrimeSizeMult;
     }

   double lots = CalcLots("MONSTER", dir, slDist);
   if(lots <= 0.0) return false;
   lots = ValidateLot(lots * sizeBoost);
   if(lots <= 0.0) return false;

   if(!HardGatesPass("MONSTER", dir)) return false;
   if(!EntryAllowed("MONSTER", lots, dir)) return false;

   if(UseBiasedStraddle && IsStraddleExtremeContext())
     {
      if(PlaceBiasedStraddle("MONSTER", dir, false, true))
        {
         g_MonsterPhase = MP_ACCELERATION;
         g_MonsterStart = TimeCurrent();
         g_MonsterDir   = dir;
         g_MonsterPyramidCount = 0;
         g_MonsterPeakR = 0.0;
         g_LastPyramidAt = TimeCurrent();
         g_LastModelEngine = "MONSTER_KILLSHOT";
         g_LastEngine      = ENG_KILLSHOT;
         int mbi = EngineIndexFromName("MONSTER");
         if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
         CancelOtherEnginePendingOrders("MONSTER_");
         PrintFormat("[KILLSHOT STRADDLE] dir=%s", DirStr(dir));
         return true;
        }
     }

   double entry = (dir == 1) ? AskPrice() : BidPrice();
   if(entry <= 0.0) return false;
   double stop = (dir == 1) ? entry - slDist : entry + slDist;
   double take = (dir == 1) ? entry + tpDist : entry - tpDist;

   string cmt = "MONSTER_FAST_" + (dir == 1 ? "B" : "S");
   bool ok = SendMarketV2(
      (dir == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
      lots,
      NormalizeDouble(stop, _Digits),
      NormalizeDouble(take, _Digits),
      cmt);

   if(ok)
     {
      g_MonsterPhase        = MP_ACCELERATION;
      g_MonsterStart        = TimeCurrent();
      g_MonsterDir          = dir;
      g_MonsterPyramidCount = 0;
      g_MonsterPeakR        = 0.0;
      g_LastPyramidAt       = TimeCurrent();
      g_LastPlaceTime       = TimeCurrent();
      g_LastEntryDir        = dir;
      g_LastEntryTime       = TimeCurrent();
      g_LastModelEngine     = "MONSTER_KILLSHOT";
      g_LastEngine          = ENG_KILLSHOT;
      int mbi = EngineIndexFromName("MONSTER");
      if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
      CancelOtherEnginePendingOrders("MONSTER_");
      PrintFormat("[KILLSHOT] dir=%s lots=%.4f SL=%.0f TP=%.0f boost=%.2f",
                  DirStr(dir), lots, slDist / _Point, tpDist / _Point, sizeBoost);
     }
   return ok;
  }

//===================================================================
// SECTION 96 — MONSTER ENGINE
//===================================================================
bool Monster_IgnitionCheck(int &outDir)
  {
   outDir = 0;

   if(UseCUSUM && g_CUSUMDir != 0 &&
      TimeCurrent() <= g_CUSUMOverrideUntil &&
      VNShockEligible(g_CUSUMDir))
     {
      int d = g_CUSUMDir;
      double s = VNSMC_StructureScore(d, "MONSTER");
      double expStr = 0.0;
      int expDir = 0;
      bool explosive = IsExplosiveBar(expDir, expStr);
      if(s >= SMC_MinMonsterScore || (explosive && expDir == d))
        {
         outDir = d;
         g_LastModelEngine = "MONSTER_SHOCK";
         g_LastSignalConfidence = MathMax(g_LastSignalConfidence, 0.66);
         return true;
        }
     }

   int expDir = 0; double expStr = 0.0;
   bool explosive = IsExplosiveBar(expDir, expStr);
   double atrRatio = (NormalATR1 > 0.0) ? CurrentATR1 / NormalATR1 : 1.0;

   if((explosive || atrRatio >= 1.45) && expDir != 0)
     {
      bool pa = (expDir ==  1)
                ? (M1PA_BullDisp || M1PA_BullMSS || M1PA_BullSweep || M1PA_BullFVG)
                : (M1PA_BearDisp || M1PA_BearMSS || M1PA_BearSweep || M1PA_BearFVG);
      if(pa)
        {
         double smc = VNSMC_StructureScore(expDir, "MONSTER");
         bool catalyst = VNSMC_TrendBreak(expDir) ||
                         VNFlowCascade(expDir) || VNFlowTradeRateSurge() ||
                         VNFlowCVDAccelerationStrong(expDir) ||
                         smc >= SMC_MinMonsterScore || atrRatio >= 1.80;
         if(catalyst)
           {
            outDir = expDir;
            g_LastSignalConfidence = MathMax(g_LastSignalConfidence,
                                             Clamp(0.50 + MathMin(0.35, expStr / 180.0), 0.50, 0.90));
            g_LastModelEngine = (atrRatio >= 1.80 ? "MONSTER_EXPANSION" : "MONSTER_KILLSHOT");
            return true;
           }
        }
     }

   int trendDir = 0;
   if(M15Direction != 0 && M5Direction == M15Direction) trendDir = M15Direction;
   else if(g_SMC.m15_bias != 0 && g_SMC.m5_bias == g_SMC.m15_bias) trendDir = g_SMC.m15_bias;
   else if(g_MTF_confidence >= 0.55 && g_LastModelDir != 0) trendDir = g_LastModelDir;
   if(trendDir == 0) return false;

   bool trigger = (trendDir ==  1)
                  ? (M1BullDisplacement() || M1BullMSS() || M1BullFVG() || g_SMC.m1_event ==  1)
                  : (M1BearDisplacement() || M1BearMSS() || M1BearFVG() || g_SMC.m1_event == -1);
   if(!trigger) return false;

   double smcScore = VNSMC_StructureScore(trendDir, "MONSTER");
   if(smcScore < SMC_MinMonsterScore && g_MTF_confidence < 0.55) return false;
   if(!Flow_NotOpposed(trendDir)) return false;

   outDir = trendDir;
   g_LastModelEngine = "MONSTER_TREND";
   g_LastSignalConfidence = MathMax(g_LastSignalConfidence,
                                    Clamp(0.50 + 0.45 * smcScore, 0.50, 0.92));
   return true;
  }

void Monster_Ignite(int dir)
  {
   double atr = CurrentATR5;
   if(atr <= 0.0) return;

   double slDist = ComputeSLDistance("MONSTER");
   if(g_LastModelEngine == "MONSTER_SHOCK") slDist *= 0.80;
   slDist = MathMax(slDist, StopsLevelPrice() * 2.0);
   double tpDist = slDist * TP_RR_Monster;

   double lots = CalcLots("MONSTER", dir, slDist);
   if(lots <= 0.0) return;
   if(!EntryAllowed("MONSTER", lots, dir)) return;

   if(UseBiasedStraddle)
     {
      bool jerk    = IsStraddleJerkContext();
      bool extreme = IsStraddleExtremeContext();
      if(PlaceBiasedStraddle("MONSTER", dir, jerk, extreme))
        {
         g_MonsterPhase        = MP_ACCELERATION;
         g_MonsterStart        = TimeCurrent();
         g_MonsterDir          = dir;
         g_MonsterPyramidCount = 0;
         g_MonsterPeakR        = 0.0;
         g_LastPyramidAt       = TimeCurrent();
         g_LastPlaceTime       = TimeCurrent();
         g_LastEntryDir        = dir;
         g_LastEntryTime       = TimeCurrent();
         g_LastEngine          = ENG_MONSTER;
         int mbi = EngineIndexFromName("MONSTER");
         if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
         CancelOtherEnginePendingOrders("MONSTER_");
         PrintFormat("[MONSTER IGN STRADDLE] %s dir=%s",
                     g_LastModelEngine, DirStr(dir));
         return;
        }
     }

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return;
   double entry = (dir == 1) ? ask : bid;
   double stop  = (dir == 1) ? entry - slDist : entry + slDist;
   double take  = (dir == 1) ? entry + tpDist : entry - tpDist;

   string mode = (g_LastModelEngine == "" ? "MONSTER" : g_LastModelEngine);
   string cmt = "MONSTER_IGN_" + (dir == 1 ? "B" : "S");

   bool ok = SendMarketV2(
      (dir == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
      lots,
      NormalizeDouble(stop, _Digits),
      NormalizeDouble(take, _Digits),
      cmt);

   if(ok)
     {
      g_MonsterPhase        = MP_ACCELERATION;
      g_MonsterStart        = TimeCurrent();
      g_MonsterDir          = dir;
      g_MonsterPyramidCount = 0;
      g_MonsterPeakR        = 0.0;
      g_LastPyramidAt       = TimeCurrent();
      g_LastPlaceTime       = TimeCurrent();
      g_LastEntryDir        = dir;
      g_LastEntryTime       = TimeCurrent();
      g_LastEngine          = ENG_MONSTER;
      int mbi = EngineIndexFromName("MONSTER");
      if(mbi >= 0) BasketInitialRiskUSD[mbi] = CalculateBasketRiskUSD("MONSTER_");
      CancelOtherEnginePendingOrders("MONSTER_");
      PrintFormat("[MONSTER IGN] %s dir=%s lots=%.4f SL=%.0f TP=%.0f",
                  mode, DirStr(dir), lots, slDist / _Point, tpDist / _Point);
     }
  }

bool Monster_Pyramid()
  {
   if(g_MonsterDir == 0) return false;
   if(g_MonsterPyramidCount >= Monster_MaxPyramid) return false;
   if(g_LastSignalConfidence < 0.55) return false;
   if(!MsgBudget_CanTrade()) return false;

   double atr = CurrentATR5;
   if(atr <= 0.0) return false;
   double slDist = ComputeSLDistance("MONSTER");
   double tpDist = slDist * TP_RR_Monster;

   double lots = ValidateLot(CalcLots("MONSTER", g_MonsterDir, slDist) * 0.65);
   if(lots <= 0.0) return false;
   if(TotalOurLots() + lots > CapTotalLots() + 1e-12) return false;

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return false;
   double entry = (g_MonsterDir == 1) ? ask : bid;
   double stop  = (g_MonsterDir == 1) ? entry - slDist : entry + slDist;
   double take  = (g_MonsterDir == 1) ? entry + tpDist : entry - tpDist;

   string cmt = "MONSTER_PYR" + IntegerToString(g_MonsterPyramidCount + 1);
   bool ok = SendMarketV2(
      (g_MonsterDir == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
      lots,
      NormalizeDouble(stop, _Digits),
      NormalizeDouble(take, _Digits),
      cmt);

   if(ok)
     {
      g_LastPlaceTime = TimeCurrent();
      PrintFormat("[MONSTER PYR] level=%d dir=%d lots=%.4f",
                  g_MonsterPyramidCount + 1, g_MonsterDir, lots);
     }
   return ok;
  }

void Monster_HarvestStart()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
      if(StringFind(posInfo.Comment(), "MONSTER_") < 0) continue;
      double vol = posInfo.Volume();
      double cv = NormalizeLots(vol * (double)Monster_HarvestClosePct / 100.0);
      if(cv <= 0.0 || cv >= vol || cv < g_LotMin) continue;
      if(trade.PositionClosePartial(posInfo.Ticket(), cv))
         MsgBudget_TickModify();
     }
   PrintFormat("[MONSTER HARVEST] partial %d%% peak=%.2fR",
               Monster_HarvestClosePct, g_MonsterPeakR);
  }

void Monster_Manage()
  {
   if(g_MonsterPhase == MP_IDLE) return;
   int posCount = CountEnginePositions("MONSTER_");
   int ordCount = CountEngineOrders("MONSTER_");
   if(posCount == 0 && ordCount == 0)
     {
      PrintFormat("[MONSTER] cycle end phase=%d peak=%.2fR",
                  (int)g_MonsterPhase, g_MonsterPeakR);
      g_MonsterPhase = MP_IDLE;
      g_MonsterDir = 0;
      g_MonsterPyramidCount = 0;
      g_MonsterPeakR = 0.0;
      g_LastModelEngine = "";
      return;
     }

   int mbi = EngineIndexFromName("MONSTER");
   double basketRisk = (mbi >= 0) ? BasketInitialRiskUSD[mbi] : 0.0;
   double pnl = PrefixFloatingPnL("MONSTER_");
   double monsterR = (basketRisk > 0.0) ? pnl / basketRisk : 0.0;
   if(monsterR > g_MonsterPeakR) g_MonsterPeakR = monsterR;

   if(!UseUnifiedExitManagerV2 && g_MonsterDir != 0 && VNSMC_TrendBreak(-g_MonsterDir) &&
      g_R7 != R7_EXPANSION && !VNFlowTradeRateSurge() && monsterR > 0.0)
     {
      PrintFormat("[MONSTER THESIS EXIT] R=%.2f", monsterR);
      CloseEnginePositions("MONSTER_");
      g_MonsterPhase = MP_IDLE;
      return;
     }

   if(g_MonsterPhase == MP_ACCELERATION)
     {
      if(g_MonsterPyramidCount < Monster_MaxPyramid &&
         TimeCurrent() - g_LastPyramidAt >= Monster_PyramidCooldownS &&
         monsterR >= Monster_PyramidMinR)
        {
         bool momentum = (g_R7 == R7_EXPANSION ||
                          g_R7 == (g_MonsterDir == 1 ? R7_STRONG_UP : R7_STRONG_DOWN) ||
                          VNFlowCVDAccelerationStrong(g_MonsterDir) ||
                          VNFlowTradeRateSurge());
         if(momentum && Monster_Pyramid())
           {
            g_MonsterPyramidCount++;
            g_LastPyramidAt = TimeCurrent();
           }
        }

      if(monsterR >= Monster_HarvestMinR)
        {
         g_MonsterPhase = MP_HARVEST;
         Monster_HarvestStart();
        }
     }

   if(g_MonsterPhase == MP_HARVEST)
     {
      double giveback = g_MonsterPeakR - monsterR;
      if(!UseUnifiedExitManagerV2 && monsterR > 0.0 && giveback >= Monster_TrailGivebackR)
        {
         PrintFormat("[MONSTER TRAIL] peak=%.2fR now=%.2fR", g_MonsterPeakR, monsterR);
         CloseEnginePositions("MONSTER_");
         g_MonsterPhase = MP_IDLE;
        }
     }
  }

bool Monster_Run()
  {
   if(!Regime_AllowsEngine("MONSTER") &&
      !(g_R7 == R7_WEAK_UP || g_R7 == R7_WEAK_DOWN)) return false;
   if(!EngineBudgetOK("MONSTER"))   return false;
   if(!EngineCooldownOK("MONSTER")) return false;

   if(g_MonsterPhase == MP_IDLE &&
      CountEnginePositions("MONSTER_") == 0 &&
      CountEngineOrders("MONSTER_") == 0)
     {
      int dir = 0;
      if(Monster_IgnitionCheck(dir))
        {
         if(!RegimeGateAllows(dir, "MONSTER"))
           {
            Print("[MONSTER BLOCK] regime gate");
            return false;
           }

         double est = ComputeSLDistance("MONSTER");
         double estLots = CalcLots("MONSTER", dir, est);
         if(estLots > 0.0 && HardGatesPass("MONSTER", dir) &&
            EntryAllowed("MONSTER", estLots, dir))
           {
            Monster_Ignite(dir);
            Monster_Manage();
            return CountEnginePositions("MONSTER_") > 0 ||
                   CountEngineOrders("MONSTER_") > 0;
           }
        }
     }
   Monster_Manage();
   return false;
  }

//===================================================================
// SECTION 97 — SWING ENGINE
//===================================================================
bool Swing_ComputeStructureTarget(int dir, double &outTP)
  {
   outTP = 0.0;
   double price = MidPrice();
   if(price <= 0.0) return false;
   double best = 0.0;

   if(BridgeReady() && gBinAux.naked_above > 0.0 && gBinAux.naked_below > 0.0)
     {
      if(dir ==  1 && gBinAux.naked_above > price) best = gBinAux.naked_above;
      if(dir == -1 && gBinAux.naked_below > 0.0 && gBinAux.naked_below < price)
         best = gBinAux.naked_below;
     }

   if(best == 0.0)
     {
      if(dir == 1)
        {
         for(int i = 0; i < BearOBCount; i++)
           {
            if(BearOBs[i].mitigated) continue;
            if(BearOBs[i].low > price)
               if(best == 0.0 || BearOBs[i].low < best) best = BearOBs[i].low;
           }
        }
      else
        {
         for(int i = 0; i < BullOBCount; i++)
           {
            if(BullOBs[i].mitigated) continue;
            if(BullOBs[i].high < price)
               if(best == 0.0 || BullOBs[i].high > best) best = BullOBs[i].high;
           }
        }
     }

   if(best == 0.0) return false;
   outTP = MathAbs(best - price);
   return (outTP > CurrentATR5 * 0.5);
  }

bool Swing_Run()
  {
   if(g_R7 == R7_CHOP || g_R7 == R7_COMPRESSION) return false;
   if(!Regime_AllowsEngine("SWING")) return false;
   if(!EngineBudgetOK("SWING"))      return false;
   if(!EngineCooldownOK("SWING"))    return false;
   if(CountEnginePositions("SWING_") > 0) return false;
   if(CountEngineOrders("SWING_") > 0)    return false;

   int dir = 0;
   if(M15Direction != 0 && M5Direction == M15Direction) dir = M15Direction;
   else if(g_SMC.m15_bias != 0 && g_SMC.m5_bias == g_SMC.m15_bias) dir = g_SMC.m15_bias;
   else if(Jerk_M5 != 0 && Jerk_M5 == M15Direction) dir = Jerk_M5;
   if(dir == 0) return false;

   if(!RegimeGateAllows(dir, "SWING"))
     {
      Print("[SWING BLOCK] regime gate");
      return false;
     }

   bool disp = (dir ==  1) ? M1BullDisplacement() : M1BearDisplacement();
   bool mss  = (dir ==  1) ? M1BullMSS()          : M1BearMSS();
   bool fvg  = (dir ==  1) ? M1BullFVG()          : M1BearFVG();
   bool structural = VNSMC_TrendBreak(dir) ||
                     (VNSMC_StructureScore(dir, "SWING") >= SMC_MinSwingScore);
   if(!disp && !mss && !fvg && !structural) return false;

   if(!HardGatesPass("SWING", dir)) return false;
   if(!M15VetoAllows(dir)) return false;
   if(!H1VetoAllows(dir))  return false;
   if(!Flow_Agrees(dir, false)) return false;

   double atr = CurrentATR5;
   if(atr <= 0.0) return false;
   double slDist = ComputeSLDistance("SWING");
   double tpDist = 0.0;
   bool structTarget = Swing_ComputeStructureTarget(dir, tpDist);
   if(!structTarget) tpDist = ComputeTPDistance("SWING", slDist);
   if(tpDist < slDist * 1.5) tpDist = slDist * 1.5;

   double lots = CalcLots("SWING", dir, slDist);
   if(lots <= 0.0) return false;
   if(!EntryAllowed("SWING", lots, dir)) return false;

   if(UseBiasedStraddle)
     {
      bool jerk    = IsStraddleJerkContext();
      bool extreme = IsStraddleExtremeContext();
      if(PlaceBiasedStraddle("SWING", dir, jerk, extreme))
        {
         g_LastEngine = ENG_TREND;
         CancelOtherEnginePendingOrders("SWING_");
         return true;
        }
     }

   double bid = BidPrice(), ask = AskPrice();
   if(bid <= 0.0 || ask <= 0.0) return false;

   double breakDist = atr * 0.15;
   double entry, stop, take;
   if(dir == 1)
     {
      entry = NormalizeDouble(ask + breakDist, _Digits);
      stop  = NormalizeDouble(entry - slDist, _Digits);
      take  = NormalizeDouble(entry + tpDist, _Digits);
     }
   else
     {
      entry = NormalizeDouble(bid - breakDist, _Digits);
      stop  = NormalizeDouble(entry + slDist, _Digits);
      take  = NormalizeDouble(entry - tpDist, _Digits);
     }

   string cmt = "SWING_" + (dir == 1 ? "B" : "S");
   bool ok = SendStopV2(dir == 1, entry, lots, stop, take, cmt);

   if(ok)
     {
      g_LastPlaceTime = TimeCurrent();
      g_LastEntryDir  = dir;
      g_LastEntryTime = TimeCurrent();
      g_LastEngine    = ENG_TREND;
      CancelOtherEnginePendingOrders("SWING_");
      PrintFormat("[SWING] %s lots=%.4f SL=%.0f TP=%.0f struct=%s",
                  DirStr(dir), lots, slDist / _Point, tpDist / _Point,
                  (structTarget ? "yes" : "fallback"));
     }
   return ok;
  }

//===================================================================
// SECTION 98 — RANGE ENGINE
//===================================================================
bool VNRangeExpansionInvalidated()
  {
   if(!ORangeAbortOnExpansion) return false;
   if(g_R7 == R7_EXPANSION || g_R7 == R7_COMPRESSION) return true;
   // Also protect the regime-sticky transition interval with direct evidence.
   double atrRatio=(NormalATR5>0.0 && CurrentATR5>0.0) ? CurrentATR5/NormalATR5 : 1.0;
   double m5Range=TfHigh(PERIOD_M5,1)-TfLow(PERIOD_M5,1);
   double m5RangeATR=(CurrentATR5>0.0 ? m5Range/CurrentATR5 : 1.0);
   if(atrRatio>=ExpansionATRRatio || m5RangeATR>=1.75) return true;
   if(g_CUSUMDir==1 && TimeCurrent()<=g_CUSUMOverrideUntil && M1BullDisplacement() && M1BullMSS()) return true;
   if(g_CUSUMDir==-1 && TimeCurrent()<=g_CUSUMOverrideUntil && M1BearDisplacement() && M1BearMSS()) return true;
   if(VNFlowTradeRateSurge()) return true;
   if(MathAbs(CVDAccelerationNormalized) >= 0.25 * 1.25) return true;
   return false;
  }

void VNCancelRangeOnBreak()
  {
   if(VNRangeExpansionInvalidated())
     {
      if(CountEngineOrders("RANGE_") > 0)
        {
         DeleteOrdersPrefix("RANGE_");
         Print("[RANGE -> MONSTER] mean-reversion invalidated; pending orders cancelled");
        }
     }
  }

//===================================================================
// BGBI PERFECT V3 — RANGE EDGE LIMIT ROUTER
//===================================================================
bool V3_RangeLimitRoute()
  {
   if(!V3EnableRangeLimitRoute || !g_V3ProfileMatch) return false;
   if(g_R7!=R7_CHOP) return false; // true range only; compression is handled by the paired OCO route
   if(VNRangeExpansionInvalidated()) return false;
   if(!EngineBudgetOK("RANGE") || !EngineCooldownOK("RANGE")) return false;
   if(CountOurPositions()>0 || CountPendingTotal()>0) return false; // one route/campaign per symbol
   if(g_LastRangePlace>0 && TimeCurrent()-g_LastRangePlace<Range_PendingLifetimeMin*60) return false;
   if(CurrentATR5<=0.0 || Bars(_Symbol,PERIOD_M5)<MathMax(12,V3RangeLookbackM5+3)) return false;

   int lookback=MathMax(6,MathMin(20,V3RangeLookbackM5));
   double hi=-1e100,lo=1e100;
   for(int i=1;i<=lookback;i++)
     {
      double h=TfHigh(PERIOD_M5,i), l=TfLow(PERIOD_M5,i);
      if(h<=0.0 || l<=0.0 || h<=l) return false;
      if(h>hi) hi=h;
      if(l<lo) lo=l;
     }
   double width=hi-lo, atr=CurrentATR5;
   if(width<atr*V3RangeMinWidthATR || width>atr*V3RangeMaxWidthATR) return false;
   double bid=BidPrice(),ask=AskPrice(),mid=MidPrice();
   if(bid<=0.0 || ask<bid || mid<=0.0) return false;
   double minDist=MathMax(StopsLevelPrice()*1.25,MathMax(SafeTrailBuffer(),(ask-bid)*1.5));
   double edge=Clamp(V3RangeEdgeFraction,0.08,0.25);
   double slBuf=MathMax(atr*V3RangeSLBufferATR,MathMax(StopsLevelPrice()*2.0,SafeTrailBuffer()*1.5));
   bool buySetup=(mid<=lo+width*edge*1.75) && (M1BullSweep() || M1BullMSS());
   bool sellSetup=(mid>=hi-width*edge*1.75) && (M1BearSweep() || M1BearMSS());
   if(!buySetup && !sellSetup) return false; // no edge setup, allow the higher-level router to assess other non-range routes
   if(buySetup && sellSetup)
     { PrintFormat("[V3 RANGE WAIT] symbol=%s simultaneous opposite edge evidence; no range order",_Symbol); return true; }

   int dir=buySetup?1:-1;
   double entry=buySetup ? lo+width*edge : hi-width*edge;
   entry=NormalizeDouble(entry,_Digits);
   if(buySetup && entry>=bid-minDist)
     { PrintFormat("[V3 RANGE WAIT] symbol=%s BUY limit too close to current price; entry=%.5f bid=%.5f minDist=%.5f",_Symbol,entry,bid,minDist); return true; }
   if(sellSetup && entry<=ask+minDist)
     { PrintFormat("[V3 RANGE WAIT] symbol=%s SELL limit too close to current price; entry=%.5f ask=%.5f minDist=%.5f",_Symbol,entry,ask,minDist); return true; }
   double sl=buySetup ? NormalizeDouble(lo-slBuf,_Digits) : NormalizeDouble(hi+slBuf,_Digits);
   double target=buySetup ? lo+width*0.66 : hi-width*0.66;
   double tp=NormalizeDouble(target,_Digits);
   double risk=MathAbs(entry-sl), reward=MathAbs(tp-entry);
   double cost=MathMax(0.0,ask-bid);
   double netReward=reward-cost;
   if(risk<=0.0 || netReward/risk<V3RangeMinRewardRisk)
     { PrintFormat("[V3 RANGE WAIT] symbol=%s target room after spread too small: risk=%.5f grossReward=%.5f netReward=%.5f",_Symbol,risk,reward,netReward); return true; }
   if(buySetup && (sl>=entry || tp<=entry || tp>=hi))
     { PrintFormat("[V3 RANGE WAIT] symbol=%s invalid BUY structure geometry",_Symbol); return true; }
   if(sellSetup && (sl<=entry || tp>=entry || tp<=lo))
     { PrintFormat("[V3 RANGE WAIT] symbol=%s invalid SELL structure geometry",_Symbol); return true; }
   if(!HardGatesPass("RANGE",dir) || !M15VetoAllows(dir) || !H1VetoAllows(dir))
     { PrintFormat("[V3 RANGE WAIT] symbol=%s route-specific hard/MTF gate blocked dir=%s",_Symbol,DirStr(dir)); return true; }
   if(!SpreadOK() || !SessionAllowed() || !HourFilterOK() || WickPauseActive())
     { PrintFormat("[V3 RANGE WAIT] symbol=%s spread/session/wick gate blocked",_Symbol); return true; }
   int breakoutDir = buySetup ? -1 : 1;
   bool breakoutIsBuy = (breakoutDir==1);
   double breakoutEntry=0.0,breakoutSL=0.0,breakoutTP=0.0,breakoutRisk=0.0,breakoutReward=0.0,breakoutNetReward=0.0;
   double breakoutBuffer=MathMax(atr*MathMax(0.05,V3RangeBreakoutBufferATR),
                                 MathMax(StopsLevelPrice()*2.0,MathMax((ask-bid)*2.0,SafeTrailBuffer()*1.5)));
   if(V3EnableRangeBreakoutContingency)
     {
      // At the lower edge: BUY LIMIT for a bounce + SELL STOP below the floor.
      // At the upper edge: SELL LIMIT for a rejection + BUY STOP above the ceiling.
      // First fill cancels all remaining same-symbol siblings (software OCO).
      if(buySetup)
        {
         breakoutEntry=NormalizeDouble(lo-breakoutBuffer,_Digits);
         breakoutSL=NormalizeDouble(breakoutEntry+slBuf,_Digits);
        }
      else
        {
         breakoutEntry=NormalizeDouble(hi+breakoutBuffer,_Digits);
         breakoutSL=NormalizeDouble(breakoutEntry-slBuf,_Digits);
        }
      breakoutRisk=MathAbs(breakoutEntry-breakoutSL);
      double minRR=MathMax(1.25,V3RangeMinRewardRisk);
      breakoutReward=MathMax(width*0.80,breakoutRisk*(minRR+0.20)+(ask-bid)*1.5);
      breakoutNetReward=breakoutReward-MathMax(0.0,ask-bid);
      breakoutTP=NormalizeDouble(breakoutIsBuy ? breakoutEntry+breakoutReward : breakoutEntry-breakoutReward,_Digits);
      if(breakoutRisk<=0.0 || breakoutNetReward/breakoutRisk<V3RangeMinRewardRisk ||
         (breakoutIsBuy && (breakoutEntry<=ask || breakoutSL>=breakoutEntry || breakoutTP<=breakoutEntry)) ||
         (!breakoutIsBuy && (breakoutEntry>=bid || breakoutSL<=breakoutEntry || breakoutTP>=breakoutEntry)))
        { PrintFormat("[V3.5 RANGE WAIT] invalid breakout geometry symbol=%s dir=%s entry=%.5f SL=%.5f TP=%.5f",_Symbol,DirStr(breakoutDir),breakoutEntry,breakoutSL,breakoutTP); return true; }
     }

   double rawLimitLots=CalcLots("RANGE",dir,risk);
   double lots=rawLimitLots;
   double breakoutLots=0.0;
   if(V3EnableRangeBreakoutContingency)
     {
      double limitShare=Clamp(V3RangePairRiskShare,0.10,0.90);
      lots=NormalizeLots(rawLimitLots*limitShare);
      double rawBreakLots=CalcLots("RANGE",breakoutDir,breakoutRisk);
      breakoutLots=NormalizeLots(rawBreakLots*(1.0-limitShare));
      if(lots<=0.0 || breakoutLots<=0.0)
        { PrintFormat("[V3.5 RANGE WAIT] paired risk share is below broker minimum; limitLots=%.4f breakoutLots=%.4f",lots,breakoutLots); return true; }
     }
   if(lots<=0.0 || !EntryAllowed("RANGE",lots+(V3EnableRangeBreakoutContingency?breakoutLots:0.0),dir))
     { PrintFormat("[V3.5 RANGE WAIT] sizing/entry governor blocked dir=%s",DirStr(dir)); return true; }

   string cmt=buySetup ? "RANGE_V3_BUYLIMIT" : "RANGE_V3_SELLLIMIT";
   bool sentLimit=SendLimitV2(buySetup,entry,lots,sl,tp,cmt);
   if(!sentLimit)
     { PrintFormat("[V3.5 RANGE PAIR REJECTED] range LIMIT failed symbol=%s dir=%s; no breakout leg armed",_Symbol,DirStr(dir)); return true; }

   bool sentBreakout=true;
   if(V3EnableRangeBreakoutContingency)
     {
      string breakComment=breakoutIsBuy ? "RANGE_V3_BREAKOUT_BUYSTOP" : "RANGE_V3_BREAKOUT_SELLSTOP";
      sentBreakout=SendStopV2(breakoutIsBuy,breakoutEntry,breakoutLots,breakoutSL,breakoutTP,breakComment);
      if(!sentBreakout)
        {
         // The range pair is all-or-none: never leave a lone LIMIT after its contingency STOP failed.
         DeleteOrdersPrefix("RANGE_V3_");
         PrintFormat("[V3.5 RANGE PAIR ROLLBACK] symbol=%s companion STOP failed; removed partial pending batch",_Symbol);
         return true;
        }
     }

   g_LastRangePlace=TimeCurrent(); g_LastPlaceTime=TimeCurrent(); g_LastEntryDir=dir; g_LastEntryTime=TimeCurrent(); g_LastEngine=ENG_RANGE;
   PrintFormat("[V3.5 RANGE HYBRID ARMED] symbol=%s edgeDir=%s LIMIT=%.5f SL=%.5f TP=%.5f lots=%.4f breakoutDir=%s STOP=%.5f SL=%.5f TP=%.5f lots=%.4f widthATR=%.2f RRlimit=%.2f RRbreak=%.2f",
               _Symbol,DirStr(dir),entry,sl,tp,lots,DirStr(breakoutDir),breakoutEntry,breakoutSL,breakoutTP,
               (V3EnableRangeBreakoutContingency?breakoutLots:0.0),width/atr,netReward/risk,
               (V3EnableRangeBreakoutContingency?breakoutNetReward/breakoutRisk:0.0));
   return true; // route owns both the edge LIMIT and breakout STOP until fill, cancellation, or expiry
  }

void V3_MaintainRangeLimits()
  {
   if(!V3EnableRangeLimitRoute) return;
   bool invalid=(g_R7!=R7_CHOP || VNRangeExpansionInvalidated());
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      string c=ordInfo.Comment();
      if(StringFind(c,"RANGE_V3_")!=0) continue;
      bool expired=(Range_PendingLifetimeMin>0 && TimeCurrent()-ordInfo.TimeSetup()>=Range_PendingLifetimeMin*60);
      if(!invalid && !expired) continue;
      ulong ticket=ordInfo.Ticket();
      if(trade.OrderDelete(ticket))
        { MsgBudget_TickDelete(); PrintFormat("[V3.4 RANGE CAMPAIGN CLEANUP] symbol=%s ticket=%I64u invalid=%d expired=%d",_Symbol,ticket,(int)invalid,(int)expired); }
      else PrintFormat("[V3.4 RANGE CAMPAIGN CLEANUP FAIL] symbol=%s ticket=%I64u ret=%u %s",_Symbol,ticket,trade.ResultRetcode(),trade.ResultRetcodeDescription());
     }
  }

bool Range_Run()
  {
   VNCancelRangeOnBreak();
   if(V3EnableRangeLimitRoute) return false; // V3 range path is pending LIMIT only; no market fallback from this engine

   if(g_R7 != R7_CHOP && g_R7 != R7_WEAK_UP && g_R7 != R7_WEAK_DOWN)
      return false;
   if(!EngineBudgetOK("RANGE"))   return false;
   if(!EngineCooldownOK("RANGE")) return false;
   if(CountEnginePositions("RANGE_") > 0) return false;
   if(CountEngineOrders("RANGE_") > 0)    return false;
   if(CountOurPositions() > 0) return false;

   if(g_LastRangePlace > 0 &&
      TimeCurrent() - g_LastRangePlace < Range_PendingLifetimeMin * 60) return false;

   double rHigh = -1e18, rLow = 1e18;
   for(int i = 1; i <= Range_WindowBars; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      if(h > rHigh) rHigh = h;
      if(l < rLow)  rLow  = l;
     }
   if(rHigh <= 0.0 || rLow <= 0.0 || rHigh <= rLow) return false;

   double atr = CurrentATR1;
   if(atr <= 0.0) return false;
   double width = rHigh - rLow;
   if(width < atr * Range_MinWidthATR) return false;
   if(width > atr * Range_MaxWidthATR) return false;

   if(!VNComputeOU()) return false;
   double z = g_OU.z;
   int dir = 0;
   if(z <= -OUMinAbsZ) dir = 1;
   else if(z >= OUMinAbsZ) dir = -1;
   else return false;

   if(!VNOUAllowsRange(dir)) return false;

   if(UseSMCStructure)
     {
      double oppScore = VNSMC_StructureScore(-dir, "RANGE");
      if(oppScore >= 0.72 && VNSMC_TrendBreak(-dir)) return false;
     }

   bool revTrigger = (dir ==  1)
                     ? (M1BullMSS() || M1BullSweep() || M1BullFVG())
                     : (M1BearMSS() || M1BearSweep() || M1BearFVG());
   if(!revTrigger) return false;

   if(g_MTF_confidence > MTFMaxRangeTrendConf) return false;
   if(g_OU.reversion_prob < OURangeMinProbability) return false;

   double slDist = MathMax(width * 0.90, MathMax(atr * 1.10, StopsLevelPrice() * 2.0));
   if(dir ==  1) slDist = MathMax(slDist, MidPrice() - rLow  + atr * 0.10);
   else          slDist = MathMax(slDist, rHigh - MidPrice() + atr * 0.10);

   double price = (dir == 1) ? AskPrice() : BidPrice();
   if(price <= 0.0) return false;

   double tpDist = MathAbs(g_OU.mu - price) * ORangeTargetFraction;
   double minTp = MathMax(StopsLevelPrice() * 2.0, atr * 0.60);
   if(tpDist < minTp) tpDist = minTp;

   if(!HardGatesPass("RANGE", dir)) return false;
   if(!M15VetoAllows(dir)) return false;
   if(!H1VetoAllows(dir))  return false;

   double lots = CalcLots("RANGE", dir, slDist);
   if(lots <= 0.0) return false;
   if(!EntryAllowed("RANGE", lots, dir)) return false;

   if(UseBiasedStraddle && MathAbs(z) >= OUMinAbsZ * 1.3)
     {
      if(PlaceBiasedStraddle("RANGE", dir, false, false))
        {
         g_LastRangePlace = TimeCurrent();
         g_LastPlaceTime  = TimeCurrent();
         g_LastEntryDir   = dir;
         g_LastEntryTime  = TimeCurrent();
         g_LastEngine     = ENG_RANGE;
         PrintFormat("[RANGE OU STRADDLE] dir=%s z=%.2f", DirStr(dir), z);
         return true;
        }
     }

   double stop = (dir == 1) ? price - slDist : price + slDist;
   double take = (dir == 1) ? price + tpDist : price - tpDist;

   string cmt = "RANGE_" + (dir == 1 ? "B" : "S");
   bool ok = SendMarketV2((dir == 1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
                          lots,
                          NormalizeDouble(stop, _Digits),
                          NormalizeDouble(take, _Digits),
                          cmt);

   if(ok)
     {
      g_LastRangePlace = TimeCurrent();
      g_LastPlaceTime  = TimeCurrent();
      g_LastEntryDir   = dir;
      g_LastEntryTime  = TimeCurrent();
      g_LastEngine     = ENG_RANGE;
      PrintFormat("[RANGE OU] %s lots=%.4f z=%.2f theta=%.4f prob=%.2f",
                  DirStr(dir), lots, z, g_OU.theta, g_OU.reversion_prob);
     }
   return ok;
  }

//===================================================================
// SECTION 99 — FACTOR B — HELPERS
//===================================================================
void FB_BuildVolumeProfile()
  {
   g_FB_VP.valid = false;
   int bins = MathMin(VP_Bins, 40);
   if(Bars(_Symbol, PERIOD_M1) < VP_LookbackBars + 10) return;

   double high = -1e18, low = 1e18;
   for(int i=0; i<VP_LookbackBars; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      if(h<=0 || l<=0) continue;
      if(h>high) high = h;
      if(l<low)  low  = l;
     }
   if(high<=low) return;

   g_FB_VP.minP = low;
   g_FB_VP.maxP = high;
   g_FB_VP.binSize = (high-low)/bins;
   for(int i=0; i<bins; i++) g_FB_VP.bins[i] = 0;
   g_FB_VP.totalVol = 0;

   for(int i=0; i<VP_LookbackBars; i++)
     {
      double h = TfHigh(PERIOD_M1, i);
      double l = TfLow(PERIOD_M1, i);
      double v = (double)TfVolume(PERIOD_M1, i);
      if(h<=l || v<=0) continue;
      double barRange = h-l;
      for(int b=0; b<bins; b++)
        {
         double binLo = g_FB_VP.minP + b*g_FB_VP.binSize;
         double binHi = binLo + g_FB_VP.binSize;
         double ovl = MathMin(h,binHi) - MathMax(l,binLo);
         if(ovl > 0) g_FB_VP.bins[b] += v * (ovl/barRange);
        }
     }

   double maxVol = 0; int pocIdx = 0;
   for(int i=0; i<bins; i++)
     {
      g_FB_VP.totalVol += g_FB_VP.bins[i];
      if(g_FB_VP.bins[i] > maxVol){ maxVol = g_FB_VP.bins[i]; pocIdx = i; }
     }
   if(g_FB_VP.totalVol <= 0) return;
   g_FB_VP.poc = g_FB_VP.minP + (pocIdx+0.5)*g_FB_VP.binSize;

   double target = g_FB_VP.totalVol * VP_ValueAreaPct / 100.0;
   int left = pocIdx, right = pocIdx;
   double cum = g_FB_VP.bins[pocIdx];
   while(cum < target && (left>0 || right<bins-1))
     {
      double lv = (left>0)       ? g_FB_VP.bins[left-1]  : -1;
      double rv = (right<bins-1) ? g_FB_VP.bins[right+1] : -1;
      if(rv >= lv && right<bins-1){ right++; cum += g_FB_VP.bins[right]; }
      else if(left>0)             { left--;  cum += g_FB_VP.bins[left]; }
      else break;
     }
   g_FB_VP.val = g_FB_VP.minP + left*g_FB_VP.binSize;
   g_FB_VP.vah = g_FB_VP.minP + (right+1)*g_FB_VP.binSize;
   if(g_FB_VP.poc > 0) g_FB_VP.vaWidthPct = (g_FB_VP.vah - g_FB_VP.val) / g_FB_VP.poc * 100.0;
   else g_FB_VP.vaWidthPct = 100.0;
   g_FB_VP.valid = true;
  }

bool FB_PriceInVA()
  {
   if(!g_FB_VP.valid) return false;
   double m = MidPrice();
   return (m >= g_FB_VP.val && m <= g_FB_VP.vah);
  }

bool FB_VACompressed()
  {
   if(!g_FB_VP.valid) return false;
   return (g_FB_VP.vaWidthPct < VP_CompressMaxPct);
  }

void FB_UpdateVROC()
  {
   double avgVol = 0; int c = 0;
   for(int i=2; i<22; i++)
     {
      double v = (double)TfVolume(PERIOD_M1, i);
      if(v>0){ avgVol += v; c++; }
     }
   if(c>0) avgVol /= c;
   double curVol = (double)TfVolume(PERIOD_M1, 0) + (double)TfVolume(PERIOD_M1, 1);
   g_FB_VROC = (avgVol > 0) ? curVol / (avgVol * 2.0) : 0;

   double rng = TfHigh(PERIOD_M1, 0) - TfLow(PERIOD_M1, 0);
   double atr = CurrentATR1;
   g_FB_RangeExp = (atr > 0) ? rng/atr : 0;
  }

void FB_UpdateSessionVWAP()
  {
   MqlDateTime dt; TimeToStruct(TimeCurrent(), dt);
   int mins = dt.hour*60 + dt.min;
   if(mins < 5) return;
   int lookback = MathMin(mins, 1440);
   double pv=0, vol=0;
   for(int i=0; i<lookback; i++)
     {
      double h=TfHigh(PERIOD_M1,i), l=TfLow(PERIOD_M1,i), cl=TfClose(PERIOD_M1,i);
      double v=(double)TfVolume(PERIOD_M1,i);
      if(h<=0||l<=0||cl<=0||v<=0) continue;
      pv += ((h+l+cl)/3.0) * v;
      vol += v;
     }
   if(vol<=0) return;
   double vwap = pv/vol;

   double pv10=0, vol10=0;
   for(int i=10; i<lookback+10 && i<1440; i++)
     {
      double h=TfHigh(PERIOD_M1,i), l=TfLow(PERIOD_M1,i), cl=TfClose(PERIOD_M1,i);
      double v=(double)TfVolume(PERIOD_M1,i);
      if(h<=0||l<=0||cl<=0||v<=0) continue;
      pv10 += ((h+l+cl)/3.0) * v;
      vol10 += v;
     }
   double vwapOld = (vol10>0) ? pv10/vol10 : vwap;
   g_FB_VWAP = vwap;
   g_FB_VWAPSlope = (vwap - vwapOld) / (10.0 * _Point);
  }

int FB_DetectMSS_Event()
  {
   int bars = Bars(_Symbol, PERIOD_M15);
   if(bars < FB_MSS_LeftBars + FB_MSS_RightBars + 5) return 0;

   int searchDepth = MathMin(100, bars - FB_MSS_LeftBars - FB_MSS_RightBars - 1);
   double pivH=0, pivL=0;
   datetime pivHt=0, pivLt=0;

   for(int i = FB_MSS_RightBars; i < searchDepth; i++)
     {
      double h = TfHigh(PERIOD_M15, i);
      if(h > 0 && pivH == 0)
        {
         bool ok = true;
         for(int j=1; j<=FB_MSS_LeftBars; j++)
            if(TfHigh(PERIOD_M15,i+j) >= h){ ok=false; break; }
         if(ok) for(int j=1; j<=FB_MSS_RightBars; j++)
            if(TfHigh(PERIOD_M15,i-j) >= h){ ok=false; break; }
         if(ok){ pivH = h; pivHt = TfTime(PERIOD_M15,i); }
        }
      double l = TfLow(PERIOD_M15, i);
      if(l > 0 && pivL == 0)
        {
         bool ok = true;
         for(int j=1; j<=FB_MSS_LeftBars; j++)
            if(TfLow(PERIOD_M15,i+j) <= l){ ok=false; break; }
         if(ok) for(int j=1; j<=FB_MSS_RightBars; j++)
            if(TfLow(PERIOD_M15,i-j) <= l){ ok=false; break; }
         if(ok){ pivL = l; pivLt = TfTime(PERIOD_M15,i); }
        }
      if(pivH > 0 && pivL > 0) break;
     }

   if(pivH > 0 && pivHt > g_FB_MSS_LastHighTime) { g_FB_MSS_LastHigh = pivH; g_FB_MSS_LastHighTime = pivHt; }
   if(pivL > 0 && pivLt > g_FB_MSS_LastLowTime)  { g_FB_MSS_LastLow  = pivL; g_FB_MSS_LastLowTime  = pivLt; }

   double close = TfClose(PERIOD_M15, 1);
   if(close <= 0) return 0;

   int dir = 0;
   if(g_FB_MSS_LastHigh>0 && close>g_FB_MSS_LastHigh && g_FB_MSS_LastDir!=1)  dir = 1;
   else if(g_FB_MSS_LastLow>0 && close<g_FB_MSS_LastLow && g_FB_MSS_LastDir!=-1) dir = -1;

   if(dir != 0)
     {
      g_FB_MSS_LastDir = dir;
      g_FB_MSS_LastEventDir = dir;
      g_FB_MSS_LastEventTime = TimeCurrent();
     }
   return dir;
  }

bool FB_MSSFresh(int dir)
  {
   if(g_FB_MSS_LastEventDir != dir || g_FB_MSS_LastEventTime == 0) return false;
   return (TimeCurrent() - g_FB_MSS_LastEventTime <= FB_MSS_ConfirmWindowMin*60);
  }

void FB_StoreBullOB(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FB_OB_MaxStored, 8);
   if(g_FB_BullOBCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) g_FB_BullOB[i]=g_FB_BullOB[i-1]; g_FB_BullOBCount=maxKeep-1; }
   else
     { for(int i=g_FB_BullOBCount;i>0;i--) g_FB_BullOB[i]=g_FB_BullOB[i-1]; }
   g_FB_BullOB[0].high=high; g_FB_BullOB[0].low=low;
   g_FB_BullOB[0].avg=(high+low)/2.0;
   g_FB_BullOB[0].dir=1; g_FB_BullOB[0].t=t; g_FB_BullOB[0].mitigated=false;
   g_FB_BullOBCount++;
  }

void FB_StoreBearOB(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FB_OB_MaxStored, 8);
   if(g_FB_BearOBCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) g_FB_BearOB[i]=g_FB_BearOB[i-1]; g_FB_BearOBCount=maxKeep-1; }
   else
     { for(int i=g_FB_BearOBCount;i>0;i--) g_FB_BearOB[i]=g_FB_BearOB[i-1]; }
   g_FB_BearOB[0].high=high; g_FB_BearOB[0].low=low;
   g_FB_BearOB[0].avg=(high+low)/2.0;
   g_FB_BearOB[0].dir=-1; g_FB_BearOB[0].t=t; g_FB_BearOB[0].mitigated=false;
   g_FB_BearOBCount++;
  }

void FB_ScanOB()
  {
   if(Bars(_Symbol, PERIOD_M15) < 20) return;
   int shift = 1;
   double obO = TfOpen(PERIOD_M15,shift);
   double obC = TfClose(PERIOD_M15,shift);
   double obH = TfHigh(PERIOD_M15,shift);
   double obL = TfLow(PERIOD_M15,shift);
   datetime obT = TfTime(PERIOD_M15,shift);
   if(obO<=0||obC<=0||obH<=0||obL<=0||obT==0) return;

   int up=0, dn=0;
   for(int i=2; i<=6; i++)
     {
      double o=TfOpen(PERIOD_M15,i), c=TfClose(PERIOD_M15,i);
      if(c>o) up++; else if(c<o) dn++;
     }
   if(obC<obO && up==5)
     {
      bool exists=false;
      for(int i=0;i<g_FB_BullOBCount;i++) if(g_FB_BullOB[i].t==obT){ exists=true; break; }
      if(!exists) FB_StoreBullOB(obO, obL, obT);
     }
   if(obC>obO && dn==5)
     {
      bool exists=false;
      for(int i=0;i<g_FB_BearOBCount;i++) if(g_FB_BearOB[i].t==obT){ exists=true; break; }
      if(!exists) FB_StoreBearOB(obH, obO, obT);
     }

   double current = TfClose(PERIOD_M15, 0);
   for(int i=0;i<g_FB_BullOBCount;i++)
      if(!g_FB_BullOB[i].mitigated && current<g_FB_BullOB[i].low) g_FB_BullOB[i].mitigated=true;
   for(int i=0;i<g_FB_BearOBCount;i++)
      if(!g_FB_BearOB[i].mitigated && current>g_FB_BearOB[i].high) g_FB_BearOB[i].mitigated=true;
  }

void FB_StoreBullFVG(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FB_FVG_MaxStored, 8);
   if(g_FB_BullFVGCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) g_FB_BullFVG[i]=g_FB_BullFVG[i-1]; g_FB_BullFVGCount=maxKeep-1; }
   else
     { for(int i=g_FB_BullFVGCount;i>0;i--) g_FB_BullFVG[i]=g_FB_BullFVG[i-1]; }
   g_FB_BullFVG[0].high=high; g_FB_BullFVG[0].low=low;
   g_FB_BullFVG[0].mid=(high+low)/2.0;
   g_FB_BullFVG[0].dir=1; g_FB_BullFVG[0].t=t; g_FB_BullFVG[0].mitigated=false;
   g_FB_BullFVGCount++;
  }

void FB_StoreBearFVG(double high, double low, datetime t)
  {
   int maxKeep = MathMin(FB_FVG_MaxStored, 8);
   if(g_FB_BearFVGCount >= maxKeep)
     { for(int i=maxKeep-1;i>0;i--) g_FB_BearFVG[i]=g_FB_BearFVG[i-1]; g_FB_BearFVGCount=maxKeep-1; }
   else
     { for(int i=g_FB_BearFVGCount;i>0;i--) g_FB_BearFVG[i]=g_FB_BearFVG[i-1]; }
   g_FB_BearFVG[0].high=high; g_FB_BearFVG[0].low=low;
   g_FB_BearFVG[0].mid=(high+low)/2.0;
   g_FB_BearFVG[0].dir=-1; g_FB_BearFVG[0].t=t; g_FB_BearFVG[0].mitigated=false;
   g_FB_BearFVGCount++;
  }

void FB_ScanFVG()
  {
   if(Bars(_Symbol, PERIOD_M5) < 20) return;
   double h1 = TfHigh(PERIOD_M5,1);
   double l1 = TfLow(PERIOD_M5,1);
   double h3 = TfHigh(PERIOD_M5,3);
   double l3 = TfLow(PERIOD_M5,3);
   double c2 = TfClose(PERIOD_M5,2);
   datetime t1 = TfTime(PERIOD_M5,1);
   if(h1<=0||l1<=0||h3<=0||l3<=0||c2<=0) return;

   if(l1 > h3 && c2 > h3 && ((l1-h3)/_Point) >= FB_FVG_MinSizePts)
     {
      bool exists=false;
      for(int i=0;i<g_FB_BullFVGCount;i++) if(g_FB_BullFVG[i].t==t1){ exists=true; break; }
      if(!exists) FB_StoreBullFVG(l1, h3, t1);
     }
   if(h1 < l3 && c2 < l3 && ((l3-h1)/_Point) >= FB_FVG_MinSizePts)
     {
      bool exists=false;
      for(int i=0;i<g_FB_BearFVGCount;i++) if(g_FB_BearFVG[i].t==t1){ exists=true; break; }
      if(!exists) FB_StoreBearFVG(l3, h1, t1);
     }

   double current = TfClose(PERIOD_M5, 0);
   for(int i=0;i<g_FB_BullFVGCount;i++)
      if(!g_FB_BullFVG[i].mitigated && current<g_FB_BullFVG[i].low) g_FB_BullFVG[i].mitigated=true;
   for(int i=0;i<g_FB_BearFVGCount;i++)
      if(!g_FB_BearFVG[i].mitigated && current>g_FB_BearFVG[i].high) g_FB_BearFVG[i].mitigated=true;
  }

bool FB_NearStoredZone(int dir, double distATR)
  {
   double price = MidPrice();
   if(price<=0 || CurrentATR1<=0) return false;

   if(dir > 0)
     {
      for(int i=0;i<g_FB_BullOBCount;i++)
        {
         if(g_FB_BullOB[i].mitigated) continue;
         double d = 0;
         if(price<g_FB_BullOB[i].low)       d = g_FB_BullOB[i].low - price;
         else if(price>g_FB_BullOB[i].high) d = price - g_FB_BullOB[i].high;
         if(d <= CurrentATR1*distATR) return true;
        }
      for(int i=0;i<g_FB_BullFVGCount;i++)
        {
         if(g_FB_BullFVG[i].mitigated) continue;
         double d = 0;
         if(price<g_FB_BullFVG[i].low)       d = g_FB_BullFVG[i].low - price;
         else if(price>g_FB_BullFVG[i].high) d = price - g_FB_BullFVG[i].high;
         if(d <= CurrentATR1*distATR) return true;
        }
     }
   else if(dir < 0)
     {
      for(int i=0;i<g_FB_BearOBCount;i++)
        {
         if(g_FB_BearOB[i].mitigated) continue;
         double d = 0;
         if(price<g_FB_BearOB[i].low)       d = g_FB_BearOB[i].low - price;
         else if(price>g_FB_BearOB[i].high) d = price - g_FB_BearOB[i].high;
         if(d <= CurrentATR1*distATR) return true;
        }
      for(int i=0;i<g_FB_BearFVGCount;i++)
        {
         if(g_FB_BearFVG[i].mitigated) continue;
         double d = 0;
         if(price<g_FB_BearFVG[i].low)       d = g_FB_BearFVG[i].low - price;
         else if(price>g_FB_BearFVG[i].high) d = price - g_FB_BearFVG[i].high;
         if(d <= CurrentATR1*distATR) return true;
        }
     }
   return false;
  }

int FB_FastDirection()
  {
   int dirV = 0;
   if(g_FB_VROC >= FB_VROC_TrendMin)
     {
      double o = TfOpen(PERIOD_M1, 0);
      double c = TfClose(PERIOD_M1, 0);
      if(o > 0 && c > 0)
        {
         if(c > o + 5*_Point) dirV = 1;
         if(c < o - 5*_Point) dirV = -1;
        }
     }
   int dirC = 0;
   if(FlowFresh())
     {
      if(CVDAccelerationNormalized > CVDAccelMin && CVDVelocityNormalized > 0) dirC = 1;
      if(CVDAccelerationNormalized < -CVDAccelMin && CVDVelocityNormalized < 0) dirC = -1;
     }
   int dirW = 0;
   if(g_FB_VWAPSlope >  FB_VWAP_SlopeMin) dirW = 1;
   if(g_FB_VWAPSlope < -FB_VWAP_SlopeMin) dirW = -1;

   if(MQLInfoInteger(MQL_TESTER))
     {
      if(dirV == 1  && dirW >= 0) return 1;
      if(dirV == -1 && dirW <= 0) return -1;
      return 0;
     }
   int votes = dirV + dirC + dirW;
   if(dirV == 1  && votes >= 1)  return 1;
   if(dirV == -1 && votes <= -1) return -1;
   return 0;
  }

double FB_NormalizeLots(double lots)
  {
   double mn=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double st=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   double mx=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   if(mn<=0) mn=0.01; if(st<=0) st=0.01; if(mx<=0) mx=100;
   if(mx>CapTotalLots_Max) mx = CapTotalLots_Max;
   int s = (int)MathFloor(lots/st + 1e-9);
   lots = NormalizeDouble(s*st, 2);
   if(lots<mn) return 0;
   if(lots>mx) lots = mx;
   return lots;
  }

//===================================================================
// SECTION 100 — FACTOR B — MODE + ENGINES
//===================================================================
int FB_DetectMode()
  {
   bool bSweep = M1BullSweep(), sSweep = M1BearSweep();
   bool bMSS   = M1BullMSS(),   sMSS   = M1BearMSS();
   bool bDisp  = M1BullDisplacement(), sDisp = M1BearDisplacement();

   if(bSweep && bMSS && bDisp) return 3;
   if(sSweep && sMSS && sDisp) return 3;

   if(g_FB_VROC >= FB_VROC_MonsterMin && g_FB_RangeExp >= FB_RE_MonsterMin) return 2;
   if(g_FB_VROC >= FB_VROC_TrendMin   && g_FB_RangeExp >= FB_RE_TrendMin)   return 1;

   if(g_FB_VP.valid && FB_PriceInVA()) return 0;

   if(!g_FB_VP.valid) return 1;
   return 1;
  }

void FB_ChopEngine()
  {
   if(CountEnginePositions("FB_CHOP_") > 0) return;
   if(TimeCurrent() - g_FB_LastClose[0] < 10*60) return;
   if(!g_FB_VP.valid) return;
   if(!FB_VACompressed()) return;

   double vaRange = g_FB_VP.vah - g_FB_VP.val;
   if(vaRange <= 0) return;
   double mid = MidPrice();
   double posInVA = (mid - g_FB_VP.val) / vaRange;
   bool nearLow  = (posInVA < 0.25);
   bool nearHigh = (posInVA > 0.75);
   if(!nearLow && !nearHigh) return;

   double slDist = FB_Chop_SL_Pts * _Point;
   double tpDist = FB_Chop_TP_Pts * _Point;
   //--- [S1] apply spread floor
   slDist = SafeSLDistance(slDist);
   tpDist = SafeTPDistance(tpDist, slDist);

   double buffer = CurrentSpreadPoints * 2 * _Point;
   double buyPrice  = NormalizeDouble(g_FB_VP.val + buffer, _Digits);
   double sellPrice = NormalizeDouble(g_FB_VP.vah - buffer, _Digits);

   if(buyPrice  >= AskPrice()) buyPrice  = NormalizeDouble(AskPrice()  - 20*_Point, _Digits);
   if(sellPrice <= BidPrice()) sellPrice = NormalizeDouble(BidPrice()  + 20*_Point, _Digits);

   double lot = FB_NormalizeLots(FB_Chop_Lot * SpreadThrottle());
   if(lot<=0) return;

   int placed = 0;
   double sl = NormalizeDouble(buyPrice - slDist, _Digits);
   double tp = NormalizeDouble(buyPrice + tpDist, _Digits);
   if(SendLimitV2(true, buyPrice, lot, sl, tp, "FB_CHOP_BL")) placed++;

   sl = NormalizeDouble(sellPrice + slDist, _Digits);
   tp = NormalizeDouble(sellPrice - tpDist, _Digits);
   if(SendLimitV2(false, sellPrice, lot, sl, tp, "FB_CHOP_SL")) placed++;

   if(placed > 0)
      PrintFormat("[FB CHOP] pos=%.2f width=%.3f placed=%d",
                  posInVA, g_FB_VP.vaWidthPct, placed);
  }

void FB_TrendEngine()
  {
   if(CountEnginePositions("FB_TREND_") > 0) return;
   if(TimeCurrent() - g_FB_LastClose[1] < 10*60) return;

   int dir = 0;
   if(g_FB_JerkM15 != 0) dir = g_FB_JerkM15;
   else if((dir = FB_FastDirection()) != 0) { }
   else if(g_FB_VWAPSlope >  FB_VWAP_SlopeMin) dir = 1;
   else if(g_FB_VWAPSlope < -FB_VWAP_SlopeMin) dir = -1;
   else return;

   if(dir ==  1 && g_FB_VWAPSlope < 0) return;
   if(dir == -1 && g_FB_VWAPSlope > 0) return;

   double slDist = FB_Trend_SL_Pts * _Point;
   double tpDist = FB_Trend_TP_Pts * _Point;
   slDist = SafeSLDistance(slDist);
   tpDist = SafeTPDistance(tpDist, slDist);
   double gapP = FB_Trend_Gap_Pts * _Point;

   double lot = FB_NormalizeLots(FB_Trend_Lot * SpreadThrottle());
   if(lot<=0) return;

   double bid = BidPrice(), ask = AskPrice();
   int placed = 0;
   int depth = MathMax(1, FB_TrendLadderDepth);

   if(dir == 1)
     {
      for(int i=0; i<depth; i++)
        {
         double p = NormalizeDouble(ask + gapP*(i+1), _Digits);
         double sl = NormalizeDouble(p - slDist, _Digits);
         double tp = NormalizeDouble(p + tpDist, _Digits);
         if(SendStopV2(true, p, lot, sl, tp, "FB_TREND_B"+IntegerToString(i))) placed++;
        }
     }
   else
     {
      for(int i=0; i<depth; i++)
        {
         double p = NormalizeDouble(bid - gapP*(i+1), _Digits);
         double sl = NormalizeDouble(p + slDist, _Digits);
         double tp = NormalizeDouble(p - tpDist, _Digits);
         if(SendStopV2(false, p, lot, sl, tp, "FB_TREND_S"+IntegerToString(i))) placed++;
        }
     }

   if(placed > 0)
      PrintFormat("[FB TREND] dir=%d placed=%d VROC=%.2f RE=%.2f",
                  dir, placed, g_FB_VROC, g_FB_RangeExp);
  }

void FB_MonsterEngine()
  {
   if(CountEnginePositions("FB_MON_") > 0) return;
   if(TimeCurrent() - g_FB_LastClose[2] < 20*60) return;

   int dir = FB_FastDirection();
   if(dir == 0 && g_FB_JerkM15 != 0) dir = g_FB_JerkM15;
   if(dir == 0) return;

   double slDist = FB_Monster_SL_Pts * _Point;
   double tpDist = FB_Monster_TP_Pts * _Point;
   slDist = SafeSLDistance(slDist);
   tpDist = SafeTPDistance(tpDist, slDist);
   double gapP = FB_Monster_Gap_Pts * _Point;

   double lot = FB_NormalizeLots(FB_Monster_Lot * SpreadThrottle());
   if(lot<=0) return;

   double bid = BidPrice(), ask = AskPrice();
   int placed = 0;
   int depth = MathMax(1, FB_MonsterLadderDepth);

   if(dir == 1)
     {
      for(int i=0; i<depth; i++)
        {
         double p = NormalizeDouble(ask + gapP*(i+1), _Digits);
         double sl = NormalizeDouble(p - slDist, _Digits);
         double tp = NormalizeDouble(p + tpDist, _Digits);
         if(SendStopV2(true, p, lot, sl, tp, "FB_MON_B"+IntegerToString(i))) placed++;
        }
     }
   else
     {
      for(int i=0; i<depth; i++)
        {
         double p = NormalizeDouble(bid - gapP*(i+1), _Digits);
         double sl = NormalizeDouble(p + slDist, _Digits);
         double tp = NormalizeDouble(p - tpDist, _Digits);
         if(SendStopV2(false, p, lot, sl, tp, "FB_MON_S"+IntegerToString(i))) placed++;
        }
     }

   if(placed > 0)
      PrintFormat("[FB MONSTER] dir=%d placed=%d VROC=%.2f", dir, placed, g_FB_VROC);
  }

void FB_ReversalEngine()
  {
   if(CountEnginePositions("FB_REV_") > 0) return;
   if(TimeCurrent() - g_FB_LastClose[3] < 15*60) return;

   bool bSweep = M1BullSweep(), sSweep = M1BearSweep();
   bool bMSS   = M1BullMSS(),   sMSS   = M1BearMSS();
   bool bDisp  = M1BullDisplacement(), sDisp = M1BearDisplacement();

   int dir = 0;
   if(bSweep && bMSS && bDisp) dir = 1;
   else if(sSweep && sMSS && sDisp) dir = -1;
   else return;

   if(FB_ReqM1Sweep       && !(dir== 1?bSweep:sSweep)) return;
   if(FB_ReqM1MSS         && !(dir== 1?bMSS:sMSS))     return;
   if(FB_ReqM1Displ       && !(dir== 1?bDisp:sDisp))   return;
   if(FB_ReqZoneProximity && !FB_NearStoredZone(dir, 1.50)) return;

   double slDist = FB_Reversal_SL_Pts * _Point;
   double tpDist = FB_Reversal_TP_Pts * _Point;
   slDist = SafeSLDistance(slDist);
   tpDist = SafeTPDistance(tpDist, slDist);

   double lot = FB_NormalizeLots(FB_Reversal_Lot * SpreadThrottle());
   if(lot<=0) return;

   double entry = (dir == 1) ? AskPrice() : BidPrice();
   double sl = (dir ==  1) ? entry - slDist : entry + slDist;
   double tp = (dir ==  1) ? entry + tpDist : entry - tpDist;
   sl = NormalizeDouble(sl, _Digits);
   tp = NormalizeDouble(tp, _Digits);

   bool ok = (dir == 1)
             ? SendMarketV2(ORDER_TYPE_BUY,  lot, sl, tp, "FB_REV_B")
             : SendMarketV2(ORDER_TYPE_SELL, lot, sl, tp, "FB_REV_S");

   if(ok)
      PrintFormat("[FB REVERSAL] dir=%d lots=%.2f SL=%.0f TP=%.0f",
                  dir, lot, slDist/_Point, tpDist/_Point);
  }

//===================================================================
// SECTION 101 — FACTOR B — BASKET MANAGEMENT
//===================================================================
double FB_BasketBE()
  {
   double base = (StartBalance > 0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   double pctTarget = base * FB_BasketBE_Pct / 100.0;
   //--- spread floor
   int posCount = MathMax(1, CountOurPositions());
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double spreadUSD = SpreadInPoints() * posCount * TotalOurLots() * tickValue;
   return MathMax(pctTarget, spreadUSD * SpreadMultiplier_Basket);
  }
double FB_BasketTrailUSD()
  {
   double base = (StartBalance > 0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   double pctTarget = base * FB_BasketTrail_Pct / 100.0;
   double be = FB_BasketBE();
   if(pctTarget < be * 1.5) pctTarget = be * 1.5;
   return pctTarget;
  }
double FB_BasketStepUSD()
  {
   double base = (StartBalance > 0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   double pctTarget = base * FB_BasketStep_Pct / 100.0;
   int posCount = MathMax(1, CountOurPositions());
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double spreadUSD = SpreadInPoints() * posCount * TotalOurLots() * tickValue;
   double spreadFloor = spreadUSD * SpreadMultiplier_Basket * 0.75;
   return MathMax(pctTarget, spreadFloor);
  }
double FB_BasketSL_USD()
  {
   double base = (StartBalance > 0) ? StartBalance : AccountInfoDouble(ACCOUNT_BALANCE);
   return -base * MathAbs(FB_BasketSL_Pct) / 100.0;
  }

void FB_BasketManage(string pfx, int idx, datetime &lastClose)
  {
   if(CountEnginePositions(pfx) <= 0)
     {
      g_FB_BE[idx] = false;
      g_FB_Trail[idx] = false;
      return;
     }
   double pnl = PrefixFloatingPnL(pfx);

   if(pnl <= FB_BasketSL_USD())
     {
      DeleteOrdersPrefix(pfx);
      CloseEnginePositions(pfx);
      lastClose = TimeCurrent();
      g_FB_BE[idx] = false;
      g_FB_Trail[idx] = false;
      PrintFormat("[FB BASKET SL] %s pnl=%.2f", pfx, pnl);
      return;
     }
   if(!g_FB_BE[idx] && pnl >= FB_BasketBE())
     {
      MovePrefixToBE(pfx);
      g_FB_BE[idx] = true;
      PrintFormat("[FB BASKET BE] %s pnl=%.2f", pfx, pnl);
     }
   if(!g_FB_Trail[idx] && pnl >= FB_BasketTrailUSD())
     {
      g_FB_Trail[idx] = true;
      g_FB_TrailHigh[idx] = pnl;
      g_FB_TrailSL[idx] = pnl - FB_BasketStepUSD();
     }
   if(g_FB_Trail[idx])
     {
      if(pnl > g_FB_TrailHigh[idx])
        {
         g_FB_TrailHigh[idx] = pnl;
         g_FB_TrailSL[idx] = pnl - FB_BasketStepUSD();
        }
      if(pnl <= g_FB_TrailSL[idx] && pnl > 0)
        {
         DeleteOrdersPrefix(pfx);
         CloseEnginePositions(pfx);
         lastClose = TimeCurrent();
         g_FB_Trail[idx] = false;
         PrintFormat("[FB BASKET TRAIL] %s pnl=%.2f", pfx, pnl);
        }
     }
  }

//===================================================================
// SECTION 102 — FACTOR B — MASTER DISPATCHER
//===================================================================
void RunFactorB()
  {
   //--- Block B if Factor A has open positions
   if(CountEnginePositions("SWING_")    > 0) return;
   if(CountEnginePositions("MONSTER_")  > 0) return;
   if(CountEnginePositions("RANGE_")    > 0) return;
   if(CountEnginePositions("REVERSAL_") > 0) return;
   if(CountEnginePositions("CHOP_")     > 0) return;

   if(CountOurPositions() >= 2) return;
   if(!MsgBudget_CanTrade()) return;

   //--- Per-bar refresh
   datetime cm15 = TfTime(PERIOD_M15, 0);
   if(cm15 > 0 && cm15 != g_FB_LastM15Time)
     {
      g_FB_LastM15Time = cm15;
      g_FB_JerkM15 = DetectM15Jerk();
      FB_DetectMSS_Event();
      FB_ScanOB();
     }
   datetime cm5 = TfTime(PERIOD_M5, 0);
   if(cm5 > 0 && cm5 != g_FB_LastM5Time)
     {
      g_FB_LastM5Time = cm5;
      FB_UpdateSessionVWAP();
      FB_ScanFVG();
      FB_BuildVolumeProfile();
     }
   datetime cm1 = TfTime(PERIOD_M1, 0);
   if(cm1 > 0 && cm1 != g_FB_LastM1Time)
     {
      g_FB_LastM1Time = cm1;
      FB_UpdateVROC();

      int newMode = FB_DetectMode();
      if(newMode != g_FB_Mode)
        {
         PrintFormat("[FB MODE] %d -> %d VROC=%.2f RE=%.2f VA=%.3f",
                     g_FB_Mode, newMode, g_FB_VROC, g_FB_RangeExp,
                     g_FB_VP.valid ? g_FB_VP.vaWidthPct : 0.0);
         g_FB_Mode = newMode;
        }
     }

   //--- Basket management runs every tick (or on timer)
   FB_BasketManage("FB_CHOP_",  0, g_FB_LastClose[0]);
   FB_BasketManage("FB_TREND_", 1, g_FB_LastClose[1]);
   FB_BasketManage("FB_MON_",   2, g_FB_LastClose[2]);
   FB_BasketManage("FB_REV_",   3, g_FB_LastClose[3]);

   //--- One entry per M1 bar
   static datetime lastExec = 0;
   if(cm1 == 0 || cm1 == lastExec) return;
   lastExec = cm1;

   if(g_FB_Mode == 0)      FB_ChopEngine();
   else if(g_FB_Mode == 1) FB_TrendEngine();
   else if(g_FB_Mode == 2) FB_MonsterEngine();
   else if(g_FB_Mode == 3) FB_ReversalEngine();
  }

//===================================================================
// V3.4 — SINGLE SYMBOL CAMPAIGN GUARANTEE
// One active position OR one pending campaign per symbol/magic. If an
// entry fills, all remaining pending siblings on that symbol are removed.
//===================================================================
void V3_CancelAllSymbolPendingOrders(string reason)
  {
   int removed=0;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      if(!ordInfo.SelectByIndex(i)) continue;
      if(ordInfo.Symbol()!=_Symbol || ordInfo.Magic()!=MagicNumber) continue;
      ulong ticket=ordInfo.Ticket();
      if(trade.OrderDelete(ticket))
        { MsgBudget_TickDelete(); removed++; }
      else
        PrintFormat("[V3.4 CAMPAIGN CLEANUP FAIL] reason=%s ticket=%I64u ret=%u %s",reason,ticket,trade.ResultRetcode(),trade.ResultRetcodeDescription());
     }
   if(removed>0) PrintFormat("[V3.4 CAMPAIGN CLEANUP] symbol=%s removed=%d reason=%s",_Symbol,removed,reason);
  }

bool V3_SymbolCampaignBusy()
  {
   int positions=CountOurPositions();
   int pending=CountPendingTotal();
   if(positions>0)
     {
      if(pending>0) V3_CancelAllSymbolPendingOrders("open position; cancel remaining siblings/other-engine orders");
      return true;
     }
   // An existing pending campaign owns the symbol; never let another engine
   // submit a separate route while that campaign is waiting to trigger.
   return (pending>0);
  }

// Let strong AI + technical agreement bypass a lagging CHOP label only when
// native expansion evidence exists. This is not a free-standing AI entry.
bool KronosChopEscapeAllows(int &dir)
  {
   dir=0;
   if(!KronosEnableChopEscapeV1 || KronosModeV1<=0) return false;
   if(!VNRangeExpansionInvalidated()) return false;
   if(CountOurPositions()>0 || CountPendingTotal()>0) return false;
   if(!KronosFreshTF(1) || !KronosFreshTF(5)) return false;
   int kd=g_Kronos.m1_dir;
   if(kd==0 || g_Kronos.m5_dir!=kd) return false;
   int m5Tech=M5Direction;
   if(m5Tech==0) m5Tech=g_SMC.m5_bias;
   if(m5Tech!=kd) return false;
   int m15Tech=M15Direction;
   if(m15Tech==0) m15Tech=g_SMC.m15_bias;
   if(m15Tech==-kd) return false;
   if(KronosFreshTF(15) && g_Kronos.m15_dir==-kd) return false;
   if(g_FastTrendDir!=0 && g_FastTrendDir!=kd) return false;
   dir=kd;
   return true;
  }

//===================================================================
// SECTION 103 — MASTER ENGINE DISPATCHER [A9 + FB2]
//===================================================================
void RunEngines()
  {
   g_KronosChopEscapeActive=false;
   g_KronosChopEscapeDir=0;
   if(!g_V3ProfileMatch) return;

   // V3.5: enforce campaign ownership before pause/daily/message-budget gates.
   // This also cleans leftover sibling orders when a position is already open,
   // even when new entries are paused or the account has halted for the day.
   if(V3_SymbolCampaignBusy()) return;

   if(TimeCurrent() < PauseUntil) return;
   if(DailyHalted || GlobalHalted) return;
   if(!MsgBudget_CanTrade()) return;

   //--- Base gates
   if(!SpreadOK()) return;
   if(!SessionAllowed()) return;
   if(!HourFilterOK()) return;
   if(WickPauseActive()) return;

   DetectMoveState();
   if(UseFastTrendScore) ComputeFastTrendScore();
   ApplyUSDHybridConfirmationV2();

   //--- Log factor switch
   LogFactorSwitchIfChanged();

   //================================================================
   // BGBI PERFECT V2: FACTOR B PRIMARY DECISION PATH
   // Factor A bridge data is supportive confirmation only; its health does not switch the brain.
   //================================================================
   if(!UseFactorBPrimaryDecisionV2 && g_ActiveFactor == FACTOR_B_FALLBACK)
     {
      RunFactorB(); // legacy compatibility only; disabled by the V2 preset
      return;
     }

   // A fully confirmed structure reversal may still trade as its own engine.
   if(Rev_Tick()) return;

   // Stable range regimes own the remaining entry route before generic market/shock engines.
   // This prevents a single M1 CUSUM spike from silently bypassing range LIMIT logic.
   if(V3EnableCompressionOCO && g_R7==R7_COMPRESSION &&
      (!UseFastTrendScore || g_FastTrendScore<FastTrend_ChopThreshold))
     {
      if(PlaceVWAPChopStraddle()) return;
      PrintFormat("[V3.4 ROUTE WAIT] neutral compression OCO did not pass preflight; symbol=%s regime=%s spread=%.1f",_Symbol,Regime7Name(g_R7),CurrentSpreadPoints);
      return; // no directional fallback while neutral compression owns this symbol
     }
   else if(UseVWAPChopStraddle && g_R7==R7_COMPRESSION && UseFastTrendScore && g_FastTrendScore<FastTrend_ChopThreshold)
     {
      if(PlaceVWAPChopStraddle()) return;
      return;
     }

   if(V3EnableRangeLimitRoute && g_R7==R7_CHOP)
     {
      if(V3_RangeLimitRoute()) return;
      int kronosEscapeDir=0;
      if(KronosChopEscapeAllows(kronosEscapeDir))
        {
         g_KronosChopEscapeActive=true;
         g_KronosChopEscapeDir=kronosEscapeDir;
         PrintFormat("[V3.5 KRONOS CHOP ESCAPE] symbol=%s dir=%s reason=expansion+M1/M5 forecast+M5 technical alignment",
                     _Symbol,DirStr(kronosEscapeDir));
         // Continue only into directional engines; EntryAllowed enforces the same direction.
        }
      else return; // No valid range campaign and no qualified continuation; wait safely.
     }

   // Internal technical confluence + other engines for directional/confirmed-expansion regimes.
   if(CUSUMShockRun()) return;
   if(KillShotFastPath()) return;

   if(Monster_Run()) return;
   if(Swing_Run()) return;
   if(Range_Run()) return;
  }

//===================================================================
// SECTION 104 — DIAGNOSTICS [A5: 60s DIAG-FULL]
//===================================================================
void PrintDiagnostics()
  {
   static datetime lastDiag = 0;
   if(TimeCurrent() - lastDiag < 600) return;
   lastDiag = TimeCurrent();

   PrintFormat("[DIAG] R7=%s conf=%.2f | FastTrend=%.0f dir=%d | Health=%d | "
               "Flow=%s comp=%.1f | Monster=%s Rev=%s | "
               "Pos S/M/R/V=%d/%d/%d/%d | Trades=%d W/L=%d/%d PF=%.2f | "
               "Msgs=%d/%d Grid=%d | Factor=%s",
               Regime7Name(g_R7), g_R7Confidence,
               g_FastTrendScore, g_FastTrendDir,
               (int)g_HealthState,
               FlowStateStr(), FlowComposite(),
               MonsterPhaseStr(), RevStateStr(),
               CountEnginePositions("SWING_"),
               CountEnginePositions("MONSTER_"),
               CountEnginePositions("RANGE_"),
               CountEnginePositions("REVERSAL_"),
               WinCount + LossCount, WinCount, LossCount,
               (TotalLossUSD > 0.0) ? TotalWinUSD / TotalLossUSD : 0.0,
               MsgBudget_GetCount(), MsgBudgetHardLimit,
               g_GridLevelV2,
               FactorStr(g_ActiveFactor));
  }

void PrintDiagFull()   // [A5] Every 60s full snapshot
  {
   static datetime lastDiagFull = 0;
   if(TimeCurrent() - lastDiagFull < 60) return;
   lastDiagFull = TimeCurrent();

   PrintFormat("[DIAG-FULL] StopsLevel=%.0f Spread=%.0f SLbuf=%.0f "
               "PendTotal=%d CHOP p/o=%d/%d SWING p/o=%d/%d MONSTER p/o=%d/%d REV p/o=%d/%d "
               "Health=%d(%s) R7=%s FastT=%.0f Flow=%s "
               "Msgs=%d/%d",
               StopsLevelPrice() / _Point,
               CurrentSpreadPoints,
               SafeTrailBuffer() / _Point,
               CountPendingTotal(),
               CountEnginePositions("CHOP_"),    CountEngineOrders("CHOP_"),
               CountEnginePositions("SWING_"),   CountEngineOrders("SWING_"),
               CountEnginePositions("MONSTER_"), CountEngineOrders("MONSTER_"),
               CountEnginePositions("REVERSAL_"),CountEngineOrders("REVERSAL_"),
               (int)g_HealthState, g_HealthReason,
               Regime7Name(g_R7),
               g_FastTrendScore,
               FlowStateStr(),
               MsgBudget_GetCount(), MsgBudgetHardLimit);
  }

//===================================================================
// SECTION 105 — CHART DISPLAY [C3]
//===================================================================
void UpdateDisplay()
  {
   if(!ShowDisplay) return;

   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double dayDD   = (DayStartEquity > 0.0)
                    ? (DayStartEquity - equity) / DayStartEquity * 100.0 : 0.0;
   double peakDD  = (PeakEquity > 0.0)
                    ? (PeakEquity - equity) / PeakEquity * 100.0 : 0.0;

   int totalTrades = WinCount + LossCount;
   double winRate = (totalTrades > 0) ? (double)WinCount / (double)totalTrades * 100.0 : 0.0;
   double pf = (TotalLossUSD > 0.0) ? TotalWinUSD / TotalLossUSD : 0.0;
   double net = TotalWinUSD - TotalLossUSD;

   string s = "";
   s += "════════════════════════════════════════════════\n";
   s += " BGBI-INTELLIGENT-PERFECT V3.4 ROUTE-REPAIR\n";
   s += " Factor B primary · Factor A confirmatory\n";
   s += "════════════════════════════════════════════════\n";
   s += StringFormat(" Account: %s  Currency: %s  Contract: %.2f\n",
                     AccountModeLabel(), g_AcctCurrency, g_ContractSize);
   s += StringFormat(" Symbol: %s  Magic: %d  Factor: %s\n",
                     _Symbol, MagicNumber, FactorStr(g_ActiveFactor));
   s += StringFormat(" Spread=%.0f pts  SL_buf=%.0f  Stops_lvl=%.0f\n",
                     CurrentSpreadPoints, SafeTrailBuffer() / _Point,
                     StopsLevelPrice() / _Point);
   s += StringFormat(" Msgs today: %d / %d %s\n",
                     MsgBudget_GetCount(), MsgBudgetHardLimit,
                     (MsgBudget_SoftThrottled() ? "[THROTTLED]" : ""));

   s += "─── L1 CONTEXT ───\n";
   s += StringFormat("  Regime: %s  conf=%.2f\n",
                     Regime7Name(g_R7), g_R7Confidence);
   s += StringFormat("  FastTrend: %.0f dir=%s\n",
                     g_FastTrendScore, DirStr(g_FastTrendDir));
   s += StringFormat("  Health: %s (%s)\n", HealthStr(), g_HealthReason);
   s += StringFormat("  Flow: %s  comp=%.1f\n", FlowStateStr(), FlowComposite());
   s += StringFormat("  USD ctx: %s %s score=%.1f riskMult=%.2f\n",g_USDHybridStateV2,g_USDHybridSymbolV2,g_USDHybridPairScoreV2,g_USDHybridRiskMultV2);

   s += "─── L4 DISPATCH ───\n";
   s += StringFormat("  Last engine: %s\n", EngineName(g_LastEngine));
   s += StringFormat("  CUSUM dir=%d  until=%s\n", g_CUSUMDir,
                     (TimeCurrent() <= g_CUSUMOverrideUntil ? "YES" : "no"));
   s += StringFormat("  Rev sentinel: %s dir=%d checks=%d\n",
                     RevStateStr(), g_RevDir, g_RevConfirmCount);
   s += StringFormat("  Grid=%d  Straddle=%d  FactorB mode=%s\n",
                     g_GridLevelV2, (int)g_StraddleActive,
                     FB_ModeName(g_FB_Mode));

   s += "─── ENGINES (Factor B primary core) ───\n";
   s += StringFormat("  SWING:    %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("SWING_"), CountEngineOrders("SWING_"),
                     PrefixFloatingPnL("SWING_"));
   s += StringFormat("  MONSTER:  %d pos / %d ord  $%+.2f [%s]\n",
                     CountEnginePositions("MONSTER_"), CountEngineOrders("MONSTER_"),
                     PrefixFloatingPnL("MONSTER_"), MonsterPhaseStr());
   s += StringFormat("  RANGE:    %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("RANGE_"), CountEngineOrders("RANGE_"),
                     PrefixFloatingPnL("RANGE_"));
   s += StringFormat("  REVERSAL: %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("REVERSAL_"), CountEngineOrders("REVERSAL_"),
                     PrefixFloatingPnL("REVERSAL_"));
   s += StringFormat("  CHOP:     %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("CHOP_"), CountEngineOrders("CHOP_"),
                     PrefixFloatingPnL("CHOP_"));

   s += "─── LEGACY FB positions (management only) ───\n";
   s += StringFormat("  FB_CHOP:   %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("FB_CHOP_"), CountEngineOrders("FB_CHOP_"),
                     PrefixFloatingPnL("FB_CHOP_"));
   s += StringFormat("  FB_TREND:  %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("FB_TREND_"), CountEngineOrders("FB_TREND_"),
                     PrefixFloatingPnL("FB_TREND_"));
   s += StringFormat("  FB_MON:    %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("FB_MON_"), CountEngineOrders("FB_MON_"),
                     PrefixFloatingPnL("FB_MON_"));
   s += StringFormat("  FB_REV:    %d pos / %d ord  $%+.2f\n",
                     CountEnginePositions("FB_REV_"), CountEngineOrders("FB_REV_"),
                     PrefixFloatingPnL("FB_REV_"));

   s += "─── SAFETY ───\n";
   s += StringFormat("  Daily DD=%.2f%%  Peak DD=%.2f%%\n", dayDD, peakDD);
   s += StringFormat("  ConsecLoss=%d/%d  Daily=%d  Global=%d\n",
                     ConsecutiveLosses, MaxConsecutiveLosses,
                     (int)DailyHalted, (int)GlobalHalted);
   s += StringFormat("  Positions=%d/2  Pend=%d/%d  Lots=%.2f/%.2f\n",
                     CountOurPositions(), CountPendingTotal(), MaxPendingTotal,
                     TotalOurLots(), CapTotalLots());

   s += "─── STATS ───\n";
   s += StringFormat("  Trades=%d W/L=%d/%d (%.1f%%) Net=$%+.2f PF=%.2f\n",
                     totalTrades, WinCount, LossCount, winRate, net, pf);
   s += StringFormat("  Balance=$%.2f  Equity=$%.2f\n", balance, equity);
   s += "════════════════════════════════════════════════\n";

   Comment(s);
  }

//===================================================================
// SECTION 106 — INITIALIZATION [C1, C2, B1]
//===================================================================
int OnInit()
  {
   RefreshLotMeta();
   DetectAccountType();       // [C1] detect cent vs dollar
   MsgBudget_Init();          // [B1] reset counter

   if(AccountMode == ACC_AUTO)
      g_ResolvedMode = IsCentAccount() ? ACC_CENT : ACC_DOLLAR;
   else
      g_ResolvedMode = AccountMode;

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(SlippagePoints);
   trade.SetTypeFillingBySymbol(_Symbol);
   trade.LogLevel(LOG_LEVEL_ERRORS);
   PrintFormat("[KRONOS INIT] mode=%d endpoint=%s poll=%ds chopEscape=%d testerReplay=not-enabled",KronosModeV1,KronosBaseURLV1,KronosPollSecondsV1,(int)KronosEnableChopEscapeV1);

   //--- Indicator handles
   hATR_M1   = iATR(_Symbol, PERIOD_M1,  ATR_Period);
   hATR_M5   = iATR(_Symbol, PERIOD_M5,  ATR_Period);
   hATR_M15  = iATR(_Symbol, PERIOD_M15, ATR_Period);

   hEMA10_M15 = iMA(_Symbol, PERIOD_M15, EMA_Fast_M15, 0, MODE_EMA, PRICE_CLOSE);
   hEMA20_M15 = iMA(_Symbol, PERIOD_M15, EMA_Slow_M15, 0, MODE_EMA, PRICE_CLOSE);
   hEMA50_M15 = iMA(_Symbol, PERIOD_M15, EMA_Base_M15, 0, MODE_EMA, PRICE_CLOSE);
   hRSI_M15   = iRSI(_Symbol, PERIOD_M15, RSI_Period_M15, PRICE_CLOSE);
   hADX_M15   = iADX(_Symbol, PERIOD_M15, ADX_Period_M15);
   hMACD_M15  = iMACD(_Symbol, PERIOD_M15, 12, 26, 9, PRICE_CLOSE);

   hEMA10_M5  = iMA(_Symbol, PERIOD_M5, 10, 0, MODE_EMA, PRICE_CLOSE);
   hEMA8_M5   = iMA(_Symbol, PERIOD_M5, EMA_Fast_M5, 0, MODE_EMA, PRICE_CLOSE);
   hEMA21_M5  = iMA(_Symbol, PERIOD_M5, EMA_Slow_M5, 0, MODE_EMA, PRICE_CLOSE);
   hEMA50_M5  = iMA(_Symbol, PERIOD_M5, EMA_Base_M5, 0, MODE_EMA, PRICE_CLOSE);
   hRSI_M5    = iRSI(_Symbol, PERIOD_M5, RSI_Period_M5, PRICE_CLOSE);
   hADX_M5    = iADX(_Symbol, PERIOD_M5, ADX_Period_M5);
   hMACD_M5   = iMACD(_Symbol, PERIOD_M5, 8, 17, 9, PRICE_CLOSE);
   hMom14_M5  = iMomentum(_Symbol, PERIOD_M5, 14, PRICE_CLOSE);

   hADX_M30   = iADX(_Symbol, PERIOD_M30, 14);
   hExitEMA5_M1  = iMA(_Symbol, PERIOD_M1, 5, 0, MODE_EMA, PRICE_CLOSE);
   hExitEMA13_M1 = iMA(_Symbol, PERIOD_M1, 13, 0, MODE_EMA, PRICE_CLOSE);

   if(hATR_M1    == INVALID_HANDLE || hATR_M5    == INVALID_HANDLE ||
      hATR_M15   == INVALID_HANDLE ||
      hEMA10_M15 == INVALID_HANDLE || hEMA20_M15 == INVALID_HANDLE ||
      hEMA50_M15 == INVALID_HANDLE || hRSI_M15   == INVALID_HANDLE ||
      hADX_M15   == INVALID_HANDLE || hMACD_M15  == INVALID_HANDLE ||
      hEMA10_M5  == INVALID_HANDLE || hEMA8_M5   == INVALID_HANDLE ||
      hEMA21_M5  == INVALID_HANDLE || hEMA50_M5  == INVALID_HANDLE ||
      hRSI_M5    == INVALID_HANDLE || hADX_M5    == INVALID_HANDLE ||
      hMACD_M5   == INVALID_HANDLE || hMom14_M5  == INVALID_HANDLE ||
      hADX_M30   == INVALID_HANDLE || hExitEMA5_M1 == INVALID_HANDLE ||
      hExitEMA13_M1 == INVALID_HANDLE)
     {
      Print("[INIT] Indicator handle creation failed.");
      return INIT_FAILED;
     }

   if(OB_MaxStored > 8 || FVG_MaxStored > 8)
     {
      Print("[INIT] OB_MaxStored/FVG_MaxStored must be <= 8.");
      return INIT_PARAMETERS_INCORRECT;
     }

   if(BotMode == "Live" && !MQLInfoInteger(MQL_TESTER))
     {
      string gv = "GOD_ULT_V21_START_" + IntegerToString(MagicNumber) + "_" + _Symbol;
      if(!GlobalVariableCheck(gv))
         GlobalVariableSet(gv, AccountInfoDouble(ACCOUNT_BALANCE));
      StartBalance = GlobalVariableGet(gv);
      if(StartBalance <= 0.0) StartBalance = AccountInfoDouble(ACCOUNT_BALANCE);
     }
   else
      StartBalance = AccountInfoDouble(ACCOUNT_BALANCE);

   DayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
   PeakEquity     = DayStartEquity;
   TodayStamp     = (int)(TimeCurrent() / 86400);
   g_V3ProfileMatch=V3_ProfileMatchesChart();
   V3_SyncAccountSafetyState();

   Health_Init();

   ArrayInitialize(SpreadHistory, 0.0);
   ArrayInitialize(FlowRateHistory, 0.0);
   ArrayInitialize(BasketInitialRiskUSD, 0.0);
   ArrayInitialize(g_HMMProb, 1.0 / 7.0);
   for(int i = 0; i < 40; i++) g_NVP.bins[i] = 0.0;
   for(int i = 0; i < 40; i++) g_FB_VP.bins[i] = 0.0;

   g_R7 = R7_CHOP;
   g_R7Since = TimeCurrent();
   g_BrokerMsgResetDay = (int)(TimeCurrent() / 86400);

   RefreshLegacyContext(true);
   UpdateSpread();
   CurrentATR1  = BufVal(hATR_M1,  0, 1);
   CurrentATR5  = BufVal(hATR_M5,  0, 1);
   CurrentATR15 = BufVal(hATR_M15, 0, 1);
   NormalATR1   = GetNormalATR1();
   NormalATR5   = GetNormalATR5();
   NormalATR15  = GetNormalATR15();

   BuildNativeVP();
   FB_BuildVolumeProfile();

   EventSetTimer(1);

   Print("════════════════════════════════════════════════════════");
   Print(" BGBI-INTELLIGENT-PERFECT V3.4 ROUTE-REPAIR — Factor B primary / Factor A confirmation");
   PrintFormat(" V3.4 profile=%s expectedCryptoPort=%d match=%d rangeLimit=%d rangeBreakout=%d compressionOCO=%d shockStop=%d fastTick=%d",
               V3ExpectedSymbolProfile,V3ExpectedCryptoPort,(int)g_V3ProfileMatch,(int)V3EnableRangeLimitRoute,(int)V3EnableRangeBreakoutContingency,(int)V3EnableCompressionOCO,(int)V3EnableShockBreakoutStop,(int)V3FastImpulseTickCheck);
   Print("════════════════════════════════════════════════════════");
   PrintFormat(" Account mode : %s (currency=%s)", AccountModeLabel(), g_AcctCurrency);
   PrintFormat(" Symbol       : %s   Magic: %d   Contract: %.4f",
               _Symbol, MagicNumber, g_ContractSize);
   PrintFormat(" Start balance: %.2f", StartBalance);
   PrintFormat(" Sizing       : %s  risk(%%): SW=%.2f MN=%.2f RG=%.2f RV=%.2f",
               (UsePercentRisk ? "% risk" : "fixed lot"),
               RiskPct_Swing, RiskPct_Monster, RiskPct_Range, RiskPct_Reversal);
   PrintFormat(" Tiers on     : RegimeGate=%d FastTrend=%d Straddle=%d GridV2=%d "
               "TightBE=%d DollarBasket=%d OrderCheck=%d Recovery=%d",
               (int)UseRegimeDirectionGate, (int)UseFastTrendScore,
               (int)UseBiasedStraddle, (int)UseWinGatedGrid,
               (int)UseTightBEV2, (int)UseBasketDollarMode,
               (int)UseOrderCheckBeforeSendV2, (int)UseRecoveryModeV2);
   PrintFormat(" Decision     : %s | Factor-A bridge=%s | UnifiedExit=%d RiskGov=%d ProfileOK=%d",
               (UseFactorBPrimaryDecisionV2 ? "FACTOR-B PRIMARY" : "legacy selector"),
               (UseBinanceFlow ? BinanceBaseURL : "disabled"),
               (int)UseUnifiedExitManagerV2,(int)UsePortfolioRiskGovernorV2,(int)g_V3ProfileMatch);
   PrintFormat(" MsgBudget    : hard=%d soft=%d", MsgBudgetHardLimit, MsgBudgetSoftLimit);
   PrintFormat(" Spread rules : SL=%.1fx TP=%.1fx Trail=%.1fx Basket=%.1fx",
               SpreadMultiplier_SL, SpreadMultiplier_TP,
               SpreadMultiplier_Trail, SpreadMultiplier_Basket);
   PrintFormat(" Bridge       : %s  mode=%d",
               (UseBinanceFlow ? BinanceBaseURL : "disabled"), (int)FlowMode);
   if(MQLInfoInteger(MQL_TESTER) && UseBinanceFlow)
      Print("[INIT] Tester detected: Factor B active, bridge disabled.");
   Print("════════════════════════════════════════════════════════");

   return INIT_SUCCEEDED;
  }

//===================================================================
// SECTION 107 — DEINITIALIZATION
//===================================================================
void OnDeinit(const int reason)
  {
   EventKillTimer();
   Comment("");

   if(hATR_M1    != INVALID_HANDLE) IndicatorRelease(hATR_M1);
   if(hATR_M5    != INVALID_HANDLE) IndicatorRelease(hATR_M5);
   if(hATR_M15   != INVALID_HANDLE) IndicatorRelease(hATR_M15);
   if(hEMA10_M15 != INVALID_HANDLE) IndicatorRelease(hEMA10_M15);
   if(hEMA20_M15 != INVALID_HANDLE) IndicatorRelease(hEMA20_M15);
   if(hEMA50_M15 != INVALID_HANDLE) IndicatorRelease(hEMA50_M15);
   if(hRSI_M15   != INVALID_HANDLE) IndicatorRelease(hRSI_M15);
   if(hADX_M15   != INVALID_HANDLE) IndicatorRelease(hADX_M15);
   if(hMACD_M15  != INVALID_HANDLE) IndicatorRelease(hMACD_M15);
   if(hEMA10_M5  != INVALID_HANDLE) IndicatorRelease(hEMA10_M5);
   if(hEMA8_M5   != INVALID_HANDLE) IndicatorRelease(hEMA8_M5);
   if(hEMA21_M5  != INVALID_HANDLE) IndicatorRelease(hEMA21_M5);
   if(hEMA50_M5  != INVALID_HANDLE) IndicatorRelease(hEMA50_M5);
   if(hRSI_M5    != INVALID_HANDLE) IndicatorRelease(hRSI_M5);
   if(hADX_M5    != INVALID_HANDLE) IndicatorRelease(hADX_M5);
   if(hMACD_M5   != INVALID_HANDLE) IndicatorRelease(hMACD_M5);
   if(hMom14_M5  != INVALID_HANDLE) IndicatorRelease(hMom14_M5);
   if(hADX_M30   != INVALID_HANDLE) IndicatorRelease(hADX_M30);
   if(hExitEMA5_M1 != INVALID_HANDLE) IndicatorRelease(hExitEMA5_M1);
   if(hExitEMA13_M1 != INVALID_HANDLE) IndicatorRelease(hExitEMA13_M1);

   PrintFormat("[DEINIT] reason=%d Trades=%d W/L=%d/%d Net=%.2f PF=%.2f Msgs=%d",
               reason, TradeCount, WinCount, LossCount,
               TotalWinUSD - TotalLossUSD,
               (TotalLossUSD > 0.0) ? TotalWinUSD / TotalLossUSD : 0.0,
               MsgBudget_GetCount());
  }

//===================================================================
// BGBI PERFECT V3 — DEBOUNCED INTRATICK IMPULSE PULSE
//===================================================================
void V3_FastImpulseTickPulse()
  {
   if(!V3FastImpulseTickCheck || !g_V3ProfileMatch) return;
   ulong nowMs=GetTickCount64();
   int interval=MathMax(100,V3FastImpulseCheckMs);
   if(g_V3LastFastPulseMs>0 && nowMs>=g_V3LastFastPulseMs && nowMs-g_V3LastFastPulseMs<(ulong)interval) return;
   g_V3LastFastPulseMs=nowMs;
   if(DailyHalted || GlobalHalted || TimeCurrent()<PauseUntil) return;
   if(!MsgBudget_CanTrade() || !SpreadOK() || !SessionAllowed() || !HourFilterOK() || WickPauseActive()) return;
   // CUSUM/KillShot use already-updated closed-bar structure and current quotes; senders/risk governor still own permission.
   if(CUSUMShockRun()) return;
   KillShotFastPath();
  }

//===================================================================
// SECTION 108 — TICK HANDLER [A5: 60s DIAG-FULL]
//===================================================================
void OnTick()
  {
   MsgBudget_Tick();          // [B1] day rollover
   PrintDiagFull();           // [A5] 60s snapshot

   UpdateSpread();

   CurrentATR1  = BufVal(hATR_M1,  0, 1);
   CurrentATR5  = BufVal(hATR_M5,  0, 1);
   CurrentATR15 = BufVal(hATR_M15, 0, 1);

   NormalATR1   = GetNormalATR1();
   NormalATR5   = GetNormalATR5();
   NormalATR15  = GetNormalATR15();

   UpdateWickProtection();
   UpdateLiquiditySessions();
   DailyResetIfNeeded();
   CheckSafety();

   //--- Every M1 bar
   datetime curM1 = TfTime(PERIOD_M1, 0);
   static datetime lastM1 = 0;

   if(curM1 > 0 && curM1 != lastM1)
     {
      lastM1 = curM1;

      RefreshLegacyContext();
      UpdateM1PA();
      ComputeInternalVWAPZ();
      VNSMC_Update();
      BuildNativeVP();

      ComputeAdaptiveRegimeMetrics();
      VNAdvancedMarketUpdate();

      Health_Evaluate();

      RunEngines();
     }

   V3_FastImpulseTickPulse();
   UpdateDisplay();
  }

//===================================================================
// SECTION 109 — TIMER
//===================================================================
void OnTimer()
  {
   HourlyHardReset();
   HourlyStraddleReset();
   DailyResetIfNeeded();
   MsgBudget_DailyReset();

   PollBinanceFlow();
   PollUSDHybridContextV2();
   PollBinanceVP();
   PollBinanceAux();
   PollBinanceVPIN();
   PollKronosForecast();

   UpdateSpread();

   CurrentATR1  = BufVal(hATR_M1,  0, 1);
   CurrentATR5  = BufVal(hATR_M5,  0, 1);
   CurrentATR15 = BufVal(hATR_M15, 0, 1);
   NormalATR1   = GetNormalATR1();
   NormalATR5   = GetNormalATR5();
   NormalATR15  = GetNormalATR15();

   UpdateWickProtection();
   UpdateLiquiditySessions();
   CheckSafety();
   CancelStalePendingOrders();
   V3_MaintainRangeLimits();

   //--- Position management (Factor B primary; exit manager independent of Factor A)
   ManagePositions();
   ManageAllTightExits();
   ManageStalePositions();
   CheckWickAbort();
   CheckFlowFlipExit();
   WallGuardExit();
   ManageReversalPartial();
   CheckMonsterThesisExit();

   //--- Legacy basket stop managers are disabled when V2 owns per-ticket exits.
   if(!UseUnifiedExitManagerV2)
     {
      ManageBasket("SWING",    SwingBE,   SwingTrail,   SwingTrailHigh,   SwingTrailSL);
      ManageBasket("MONSTER",  MonsterBE, MonsterTrail, MonsterTrailHigh, MonsterTrailSL);
      ManageBasket("RANGE",    RangeBE,   RangeTrail,   RangeTrailHigh,   RangeTrailSL);
      ManageBasket("REVERSAL", ReversalBE,ReversalTrail,ReversalTrailHigh,ReversalTrailSL);
     }

   //--- Basket management (Factor B)
   if(UseFactorBFallback)
     {
      FB_BasketManage("FB_CHOP_",  0, g_FB_LastClose[0]);
      FB_BasketManage("FB_TREND_", 1, g_FB_LastClose[1]);
      FB_BasketManage("FB_MON_",   2, g_FB_LastClose[2]);
      FB_BasketManage("FB_REV_",   3, g_FB_LastClose[3]);
     }

   CheckFloatingBudgets();
   ResetMonsterIfIdle();
   ResetRevIfStale();

   TryGridAddV2();

   static datetime lastV2RiskDiag=0;
   if(TimeCurrent()-lastV2RiskDiag>=60)
     {
      lastV2RiskDiag=TimeCurrent();
      if(UsePortfolioRiskGovernorV2)
         PrintFormat("[V2 RISK STATE] symbol=%s symbolRisk=%.2f/%.2f accountRisk=%.2f/%.2f positions=%d pending=%d FactorB=PRIMARY FactorA=%s",
                     _Symbol,V2_CurrentRiskMoney(true),AccountInfoDouble(ACCOUNT_EQUITY)*MaxSymbolCampaignRiskPctV2/100.0,
                     V2_CurrentRiskMoney(false),AccountInfoDouble(ACCOUNT_EQUITY)*MaxPortfolioRiskPctV2/100.0,
                     V2_CountAccountPositions(),V2_CountAccountPendingOrders(),
                     (!UseBinanceFlow?"OFF":(!FlowFresh()?"STALE/UNAVAILABLE":"FRESH CONFIRMATION")));
     }
   UpdateDisplay();
   PrintDiagnostics();
  }

//===================================================================
// SECTION 110 — TRADE TRANSACTION
//===================================================================
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest     &request,
                        const MqlTradeResult      &result)
  {
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD) return;
   ulong deal = trans.deal;
   if(deal == 0) return;
   if(!HistoryDealSelect(deal)) return;

   long   magic  = HistoryDealGetInteger(deal, DEAL_MAGIC);
   string symbol = HistoryDealGetString (deal, DEAL_SYMBOL);
   if(magic != MagicNumber || symbol != _Symbol) return;

   long   entry = HistoryDealGetInteger(deal, DEAL_ENTRY);
   long   dtype = HistoryDealGetInteger(deal, DEAL_TYPE);
   string cmt   = HistoryDealGetString (deal, DEAL_COMMENT);

   //--- ENTRY SIDE
   if(entry == DEAL_ENTRY_IN)
     {
      TradeCount++;
      int filledDir = (dtype == DEAL_TYPE_BUY) ? 1 : (dtype == DEAL_TYPE_SELL ? -1 : 0);

      //--- V3.2 software OCO / campaign sibling cancellation.
      // A confirmed entry deal means this pending ticket is already filled;
      // cancel every remaining same-symbol sibling regardless of whether the
      // terminal has exposed the new position to PositionsTotal() yet.
      V3_CancelAllSymbolPendingOrders("entry fill; single-campaign software OCO");
      if(StringFind(cmt, "RANGE_")    >= 0) CancelOtherEnginePendingOrders("RANGE_");
      if(StringFind(cmt, "SWING_")    >= 0) CancelOtherEnginePendingOrders("SWING_");
      if(StringFind(cmt, "MONSTER_")  >= 0) CancelOtherEnginePendingOrders("MONSTER_");
      if(StringFind(cmt, "REVERSAL_") >= 0) CancelOtherEnginePendingOrders("REVERSAL_");
      if(StringFind(cmt, "CHOP_")     >= 0) DeleteOrdersPrefix("CHOP_");
      if(StringFind(cmt, "FB_CHOP_")  >= 0) DeleteOrdersPrefix("FB_CHOP_");
      if(StringFind(cmt, "FB_TREND_") >= 0) DeleteOrdersPrefix("FB_TREND_");
      if(StringFind(cmt, "FB_MON_")   >= 0) DeleteOrdersPrefix("FB_MON_");
      if(StringFind(cmt, "FB_REV_")   >= 0) DeleteOrdersPrefix("FB_REV_");

      if(filledDir != 0)
        {
         g_LastEntryDir  = filledDir;
         g_LastEntryTime = TimeCurrent();
        }

      //--- Tier 3: SL/TP re-anchor after fill, then store initial risk immediately.
      if(UseSlippageReAnchorV2 && trans.position > 0)
         ReAnchorStopsAfterFill(trans.position, cmt);
      if(trans.position>0) V3_InitializePositionState(trans.position);

      return;
     }

   //--- EXIT SIDE
   if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_OUT_BY) return;

   long positionId = HistoryDealGetInteger(deal, DEAL_POSITION_ID);

   bool stillOpen = false;
   if(trans.position > 0)
      stillOpen = PositionSelectByTicket(trans.position);

   if(!stillOpen && positionId > 0)
     {
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         if(!posInfo.SelectByIndex(i)) continue;
         if(posInfo.Symbol() != _Symbol || posInfo.Magic() != MagicNumber) continue;
         long pid = PositionGetInteger(POSITION_IDENTIFIER);
         if(pid == positionId) { stillOpen = true; break; }
        }
     }
   if(stillOpen) return;

   // Clean the V2 per-ticket protection state after final close (global variables survive EA restart).
   if(trans.position > 0)
     {
      GlobalVariableDel(V2_PositionStateKey(trans.position,"R"));
      GlobalVariableDel(V2_PositionStateKey(trans.position,"RM"));
      GlobalVariableDel(V2_PositionStateKey(trans.position,"PK"));
      GlobalVariableDel(V2_PositionStateKey(trans.position,"NP"));
      GlobalVariableDel(V2_PositionStateKey(trans.position,"RT"));
     }

   //--- Sum P&L across all closing deals
   double profit = 0.0;
   if(positionId > 0 && HistorySelectByPosition(positionId))
     {
      int total = HistoryDealsTotal();
      for(int i = 0; i < total; i++)
        {
         ulong cd = HistoryDealGetTicket(i);
         if(cd == 0) continue;
         long   cm = HistoryDealGetInteger(cd, DEAL_MAGIC);
         string cs = HistoryDealGetString (cd, DEAL_SYMBOL);
         long   ce = HistoryDealGetInteger(cd, DEAL_ENTRY);
         if(cm != MagicNumber || cs != _Symbol) continue;
         if(ce != DEAL_ENTRY_OUT && ce != DEAL_ENTRY_OUT_BY) continue;
         profit += HistoryDealGetDouble(cd, DEAL_PROFIT)
                 + HistoryDealGetDouble(cd, DEAL_SWAP)
                 + HistoryDealGetDouble(cd, DEAL_COMMISSION);
        }
     }
   else
     {
      profit = HistoryDealGetDouble(deal, DEAL_PROFIT)
             + HistoryDealGetDouble(deal, DEAL_SWAP)
             + HistoryDealGetDouble(deal, DEAL_COMMISSION);
     }

   int engIdx = EngineIndexFromComment(cmt);

   if(profit > 0.0)
     {
      WinCount++;
      ConsecutiveWins++;
      ConsecutiveLosses = 0;
      LastWinTime = TimeCurrent();
      g_LastWasWin = true;
      TotalWinUSD += profit;
      if(engIdx >= 0)
        {
         string engName = (engIdx == 0 ? "SWING" :
                           engIdx == 1 ? "MONSTER" :
                           engIdx == 2 ? "RANGE" : "REVERSAL");
         RecordEngineWin(engName);
         g_EnginePnLToday[engIdx] += profit;
        }
      Recovery_RegisterWin();
     }
   else if(profit < 0.0)
     {
      LossCount++;
      ConsecutiveLosses++;
      ConsecutiveWins = 0;
      LastLossTime = TimeCurrent();
      g_LastWasWin = false;
      TotalLossUSD += MathAbs(profit);
      if(engIdx >= 0)
        {
         string engName = (engIdx == 0 ? "SWING" :
                           engIdx == 1 ? "MONSTER" :
                           engIdx == 2 ? "RANGE" : "REVERSAL");
         RecordEngineLoss(engName);
         g_EnginePnLToday[engIdx] += profit;
        }
      Recovery_RegisterLoss(profit);
     }

   if(StringFind(cmt, "REVERSAL_") >= 0) ReversalPartial = false;

   PrintFormat("[DEAL OUT] pos=%I64d pnl=%.2f W/L=%d/%d streak=%d grid=%d msgs=%d",
               positionId, profit, WinCount, LossCount,
               ConsecutiveLosses, g_GridLevelV2, MsgBudget_GetCount());
  }

//+------------------------------------------------------------------+
//| END OF FILE — BGBI-INTELLIGENT-PERFECT V2                       |
//| Factor A (bridge-fed) + Factor B (V106A fallback)                |
//+------------------------------------------------------------------+